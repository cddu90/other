package com.bsc.qa.web.pages;


import java.util.Map;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindAll;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;

import com.bsc.qa.framework.base.BasePage;
import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;

import WebUtils.WebUtils;

public class ServicingFacilityProviderInformationPage extends BasePage {

	public WebUtils webUtils = new WebUtils();

	@FindAll({ @FindBy(how = How.XPATH, using = "//a[contains(text(),'Add Servicing/Facility Provider')]") })
	public WebElement selectServicingProvider;
	@FindAll({ @FindBy(how = How.XPATH, using = "//*[@id='MEDICAL_SERVICING_PROVIDER_DIV']/div[2]/div/div/div[1]/ul/li[1]/a") })
	public WebElement servicingProvider;
	
	@FindAll({ @FindBy(how = How.XPATH, using = "//input[@id='MEDICAL_SEARCH_SP_ORGANIZATION']") })
	public WebElement organisation;
	
	@FindAll({ @FindBy(how = How.XPATH, using = "//input[@id='MEDICAL_SEARCH_SP_STATE']") })
	public WebElement state;
	
	@FindAll({ @FindBy(how = How.XPATH, using = "//select[@id='MEDICAL_SEARCH_SP_PROVIDER_TYPE_2']") })
	public WebElement requestType;
	

//	@FindAll({ @FindBy(how = How.XPATH, using = "//*[@id='PROVIDER_SEARCH_BTN_FORM']/div[3]/div[1]/div/div[1]/ins") })
	@FindAll({ @FindBy(how = How.XPATH, using = "//div/input[@id='MEDICAL_SEARCH_SP_PAR_PROVIDER_0']/following-sibling::ins") })
	public WebElement parRadio;

//	@FindAll({ @FindBy(how = How.XPATH, using = "//*[@id='PROVIDER_SEARCH_BTN_FORM']/div[3]/div[1]/div/div[2]/ins") })
	@FindAll({ @FindBy(how = How.XPATH, using = "//div/input[@id='MEDICAL_SEARCH_SP_PAR_PROVIDER_1']/following-sibling::ins") })
	public WebElement parRadio1;

	@FindAll({ @FindBy(how = How.XPATH, using = "//label[text()='Participating:']//following-sibling::div//div[2]") })
	public WebElement parRadio2;
	
	@FindAll({ @FindBy(how = How.XPATH, using = "//*[@id='medical_search_servicing_provider_check_type_href_id']/span") })
	public WebElement search;
	
	@FindAll({ @FindBy(how = How.XPATH, using = "//*[@id='MEDICAL_SEARCH_SERVICING_PROVIDER_GRID']/tr[1]/td[1]/a/span") })
	public WebElement selectProvider;
	

	//@FindAll({ @FindBy(how = How.XPATH, using = "//*[@id='SERVICING_FACILITY_PROVIDER_FAX_NUMBER_DIV']/div/div/div[2]/div[2]/a") })
	//public WebElement save;
	////div[@class='modal-footer']//a[@class='btn btn-default'][contains(text(),'Save')]
	
	@FindAll({ @FindBy(how = How.XPATH, using = "//div[@class='modal-footer']/a[@class='btn btn-default'][contains(text(),'Save')]") })
	public WebElement save;
	@FindAll({ @FindBy(how = How.XPATH, using = "//input[@id='MEDICAL_SEARCH_SP_PROVIDER_ID']") })
	public WebElement providerID;
	
	@FindAll({ @FindBy(how = How.XPATH, using = "//input[@id='SERVICING_FACILITY_PROVIDER_FAX_NUMBER']") })
	public WebElement FaxNumb;
	public void enterDetailsInServecingFacilityPage(Map<String, String> data, WebDriver driver, ExtentTest logger,String serviceType)throws InterruptedException{
		//Entering deatils in Service specialty Page
		logger.log(LogStatus.INFO, "Select Servicing Provider: " +data.get("ProviderID"));
		//Dynamic selection from WebTable required
		selectServicingProvider.click();
		webUtils.explicitWaitByElementToBeClickable(driver, 10, providerID);
		
		providerID.sendKeys(data.get("ProviderID"));
		logger.log(LogStatus.INFO, "Entered Organisation"+data.get("Organization"));
		organisation.sendKeys(data.get("Organization").toString());
//		logger.log(LogStatus.INFO, "Enter State");
		state.sendKeys(data.get("State").toString());
		// Added wait time for flow synchronization
		Thread.sleep(4000);
		if(data.get("OnPar").toString().equalsIgnoreCase("Yes")){
			//webUtils.explicitWaitByElementToBeClickable(driver, parRadioBtn.get(1));
			logger.log(LogStatus.INFO, "click on Par Radio Button!!");
			
			parRadio.click();
			
		}
		else if(data.get("OnPar").toString().equalsIgnoreCase("No")){
			logger.log(LogStatus.INFO, "click on Par Radio Button!!");
			//webUtils.explicitWaitByElementToBeClickable(driver, parRadioBtn.get(1));
			parRadio1.click();
		}
//	    logger.log(LogStatus.INFO, "Enter Request Type::::::::::::::"+serviceType);
		requestType.sendKeys(serviceType);
		search.click();
		webUtils.explicitWaitByElementToBeClickable(driver, "//*[@id='MEDICAL_SEARCH_SERVICING_PROVIDER_GRID']/tr[1]/td[1]/a/span",60);//increased wait time by Sirisha
		
		selectProvider.click();
		// Added wait time for flow synchronization
		Thread.sleep(1000);
		FaxNumb.clear();
		webUtils.explicitWaitByElementToBeClickable(driver, "//input[@id='SERVICING_FACILITY_PROVIDER_FAX_NUMBER']",20);
		FaxNumb.sendKeys(data.get("FaxNumber").toString());
		webUtils.explicitWaitByElementToBeClickable(driver, "//div[@class='modal-footer']/a[@class='btn btn-default'][contains(text(),'Save')]",600);
		logger.log(LogStatus.INFO, "Clicked on Save!!");
		save.click();
		Thread.sleep(3000);
		
		
		
		

	}
	

}