package com.bsc.qa.web.pages;

import java.util.Map;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindAll;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;

import com.bsc.qa.framework.base.BasePage;
import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;

import WebUtils.WebUtils;

public class PrimaryDiagnosis extends BasePage {

	public WebUtils webUtils = new WebUtils();

	@FindAll({
			@FindBy(how = How.XPATH, using = "//*[@id='MEDICAL_DIAGNOSIS_INFORMATION_DIV']/div[2]/div/div/div[1]/ul/li[1]/a/b") })
	public WebElement primaryDiagnosis;
	// *[@id="PHARMACY_ICD_GRID_DIV"]/div[2]/div/div/div[1]/ul/li/a
	@FindAll({ @FindBy(how = How.XPATH, using = "//input[@name='MEDICAL_DIAGNOSIS_CODE_SEARCH']") })
	public WebElement diagnosisCode;
	// *[@id="icd_search_code"]

	@FindAll({ @FindBy(how = How.XPATH, using = "//*[@id='MEDICAL_DIAGNOSIS_FORM']/div[2]/a/span") })
	public WebElement searchButton;

	@FindAll({
			@FindBy(how = How.XPATH, using = "//*[@id='MEDICAL_DIAGNOSIS_CODE_SEARCH_RESULTS_GRID']/tr[1]/td[1]/a/span") })
	public WebElement select;

	@FindAll({ @FindBy(how = How.XPATH, using = "//*[@id='medical_submit_auth_btn1']") })
	public WebElement submit;
	@FindAll({ @FindBy(how = How.XPATH, using = "//span[@id='MEDICAL_DIAGNOSIS_STATUS']") })
	public WebElement medicalDiagnosisStatus;
	public static String username;

	public void enterDetailsInPrimaryDiagnosisPage(Map<String, String> data, WebDriver driver, ExtentTest logger)
			throws InterruptedException {
		username = new com.sun.security.auth.module.NTSystem().getName();
		username = System.getProperty("user.dir");
		System.out.println("username:::::::" + username);
		// Selecting specific Diagnosis code
//		logger.log(LogStatus.INFO, "click on Primary Diagnosis!!");
		primaryDiagnosis.click();
		webUtils.explicitWaitByVisibilityofElement(driver, diagnosisCode);
		logger.log(LogStatus.INFO, "Enter Diagnosis code" + data.get("DiagnosisCode"));
		diagnosisCode.sendKeys(data.get("DiagnosisCode"));
//		logger.log(LogStatus.INFO, "Click on Search Button");
		searchButton.click();
//		logger.log(LogStatus.INFO, "click on Select Button!!");
		webUtils.explicitWaitByElementToBeClickable(driver, select);
		select.click();
		webUtils.explicitWaitByVisibilityofElement(driver, submit);
		String diagnosisStatus = null;
		try {
			diagnosisStatus = medicalDiagnosisStatus.getText();
			if (diagnosisStatus != null || diagnosisStatus != "") {

				if (diagnosisStatus.trim().replaceAll("\\s+", "")
						.equalsIgnoreCase(data.get("AlertMessage").trim().replaceAll("\\s+", ""))) {
					logger.log(LogStatus.PASS, "Alert Message is matched " + diagnosisStatus);

				} else {
					logger.log(LogStatus.FAIL, "Alert Message is not matched " + diagnosisStatus);
				}

				webUtils.scrollDown(driver, primaryDiagnosis);
				webUtils.takeSnapShot(driver, username + "//test-output//BSC-reports//screenshots//"
						+ data.get("TestCaseID").trim() + "//" + data.get("TestCaseID").trim() + "diagnosisStatus.png");
				logger.log(LogStatus.INFO,
						logger.addScreenCapture(
								username + "//test-output//BSC-reports//screenshots//" + data.get("TestCaseID").trim()
										+ "//" + data.get("TestCaseID").trim() + "diagnosisStatus.png"));
			}
		} catch (Exception e) {
			// TODO: handle exception
		}

	}

}