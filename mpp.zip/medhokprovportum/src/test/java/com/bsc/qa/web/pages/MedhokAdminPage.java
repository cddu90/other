package com.bsc.qa.web.pages;

import java.util.Map;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindAll;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;

import com.bsc.qa.framework.base.BasePage;
import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;

import WebUtils.WebUtils;

public class MedhokAdminPage extends BasePage {

	public WebUtils webUtils = new WebUtils();

	
	@FindAll({ @FindBy(how = How.XPATH, using = "//input[@id='login-username']") })
	public WebElement userName;
	
	@FindAll({ @FindBy(how = How.XPATH, using = "//a[@id='pre_submit_login']") })
	public WebElement signIn;
	

	
		public void adminLogin(Map<String, String> data, WebDriver driver, ExtentTest logger)throws 
		InterruptedException{
		//Logging into MedHok Admin Portal with user id and blank(NULL) password
			
//		logger.log(LogStatus.INFO, "Log into application");
//		logger.log(LogStatus.INFO, "Enter username!!");
		logger.log(LogStatus.INFO, "Testcase Name "+data.get("TestCaseID").toString());
		userName.sendKeys(data.get("UserName").toString());
		
		webUtils.explicitWaitByElementToBeClickable(driver, "//a[@id='pre_submit_login']",60);
		logger.log(LogStatus.INFO, "Logged into Provider Portal application with Provider ID: "+data.get("UserName").toString());
		signIn.click();

	}

}
	

	