package com.bsc.qa.web.pages;

import java.awt.AWTException;
import java.awt.Robot;
import java.awt.event.KeyEvent;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindAll;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import WebUtils.WebUtils;

import com.bsc.qa.framework.base.BasePage;
import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;

/**
 * @author SaiKiran Ayyagari
 *
 */
public class AuthAccelPriorAuthReviewPage extends BasePage {

	public WebUtils webUtils = new WebUtils();

	@FindAll({ @FindBy(how = How.XPATH, using = "//div[@eventproxy='isc_Snapbar_0']//img[contains(@src,'hsplit_snap')]") })
	public WebElement hsplit;

	@FindAll({ @FindBy(how = How.XPATH, using = "//td[text()='Correspondence Templates']/ancestor::table/parent::div/parent::div/parent::div/parent::div/following::div[2]") })
	public WebElement close;

	@FindAll({ @FindBy(how = How.XPATH, using = "//div[text()='Inpatient - California']") })
	public WebElement inpatientTask;
	@FindAll({ @FindBy(how = How.XPATH, using = "//div[contains(@id,'isc_CodesSearch')]//following-sibling::table[@role='presentation' and @class='listTable']//tbody//tr[1]") })
	public WebElement firstRow;
	@FindAll({ @FindBy(how = How.XPATH, using = "//textarea[@name='lti1']") })
	public WebElement MDnotes;
	
	
	
	@FindAll({ @FindBy(how = How.XPATH, using = "//div[contains(@eventproxy,'isc_PagingListGrid_')]/div/table/tbody/tr/td[3]") })
	public List<WebElement> inpatientTaskList;

	@FindAll({ @FindBy(how = How.XPATH, using = "//div[contains(@eventproxy,'isc_PagingListGrid_')]/div/table/tbody/tr//td[5]") })
	public List<WebElement> taskList;
	@FindAll({ @FindBy(how = How.XPATH, using = "//tbody//tr//td[@class='button']//child::div//div[text()='Search']") })
	public List<WebElement> searchButton;
	@FindAll({ @FindBy(how = How.XPATH, using = "//b[contains(text(),'Cancel Reason')]/parent::td/following-sibling::td//td") })
	public List<WebElement> cancelReasonDropdown;
	
	@FindAll({ @FindBy(how = How.XPATH, using = "//td[text()='Alerts']/ancestor::div/div[1]/div[2]/following::div/img[contains(@src,'close')]") })
	public WebElement closePopup;

	@FindAll({ @FindBy(how = How.XPATH, using = "//div[contains(@eventproxy,'isc_ListGrid_')]//table[@class='listTable']//tr[1]/td[2]") })
	public WebElement taskreview;
	
	@FindAll({ @FindBy(how = How.XPATH, using = "//tbody/tr[@aria-setsize='4' and @aria-posinset='1']") })
	public WebElement ariaSetsize4_1;
	
	@FindAll({ @FindBy(how = How.XPATH, using = "//tbody/tr[@aria-setsize='4' and @aria-posinset='2']") })
	public WebElement ariaSetsize4_2;
	
	@FindAll({ @FindBy(how = How.XPATH, using = "//tbody/tr[@aria-setsize='4' and @aria-posinset='3']") })
	public WebElement ariaSetsize4_3;
	
	@FindAll({ @FindBy(how = How.XPATH, using = "//tbody/tr[@aria-setsize='4' and @aria-posinset='4']") })
	public WebElement ariaSetsize4_4;
	
	@FindAll({ @FindBy(how = How.XPATH, using = "//div[contains(@eventproxy,'isc_ListGrid_')]//table[@class='listTable']//tr[1]/td[7]//nobr") })
	public WebElement inpatientAuthStatus;
	
	@FindAll({ @FindBy(how = How.XPATH, using = "//div[contains(@eventproxy,'isc_ListGrid_')]//table[@class='listTable']//tr[1]/td[6]//nobr") })
	public WebElement AuthStatus;

	@FindAll({ @FindBy(how = How.XPATH, using = "//td/div/nobr[text()='Edit']") })
	public WebElement edit;

	@FindAll({ @FindBy(how = How.XPATH, using = "//td[contains(text(),'DRG') and @class='formTitle']/parent::tr/td[4]") })
	public WebElement decisionDropdown;
	@FindAll({ @FindBy(how = How.XPATH, using = "//td[contains(text(),'DRG') and @class='formTitle']/parent::tr/td[8]") })
	public WebElement criteriaDropdown;
	@FindAll({ @FindBy(how = How.XPATH, using = "//td[contains(text(),'Policy') and @class='formTitle']/parent::tr/td[2]") })
	public WebElement policyDropdown;
	@FindAll({ @FindBy(how = How.XPATH, using = "//td[contains(text(),'Policy') and @class='formTitle']/parent::tr/td[4]") })
	public WebElement rationaleDropdown;
	

	@FindAll({ @FindBy(how = How.XPATH, using = "//span[contains(text(),'Criteria') and @class='formTitle']/parent::td/preceding-sibling::td[4]/table") })
	public WebElement serviceDecisionDropdown;

	@FindAll({ @FindBy(how = How.XPATH, using = "//span[contains(text(),'Criteria') and @class='formTitle']/parent::td/preceding-sibling::td[3]/table") })
	public WebElement serviceDecisionReasonDropdown;
	@FindAll({ @FindBy(how = How.XPATH, using = "//span[contains(text(),'Criteria') and @class='formTitle']/parent::td/table/tbody") })
	public WebElement serviceCriteriaDropdown;
	@FindAll({ @FindBy(how = How.XPATH, using = "//span[contains(text(),'Policy') and @class='formTitle']/parent::td/table/tbody") })
	public WebElement servicePolicyDropdown;
	@FindAll({ @FindBy(how = How.XPATH, using = "//span[contains(text(),'Rationale') and @class='formTitle']/parent::td/table/tbody/tr/td[1]") })
	public WebElement serviceRationaleDropdown;
	
	@FindAll({ @FindBy(how = How.XPATH, using = "//b[contains(text(),'Review Type')]") })
	public WebElement reviewType;

	@FindAll({ @FindBy(how = How.XPATH, using = "//td/b[contains(text(),'Bed Type')]/following::td[1]") })
	public WebElement bedTypeDropDown;

	@FindAll({ @FindBy(how = How.XPATH, using = "//label[contains(text(),'Decision Date')]/parent::td/preceding-sibling::td[1]") })
	public WebElement authDecisionReason;

	@FindAll({ @FindBy(how = How.XPATH, using = "//label[contains(text(),'Decision Date')]/parent::td/preceding-sibling::td[3]") })
	public WebElement authDecision;


	@FindAll({ @FindBy(how = How.XPATH, using = "//td[contains(text(),'Letter Review')]") })
	public WebElement servicerighClickArea;

	@FindAll({ @FindBy(how = How.XPATH, using = "//td[contains(text(),'DRG') and @class='formTitle']/parent::tr/td[6]") })
	public WebElement decisionReasonDropdown;

	@FindAll({ @FindBy(how = How.XPATH, using = "//div[contains(@eventproxy,'InPatientAuthIPDaysGrid_')]/div/table/tbody/tr/td[3]") })
	public WebElement inpatientRequest;

	@FindAll({ @FindBy(how = How.XPATH, using = "//div[contains(@eventproxy,'outPatientReviewCptCodes_')]//table[@class='listTable']/tbody/tr") })
	public WebElement serviceRequest;

	@FindAll({ @FindBy(how = How.XPATH, using = "//div[contains(@eventproxy,'isc_UmAuthInPatientReviewLayout_')]/div/table/tbody/tr/td[2]/div/nobr[text()='Edit']") })
	public WebElement Edit;
	
	@FindAll({ @FindBy(how = How.XPATH, using = "//div[contains(@eventproxy,'isc_UmAuthInPatientReviewLayout_')]/div/table/tbody/tr/td[2]/div/nobr[text()='Add']")})
	public WebElement Add;
	
	

	@FindAll({ @FindBy(how = How.XPATH, using = "//div[contains(@eventproxy,'isc_UmAuthOutPatientReviewLayout_')]/div/table/tbody/tr/td[2]/div/nobr[text()='Edit']") })
	public WebElement serviceRequestEdit;
	@FindAll({ @FindBy(how = How.XPATH, using = "//div[contains(@eventproxy,'isc_UmAuthOutPatientReviewLayout_')]/div/table/tbody/tr/td[2]/div/nobr[text()='Add']") })
	public WebElement serviceRequestAdd;

	@FindAll({ @FindBy(how = How.NAME, using = "qty") })
	public WebElement quantity;

	@FindAll({ @FindBy(how = How.XPATH, using = "//input[@name='qty']/parent::td/following-sibling::td[1]//table") })
	public WebElement quantityUnits;
	@FindAll({ @FindBy(how = How.XPATH, using = "//td//label[contains(text(),'From')]/following::td[2]") })
	public WebElement fromDate;
	@FindAll({ @FindBy(how = How.XPATH, using = "//td//label[contains(text(),'Thru')]/following::td[2]") })
	public WebElement thruDate;

	
	
	@FindAll({ @FindBy(how = How.XPATH, using = "//b[contains(text(),'Admission BedType')]//parent::td//following-sibling::td//td[1]") })
	public WebElement addmissionBedTy;
	@FindAll({ @FindBy(how = How.XPATH, using = "//input[@name='approvedQty']/parent::td/following-sibling::td[1]//table") })
	public WebElement approvedQuantityUnits;

	@FindAll({ @FindBy(how = How.NAME, using = "approvedQty") })
	public WebElement approvedQuantity;

	@FindAll({ @FindBy(how = How.XPATH, using = "//div[contains(@class,'pickListMenuBody')]/div/table/tbody/tr") })
	public List<WebElement> commondropdownList;

	@FindAll({ @FindBy(how = How.XPATH, using = "//div[contains(@eventproxy,'isc_CorrespondanceGrid_')]//table[@class='listTable']//tr/td[2]/div/nobr") })
	public List<WebElement> letterTypeList;

	@FindAll({ @FindBy(how = How.XPATH, using = "//div[contains(@eventproxy,'isc_MHIButton_')]//div[text()='Close']/ancestor::table/parent::div//preceding-sibling::div//div[text()='Save']") })
	public WebElement Save;

	@FindAll({ @FindBy(how = How.XPATH, using = "//div[contains(@eventproxy,'InPatientAuthReviewsave_')]//div[text()='Save']") })
	public WebElement SaveRequest;

	@FindAll({ @FindBy(how = How.XPATH, using = "//div[contains(@eventproxy,'OutPatientAuthReviewSave_')]//div[text()='Save']") })
	public WebElement serviceSaveRequest;

	@FindAll({ @FindBy(how = How.XPATH, using = "//div[contains(@eventproxy,'isc_MHIButton_')]//div[text()='Close']") })
	public WebElement Close;
	
	
	@FindAll({ @FindBy(how = How.NAME, using = "approvedEffectiveDate_dateTextField") })
	public WebElement From;
	
	
	@FindAll({ @FindBy(how = How.NAME, using = "approvedTermDate_dateTextField") })
	public WebElement Thru;
	

	@FindAll({ @FindBy(how = How.XPATH, using = "//div[@eventproxy='isc_globalWarn_toolbar']//div[text()='Yes']") })
	public WebElement yes;

	@FindAll({ @FindBy(how = How.XPATH, using = "//nobr[text()='Correspondence']") })
	public WebElement correspondance;

	@FindAll({ @FindBy(how = How.XPATH, using = "//td[@class='recordEditorCell']//input[@name='name']") })
	public WebElement search;

	@FindAll({ @FindBy(how = How.XPATH, using = "//div[@class='imgButton']/img[contains(@src,'corres')]") })
	public WebElement sendToCorrespondance;

	@FindAll({ @FindBy(how = How.XPATH, using = "//div[@eventproxy='isc_globalWarn_toolbar']//div[text()='okBtn']") })
	public WebElement okBtn;
	
	@FindAll({ @FindBy(how = How.XPATH, using = "//td[@class='buttonSelected']//div[text()='okBtn']") })
	public WebElement selectedOK;
	
	@FindAll({ @FindBy(how = How.XPATH, using = "//label[text()='Free Form Letter Narrative']") })
	public WebElement letterconfirmation;
	
	@FindAll({ @FindBy(how = How.NAME, using = "ti1") })
	public WebElement infoReturnFaxNo;
	@FindAll({ @FindBy(how = How.NAME, using = "//input[@name='code']") })
	public WebElement code;
	
	
	@FindAll({ @FindBy(how = How.XPATH, using = "//b[contains(text(),'Department')]/ancestor::td/following-sibling::td") })
	public WebElement department;
	
	@FindAll({ @FindBy(how = How.XPATH, using = "//label[text()='! HMO IPA Address (Complete when Transplant BSC HMO is chosen)']") })
	public WebElement transplantletterconfirmation;

	@FindAll({ @FindBy(how = How.XPATH, using = "//td[text()='Notes' and @class='windowHeaderText']") })
	public WebElement Notes;

	@FindAll({ @FindBy(how = How.XPATH, using = "//b[contains(text(),'Status ')]/ancestor::td/preceding-sibling::td[1]") })
	public WebElement statusDropdown;

	@FindAll({ @FindBy(how = How.XPATH, using = "//b[contains(text(),'Status ')]/ancestor::td/following::td[1]") })
	public WebElement statusReasonDropdown;

	@FindAll({ @FindBy(how = How.XPATH, using = "//div[contains(@eventproxy,'isc_MHIButton_')]//div[text()='Submit']") })
	public WebElement submitButton;

	@FindAll({ @FindBy(how = How.NAME, using = "dischargeDate_dateTextField") })
	public WebElement dischargeDate;

	@FindAll({ @FindBy(how = How.XPATH, using = "//div[contains(@eventproxy,'isc_CorrespondanceTrackingView_')]//table/tbody/tr[@role='listitem']/td[5]/div/nobr") })
	public List<WebElement> letterVerification;
	@FindAll({ @FindBy(how = How.XPATH, using = "//div[contains(@eventproxy,'isc_CorrespondanceTrackingView_')]//tr[1]//td[2]") })
	public WebElement firstLetterRow;
	@FindAll({ @FindBy(how = How.XPATH, using = "//div[contains(@eventproxy,'isc_CorrespondanceTrackingView_')]//tr[2]//td[2]") })
	public WebElement secondLetterRow;
	
	@FindAll({ @FindBy(how = How.XPATH, using = "//div[contains(@eventproxy,'isc_CorrespondanceTrackingView_')]//table/tbody/tr[@role='listitem'][2]/td[5]/div/nobr") })
	public WebElement secondLetterVerification;
	

	@FindAll({ @FindBy(how = How.XPATH, using = "//td[@class='tabButtonTop' and text()='Correspondence']") })
	public WebElement correspondence;

	@FindAll({ @FindBy(how = How.XPATH, using = "//div[@class='stretchImgButton']//img[contains(@src,'hscroll_forward')]") })
	public WebElement forward;

	@FindAll({ @FindBy(how = How.XPATH, using = "//div[text()='Received Date']") })
	public WebElement receivedDate;

	@FindAll({ @FindBy(how = How.XPATH, using = "//div[text()='Auth - My Cases']") })
	public WebElement AuthCases;

	@FindAll({ @FindBy(how = How.XPATH, using = "//div[text()='Received Date']") })
	public List<WebElement> ReceivedDate;

	@FindAll({ @FindBy(how = How.XPATH, using = "//div[contains(@id,'isc_PickList')]//following-sibling::table[@role='presentation' and @class='listTable']//tbody//tr") })
	public List<WebElement> cancelReasonList;

	@FindAll({ @FindBy(how = How.XPATH, using = "//b[contains(text(),'Status')]/parent::nobr/parent::td/following-sibling::td//td[1]") })
	public List<WebElement> facilityStatus;
	
	@FindAll({ @FindBy(how = How.XPATH, using = "//div[contains(@id,'isc_PickList')]//following-sibling::table[@role='presentation' and @class='listTable']//tbody//tr") })
	public List<WebElement> facilityStatusList;

	
		
	@FindAll({ @FindBy(how = How.XPATH, using = "//div[text()='Received Date']/ancestor::td/following-sibling::td[1]") })
	public List<WebElement> ReceivedDatebutton;

	@FindAll({ @FindBy(how = How.XPATH, using = "//b[contains(text(),'Withdrawn By')]/parent::td/following-sibling::td") })
	public WebElement withdrawnBy;

	@FindAll({ @FindBy(how = How.XPATH, using = "//nobr[text()='Sort Descending']") })
	public WebElement sortDescending;
	
	@FindAll({ @FindBy(how = How.XPATH, using = "//div[contains(@eventproxy,'isc_ListGrid_')]//table[@class='listTable']//tr[1]") })
	public WebElement reviewFirstRow;
	
	@FindAll({ @FindBy(how = How.XPATH, using = "//td/div/nobr[text()='Edit']") })
	public WebElement editList;
	
	@FindAll({ @FindBy(how = How.XPATH, using = "//td/div/nobr[text()='Edit']") })
	public List<WebElement> editList1;
	
	@FindAll({ @FindBy(how = How.XPATH, using = "//div[contains(@eventproxy,'InPatientA')]//following-sibling::table[@class='listTable']//tr[1]") })
	public WebElement inpatientRow;
	
	@FindAll({ @FindBy(how = How.XPATH, using = "//div//nobr[text()='View']") })
	public WebElement View;
	
	@FindAll({ @FindBy(how = How.XPATH, using = "//td//div[text()='Yes']") })
	public WebElement yesButton;
	
	@FindAll({ @FindBy(how = How.XPATH, using = "//td[@class='button']//div//div[text()='Cancel']") })
	public List<WebElement> cancelButton;
	
	@FindAll({ @FindBy(how = How.XPATH, using = "//b[contains(text() , 'Service Category')]/parent::td/following-sibling::td//tr//div") })
	public WebElement serviceCategory;
	
	@FindAll({ @FindBy(how = How.XPATH, using = "//*[text()='Access to Care (ATC)']") })
	public WebElement serviceCategoryOption;
	
	@FindAll({ @FindBy(how = How.XPATH, using = "//*[text()='okBtn']") })
	public WebElement LOApopUp;
	
	@FindAll({ @FindBy(how = How.XPATH, using = "//*[@name='facilityLoa_id' and @value='1']") })
	public WebElement LOAFacbutton;
	
	@FindAll({ @FindBy(how = How.XPATH, using = "//*[@name='servicingLoa_id' and @value='1']") })
	public WebElement LOAServicebutton;
	
	@FindAll({ @FindBy(how = How.XPATH, using = "//table[@class ='menuTable']/tbody//td[2]/div/nobr[text()='Cancel']") })
	public WebElement cancel;
	
	@FindAll({ @FindBy(how = How.XPATH, using = "//*[contains(text(),'Cancel Reason')]/parent::td[@class='formTitle']/following-sibling::td") })
	public List<WebElement> cancelReason;
	
	@FindAll({ @FindBy(how = How.XPATH, using = "//textarea[@name='cancelReasonText']")})
	public WebElement textArea;
	
	@FindAll({ @FindBy(how = How.XPATH, using = "//div[text()='Save']")})
	public List<WebElement> saveCancelReason;
	@FindAll({ @FindBy(how = How.XPATH, using = "//div[contains(@eventproxy,'isc_MHIButton_')]//div[text()='Save']") })
	public List<WebElement> cancelSave;
	@FindAll({ @FindBy(how = How.XPATH, using = "//div[text()='Unknown']") })
	public List<WebElement> checkBoxUnknown;
	@FindAll({ @FindBy(how = How.XPATH, using = "//*[text()='Servicing Provider']") })
	public WebElement servicingProvider;
	
	@FindAll({ @FindBy(how = How.XPATH, using = "//*[text()='Recommendations']") })
	public WebElement recommendations;
	
	@FindAll({ @FindBy(how = How.XPATH, using = "//*[contains(@eventproxy,'isc_NotesView')]//table") })
	public List<WebElement> recommendationsGrid;
	
	@FindAll({ @FindBy(how = How.XPATH, using = "//*[text()='Add Nurse Recommendation']") })
	public WebElement addNurseRecom;
	
	@FindAll({ @FindBy(how = How.XPATH, using = "//b[contains(text(),'Type')]//parent::td//following-sibling::td[@class='formCell']//tr") })
	public List<WebElement> recommendationsType;
	@FindAll({ @FindBy(how = How.XPATH, using = "//input[@name='noteDate_dateTextField']/ancestor::td/preceding-sibling::td[2]//td") })
	public WebElement recomType;
	
	@FindAll({ @FindBy(how = How.XPATH, using = "//b[contains(text(),'Determination')]//parent::nobr/parent::td/following-sibling::td")})
//	@FindAll({ @FindBy(how = How.CSS, using = "#isc_1EM"),@FindBy(how=How.XPATH , using="//*[@id=\"isc_1EM\"]")})
//	@FindAll({ @FindBy(how=How.XPATH , using="//*[@id=\"isc_1EM\"]")})
	public WebElement MDDetermination;
	
	@FindAll({ @FindBy(how = How.XPATH, using = "//*[contains(text(),'Reconsideration Option')]/parent::td/following-sibling::td") })
	public WebElement reconOption;
	
	@FindAll({ @FindBy(how = How.XPATH, using = "//input[@name='di1_dateTextField']")})
	public WebElement serviceDate;
	@FindAll({ @FindBy(how = How.XPATH, using = "//input[@name='ti1']")})
	public WebElement returnFax;
	@FindAll({ @FindBy(how = How.XPATH, using = "//b[contains(text(),'Department')]//parent::nobr/parent::td/following-sibling::td")})
	public WebElement dep;
	@FindAll({ @FindBy(how = How.XPATH, using = "//b[contains(text(),'Medical Director Name')]/ancestor::td/following-sibling::td[1]/table") })
	public WebElement medDirName;
	    
	@FindAll({ @FindBy(how = How.XPATH, using = "//b[contains(text(),'Medical Director Name')]/ancestor::td/following-sibling::td[3]/table") })
	public WebElement medDetermination; 

	@FindAll({ @FindBy(how = How.XPATH, using = "//*[text()='Add MD Recommendation']") })
	public WebElement addMDRecom;
	
	@FindAll({ @FindBy(how = How.XPATH, using = "//td/b[contains(text(),'Admission BedType')]/parent::td/following-sibling::td//div[@class='selectItemText']") })
	public WebElement admBedType;
	
	@FindAll({@FindBy(how=How.XPATH , using="//*[@id='isc_1E8']/table/tbody/tr/td/img")})
	public WebElement MDScroll;
	//div[contains(@eventproxy,'isc_CorrespondanceTrackingView_')]//table/tbody/tr[@role='listitem']/td[2]/div/nobr
	public void taskVerification(WebDriver driver, String referenceNo,
			String taskName, ExtentTest logger) {
		try {


			int taskListflag = 0;

			
			WebElement task = driver.findElement(By.xpath("//div[text()='"
					+ taskName.trim() + "']"));

			webUtils.explicitWaitByElementToBeClickable(driver, 15, task);

			webUtils.elementClickWithLogger(task, taskName, logger, driver);

			// task.click();

			try {

				if (AuthCases.isDisplayed()) {
					webUtils.elementClickWithLogger(AuthCases, "AuthCases Portlet",
							logger, driver);
				}
				// AuthCases.click();

			} catch (Exception e) {
				System.out.println("AuthCases validation is skipped");
			}

			Thread.sleep(5000); // Added wait time for flow synchronization
			
			System.out.println("The task name is "+taskName);

			if ("Inpatient - California".equals(taskName)) {

				webUtils.explicitWaitByPresenceofAllElements(driver, 30,
						"//div[contains(@eventproxy,'isc_PagingListGrid_')]/div/table/tbody/tr/td[3]");
				for (WebElement inpatientTask : inpatientTaskList) {

					if (inpatientTask.getText().trim().equals(referenceNo.trim())) {

						taskListflag++;

						inpatientTask.click();

						webUtils.doubleClick(driver, inpatientTask);

						break;

					} else if (inpatientTask.getText().equals("")) {

						webUtils.scrollDown(driver, inpatientTask);	
						
						
						if (inpatientTask.getText().trim().equals(referenceNo.trim())) {

							taskListflag++;

							inpatientTask.click();

							webUtils.doubleClick(driver, inpatientTask);

							break;

						}
						
					}
				}

				if (taskListflag == 1) {

					logger.log(LogStatus.INFO, "Task is selected from the "
							+ taskName + " Portlet");

				} else {

					logger.log(LogStatus.INFO, "Task is not  available in the "
							+ taskName + " Portlet");
				}

			} else {

				if (taskName.trim().equalsIgnoreCase("IP Medicare 65+")
						|| taskName.trim().equalsIgnoreCase("OP Medicare 65+")
						|| taskName.trim().equalsIgnoreCase("Delegation Oversight RN")) {

					webUtils.explicitWaitByVisibilityofElement(driver, 10,
							ReceivedDate.get(1));

					webUtils.mouseOver(ReceivedDate.get(1), driver);

					webUtils.rightClick(driver, ReceivedDate.get(1));

					webUtils.explicitWaitByElementToBeClickable(driver, 10,
							sortDescending);

					sortDescending.click();

					/*
					 * ReceivedDate.get(1).click();
					 * 
					 * webUtils.explicitWaitByPresenceofAllElements(driver,20,
					 * "//div[contains(@eventproxy,'isc_PagingListGrid_')]/div/table/tbody/tr//td[5]"
					 * );
					 * 
					 * webUtils.waitUntilElementclickable(ReceivedDate.get(1),
					 * driver);
					 */

					// ReceivedDate.get(1).click();
					
					System.out.println("The reference number is "+referenceNo);

					webUtils.explicitWaitByPresenceofElement(driver, 10,
							"//nobr[text()='"+ referenceNo.trim() +"']");

					WebElement medicaretask = driver.findElement(By
							.xpath("//nobr[text()='"+ referenceNo.trim() +"']"));
					try {
						if (medicaretask.isDisplayed()) {
							
							System.out.println("The medicartask is "+medicaretask.isDisplayed());
							medicaretask.click();

							webUtils.doubleClick(driver, medicaretask);
							logger.log(LogStatus.INFO,
									"Task is  selected from the " + taskName
											+ " portlet");

						} else if (!medicaretask.isDisplayed()){
							webUtils.scrollDown(driver, medicaretask);
							medicaretask.click();

							webUtils.doubleClick(driver, medicaretask);
							logger.log(LogStatus.INFO,
									"Task is  selected from the " + taskName
											+ " portlet");
						}
						
						else{
							
							logger.log(LogStatus.INFO, "Task is not present in the "+taskName+"portlet");
						}
					} catch (Exception e) {

						logger.log(LogStatus.INFO, "Task is not present in the "
								+ taskName + " portlet");
					}

				} else {

					webUtils.explicitWaitByElementToBeClickable(driver, 15,
							receivedDate);
					receivedDate.click();
					webUtils.explicitWaitByPresenceofAllElements(driver, 20,
							"//div[contains(@eventproxy,'isc_PagingListGrid_')]/div/table/tbody/tr//td[5]");
					webUtils.explicitWaitByElementToBeClickable(driver, 15,
							receivedDate);
					receivedDate.click();

					webUtils.explicitWaitByPresenceofAllElements(driver, 30,
							"//div[contains(@eventproxy,'isc_PagingListGrid_')]/div/table/tbody/tr//td[5]");

					for (WebElement inpatientTask : taskList) {
						
						WebDriverWait wait = new WebDriverWait(driver,15);
						
						wait.until(ExpectedConditions.not(ExpectedConditions.stalenessOf(inpatientTask)));
						
						System.out.println("The reference number is "
								+ inpatientTask.getText());
						System.out.println("The reference number from sheet is "
								+ referenceNo);

						if (inpatientTask.getText().trim()
								.equals(referenceNo.trim())) {

							taskListflag++;

							inpatientTask.click();
							logger.log(LogStatus.INFO, "Task is present in the "
									+ "Phamacist review Portlet");
							
							//webUtils.doubleClick(driver, inpatientTask);

							break;

						} else if (inpatientTask.getText().equals("")) {

							webUtils.scrollDown(driver, inpatientTask);
							
							if (inpatientTask.getText().trim()
									.equals(referenceNo.trim())) {

								taskListflag++;

								inpatientTask.click();

								webUtils.doubleClick(driver, inpatientTask);

								break;

							} 
							
							
						}

					}

					if (taskListflag == 1) {

						logger.log(LogStatus.INFO, "Task is selected from the "
								+ taskName + " Portlet");

					} else {

						logger.log(LogStatus.INFO, "Task is not  available in the "
								+ taskName + " Portlet");
					}
				}

			}

		
		}
		catch(Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * Selecting the Decision to be Made
	 * 
	 * @throws InterruptedException
	 */
	public void selectDecision(WebDriver driver, ExtentTest logger,
			String decision, String decisionReason, String bedType,
			String requestType, String taskName,String type,String dataFromDate,String dataThruDate,String criteria,String policy,String rationale) throws InterruptedException {

		try {
			webUtils.explicitWaitByElementToBeClickable(driver, 20, closePopup);

			if (closePopup.isDisplayed()) {

				closePopup.click();
			}
		} catch (Exception e) {
			System.out.println("closePopup validation is skipped");
		}
		
			webUtils.scrollDown(driver, taskreview);

			webUtils.rightClick(driver, taskreview);

			webUtils.explicitWaitByElementToBeClickable(driver, 20, edit);

			logger.log(LogStatus.INFO, "Case has been opened for Editing");
			
			
			if(edit.isDisplayed()&&edit.isEnabled()){

			edit.click();
			}
			else{
				
				logger.log(LogStatus.INFO, "Prior uthorization request is already Approved or Denied");
				
			}

		if("BSC Inpatient".equalsIgnoreCase(requestType))
		{
			System.out.println("before click on Admission type");
			//reviewsButton.click();
			//logger.log(LogStatus.INFO, "Moved to Reviews Tab");
			 
			webUtils.explicitWaitByElementToBeClickable(driver, 60,
					admBedType);
			System.out.println("AdmitBedTypeDropdown::::"+admBedType.isDisplayed());
			admBedType.click();

			webUtils.clickButtonOrLink(commondropdownList,bedType, logger,
					driver);
			logger.log(LogStatus.INFO, "Admission BedType: ICU is selected");
		}	

		
		webUtils.fluentWait(driver, "//b[contains(text(),'Review Type')]");

		if ("BSC Inpatient".equalsIgnoreCase(requestType)) {

			webUtils.scrollDown(driver, inpatientRequest);

			inpatientRequest.click();

			webUtils.rightClick(driver, inpatientRequest);

			Edit.click();

			if (!"".equals(bedType)) {
				webUtils.explicitWaitByElementToBeClickable(driver, 20,
						bedTypeDropDown);

				bedTypeDropDown.click();

				webUtils.clickButtonOrLink(commondropdownList, bedType, logger,
						driver);
			}

			Thread.sleep(5000); // Added wait time for flow synchronization

			if (!"".equals(decision)) {
//				logger.log(LogStatus.INFO, "Select the decision");
				webUtils.elementClickWithLogger(decisionDropdown,
						decision, logger, driver);

				// decisionDropdown.click();

				webUtils.clickButtonOrLink(commondropdownList, decision,
						logger, driver);
			}

			if (!"".equals(decisionReason)) {
				logger.log(LogStatus.INFO, "Select the decision reason ");
				webUtils.explicitWaitByElementToBeClickable(driver, 20,
						decisionReasonDropdown);

				webUtils.elementClickWithLogger(decisionReasonDropdown,
						decisionReason, logger, driver);
				// decisionReasonDropdown.click();

				webUtils.clickButtonOrLink(commondropdownList, decisionReason,
						logger, driver);
			}
			
			if (!"".equals(criteria)) {
				
				webUtils.explicitWaitByElementToBeClickable(driver, 20,
						criteriaDropdown);

				criteriaDropdown.click();

				webUtils.clickButtonOrLink(commondropdownList, criteria, logger,
						driver);
				logger.log(LogStatus.INFO, "Selected the Criteria as "+criteria);
			}
			if (!"".equals(policy)) {
//				logger.log(LogStatus.INFO, "Select the Policy");
				webUtils.explicitWaitByElementToBeClickable(driver, 20,
						policyDropdown);

				policyDropdown.click();

				webUtils.clickButtonOrLink(commondropdownList, policy, logger,
						driver);
			}
			if (!"".equals(rationale)) {
				
				Actions action = new Actions(driver);
				action.sendKeys(Keys.TAB).sendKeys(Keys.TAB).build().perform();
				action.sendKeys(Keys.DOWN).sendKeys(Keys.DOWN).build().perform();
				Thread.sleep(2000); // Added wait time for flow synchronization
//				logger.log(LogStatus.INFO, "Selected the Rationale");
				/*webUtils.explicitWaitByElementToBeClickable(driver, 20,
						rationaleDropdown);

				rationaleDropdown.click();

				webUtils.clickButtonOrLink(commondropdownList, rationale, logger,
						driver);*/
			}

			
			
			

		} 
		else {

			webUtils.scrollDown(driver, serviceRequest);

			serviceRequest.click();

			webUtils.rightClick(driver, serviceRequest);

			serviceRequestEdit.click();

			quantity.sendKeys("1");

			quantityUnits.click();

			webUtils.clickButtonOrLink(commondropdownList, "Units", logger,
					driver);

			// webUtils.explicitWaitByVisibilityofElement(driver, units);

			// units.click();
			webUtils.scrollDown(driver, approvedQuantity);
			
			approvedQuantity.sendKeys("1");

			approvedQuantityUnits.click();

			webUtils.clickButtonOrLink(commondropdownList, "Units", logger,
					driver);
			
			webUtils.explicitWaitByElementToBeClickable(driver, From);
			
			From.sendKeys(dataFromDate);
			
			Thru.sendKeys(dataThruDate);


			Thread.sleep(2000); // Added wait time for flow synchronization

			webUtils.scrollDown(driver, serviceDecisionDropdown);

			
			if (!"".equals(decision)) {
				logger.log(LogStatus.INFO, "Select the decision");
				webUtils.elementClickWithLogger(serviceDecisionDropdown,
						"Decision dropdown", logger, driver);
				// serviceDecisionDropdown.click();

				webUtils.clickButtonOrLink(commondropdownList, decision,
						logger, driver);
			}

 			Thread.sleep(2000); // Added wait time for flow synchronization

			if (!"".equals(decisionReason)) {

				logger.log(LogStatus.INFO, "Select the Decision Reason");

				webUtils.explicitWaitByElementToBeClickable(driver, 20,
						serviceDecisionReasonDropdown);

				webUtils.elementClickWithLogger(serviceDecisionReasonDropdown,
						"Decision Reason", logger, driver);
				// serviceDecisionReasonDropdown.click();

				webUtils.clickButtonOrLink(commondropdownList, decisionReason,
						logger, driver);
			}
			if (!"".equals(criteria)) {
				logger.log(LogStatus.INFO, "Select the Criteria");
				webUtils.elementClickWithLogger(serviceCriteriaDropdown,
						"Criteria dropdown", logger, driver);
				// serviceDecisionDropdown.click();

				webUtils.clickButtonOrLink(commondropdownList, criteria,
						logger, driver);
			}
			if (!"".equals(policy)) {
				logger.log(LogStatus.INFO, "Select the policy");
				webUtils.elementClickWithLogger(servicePolicyDropdown,
						"Policy dropdown", logger, driver);
				// serviceDecisionDropdown.click();

				webUtils.clickButtonOrLink(commondropdownList, policy,
						logger, driver);
			}
			if (!"".equals(rationale)) {
				logger.log(LogStatus.INFO, "Select the rationale");
				webUtils.elementClickWithLogger(serviceRationaleDropdown,
						"Policy dropdown", logger, driver);
				// serviceDecisionDropdown.click();

				webUtils.clickButtonOrLink(commondropdownList, rationale,
						logger, driver);
			}
			
			


		}

		webUtils.explicitWaitByVisibilityofElement(driver, 20, Save);

		Save.click();

		webUtils.explicitWaitByVisibilityofElement(driver, 20, Close);

		Close.click();

		Thread.sleep(2000); // Added wait time for flow synchronization

		try {

			if (yes.isDisplayed()) {

				Robot robot = new Robot();

				robot.keyPress(KeyEvent.VK_TAB);

				robot.keyRelease(KeyEvent.VK_TAB);

				robot.keyPress(KeyEvent.VK_ENTER);

				robot.keyRelease(KeyEvent.VK_ENTER);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}

	}
	
	public void selectDecisionWithLine(WebDriver driver, ExtentTest logger,
			String decision, String decisionReason, String bedType,
			String requestType, String taskName,String type,String dataFromDate,String dataThruDate,String criteria,String policy,String rationale , String procedureCode) throws InterruptedException {

		try {
			webUtils.explicitWaitByElementToBeClickable(driver, 20, closePopup);

			if (closePopup.isDisplayed()) {

				closePopup.click();
			}
		} catch (Exception e) {
			System.out.println("closePopup validation is skipped");
		}
		
			webUtils.scrollDown(driver, taskreview);

			webUtils.rightClick(driver, taskreview);

			webUtils.explicitWaitByElementToBeClickable(driver, 20, edit);

			logger.log(LogStatus.INFO, "Edit the Request");
			
			
			if(edit.isDisplayed()&&edit.isEnabled()){

			edit.click();
			}
			else{
				
				logger.log(LogStatus.INFO, "Prior uthorization request is already Approved or Denied");
				
			}
			
		
		 

		webUtils.fluentWait(driver, "//b[contains(text(),'Review Type')]");

		if ("BSC Inpatient".equalsIgnoreCase(requestType)) {

			webUtils.scrollDown(driver, inpatientRequest);

			inpatientRequest.click();

			webUtils.rightClick(driver, inpatientRequest);

			Edit.click();

			if (!"".equals(bedType)) {
				webUtils.explicitWaitByElementToBeClickable(driver, 20,
						bedTypeDropDown);

				bedTypeDropDown.click();

				webUtils.clickButtonOrLink(commondropdownList, bedType, logger,
						driver);
				logger.log(LogStatus.INFO, "Value for BedType Dropdown is : "+bedType);
			}

			Thread.sleep(2000); // Added wait time for flow synchronization

			if (!"".equals(decision)) {
				logger.log(LogStatus.INFO, "Select the decision");
				webUtils.elementClickWithLogger(decisionDropdown,
						"Decision dropdown ", logger, driver);

				// decisionDropdown.click();

				webUtils.clickButtonOrLink(commondropdownList, decision,
						logger, driver);
				logger.log(LogStatus.INFO, "Value for Decision Dropdown is : "+decision);
			}

			if (!("").equals(decisionReason)) {
				logger.log(LogStatus.INFO, "Select the decision reason ");
				webUtils.explicitWaitByElementToBeClickable(driver, 20,
						decisionReasonDropdown);

				webUtils.elementClickWithLogger(decisionReasonDropdown,
						"Decision Reason dropdown ", logger, driver);
				// decisionReasonDropdown.click();
				
				webUtils.clickButtonOrLink(commondropdownList, decisionReason,
						logger, driver);
				logger.log(LogStatus.INFO, "Value for Decision Reason Dropdown is : "+decisionReason);
			}
			
			if (!("").equals(criteria)) {
				webUtils.explicitWaitByElementToBeClickable(driver, 20,
						criteriaDropdown);

				criteriaDropdown.click();

				webUtils.clickButtonOrLink(commondropdownList, criteria, logger,
						driver);
				logger.log(LogStatus.INFO, "Value for Criteria Dropdown is : "+decisionReason);
			}
			if (!("").equals(policy)) {
				webUtils.explicitWaitByElementToBeClickable(driver, 20,
						policyDropdown);

				policyDropdown.click();
				List<String> policies = new ArrayList<String>();
				
				for(WebElement pol : commondropdownList)
				{
					if(!(pol.getText().equals(""))){
									
					policies.add(pol.getText().toLowerCase());
					}
				}
				
				
				List<String> sortedPolicies = policies;
				
				Collections.sort(sortedPolicies);
				
				if(policies.equals(sortedPolicies)){
					logger.log(LogStatus.INFO, "Medical Policies are alphabetized in dropdown");
				}
				else
				{
					logger.log(LogStatus.INFO, "Medical Policies are not alphabetized in dropdown");
				}
				//**using X-Path for selecting policy dropdown**//
				WebElement policyName= driver.findElement(By.xpath("//*[text()='"+policy+"']"));
				policyName.click();
				/*webUtils.clickButtonOrLink(commondropdownList, policy, logger,
						driver);*/
			}
			if (!("").equals(rationale)) {
				
				Actions action = new Actions(driver);
				action.sendKeys(Keys.TAB).sendKeys(Keys.TAB).build().perform();
				action.sendKeys(Keys.DOWN).sendKeys(Keys.DOWN).build().perform();
				Thread.sleep(2000); // Added wait time for flow synchronization
				/*webUtils.explicitWaitByElementToBeClickable(driver, 20,
						rationaleDropdown);

				rationaleDropdown.click();

				webUtils.clickButtonOrLink(commondropdownList, rationale, logger,
						driver);*/
			}
			

		} 
		else {

			webUtils.scrollDown(driver, serviceRequest);

			serviceRequest.click();

			webUtils.rightClick(driver, serviceRequest);

			serviceRequestEdit.click();

			quantity.sendKeys("1");

			quantityUnits.click();

			webUtils.clickButtonOrLink(commondropdownList, "Units", logger,
					driver);

			// webUtils.explicitWaitByVisibilityofElement(driver, units);

			// units.click();
			webUtils.scrollDown(driver, approvedQuantity);
			
			approvedQuantity.sendKeys("1");

			approvedQuantityUnits.click();

			webUtils.clickButtonOrLink(commondropdownList, "Units", logger,
					driver);
			
			webUtils.explicitWaitByElementToBeClickable(driver, From);
			
			From.sendKeys(dataFromDate);
			
			Thru.sendKeys(dataThruDate);


			Thread.sleep(2000); // Added wait time for flow synchronization

			webUtils.scrollDown(driver, serviceDecisionDropdown);
			
			
			if (!("").equals(decision)) {
				logger.log(LogStatus.INFO, "Select the decision");
				webUtils.elementClickWithLogger(serviceDecisionDropdown,
						"Decision dropdown", logger, driver);
				// serviceDecisionDropdown.click();

				webUtils.clickButtonOrLink(commondropdownList, decision,
						logger, driver);
				
				logger.log(LogStatus.INFO, "Value for Decision Dropdown is : "+decision);
			}

 			Thread.sleep(2000); // Added wait time for flow synchronization

			if (!("").equals(decisionReason)) {

				logger.log(LogStatus.INFO, "Select the Decision Reason");

				webUtils.explicitWaitByElementToBeClickable(driver, 20,
						serviceDecisionReasonDropdown);

				webUtils.elementClickWithLogger(serviceDecisionReasonDropdown,
						"Decision Reason", logger, driver);
				// serviceDecisionReasonDropdown.click();

				webUtils.clickButtonOrLink(commondropdownList, decisionReason,
						logger, driver);
				logger.log(LogStatus.INFO, "Value for Decision Reason Dropdown is : "+decision);
			}
			if (!("").equals(criteria)) {
				logger.log(LogStatus.INFO, "Select the criteria");
				webUtils.elementClickWithLogger(serviceCriteriaDropdown,
						"Criteria dropdown", logger, driver);
				// serviceDecisionDropdown.click();

				webUtils.clickButtonOrLink(commondropdownList, criteria,
						logger, driver);
				logger.log(LogStatus.INFO, "Value for Criteria Dropdown is : "+decision);
			}
			if (!("").equals(policy)) {
				logger.log(LogStatus.INFO, "Select the policy");
				webUtils.elementClickWithLogger(servicePolicyDropdown,
						"Policy dropdown", logger, driver);
				// serviceDecisionDropdown.click();

				List<String> policies = new ArrayList<String>();
				
				for(WebElement pol : commondropdownList)
				{
					if(!(pol.getText().equals(""))){
									
					policies.add(pol.getText().toLowerCase());
					}
				}
				
				
				List<String> sortedPolicies = policies;
				
				Collections.sort(sortedPolicies);
				
				
				if(policies.equals(sortedPolicies)){
					logger.log(LogStatus.INFO, "Medical Policies are alphabetized in dropdown");
				}
				else
				{
					logger.log(LogStatus.INFO, "Medical Policies are not alphabetized in dropdown");
				}
				webUtils.clickButtonOrLink(commondropdownList, policy,
						logger, driver);
			}
			if (!("").equals(rationale)) {
				logger.log(LogStatus.INFO, "Select the rationale");
				webUtils.elementClickWithLogger(serviceRationaleDropdown,
						"Rationale dropdown", logger, driver);
				// serviceDecisionDropdown.click();

				webUtils.clickButtonOrLink(commondropdownList, rationale,
						logger, driver);
			}

		}

		webUtils.explicitWaitByVisibilityofElement(driver, 20, Save);

		Save.click();

		webUtils.explicitWaitByVisibilityofElement(driver, 20, Close);

		Close.click();

		Thread.sleep(2000); // Added wait time for flow synchronization

		try {

			if (yes.isDisplayed()) {

				Robot robot = new Robot();

				robot.keyPress(KeyEvent.VK_TAB);

				robot.keyRelease(KeyEvent.VK_TAB);


				robot.keyPress(KeyEvent.VK_ENTER);

				robot.keyRelease(KeyEvent.VK_ENTER);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	if ("BSC Inpatient".equalsIgnoreCase(requestType)){
		webUtils.explicitWaitByElementToBeClickable(driver, inpatientRequest);
		webUtils.rightClick(driver, inpatientRequest);
		webUtils.explicitWaitByElementToBeClickable(driver, Add);
		Add.click();
		webUtils.explicitWaitByElementToBeClickable(driver, 20,
				fromDate);	
		webUtils.moveToClickableElement(fromDate, driver);
		System.out.println(dataFromDate);
		Actions act = new Actions(driver);
		act.sendKeys(dataFromDate).build().perform();
		//fromDate.sendKeys(dataFromDate);
		webUtils.explicitWaitByElementToBeClickable(driver, 20,
				thruDate);	
		Thread.sleep(2000);// Added wait time for flow synchronization
		webUtils.moveToClickableElement(thruDate, driver);
		act.sendKeys(dataThruDate).build().perform();
		Thread.sleep(2000);// Added wait time for flow synchronization
		if (!("").equals(bedType)) {
			webUtils.explicitWaitByElementToBeClickable(driver, 20,
					bedTypeDropDown);

			bedTypeDropDown.click();

			webUtils.clickButtonOrLink(commondropdownList, bedType, logger,
					driver);
			logger.log(LogStatus.INFO, "Value for BedType Dropdown is : "+bedType);
		}
		
		if (!("").equals(decision)) {
			logger.log(LogStatus.INFO, "Select the decision");
			webUtils.elementClickWithLogger(decisionDropdown,
					"Decision dropdown ", logger, driver);

			// decisionDropdown.click();

			webUtils.clickButtonOrLink(commondropdownList, decision,
					logger, driver);
			logger.log(LogStatus.INFO, "Value for Decision Dropdown is : "+decision);
		}

		if (!("").equals(decisionReason)) {
			logger.log(LogStatus.INFO, "Select the decision reason ");
			webUtils.explicitWaitByElementToBeClickable(driver, 20,
					decisionReasonDropdown);

			webUtils.elementClickWithLogger(decisionReasonDropdown,
					"Decision Reason dropdown ", logger, driver);
			// decisionReasonDropdown.click();

			webUtils.clickButtonOrLink(commondropdownList, decisionReason,
					logger, driver);
			logger.log(LogStatus.INFO, "Value for Decision Reason Dropdown is : "+decisionReason);
		}
		if (!("").equals(criteria)) {
			webUtils.explicitWaitByElementToBeClickable(driver, 20,
					criteriaDropdown);

			criteriaDropdown.click();

			webUtils.clickButtonOrLink(commondropdownList, criteria, logger,
					driver);
			logger.log(LogStatus.INFO, "Value for Criteria Dropdown is : "+criteria);
		}
		if (!("").equals(policy)) {
			webUtils.explicitWaitByElementToBeClickable(driver, 20,
					policyDropdown);

			policyDropdown.click();

			webUtils.clickButtonOrLink(commondropdownList, policy, logger,
					driver);
		}
		if (!("").equals(rationale)) {
			
			Actions action = new Actions(driver);
			action.sendKeys(Keys.TAB).sendKeys(Keys.TAB).build().perform();
			action.sendKeys(Keys.DOWN).sendKeys(Keys.DOWN).build().perform();
			Thread.sleep(2000);
		}
		webUtils.explicitWaitByVisibilityofElement(driver, 20, Save);
		
		Save.click();
		
		webUtils.explicitWaitByVisibilityofElement(driver, 20, Close);

		Close.click();
		try {

			if (yes.isDisplayed()) {

				Robot robot = new Robot();

				robot.keyPress(KeyEvent.VK_TAB);

				robot.keyRelease(KeyEvent.VK_TAB);


				robot.keyPress(KeyEvent.VK_ENTER);

				robot.keyRelease(KeyEvent.VK_ENTER);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		}
		else {

			
			webUtils.rightClick(driver, serviceRequest);

			serviceRequestAdd.click();
			Thread.sleep(2000); // Added wait time for flow synchronization
			//code.click();
			Actions acti = new Actions(driver);
			//acti.sendKeys(Keys.TAB).build().perform();
			acti.sendKeys(procedureCode).build().perform();
			//acti.sendKeys(Keys.TAB).sendKeys(Keys.TAB).sendKeys(Keys.ENTER).build().perform();
			//public WebElement ele = driver.findElement(By.xpath("//div[contains(@id,'isc_CodesSearch')]//following-sibling::table[@role='presentation' and @class='listTable']//tbody//tr[1]"));
 			searchButton.get(1).click();
			webUtils.explicitWaitByElementToBeClickable(driver, firstRow);
			firstRow.click();
			webUtils.doubleClick(driver, firstRow);
			/*try{
				webUtils.doubleClick(driver, firstRow);
			}catch(Exception e){}*/
			
			webUtils.explicitWaitByElementToBeClickable(driver, quantity);
			
			
			quantity.sendKeys("1");

			quantityUnits.click();

			webUtils.clickButtonOrLink(commondropdownList, "Units", logger,
					driver);

			// webUtils.explicitWaitByVisibilityofElement(driver, units);

			// units.click();
			webUtils.scrollDown(driver, approvedQuantity);
			
			approvedQuantity.sendKeys("1");

			approvedQuantityUnits.click();

			webUtils.clickButtonOrLink(commondropdownList, "Units", logger,
					driver);
			
			webUtils.explicitWaitByElementToBeClickable(driver, From);
			
			From.sendKeys(dataFromDate);
			
			Thru.sendKeys(dataThruDate);


			Thread.sleep(3000); // Added wait time for flow synchronization

			webUtils.scrollDown(driver, serviceDecisionDropdown);
			
			
			if (!("").equals(decision)) {
				logger.log(LogStatus.INFO, "Select the decision");
				webUtils.elementClickWithLogger(serviceDecisionDropdown,
						"Decision dropdown", logger, driver);
				// serviceDecisionDropdown.click();

				webUtils.clickButtonOrLink(commondropdownList, decision,
						logger, driver);
			}

 			Thread.sleep(3000); // Added wait time for flow synchronization

			if (!("").equals(decisionReason)) {

				logger.log(LogStatus.INFO, "Select the Decision Reason");

				webUtils.explicitWaitByElementToBeClickable(driver, 20,
						serviceDecisionReasonDropdown);

				webUtils.elementClickWithLogger(serviceDecisionReasonDropdown,
						"Decision Reason", logger, driver);
				// serviceDecisionReasonDropdown.click();

				webUtils.clickButtonOrLink(commondropdownList, decisionReason,
						logger, driver);
			}
			if (!("").equals(criteria)) {
				logger.log(LogStatus.INFO, "Select the Criteria");
				webUtils.elementClickWithLogger(serviceCriteriaDropdown,
						"Criteria dropdown", logger, driver);
				// serviceDecisionDropdown.click();

				webUtils.clickButtonOrLink(commondropdownList, criteria,
						logger, driver);
			}
			if (!("").equals(policy)) {
				logger.log(LogStatus.INFO, "Select the policy");
				webUtils.elementClickWithLogger(servicePolicyDropdown,
						"Policy dropdown", logger, driver);
				// serviceDecisionDropdown.click();

				webUtils.clickButtonOrLink(commondropdownList, policy,
						logger, driver);
			}
			if (!("").equals(rationale)) {
				logger.log(LogStatus.INFO, "Select the rationale");
				webUtils.elementClickWithLogger(serviceRationaleDropdown,
						"Rationale dropdown", logger, driver);
				// serviceDecisionDropdown.click();

				webUtils.clickButtonOrLink(commondropdownList, rationale,
						logger, driver);
			}
			webUtils.explicitWaitByVisibilityofElement(driver, 20, Save);

			Save.click();

			webUtils.explicitWaitByVisibilityofElement(driver, 20, Close);

			Close.click();

			Thread.sleep(3000); // Added wait time for flow synchronization

			try {

				if (yes.isDisplayed()) {

					Robot robot = new Robot();

					robot.keyPress(KeyEvent.VK_TAB);

					robot.keyRelease(KeyEvent.VK_TAB);


					robot.keyPress(KeyEvent.VK_ENTER);

					robot.keyRelease(KeyEvent.VK_ENTER);
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
			
		
		}
		
		
	}
	public void selectDecisionWithLineFEPRx(WebDriver driver, ExtentTest logger,
			String decision, String decisionReason, String bedType,
			String requestType, String taskName,String type,String dataFromDate,String dataThruDate,String criteria,String policy,String rationale) throws InterruptedException {

		try {
			webUtils.explicitWaitByElementToBeClickable(driver, 20, closePopup);

			if (closePopup.isDisplayed()) {

				closePopup.click();
			}
		} catch (Exception e) {
			System.out.println("closePopup validation is skipped");
		}
		
			webUtils.scrollDown(driver, taskreview);

			webUtils.rightClick(driver, taskreview);

			webUtils.explicitWaitByElementToBeClickable(driver, 20, edit);

			logger.log(LogStatus.INFO, "Edit the Request");
			
			
			if(edit.isDisplayed()&&edit.isEnabled()){

			edit.click();
			}
			else{
				
				logger.log(LogStatus.INFO, "Prior uthorization request is already Approved or Denied");
				
			}
			
		/*else{
			
			if(inpatientAuthStatus.getText().equals(" ")){
				
				webUtils.scrollDown(driver, taskreview);

				webUtils.rightClick(driver, taskreview);

				webUtils.explicitWaitByElementToBeClickable(driver, 20, edit);

				logger.log(LogStatus.INFO, "Edit the Request");

				edit.click();
				}else{
					
					System.out.println("The prior authorization statsus is "+inpatientAuthStatus.getText());
					
					logger.log(LogStatus.INFO, "Prior Authorization status is "+inpatientAuthStatus.getText());
				}
		}
		
*/
		

		webUtils.fluentWait(driver, "//b[contains(text(),'Review Type')]");

		if ("BSC Inpatient".equalsIgnoreCase(requestType)) {

			webUtils.scrollDown(driver, inpatientRequest);

			inpatientRequest.click();

			webUtils.rightClick(driver, inpatientRequest);

			Edit.click();

			if (!("").equals(bedType)) {
				webUtils.explicitWaitByElementToBeClickable(driver, 20,
						bedTypeDropDown);

				bedTypeDropDown.click();

				webUtils.clickButtonOrLink(commondropdownList, bedType, logger,
						driver);
			}

			Thread.sleep(3000); // Added wait time for flow synchronization

			if (!("").equals(decision)) {
				logger.log(LogStatus.INFO, "Select the decision");
				webUtils.elementClickWithLogger(decisionDropdown,
						"Decision dropdown ", logger, driver);

				// decisionDropdown.click();

				webUtils.clickButtonOrLink(commondropdownList, decision,
						logger, driver);
			}

			if (!("").equals(decisionReason)) {
				logger.log(LogStatus.INFO, "Select the decision reason ");
				webUtils.explicitWaitByElementToBeClickable(driver, 20,
						decisionReasonDropdown);

				webUtils.elementClickWithLogger(decisionReasonDropdown,
						"Decision Reason dropdown ", logger, driver);
				// decisionReasonDropdown.click();

				webUtils.clickButtonOrLink(commondropdownList, decisionReason,
						logger, driver);
			}
			
			if (!("").equals(criteria)) {
				webUtils.explicitWaitByElementToBeClickable(driver, 20,
						criteriaDropdown);

				criteriaDropdown.click();

				webUtils.clickButtonOrLink(commondropdownList, criteria, logger,
						driver);
			}
			if (!("").equals(policy)) {
				webUtils.explicitWaitByElementToBeClickable(driver, 20,
						policyDropdown);

				policyDropdown.click();
List<String> policies = new ArrayList<String>();
				
				for( WebElement pol : commondropdownList)
				{
					if(!(pol.getText().equals(""))){
									
					policies.add(pol.getText().toLowerCase());
					}
				}
				
				
				List<String> sortedPolicies = policies;
				
				Collections.sort(sortedPolicies);
				System.out.println(policies);
				System.out.println(sortedPolicies);
				if(policies.equals(sortedPolicies)){
					logger.log(LogStatus.INFO, "Medical Policies are alphabetized in dropdown");
				}
				else
				{
					logger.log(LogStatus.INFO, "Medical Policies are not alphabetized in dropdown");
				}
				



				webUtils.clickButtonOrLink(commondropdownList, policy, logger,
						driver);
			}
			if (!("").equals(rationale)) {
				
				Actions action = new Actions(driver);
				action.sendKeys(Keys.TAB).sendKeys(Keys.TAB).build().perform();
				action.sendKeys(Keys.DOWN).sendKeys(Keys.DOWN).build().perform();
				Thread.sleep(2000);// Added wait time for flow synchronization
				/*webUtils.explicitWaitByElementToBeClickable(driver, 20,
						rationaleDropdown);

				rationaleDropdown.click();

				webUtils.clickButtonOrLink(commondropdownList, rationale, logger,
						driver);*/
			}
			

		} 
		else {

			webUtils.scrollDown(driver, serviceRequest);

			serviceRequest.click();

			webUtils.rightClick(driver, serviceRequest);

			serviceRequestEdit.click();

			quantity.sendKeys("1");

			quantityUnits.click();

			webUtils.clickButtonOrLink(commondropdownList, "Units", logger,
					driver);

			// webUtils.explicitWaitByVisibilityofElement(driver, units);

			// units.click();
			webUtils.scrollDown(driver, approvedQuantity);
			
			approvedQuantity.sendKeys("1");

			approvedQuantityUnits.click();

			webUtils.clickButtonOrLink(commondropdownList, "Units", logger,
					driver);
			
			webUtils.explicitWaitByElementToBeClickable(driver, From);
			
			From.sendKeys(dataFromDate);
			
			Thru.sendKeys(dataThruDate);


			Thread.sleep(3000); // Added wait time for flow synchronization

			webUtils.scrollDown(driver, serviceDecisionDropdown);
			
			
			if (!("").equals(decision)) {
				logger.log(LogStatus.INFO, "Select the decision");
				webUtils.elementClickWithLogger(serviceDecisionDropdown,
						"Decision dropdown", logger, driver);
				// serviceDecisionDropdown.click();

				webUtils.clickButtonOrLink(commondropdownList, decision,
						logger, driver);
			}

 			Thread.sleep(3000); // Added wait time for flow synchronization

			if (!("").equals(decisionReason)) {

				logger.log(LogStatus.INFO, "Select the Decision Reason");

				webUtils.explicitWaitByElementToBeClickable(driver, 20,
						serviceDecisionReasonDropdown);

				webUtils.elementClickWithLogger(serviceDecisionReasonDropdown,
						"Decision Reason", logger, driver);
				// serviceDecisionReasonDropdown.click();

				webUtils.clickButtonOrLink(commondropdownList, decisionReason,
						logger, driver);
			}
			if (!("").equals(criteria)) {
				logger.log(LogStatus.INFO, "Select the criteria");
				webUtils.elementClickWithLogger(serviceCriteriaDropdown,
						"Criteria dropdown", logger, driver);
				// serviceDecisionDropdown.click();

				webUtils.clickButtonOrLink(commondropdownList, criteria,
						logger, driver);
			}
			if (!("").equals(policy)) {
				logger.log(LogStatus.INFO, "Select the policy");
				webUtils.elementClickWithLogger(servicePolicyDropdown,
						"Policy dropdown", logger, driver);
				// serviceDecisionDropdown.click();
				List<String> policies = new ArrayList<String>();
				
				for(WebElement pol : commondropdownList)
				{
					if(!(pol.getText().equals(""))){
									
					policies.add(pol.getText().toLowerCase());
					}
				}
				webUtils.clickButtonOrLink(commondropdownList, policy,
						logger, driver);
				
				List<String> sortedPolicies = policies;
				
				Collections.sort(sortedPolicies);
				
				
				if(policies.equals(sortedPolicies)){
					logger.log(LogStatus.INFO, "Medication Policies are alphabetized in dropdown");
				}
				else
				{
					logger.log(LogStatus.INFO, "Medication Policies are not alphabetized in dropdown");
				}
			
				Thread.sleep(2000); // Added wait time for flow synchronization
				
			}
			if (!("").equals(rationale)) {
				logger.log(LogStatus.INFO, "Select the rationale");
				webUtils.elementClickWithLogger(serviceRationaleDropdown,
						"Policy dropdown", logger, driver);
				// serviceDecisionDropdown.click();

				webUtils.clickButtonOrLink(commondropdownList, rationale,
						logger, driver);
			}

		}

		webUtils.explicitWaitByVisibilityofElement(driver, 20, Save);

		Save.click();

		webUtils.explicitWaitByVisibilityofElement(driver, 20, Close);

		Close.click();

		Thread.sleep(3000); // Added wait time for flow synchronization

		try {

			if (yes.isDisplayed()) {

				Robot robot = new Robot();

				robot.keyPress(KeyEvent.VK_TAB);

				robot.keyRelease(KeyEvent.VK_TAB);


				robot.keyPress(KeyEvent.VK_ENTER);

				robot.keyRelease(KeyEvent.VK_ENTER);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	if ("BSC Inpatient".equalsIgnoreCase(requestType)){
		webUtils.explicitWaitByElementToBeClickable(driver, inpatientRequest); 
		webUtils.rightClick(driver, inpatientRequest);
		webUtils.explicitWaitByElementToBeClickable(driver, Add);
		Add.click();
		webUtils.explicitWaitByElementToBeClickable(driver, 20,
				fromDate);	
		webUtils.moveToClickableElement(fromDate, driver);
		System.out.println(dataFromDate);
		Actions act = new Actions(driver);
		act.sendKeys(dataFromDate).build().perform();
		//fromDate.sendKeys(dataFromDate);
		webUtils.explicitWaitByElementToBeClickable(driver, 20,
				thruDate);	
		Thread.sleep(2000);// Added wait time for flow synchronization
		webUtils.moveToClickableElement(thruDate, driver);
		act.sendKeys(dataThruDate).build().perform();
		Thread.sleep(2000);// Added wait time for flow synchronization
		if (!("").equals(bedType)) {
			webUtils.explicitWaitByElementToBeClickable(driver, 20,
					bedTypeDropDown);

			bedTypeDropDown.click();

			webUtils.clickButtonOrLink(commondropdownList, bedType, logger,
					driver);
		}
		
		if (!("").equals(decision)) {
			logger.log(LogStatus.INFO, "Select the decision");
			webUtils.elementClickWithLogger(decisionDropdown,
					"Decision dropdown ", logger, driver);

			// decisionDropdown.click();

			webUtils.clickButtonOrLink(commondropdownList, decision,
					logger, driver);
		}

		if (!("").equals(decisionReason)) {
			logger.log(LogStatus.INFO, "Select the decision reason ");
			webUtils.explicitWaitByElementToBeClickable(driver, 20,
					decisionReasonDropdown);

			webUtils.elementClickWithLogger(decisionReasonDropdown,
					"Decision Reason dropdown ", logger, driver);
			// decisionReasonDropdown.click();

			webUtils.clickButtonOrLink(commondropdownList, decisionReason,
					logger, driver);
		}
		if (!("").equals(criteria)) {
			webUtils.explicitWaitByElementToBeClickable(driver, 20,
					criteriaDropdown);

			criteriaDropdown.click();

			webUtils.clickButtonOrLink(commondropdownList, criteria, logger,
					driver);
		}
		if (!("").equals(policy)) {
			webUtils.explicitWaitByElementToBeClickable(driver, 20,
					policyDropdown);

			policyDropdown.click();

			webUtils.clickButtonOrLink(commondropdownList, policy, logger,
					driver);
		}
		if (!("").equals(rationale)) {
			
			Actions action = new Actions(driver);
			action.sendKeys(Keys.TAB).sendKeys(Keys.TAB).build().perform();
			action.sendKeys(Keys.DOWN).sendKeys(Keys.DOWN).build().perform();
			Thread.sleep(2000);// Added wait time for flow synchronization
		}
		webUtils.explicitWaitByVisibilityofElement(driver, 20, Save);
		
		Save.click();
		
		webUtils.explicitWaitByVisibilityofElement(driver, 20, Close);

		Close.click();
		try {

			if (yes.isDisplayed()) {

				Robot robot = new Robot();

				robot.keyPress(KeyEvent.VK_TAB);

				robot.keyRelease(KeyEvent.VK_TAB);


				robot.keyPress(KeyEvent.VK_ENTER);

				robot.keyRelease(KeyEvent.VK_ENTER);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		}
		else {

			
			webUtils.rightClick(driver, serviceRequest);

			serviceRequestAdd.click();
			Thread.sleep(2000); // Added wait time for flow synchronization
			//code.click();
			Actions acti = new Actions(driver);
			//acti.sendKeys(Keys.TAB).build().perform();
			acti.sendKeys("L1110").build().perform();
			//acti.sendKeys(Keys.TAB).sendKeys(Keys.TAB).sendKeys(Keys.ENTER).build().perform();
			//public WebElement ele = driver.findElement(By.xpath("//div[contains(@id,'isc_CodesSearch')]//following-sibling::table[@role='presentation' and @class='listTable']//tbody//tr[1]"));
 			searchButton.get(1).click();
			webUtils.explicitWaitByElementToBeClickable(driver, firstRow);
			firstRow.click();
			webUtils.doubleClick(driver, firstRow);
			/*try{
				webUtils.doubleClick(driver, firstRow);
			}catch(Exception e){}*/
			
			Thread.sleep(3000);// Added wait time for flow synchronization
			
			//public WebElement vscroll = driver.findElement(By.xpath("//div[@eventproxy='isc_VLayout_31_vscroll_thumb']"));
			webUtils.scrollUP(driver, quantity);
			quantity.sendKeys("1");

			quantityUnits.click();

			webUtils.clickButtonOrLink(commondropdownList, "Units", logger,
					driver);

			// webUtils.explicitWaitByVisibilityofElement(driver, units);

			// units.click();
			webUtils.scrollDown(driver, approvedQuantity);
			
			approvedQuantity.sendKeys("1");

			approvedQuantityUnits.click();

			webUtils.clickButtonOrLink(commondropdownList, "Units", logger,
					driver);
			
			webUtils.explicitWaitByElementToBeClickable(driver, From);
			
			From.sendKeys(dataFromDate);
			
			Thru.sendKeys(dataThruDate);


			Thread.sleep(3000); // Added wait time for flow synchronization

			webUtils.scrollDown(driver, serviceDecisionDropdown);
			
			
			if (!("").equals(decision)) {
				logger.log(LogStatus.INFO, "Select the decision");
				webUtils.elementClickWithLogger(serviceDecisionDropdown,
						"Decision dropdown", logger, driver);
				// serviceDecisionDropdown.click();

				webUtils.clickButtonOrLink(commondropdownList, decision,
						logger, driver);
			}

 			Thread.sleep(3000); // Added wait time for flow synchronization

			if (!("").equals(decisionReason)) {

				logger.log(LogStatus.INFO, "Select the Decision Reason");

				webUtils.explicitWaitByElementToBeClickable(driver, 20,
						serviceDecisionReasonDropdown);

				webUtils.elementClickWithLogger(serviceDecisionReasonDropdown,
						"Decision Reason", logger, driver);
				// serviceDecisionReasonDropdown.click();

				webUtils.clickButtonOrLink(commondropdownList, decisionReason,
						logger, driver);
			}
			if (!("").equals(criteria)) {
				logger.log(LogStatus.INFO, "Select the decision");
				webUtils.elementClickWithLogger(serviceCriteriaDropdown,
						"Criteria dropdown", logger, driver);
				// serviceDecisionDropdown.click();

				webUtils.clickButtonOrLink(commondropdownList, criteria,
						logger, driver);
			}
			if (!("").equals(policy)) {
				logger.log(LogStatus.INFO, "Select the decision");
				webUtils.elementClickWithLogger(servicePolicyDropdown,
						"Policy dropdown", logger, driver);
				// serviceDecisionDropdown.click();

				webUtils.clickButtonOrLink(commondropdownList, policy,
						logger, driver);
			}
			if (!("").equals(rationale)) {
				logger.log(LogStatus.INFO, "Select the decision");
				webUtils.elementClickWithLogger(serviceRationaleDropdown,
						"Policy dropdown", logger, driver);
				// serviceDecisionDropdown.click();

				webUtils.clickButtonOrLink(commondropdownList, rationale,
						logger, driver);
			}
			webUtils.explicitWaitByVisibilityofElement(driver, 20, Save);

			Save.click();

			webUtils.explicitWaitByVisibilityofElement(driver, 20, Close);

			Close.click();

			Thread.sleep(3000); // Added wait time for flow synchronization

			try {

				if (yes.isDisplayed()) {

					Robot robot = new Robot();

					robot.keyPress(KeyEvent.VK_TAB);

					robot.keyRelease(KeyEvent.VK_TAB);


					robot.keyPress(KeyEvent.VK_ENTER);

					robot.keyRelease(KeyEvent.VK_ENTER);
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
			
		
		}
		
		
	}

	/**
	 * Selecting Auth Decision
	 * 
	 * @throws InterruptedException
	 */

	public void selectAuthorizationDecision(String decision,
			String decisionReason, WebDriver driver, String testCaseType,String serviceCat ,ExtentTest logger)
			throws InterruptedException {
		try
		{
		webUtils.scrollDown(driver, serviceCategory);
		webUtils.explicitWaitByElementToBeClickable(driver, serviceCategory);
		serviceCategory.click();
		/*Thread.sleep(2000);
		public WebElement option = driver.findElement(By.xpath("//*[text()='"+serviceCat+"']"));
		System.out.println(option);
		option.click();*/
		Thread.sleep(4000);// Added wait time for flow synchronization
		Actions action = new Actions(driver);
		action.sendKeys(Keys.DOWN).build().perform();
		action.sendKeys(Keys.ENTER).build().perform();
		Thread.sleep(3000);
		}
		catch(Exception e){
			e.printStackTrace();
		}
		//serviceCategory.sendKeys(Keys.ARROW_DOWN);
		webUtils.scrollDown(driver, authDecision);
		
		Thread.sleep(5000); // Added wait time for flow synchronization
if (!authDecision.isDisplayed() && !authDecision.isEnabled()) {
	Thread.sleep(1000);
}

		
		if (!("").equals(decision)) {

			webUtils.elementClickWithLogger(authDecision,
					"Authorization Decision", logger, driver);
			// authDecision.click();
          
			webUtils.clickButtonOrLink(commondropdownList, decision, logger,
					driver);

		}

		if (!("").equals(decisionReason)) {

			webUtils.explicitWaitByElementToBeClickable(driver, 20,
					authDecisionReason);

			webUtils.elementClickWithLogger(authDecisionReason,
					"Authorization Decision Reason", logger, driver);
			// authDecisionReason.click();

			webUtils.clickButtonOrLink(commondropdownList, decisionReason,
					logger, driver);

		}


		
		
	}
	public void selectAuthorizationDecisionWithNurseRecom(String decision,
			String decisionReason, WebDriver driver, String testCaseType,String serviceCat ,String mdName,ExtentTest logger)
			throws InterruptedException {
		try
		{
		webUtils.scrollDown(driver, serviceCategory);
		Thread.sleep(4000);
		serviceCategory.click();
		/*Thread.sleep(2000);
		public WebElement option = driver.findElement(By.xpath("//*[text()='"+serviceCat+"']"));
		System.out.println(option);
		option.click();*/
		Thread.sleep(4000);
		Actions action = new Actions(driver);
		action.sendKeys(Keys.DOWN).build().perform();
		action.sendKeys(Keys.ENTER).build().perform();
		Thread.sleep(3000);
		}
		catch(Exception e){
			e.printStackTrace();
		}
		//serviceCategory.sendKeys(Keys.ARROW_DOWN);
		webUtils.scrollDown(driver, authDecision);
		
		Thread.sleep(5000); // Added wait time for flow synchronization

		if (!("").equals(decision)) {

			webUtils.elementClickWithLogger(authDecision,
					"Authorization Decision", logger, driver);
			// authDecision.click();

			webUtils.clickButtonOrLink(commondropdownList, decision, logger,
					driver);

		}

		if (!("").equals(decisionReason)) {

			webUtils.explicitWaitByElementToBeClickable(driver, 20,
					authDecisionReason);

			webUtils.elementClickWithLogger(authDecisionReason,
					"Authorization Decision Reason", logger, driver);
			// authDecisionReason.click();

			webUtils.clickButtonOrLink(commondropdownList, decisionReason,
					logger, driver);

		}
		
		webUtils.scrollDown(driver, recommendations);
		
		Thread.sleep(3000);
		webUtils.rightClick(driver, recommendationsGrid.get(recommendationsGrid.size()-2));
		
		webUtils.explicitWaitByElementToBeClickable(driver, addNurseRecom);
		
		addNurseRecom.click();
		Thread.sleep(3000);
		webUtils.moveToClickableElement(recomType, driver);
		
		webUtils.clickButtonOrLink(commondropdownList, "Nurse Recommendation", logger, driver);
		
		Thread.sleep(3000);
		webUtils.moveToClickableElement(reconOption, driver);
		Thread.sleep(3000);
		/*webUtils.fluentWait(driver, "//div[contains(@class,'pickListMenuBody')]/div/table/tbody/tr");
		webUtils.clickButtonOrLink(driver.findElements(By.xpath("//div[contains(@class,'pickListMenuBody')]/div/table/tbody/tr")), "Reconsideration", logger, driver);
	*/	
		Actions acti = new Actions(driver);
		acti.sendKeys(Keys.DOWN).sendKeys(Keys.ENTER).build().perform();
		
		Thread.sleep(3000);
		webUtils.explicitWaitByElementToBeClickable(driver, saveCancelReason.get(saveCancelReason.size()-1));
		saveCancelReason.get(saveCancelReason.size()-1).click();
			
		  Thread.sleep(3000);
	      webUtils.rightClick(driver, recommendationsGrid.get(recommendationsGrid.size()-2));
	      Thread.sleep(2000);
	      
	      webUtils.explicitWaitByElementToBeClickable(driver,10, addMDRecom);
	      
	      addMDRecom.click();
	      Thread.sleep(3000);
		webUtils.moveToClickableElement(recomType, driver);
		
		webUtils.clickButtonOrLink(commondropdownList, "MD Recommendation", logger, driver);
		

	      
		 Thread.sleep(3000);
	      webUtils.moveToClickableElement(medDirName, driver);
	      Thread.sleep(3000);
	     
	      //Actions acti3 = new Actions(driver);
	     // acti3.sendKeys(Keys.DOWN).sendKeys(Keys.ENTER).build().perform();
	      webUtils.fluentWait(driver, "//div[contains(@class,'pickListMenuBody')]/div/table/tbody/tr");
		  List<WebElement> doctorsList = driver.findElements(By.xpath("//div[contains(@class,'pickListMenuBody')]/div/table/tbody/tr"));
		  Thread.sleep(1000);
		  webUtils.clickButtonOrLink(doctorsList, mdName, logger, driver);
		   
		      
		      Thread.sleep(3000);
	      webUtils.moveToClickableElement(medDetermination, driver);
	      Thread.sleep(3000);
	      
	      acti.sendKeys(Keys.DOWN).sendKeys(Keys.DOWN).sendKeys(Keys.ENTER).build().perform();
	            
	      Thread.sleep(3000);
	      webUtils.explicitWaitByElementToBeClickable(driver,10,saveCancelReason.get(saveCancelReason.size()-1));
	      saveCancelReason.get(saveCancelReason.size()-1).click();
	                 

		
		
	}
	

	public void selectAuthorizationDecisionWithMDRecom(String decision,
			String decisionReason, WebDriver driver, String testCaseType,String serviceCat ,String mdName ,ExtentTest logger)
			throws InterruptedException, AWTException {
		logger.log(LogStatus.INFO, "In MD Recommendation block");
		try
		{
			System.out.println("In MD Recommendation block");
		//webUtils.scrollDown(driver, serviceCategory);
		Thread.sleep(4000);
	//	System.out.println("serviceCategory::::::::::"+serviceCategory.isDisplayed());
	//	System.out.println("serviceCategory::::::::::"+MDScroll.isDisplayed());
		
	//	serviceCategory.click();
		/*Thread.sleep(2000);
		public WebElement option = driver.findElement(By.xpath("//*[text()='"+serviceCat+"']"));
		System.out.println(option);
		option.click();*/
		Thread.sleep(4000);
		Actions action = new Actions(driver);
		action.sendKeys(Keys.DOWN).build().perform();
		action.sendKeys(Keys.ENTER).build().perform();
		Thread.sleep(3000);
		}
		catch(Exception e){
			logger.log(LogStatus.INFO, "Error/Exception while adding MD Recommendation.");
			System.out.println("Exceptions in MD Block");
		}
	         
		//serviceCategory.sendKeys(Keys.ARROW_DOWN);
		webUtils.scrollDown(driver, authDecision);
		
		Thread.sleep(5000); // Added wait time for flow synchronization

		if (!"".equals(decision)) {

			webUtils.elementClickWithLogger(authDecision,
					"Authorization Decision", logger, driver);
			// authDecision.click();

			webUtils.clickButtonOrLink(commondropdownList, decision, logger,
					driver);

		}

		if (!"".equals(decisionReason)) {

			webUtils.explicitWaitByElementToBeClickable(driver, 20,
					authDecisionReason);

			webUtils.elementClickWithLogger(authDecisionReason,
					"Authorization Decision Reason", logger, driver);
			// authDecisionReason.click();

			webUtils.clickButtonOrLink(commondropdownList, decisionReason,
					logger, driver);

		}
		
		  webUtils.scrollDown(driver, recommendations);
	      
	      Thread.sleep(3000);
	      webUtils.rightClick(driver, recommendationsGrid.get(recommendationsGrid.size()-2));
	      Thread.sleep(2000);
	      
	      webUtils.explicitWaitByElementToBeClickable(driver,10, addMDRecom);
	      
	      addMDRecom.click();
	      Thread.sleep(3000);
	      	
		  webUtils.moveToClickableElement(recomType, driver);
		  webUtils.clickButtonOrLink(commondropdownList, "MD Recommendation", logger, driver);
		  Thread.sleep(2000);
		  System.out.println("MDDetermination:::::"+MDDetermination.isDisplayed());
		 
		  Robot robot = new Robot();
		  /*The below is to select the MD Name*/
		  robot.keyPress(KeyEvent.VK_TAB);
		  robot.keyPress(KeyEvent.VK_TAB);
		  robot.keyPress(KeyEvent.VK_TAB);
		  robot.keyRelease(KeyEvent.VK_TAB);
		  Thread.sleep(2000);
		  robot.keyPress(KeyEvent.VK_DOWN);
		  robot.keyRelease(KeyEvent.VK_DOWN);
		  Thread.sleep(2000);
		  robot.keyPress(KeyEvent.VK_TAB);
		  robot.keyPress(KeyEvent.VK_DOWN);
		  robot.keyRelease(KeyEvent.VK_TAB);
		  robot.keyRelease(KeyEvent.VK_DOWN);
		  Thread.sleep(2000);
		  /* select MD Determination as denied*/
		  robot.keyPress(KeyEvent.VK_TAB);
		  robot.keyRelease(KeyEvent.VK_TAB);
		  Thread.sleep(2000);
		  robot.keyPress(KeyEvent.VK_DOWN);
		  robot.keyRelease(KeyEvent.VK_DOWN);
		  robot.keyRelease(KeyEvent.VK_TAB);
		  robot.keyRelease(KeyEvent.VK_DOWN);
		  Thread.sleep(2000);
		  robot.keyPress(KeyEvent.VK_DOWN);
		  robot.keyRelease(KeyEvent.VK_DOWN);
		  Thread.sleep(2000);
		/*
		 * webUtils.moveToClickableElement(MDDetermination, driver);
		 * webUtils.clickButtonOrLink(commondropdownList, "Deny", logger, driver);
		 * Thread.sleep(2000);
		 */ 
		 
		  
         //  System.out.println("MDNotes::::"+MDnotes.isDisplayed());
	      Thread.sleep(3000);
	      MDnotes.sendKeys("TEST");
	      Thread.sleep(2000);
	      System.out.println("Before Save bitton");
	      
	      Actions acti3 = new Actions(driver);
	      acti3.sendKeys(Keys.DOWN).sendKeys(Keys.DOWN).sendKeys(Keys.ENTER).build().perform();
          
	      Thread.sleep(3000);
	      webUtils.explicitWaitByElementToBeClickable(driver,10,saveCancelReason.get(saveCancelReason.size()-1));
	      saveCancelReason.get(saveCancelReason.size()-1).click();
	 		
		
	}

	
	
	public void correspondanceGenerateForNOPSR(String letterRequired,String lettertype,WebDriver driver,ExtentTest logger){
		try {
			webUtils.explicitWaitByVisibilityofElement(driver, 40, reviewFirstRow);
			webUtils.rightClick(driver, reviewFirstRow);
			Thread.sleep(2000);
			editList.click();
			System.out.println("Right click has been done");
			Thread.sleep(2000);

			generateLetter(driver, letterRequired, lettertype, logger);
		}
		catch(Exception e) {
			e.printStackTrace();
		}
	}
	

	/**
	 * Verification of the letter generated
	 * 
	 * @throws InterruptedException
	 */
	public void correspondanceVerify(String letterRequired,String lettertype,String decisionReason,String decision,WebDriver driver,
			ExtentTest logger)  {
		try {

			System.out.println("Entered Verification");
			webUtils.scrollDown(driver, SaveRequest);
			Thread.sleep(3000);
			webUtils.explicitWaitByElementToBeClickable(driver, 30, SaveRequest);
			SaveRequest.click();
			System.out.println("Save After Letter Generation");
			Thread.sleep(3000);
			webUtils.moveToClickableElement(cancelButton.get(0), driver);
			try{
			if(cancelButton.get(0).isDisplayed()){
				cancelButton.get(0).click();			
			}
			}
			catch(Exception e){
				System.out.println("cancelButton validation is skipped");
			}
			//webUtils.moveToClickableElement(cancelButton.get(0), driver);
			//cancelButton.get(0).click();
			//webUtils.explicitWaitByElementToBeClickable(driver, 30, cancelButton.get(0));
			//webUtils.elementClickWithLogger(cancelButton.get(0), "Cancel", logger, driver);
			//cancelButton.get(0).click();
			System.out.println("Cancel Clicked");
			//System.out.println("Back To Member 360 Page");
			Thread.sleep(7000);
			
			
				
		
		}
		catch(Exception e) {
			e.printStackTrace();
		}
	}
	public void correspondanceGenerate(String letterRequired,String lettertype,String decisionReason,String decision,WebDriver driver,String testCaseType,String serviceCat,
		ExtentTest logger) {
		try {

			
			webUtils.explicitWaitByVisibilityofElement(driver, 40, reviewFirstRow);
			webUtils.rightClick(driver, reviewFirstRow);
			Thread.sleep(2000);
			editList.click();
			System.out.println("Right click has been done");
			Thread.sleep(2000);
			//webUtils.moveToClickableElement(inpatientRow, driver);
			webUtils.scrollDown(driver, inpatientRow);
			webUtils.rightClick(driver, inpatientRow);
			System.out.println("Right click done on inpateint row");
			Thread.sleep(3000);
			editList1.get(1).click();
			System.out.println("Edit has been clicked 2");
			Thread.sleep(3000);
			logger.log(LogStatus.INFO, "Select Decision Dropdown");
			decisionDropdown.click();
			webUtils.clickButtonOrLink(commondropdownList, decision, logger, driver);
			System.out.println("Decision is :"+decision);
			
			logger.log(LogStatus.INFO, "Select Decision Reason Dropdown");
			decisionReasonDropdown.click();
			webUtils.clickButtonOrLink(commondropdownList, decisionReason, logger, driver);
			
			Save.click();
			//change
			try{
				if(yesButton.isDisplayed()){
					yesButton.click();
					Save.click();
				}
				
			}
			catch(Exception e){
				System.out.println("yesbutton validation is skipped");
			}
			
			
			
			System.out.println("Save button is clicked");
			Close.click();
			System.out.println("Close Button has been Clicked");
			logger.log(LogStatus.INFO, "Close Button has been clicked");
			
			webUtils.scrollDown(driver, authDecision);
			selectAuthorizationDecision(decision, decisionReason, driver,testCaseType,serviceCat, logger);
			
			try{
				if(yesButton.isDisplayed()){
					yesButton.click();
					
				}
				
			}
			catch(Exception e){
				System.out.println("yesButton validation is skipped");
			}
			SaveRequest.click();
			System.out.println("Save has been Clicked !!!");
			Thread.sleep(6000);
			webUtils.explicitWaitByVisibilityofElement(driver, 50, reviewFirstRow);
			webUtils.moveToClickableElement(reviewFirstRow, driver);
			webUtils.rightClick(driver, reviewFirstRow);
			View.click();
			System.out.println("View has been Clicked");
			logger.log(LogStatus.INFO, "Right Click and Select View");
			
			Thread.sleep(3000);
			/*webUtils.explicitWaitByVisibilityofElement(driver, 20, servicerighClickArea);
			webUtils.rightClick(driver, servicerighClickArea);*/
			System.out.println("Generate Letter has been called");
			generateLetter(driver, letterRequired, lettertype, logger);
			System.out.println("Out");
			
			
			
			
			
			
		
		}
		catch(Exception e) {
			e.printStackTrace();
		}
	}
		
		
		
		
		
		
		
	//}
	/**
	 * Generating the Letters.
	 * 
	 * @throws InterruptedException
	 */
	public void generateLetter(WebDriver driver, String letterRequired,
			String lettertype,ExtentTest logger) {
		try {


			if ("Yes".equalsIgnoreCase(letterRequired)) {

				int letterflag = 0;

				webUtils.rightClick(driver, servicerighClickArea);

				webUtils.explicitWaitByElementToBeClickable(driver, 40,
						correspondance);
				
				correspondance.click();

				webUtils.explicitWaitByVisibilityofElement(driver, 20, search);

				search.sendKeys(lettertype);
				
				Actions actio = new Actions(driver);
				actio.sendKeys(Keys.ENTER).build().perform();

				/*Robot robot = new Robot();


				robot.keyPress(KeyEvent.VK_ENTER);

				robot.keyRelease(KeyEvent.VK_ENTER);*/

				// webUtils.explicitWaitByPresenceofElement(driver,
				// "//div[contains(@eventproxy,'isc_CorrespondanceGrid_')]//table[@class='listTable']//tr/td[2]");

				Thread.sleep(5000); // Added wait time for flow synchronization

				// PageFactory.initElements(driver,
				// AuthAccelPriorAuthReviewPage.class);

				for (WebElement letterType : letterTypeList) {
					
					WebDriverWait wait = new WebDriverWait(driver,25);
					
					wait.until(ExpectedConditions.not(ExpectedConditions.stalenessOf(letterType)));

					System.out.println("The letter text is " + letterType.getText());

					System.out.println("The letter type from datasheet is "
							+ lettertype);
					
					
					if (letterType.getText().trim()
							.equalsIgnoreCase(lettertype.trim() + "_Member")||letterType.getText().trim()
							.equalsIgnoreCase(lettertype.trim() + "_Mem")
							 ) {
						
						if(letterType.getText().trim().equalsIgnoreCase(
								"UM RX Partial Denial_Member")||letterType.getText().trim().equalsIgnoreCase(
										"UM LOI Outpatient_Member")){
							generateRxPartialDenialLetter(letterType,lettertype, driver,logger);
							
							break;
							
							
						}else{

						System.out.println("Clicking on  member letter!!");

						webUtils.mouseOver(letterType, driver);
						Thread.sleep(2000);
						if (!sendToCorrespondance.isDisplayed()&& !sendToCorrespondance.isEnabled()) {
							Thread.sleep(2000);
						}
						webUtils.mouseOver(sendToCorrespondance, driver);

						sendToCorrespondance.click();

						/*
						 * webUtils.mouseOver(sendToCorrespondance, driver);
						 * 
						 * Thread.sleep(5000); // Added wait time for flow synchronization
						 */

						// webUtils.moveToTextBoxusingKeys(sendToCorrespondance,
						// Keys.ENTER, driver);

						// sendToCorrespondance.sendKeys(Keys.ENTER);
						// sendToCorrespondance.click();

						

						try {
							
							webUtils.explicitWaitByVisibilityofElement(driver, 200, okBtn);

							okBtn.click();

							Thread.sleep(5000); // Added wait time for flow synchronization

							if (okBtn.isDisplayed()) {

								okBtn.click();
							}
							else if (selectedOK.isDisplayed()) {

								selectedOK.click();
								System.out.println("System Error:  Please enter MD Recommendation Note");
							}
							
						} catch (Exception e) {
							System.out.println("selectedOK validation is skipped");
						}

						letterflag++;
					}
					}

					else if (letterType.getText().trim()
							.equalsIgnoreCase(lettertype.trim() + "_Provider")||letterType.getText().trim()
							.equalsIgnoreCase(lettertype.trim() + "_Prov")
							) {
						
						System.out.println("Clicking on  Provider letter!!");
						Thread.sleep(5000); // Added wait time for flow synchronization
						webUtils.mouseOver(letterType, driver);

						webUtils.mouseOver(sendToCorrespondance, driver);
						
						Thread.sleep(2000);

						sendToCorrespondance.click();
						
						try{
							
							webUtils.explicitWaitByVisibilityofElement(driver, 200, transplantletterconfirmation);						
							if(transplantletterconfirmation.isDisplayed()){
								transplantletterconfirmation.click();

							/*robot.keyPress(KeyEvent.VK_TAB);
							robot.keyRelease(KeyEvent.VK_TAB);*/
								actio.sendKeys(Keys.TAB).sendKeys(Keys.ENTER).build().perform();
							/*robot.keyPress(KeyEvent.VK_ENTER);

							robot.keyRelease(KeyEvent.VK_ENTER);*/

							Thread.sleep(5000); // Added wait time for flow synchronization
							/*robot.keyPress(KeyEvent.VK_ENTER);

							robot.keyRelease(KeyEvent.VK_ENTER);*/
							actio.sendKeys(Keys.ENTER).build().perform();
							}
							
						}catch(Exception e){
							e.printStackTrace();
						}

						// webUtils.mouseOver(sendToCorrespondance, driver);

						// webUtils.moveToTextBoxusingKeys(sendToCorrespondance,
						// Keys.ENTER, driver);

						

						try {
							
							webUtils.explicitWaitByVisibilityofElement(driver, 200, okBtn);

							okBtn.click();

							Thread.sleep(5000); // Added wait time for flow synchronization

							if (okBtn.isDisplayed()) {

								okBtn.click();
							}

						} catch (Exception e) {
							System.out.println("okBtn validation is skipped");
						}

						letterflag++;
					}
					

					

					if (letterflag == 2) {

						break;
					}

				}

				try {
					if (close.isDisplayed()) {
						close.click();
					}
				} catch (Exception e) {
					System.out.println("close validation is skipped");

				}

			} else {

				System.out.println("Letter generation is not required!!");
			}
			
			if(lettertype.trim().equalsIgnoreCase("UM RX Partial Denial")||lettertype.trim().equalsIgnoreCase("UM LOI Outpatient")){
				
				webUtils.rightClick(driver, servicerighClickArea);

				webUtils.explicitWaitByElementToBeClickable(driver, 20,
						correspondance);

				correspondance.click();

				webUtils.explicitWaitByVisibilityofElement(driver, 20, search);

				search.sendKeys(lettertype);

				Robot robot = new Robot();

				robot.keyPress(KeyEvent.VK_ENTER);

				robot.keyRelease(KeyEvent.VK_ENTER);
				
				
				
				
					Thread.sleep(5000); // Added wait time for flow synchronization
					
					
					if(letterTypeList.get(2).getText().trim()
							.equalsIgnoreCase(lettertype.trim() + "_Provider")){
						
						System.out.println("The letter is!!!!!!! "+letterTypeList.get(2).getText());
						
						generateRxPartialDenialLetter(letterTypeList.get(2),lettertype,driver,logger);
						
						
					
				}
			}

		
		}
		catch(Exception e) {
			e.printStackTrace();
		}
	}

	public void generateLetterWithFacility(WebDriver driver, String letterRequired,
			String lettertype,ExtentTest logger){
		try {


			if ("Yes".equalsIgnoreCase(letterRequired)) {

				int letterflag = 0;

				webUtils.rightClick(driver, servicerighClickArea);

				webUtils.explicitWaitByElementToBeClickable(driver, 40,
						correspondance);
				
				correspondance.click();

				webUtils.explicitWaitByVisibilityofElement(driver, 20, search);

				search.sendKeys(lettertype);
				
				Actions actio = new Actions(driver);
				actio.sendKeys(Keys.ENTER).build().perform();

				/*Robot robot = new Robot();


				robot.keyPress(KeyEvent.VK_ENTER);

				robot.keyRelease(KeyEvent.VK_ENTER);*/

				// webUtils.explicitWaitByPresenceofElement(driver,
				// "//div[contains(@eventproxy,'isc_CorrespondanceGrid_')]//table[@class='listTable']//tr/td[2]");

				Thread.sleep(5000); // Added wait time for flow synchronization

				// PageFactory.initElements(driver,
				// AuthAccelPriorAuthReviewPage.class);

				for (WebElement letterType : letterTypeList) {
					
					WebDriverWait wait = new WebDriverWait(driver,15);
					
					wait.until(ExpectedConditions.not(ExpectedConditions.stalenessOf(letterType)));

					System.out.println("The letter text is " + letterType.getText());

					System.out.println("The letter type from datasheet is "
							+ lettertype);
					
					
					if (letterType.getText().trim()
							.equalsIgnoreCase(lettertype.trim() + "_Member")||letterType.getText().trim()
							.equalsIgnoreCase(lettertype.trim() + "_Mem")
							 ) {
						
						if(letterType.getText().trim().equalsIgnoreCase(
								"UM RX Partial Denial_Member")||letterType.getText().trim().equalsIgnoreCase(
										"UM LOI Outpatient_Member")){
							generateRxPartialDenialLetter(letterType,lettertype, driver,logger);
							
							break;
							
							
						}else{

						System.out.println("Clicking on  member letter!!");

						webUtils.mouseOver(letterType, driver);
						Thread.sleep(2000);
						webUtils.mouseOver(sendToCorrespondance, driver);

						sendToCorrespondance.click();

						/*
						 * webUtils.mouseOver(sendToCorrespondance, driver);
						 * 
						 * Thread.sleep(5000); // Added wait time for flow synchronization
						 */

						// webUtils.moveToTextBoxusingKeys(sendToCorrespondance,
						// Keys.ENTER, driver);

						// sendToCorrespondance.sendKeys(Keys.ENTER);
						// sendToCorrespondance.click();

						

						try {
							
							webUtils.explicitWaitByVisibilityofElement(driver, 10, okBtn);

							okBtn.click();

							Thread.sleep(5000); // Added wait time for flow synchronization

							if (okBtn.isDisplayed()) {

								okBtn.click();
							}

						} catch (Exception e) {
							System.out.println("okBtn validation is skipped");
						}

						letterflag++;
					}
					}

					else if (letterType.getText().trim()
							.equalsIgnoreCase(lettertype.trim() + "_Provider")||letterType.getText().trim()
							.equalsIgnoreCase(lettertype.trim() + "_Prov")
							) {
						
						System.out.println("Clicking on  Provider letter!!");
						Thread.sleep(5000); // Added wait time for flow synchronization
						webUtils.mouseOver(letterType, driver);

						webUtils.mouseOver(sendToCorrespondance, driver);

						sendToCorrespondance.click();
						
						try{
							
							webUtils.explicitWaitByVisibilityofElement(driver, 10, transplantletterconfirmation);						
							if(transplantletterconfirmation.isDisplayed()){
								transplantletterconfirmation.click();

							/*robot.keyPress(KeyEvent.VK_TAB);
							robot.keyRelease(KeyEvent.VK_TAB);*/
								actio.sendKeys(Keys.TAB).sendKeys(Keys.ENTER).build().perform();
							/*robot.keyPress(KeyEvent.VK_ENTER);

							robot.keyRelease(KeyEvent.VK_ENTER);*/

							Thread.sleep(5000); // Added wait time for flow synchronization
							/*robot.keyPress(KeyEvent.VK_ENTER);

							robot.keyRelease(KeyEvent.VK_ENTER);*/
							actio.sendKeys(Keys.ENTER).build().perform();
							}
							
						}catch(Exception e){
						e.printStackTrace();	
						}

						// webUtils.mouseOver(sendToCorrespondance, driver);

						// webUtils.moveToTextBoxusingKeys(sendToCorrespondance,
						// Keys.ENTER, driver);

						

						try {
							
							webUtils.explicitWaitByVisibilityofElement(driver, 20, okBtn);

							okBtn.click();

							Thread.sleep(5000); // Added wait time for flow synchronization

							if (okBtn.isDisplayed()) {

								okBtn.click();
							}

						} catch (Exception e) {
							System.out.println("okBtn validation is skipped");
						}

						letterflag++;
					}

					else if (letterType.getText().trim()
							.equalsIgnoreCase(lettertype.trim() + "_Facility")||letterType.getText().trim()
							.equalsIgnoreCase(lettertype.trim() + "_Fac")
							) {
						
						System.out.println("Clicking on  Facility letter!!");
						Thread.sleep(5000); // Added wait time for flow synchronization
						webUtils.mouseOver(letterType, driver);

						webUtils.mouseOver(sendToCorrespondance, driver);

						sendToCorrespondance.click();
						
						try{
							
							webUtils.explicitWaitByVisibilityofElement(driver, 10, transplantletterconfirmation);						
							if(transplantletterconfirmation.isDisplayed()){
								transplantletterconfirmation.click();

							/*robot.keyPress(KeyEvent.VK_TAB);
							robot.keyRelease(KeyEvent.VK_TAB);*/
								actio.sendKeys(Keys.TAB).sendKeys(Keys.ENTER).build().perform();
							/*robot.keyPress(KeyEvent.VK_ENTER);

							robot.keyRelease(KeyEvent.VK_ENTER);*/

							Thread.sleep(5000); // Added wait time for flow synchronization
							/*robot.keyPress(KeyEvent.VK_ENTER);

							robot.keyRelease(KeyEvent.VK_ENTER);*/
							actio.sendKeys(Keys.ENTER).build().perform();
							}
							
						}catch(Exception e){
							e.printStackTrace();
						}

						// webUtils.mouseOver(sendToCorrespondance, driver);

						// webUtils.moveToTextBoxusingKeys(sendToCorrespondance,
						// Keys.ENTER, driver);

						

						try {
							
							webUtils.explicitWaitByVisibilityofElement(driver, 20, okBtn);

							okBtn.click();

							Thread.sleep(5000); // Added wait time for flow synchronization

							if (okBtn.isDisplayed()) {

								okBtn.click();
							}

						} catch (Exception e) {
							System.out.println("okBtn validation is skipped");
						}

						letterflag++;
					}
					

					

					if (letterflag == 3) {

						break;
					}

				}

				try {
					if (close.isDisplayed()) {
						close.click();
					}
				} catch (Exception e) {
					System.out.println("close validation is skipped");
				}

			} else {

				System.out.println("Letter generation is not required!!");
			}
			
			if(lettertype.trim().equalsIgnoreCase("UM RX Partial Denial")||lettertype.trim().equalsIgnoreCase("UM LOI Outpatient")){
				
				webUtils.rightClick(driver, servicerighClickArea);

				webUtils.explicitWaitByElementToBeClickable(driver, 20,
						correspondance);

				correspondance.click();

				webUtils.explicitWaitByVisibilityofElement(driver, 20, search);

				search.sendKeys(lettertype);

				Robot robot = new Robot();

				robot.keyPress(KeyEvent.VK_ENTER);

				robot.keyRelease(KeyEvent.VK_ENTER);
				
				
				
				
					Thread.sleep(5000); // Added wait time for flow synchronization
					
					
					if(letterTypeList.get(2).getText().trim()
							.equalsIgnoreCase(lettertype.trim() + "_Provider")){
						
						System.out.println("The letter is!!!!!!! "+letterTypeList.get(2).getText());
						
						generateRxPartialDenialLetter(letterTypeList.get(2),lettertype,driver,logger);
						
						
					
				}
			}

		
		}
		catch(Exception e) {
			e.printStackTrace();
		}
	}

	public void generateLOILetter(WebDriver driver, String letterRequired,
			String lettertype,ExtentTest logger) {
		try {


			if ("Yes".equalsIgnoreCase(letterRequired)) {

			

				webUtils.rightClick(driver, servicerighClickArea);

				webUtils.explicitWaitByElementToBeClickable(driver, 20,
						correspondance);

				correspondance.click();

				webUtils.explicitWaitByVisibilityofElement(driver, 20, search);

				search.sendKeys(lettertype);

				Actions acts = new Actions(driver);

				acts.sendKeys(Keys.ENTER).build().perform();
				/*robot.keyPress(KeyEvent.VK_ENTER);

				robot.keyRelease(KeyEvent.VK_ENTER);*/

				// webUtils.explicitWaitByPresenceofElement(driver,
				// "//div[contains(@eventproxy,'isc_CorrespondanceGrid_')]//table[@class='listTable']//tr/td[2]");

				Thread.sleep(5000); // Added wait time for flow synchronization

				// PageFactory.initElements(driver,
				// AuthAccelPriorAuthReviewPage.class);

				//for (public WebElement letterType : letterTypeList) {
					
					
					//
					
					List<WebElement> firstLetter = driver.findElements(By.xpath("//div[contains(@eventproxy,'isc_CorrespondanceGrid_')]//table[@class='listTable']//tr/td[2]/div/nobr"));
					
					
					System.out.println("The letter text is " + firstLetter.get(1).getText());

					System.out.println("The letter type from datasheet is "
							+ lettertype);
					
					
					

						System.out.println("Clicking on  member letter!!");

						webUtils.mouseOver(firstLetter.get(1), driver);

						webUtils.mouseOver(sendToCorrespondance, driver);

						sendToCorrespondance.click();

						/*
						 * webUtils.mouseOver(sendToCorrespondance, driver);
						 * 
						 * Thread.sleep(5000); // Added wait time for flow synchronization
						 */

						// webUtils.moveToTextBoxusingKeys(sendToCorrespondance,
						// Keys.ENTER, driver);

						// sendToCorrespondance.sendKeys(Keys.ENTER);
						// sendToCorrespondance.click();
						Thread.sleep(4000);
						
						webUtils.explicitWaitByElementToBeClickable(driver, returnFax);
						returnFax.sendKeys("1234512345");
						webUtils.explicitWaitByElementToBeClickable(driver, dep);
						dep.click();
						List<WebElement> depList = driver.findElements(By.xpath("//div[contains(@id,'isc_PickList')]//following-sibling::table[@role='presentation' and @class='listTable']//tbody//tr"));
						webUtils.clickButtonOrLink(depList, "Prior Authorization Department", logger, driver);
						Thread.sleep(2000);
						List<WebElement> saveLOI = driver.findElements(By.xpath("//div[text()='Save']"));
						saveLOI.get(6).click();
						Thread.sleep(3000);
						try {
							
							webUtils.explicitWaitByVisibilityofElement(driver, 10, okBtn);

							okBtn.click();

							Thread.sleep(5000); // Added wait time for flow synchronization

							if (okBtn.isDisplayed()) {

								okBtn.click();
							}

						} catch (Exception e) {
							System.out.println("okBtn validation is skipped");
						}

						
						webUtils.rightClick(driver, servicerighClickArea);

						webUtils.explicitWaitByElementToBeClickable(driver, 20,
								correspondance);

						correspondance.click();

						webUtils.explicitWaitByVisibilityofElement(driver, 20, search);

						search.sendKeys(lettertype);

						


						acts.sendKeys(Keys.ENTER).build().perform();

						// webUtils.explicitWaitByPresenceofElement(driver,
						// "//div[contains(@eventproxy,'isc_CorrespondanceGrid_')]//table[@class='listTable']//tr/td[2]");

						Thread.sleep(5000); // Added wait time for flow synchronization

						// PageFactory.initElements(driver,
						// AuthAccelPriorAuthReviewPage.class);

						//for (public WebElement letterType : letterTypeList) {
							
							
							//
							
							List<WebElement> secondLetter = driver.findElements(By.xpath("//div[contains(@eventproxy,'isc_CorrespondanceGrid_')]//table[@class='listTable']//tr/td[2]/div/nobr"));
							
							
							System.out.println("The letter text is " + secondLetter.get(2).getText());

							System.out.println("The letter type from datasheet is "
									+ lettertype);
							
							
							

								System.out.println("Clicking on  member letter!!");

								webUtils.mouseOver(secondLetter.get(2), driver);

								webUtils.mouseOver(sendToCorrespondance, driver);

								sendToCorrespondance.click();

								/*
								 * webUtils.mouseOver(sendToCorrespondance, driver);
								 * 
								 * Thread.sleep(5000); // Added wait time for flow synchronization
								 */

								// webUtils.moveToTextBoxusingKeys(sendToCorrespondance,
								// Keys.ENTER, driver);

								// sendToCorrespondance.sendKeys(Keys.ENTER);
								// sendToCorrespondance.click();
								Thread.sleep(4000);
								
								WebElement dep2 = driver.findElement(By.xpath("//b[contains(text(),'Department')]//parent::nobr/parent::td/following-sibling::td"));
								webUtils.explicitWaitByElementToBeClickable(driver, dep2);
								dep2.click();
								 List<WebElement> depList2 = driver.findElements(By.xpath("//div[contains(@id,'isc_PickList')]//following-sibling::table[@role='presentation' and @class='listTable']//tbody//tr"));
								webUtils.clickButtonOrLink(depList2, "Prior Authorization Department", logger, driver);
								Thread.sleep(4000);
								 List<WebElement> saveLOI2 = driver.findElements(By.xpath("//div[text()='Save']"));
								saveLOI2.get(7).click();
								Thread.sleep(3000);
								try {
									
									webUtils.explicitWaitByVisibilityofElement(driver, 10, okBtn);

									okBtn.click();

									Thread.sleep(5000); // Added wait time for flow synchronization

									if (okBtn.isDisplayed()) {

										okBtn.click();
									}

								} catch (Exception e) {
									System.out.println("okBtn validation is skipped");
								}

								
								
							

					

					
				try {
					if (close.isDisplayed()) {
						close.click();
					}
				} catch (Exception e) {
					System.out.println("close validation is skipped");
				}

			} else {

				System.out.println("Letter generation is not required!!");
			}
			
			if(lettertype.trim().equalsIgnoreCase("UM RX Partial Denial")||lettertype.trim().equalsIgnoreCase("UM LOI Outpatient")){
				
				webUtils.rightClick(driver, servicerighClickArea);

				webUtils.explicitWaitByElementToBeClickable(driver, 20,
						correspondance);

				correspondance.click();

				webUtils.explicitWaitByVisibilityofElement(driver, 20, search);

				search.sendKeys(lettertype);

				Actions act1 = new Actions(driver);
				act1.sendKeys(Keys.ENTER).build().perform();
				
				
				
				
					Thread.sleep(5000); // Added wait time for flow synchronization
					
					
					if(letterTypeList.get(2).getText().trim()
							.equalsIgnoreCase(lettertype.trim() + "_Provider")){
						
						System.out.println("The letter is!!!!!!! "+letterTypeList.get(2).getText());
						
						generateRxPartialDenialLetter(letterTypeList.get(2),lettertype,driver,logger);
						
						
					
				}
			}

			
		
		}
		catch(Exception e) {
			e.printStackTrace();
		}
	}
	
	
	public void generateAllLetters(WebDriver driver, String letterRequired,
			String lettertype,ExtentTest logger) throws InterruptedException, AWTException {
		
try {
		if ("Yes".equalsIgnoreCase(letterRequired)) {

			webUtils.rightClick(driver, servicerighClickArea);

			webUtils.explicitWaitByElementToBeClickable(driver, 60,
					correspondance);

			correspondance.click();

			webUtils.explicitWaitByVisibilityofElement(driver, 60, search);

			search.sendKeys(lettertype);
//			logger.log(LogStatus.INFO, "The Letter Type is : "+lettertype);

			Robot robot = new Robot();

			robot.keyPress(KeyEvent.VK_ENTER);

			robot.keyRelease(KeyEvent.VK_ENTER);

			Thread.sleep(5000); // Added wait time for flow synchronization
			
			correspondenceTemplates(driver,ariaSetsize4_1,logger);
			logger.log(LogStatus.INFO, "Outbound Correspondence for "+lettertype+"Member");
			correspondenceTemplates(driver,ariaSetsize4_2,logger);
			logger.log(LogStatus.INFO, "Outbound Correspondence for "+lettertype+"Provider");
			correspondenceTemplates(driver,ariaSetsize4_3,logger);
			logger.log(LogStatus.INFO, "Outbound Correspondence for "+lettertype+"Servicing");
			correspondenceTemplates(driver,ariaSetsize4_4,logger);
			logger.log(LogStatus.INFO, "Outbound Correspondence for "+lettertype+"Facility");
			
			try {
				if (close.isDisplayed()) {
					close.click();
					
				}
			} catch (Exception e) {
				System.out.println("close validation is skipped");
			}

		} else {

			System.out.println("Letter generation is not required!!");
		}
	}catch(Exception e){
		e.printStackTrace();
	}
		
	}
	
	public void correspondenceTemplates(WebDriver driver,WebElement correspondenceType, ExtentTest logger) {
		try {

			
			Thread.sleep(2000);
			
		
			
			webUtils.mouseOver(correspondenceType, driver);
			Thread.sleep(1000);

			webUtils.mouseOver(sendToCorrespondance, driver);

			sendToCorrespondance.click();

			
			try {
				Thread.sleep(5000); // Added wait time for flow synchronization
				webUtils.explicitWaitByVisibilityofElement(driver, 10, okBtn);

				okBtn.click();

				Thread.sleep(5000); // Added wait time for flow synchronization

				if (okBtn.isDisplayed()) {

					okBtn.click();
				}
				


			} catch (InterruptedException e) {
				logger.log(LogStatus.INFO, "Error/Exception While triggering the letter "+correspondenceType);

			}

			
			
		
		}
		catch(Exception e) {
			e.printStackTrace();
		}
	}
	
	
	public void generateDNDLetter(WebDriver driver, String letterRequired,
			String lettertype,ExtentTest logger)  {
		try {


			if ("Yes".equalsIgnoreCase(letterRequired)) {

				
				webUtils.rightClick(driver, servicerighClickArea);

				webUtils.explicitWaitByElementToBeClickable(driver, 20,
						correspondance);

				correspondance.click();

				webUtils.explicitWaitByVisibilityofElement(driver, 20, search);

				search.sendKeys(lettertype);

				/*Robot robot = new Robot();


				robot.keyPress(KeyEvent.VK_ENTER);

				robot.keyRelease(KeyEvent.VK_ENTER);*/
				
				Actions act2 = new Actions(driver);
				act2.sendKeys(Keys.ENTER).build().perform();
				// webUtils.explicitWaitByPresenceofElement(driver,
				// "//div[contains(@eventproxy,'isc_CorrespondanceGrid_')]//table[@class='listTable']//tr/td[2]");

				Thread.sleep(5000); // Added wait time for flow synchronization

				// PageFactory.initElements(driver,
				// AuthAccelPriorAuthReviewPage.class);

				//for (public WebElement letterType : letterTypeList) {
					
					
					//
					
				List<WebElement> firstLetter = driver.findElements(By.xpath("//div[contains(@eventproxy,'isc_CorrespondanceGrid_')]//table[@class='listTable']//tr/td[2]/div/nobr"));
					
					
					System.out.println("The letter text is " + firstLetter.get(1).getText());

					System.out.println("The letter type from datasheet is "
							+ lettertype);
					
					
					

						System.out.println("Clicking on  member letter!!");

						webUtils.mouseOver(firstLetter.get(1), driver);

						webUtils.mouseOver(sendToCorrespondance, driver);

						sendToCorrespondance.click();

						/*
						 * webUtils.mouseOver(sendToCorrespondance, driver);
						 * 
						 * Thread.sleep(5000); // Added wait time for flow synchronization
						 */

						// webUtils.moveToTextBoxusingKeys(sendToCorrespondance,
						// Keys.ENTER, driver);

						// sendToCorrespondance.sendKeys(Keys.ENTER);
						// sendToCorrespondance.click();
						Thread.sleep(4000);
						
						webUtils.explicitWaitByElementToBeClickable(driver, serviceDate);
						webUtils.moveToClickableElement(serviceDate, driver);
						
						serviceDate.sendKeys("2/15/2019");
						
						Thread.sleep(2000);
						List<WebElement> saveLOI = driver.findElements(By.xpath("//div[text()='Save']"));
						saveLOI.get(saveLOI.size()-1).click();
						Thread.sleep(3000);
						try {
							
							webUtils.explicitWaitByVisibilityofElement(driver, 10, okBtn);

							okBtn.click();

							Thread.sleep(5000); // Added wait time for flow synchronization

							if (okBtn.isDisplayed()) {

								okBtn.click();
							}

						} catch (Exception e) {
							System.out.println("okbtn validation is skipped");
						}

						
						webUtils.rightClick(driver, servicerighClickArea);

						webUtils.explicitWaitByElementToBeClickable(driver, 20,
								correspondance);

						correspondance.click();

						webUtils.explicitWaitByVisibilityofElement(driver, 20, search);

						search.sendKeys(lettertype);

						Actions act3 = new Actions(driver);
						act3.sendKeys(Keys.ENTER).build().perform();

						

						// webUtils.explicitWaitByPresenceofElement(driver,
						// "//div[contains(@eventproxy,'isc_CorrespondanceGrid_')]//table[@class='listTable']//tr/td[2]");

						Thread.sleep(5000); // Added wait time for flow synchronization

						// PageFactory.initElements(driver,
						// AuthAccelPriorAuthReviewPage.class);

						//for (public WebElement letterType : letterTypeList) {
							
							
							//
							
							List<WebElement> secondLetter = driver.findElements(By.xpath("//div[contains(@eventproxy,'isc_CorrespondanceGrid_')]//table[@class='listTable']//tr/td[2]/div/nobr"));
							
							
							System.out.println("The letter text is " + secondLetter.get(2).getText());

							System.out.println("The letter type from datasheet is "
									+ lettertype);
							
							
							

								System.out.println("Clicking on  member letter!!");

								webUtils.mouseOver(secondLetter.get(2), driver);

								webUtils.mouseOver(sendToCorrespondance, driver);

								sendToCorrespondance.click();

								/*
								 * webUtils.mouseOver(sendToCorrespondance, driver);
								 * 
								 * Thread.sleep(5000); // Added wait time for flow synchronization
								 */

								// webUtils.moveToTextBoxusingKeys(sendToCorrespondance,
								// Keys.ENTER, driver);

								// sendToCorrespondance.sendKeys(Keys.ENTER);
								// sendToCorrespondance.click();
								Thread.sleep(4000);
								
								
								List<WebElement> saveLOI2 = driver.findElements(By.xpath("//div[text()='Save']"));
								saveLOI2.get(saveLOI2.size()-1).click();
								Thread.sleep(3000);
								try {
									
									webUtils.explicitWaitByVisibilityofElement(driver, 10, okBtn);

									okBtn.click();

									Thread.sleep(5000); // Added wait time for flow synchronization

									if (okBtn.isDisplayed()) {

										okBtn.click();
									}

								} catch (Exception e) {
									System.out.println("okBtn validation is skipped");
								}

								
								
							

					

					
				try {
					if (close.isDisplayed()) {
						close.click();
					}
				} catch (Exception e) {
					System.out.println("close validation is skipped");
				}

			} else {

				System.out.println("Letter generation is not required!!");
			}
		
		}
		catch(Exception e) {
			e.printStackTrace();
		}
	}
	public void generateDENCLetter(WebDriver driver, String letterRequired,
			String lettertype,ExtentTest logger) {
		try {


			if ("Yes".equalsIgnoreCase(letterRequired)) {

			
				webUtils.rightClick(driver, servicerighClickArea);

				webUtils.explicitWaitByElementToBeClickable(driver, 20,
						correspondance);

				correspondance.click();

				webUtils.explicitWaitByVisibilityofElement(driver, 20, search);

				search.sendKeys(lettertype);

				/*Robot robot = new Robot();


				robot.keyPress(KeyEvent.VK_ENTER);

				robot.keyRelease(KeyEvent.VK_ENTER);*/
				
				Actions act4 = new Actions(driver);
				act4.sendKeys(Keys.ENTER).build().perform();

				// webUtils.explicitWaitByPresenceofElement(driver,
				// "//div[contains(@eventproxy,'isc_CorrespondanceGrid_')]//table[@class='listTable']//tr/td[2]");

				Thread.sleep(5000); // Added wait time for flow synchronization

				// PageFactory.initElements(driver,
				// AuthAccelPriorAuthReviewPage.class);

				//for (public WebElement letterType : letterTypeList) {
					
					
					//
					
					List<WebElement> firstLetter = driver.findElements(By.xpath("//div[contains(@eventproxy,'isc_CorrespondanceGrid_')]//table[@class='listTable']//tr/td[2]/div/nobr"));
					
					
					System.out.println("The letter text is " + firstLetter.get(1).getText());

					System.out.println("The letter type from datasheet is "
							+ lettertype);
					
					
					

						System.out.println("Clicking on  member letter!!");

						webUtils.mouseOver(firstLetter.get(1), driver);

						webUtils.mouseOver(sendToCorrespondance, driver);

						sendToCorrespondance.click();

						/*
						 * webUtils.mouseOver(sendToCorrespondance, driver);
						 * 
						 * Thread.sleep(5000); // Added wait time for flow synchronization
						 */

						// webUtils.moveToTextBoxusingKeys(sendToCorrespondance,
						// Keys.ENTER, driver);

						// sendToCorrespondance.sendKeys(Keys.ENTER);
						// sendToCorrespondance.click();
						Thread.sleep(4000);
						WebElement description = driver.findElement(By.xpath("//textarea[@name='lti1']"));
						webUtils.explicitWaitByElementToBeClickable(driver, description);
						webUtils.moveToClickableElement(description, driver);
						
						description.sendKeys("Testing");
						WebElement facts = driver.findElement(By.xpath("//textarea[@name='lti2']"));
						webUtils.explicitWaitByElementToBeClickable(driver, facts);
						webUtils.moveToClickableElement(facts, driver);
						
						facts.sendKeys("Testing");
						WebElement healthPlan = driver.findElement(By.xpath("//textarea[@name='lti4']"));
						webUtils.explicitWaitByElementToBeClickable(driver, healthPlan);
						webUtils.moveToClickableElement(healthPlan, driver);
						
						healthPlan.sendKeys("Testing");
						
						Thread.sleep(3000);
						 List<WebElement> saveLOI = driver.findElements(By.xpath("//div[text()='Save']"));
						saveLOI.get(saveLOI.size()-1).click();
						Thread.sleep(3000);
						try {
							
							webUtils.explicitWaitByVisibilityofElement(driver, 10, okBtn);

							okBtn.click();

							Thread.sleep(5000); // Added wait time for flow synchronization

							if (okBtn.isDisplayed()) {

								okBtn.click();
							}

						} catch (Exception e) {
						System.out.println("okBtn validation is skipped");
						}

						
						webUtils.rightClick(driver, servicerighClickArea);

						webUtils.explicitWaitByElementToBeClickable(driver, 20,
								correspondance);

						correspondance.click();

						webUtils.explicitWaitByVisibilityofElement(driver, 20, search);

						search.sendKeys(lettertype);

						


						/*robot.keyPress(KeyEvent.VK_ENTER);

						robot.keyRelease(KeyEvent.VK_ENTER);*/
						act4.sendKeys(Keys.ENTER).build().perform();
						// webUtils.explicitWaitByPresenceofElement(driver,
						// "//div[contains(@eventproxy,'isc_CorrespondanceGrid_')]//table[@class='listTable']//tr/td[2]");

						Thread.sleep(5000); // Added wait time for flow synchronization

						// PageFactory.initElements(driver,
						// AuthAccelPriorAuthReviewPage.class);

						//for (public WebElement letterType : letterTypeList) {
							
							
							//
							
							 List<WebElement> secondLetter = driver.findElements(By.xpath("//div[contains(@eventproxy,'isc_CorrespondanceGrid_')]//table[@class='listTable']//tr/td[2]/div/nobr"));
							
							
							System.out.println("The letter text is " + secondLetter.get(2).getText());

							System.out.println("The letter type from datasheet is "
									+ lettertype);
							
							
							

								System.out.println("Clicking on  member letter!!");

								webUtils.mouseOver(secondLetter.get(2), driver);

								webUtils.mouseOver(sendToCorrespondance, driver);

								sendToCorrespondance.click();

								/*
								 * webUtils.mouseOver(sendToCorrespondance, driver);
								 * 
								 * Thread.sleep(5000); // Added wait time for flow synchronization
								 */

								// webUtils.moveToTextBoxusingKeys(sendToCorrespondance,
								// Keys.ENTER, driver);

								// sendToCorrespondance.sendKeys(Keys.ENTER);
								// sendToCorrespondance.click();
								Thread.sleep(4000);
								
								
								List<WebElement> saveLOI2 = driver.findElements(By.xpath("//div[text()='Save']"));
								saveLOI2.get(saveLOI2.size()-1).click();
								Thread.sleep(3000);
								try {
									
									webUtils.explicitWaitByVisibilityofElement(driver, 10, okBtn);

									okBtn.click();

									Thread.sleep(5000); // Added wait time for flow synchronization

									if (okBtn.isDisplayed()) {

										okBtn.click();
									}

								} catch (Exception e) {
									System.out.println("okBtn validation is skipped");
								}

								
								
							

					

					
				try {
					if (close.isDisplayed()) {
						close.click();
					}
				} catch (Exception e) {
					System.out.println("close validation is skipped");
				}

			} else {

				System.out.println("Letter generation is not required!!");
			}
		
		}
		catch(Exception e) {
			e.printStackTrace();
		}
	}
	public void generateNOMNCLetter(WebDriver driver, String letterRequired,
			String lettertype,ExtentTest logger) {
		try {


			if ("Yes".equalsIgnoreCase(letterRequired)) {

				

				webUtils.rightClick(driver, servicerighClickArea);

				webUtils.explicitWaitByElementToBeClickable(driver, 20,
						correspondance);

				correspondance.click();

				webUtils.explicitWaitByVisibilityofElement(driver, 20, search);

				search.sendKeys(lettertype);

				/*Robot robot = new Robot();*/

				Actions act5 = new Actions(driver);
				
				/*robot.keyPress(KeyEvent.VK_ENTER);

				robot.keyRelease(KeyEvent.VK_ENTER);
	*/
				act5.sendKeys(Keys.ENTER).build().perform();
				
				
				// webUtils.explicitWaitByPresenceofElement(driver,
				// "//div[contains(@eventproxy,'isc_CorrespondanceGrid_')]//table[@class='listTable']//tr/td[2]");

				Thread.sleep(5000); // Added wait time for flow synchronization

				// PageFactory.initElements(driver,
				// AuthAccelPriorAuthReviewPage.class);

				//for (public WebElement letterType : letterTypeList) {
					
					
					//
					
					List<WebElement> firstLetter = driver.findElements(By.xpath("//div[contains(@eventproxy,'isc_CorrespondanceGrid_')]//table[@class='listTable']//tr/td[2]/div/nobr"));
					
					
					System.out.println("The letter text is " + firstLetter.get(1).getText());

					System.out.println("The letter type from datasheet is "
							+ lettertype);
					
					
					

						System.out.println("Clicking on  member letter!!");

						webUtils.mouseOver(firstLetter.get(1), driver);

						webUtils.mouseOver(sendToCorrespondance, driver);

						sendToCorrespondance.click();

						/*
						 * webUtils.mouseOver(sendToCorrespondance, driver);
						 * 
						 * Thread.sleep(5000); // Added wait time for flow synchronization
						 */

						// webUtils.moveToTextBoxusingKeys(sendToCorrespondance,
						// Keys.ENTER, driver);

						// sendToCorrespondance.sendKeys(Keys.ENTER);
						// sendToCorrespondance.click();
						Thread.sleep(4000);
						WebElement description = driver.findElement(By.xpath("//input[@name='ti1']"));
						webUtils.explicitWaitByElementToBeClickable(driver, description);
						webUtils.moveToClickableElement(description, driver);
						
						description.sendKeys("2/12/19");
					WebElement facts = driver.findElement(By.xpath("//input[@name='di1_dateTextField']"));
						webUtils.explicitWaitByElementToBeClickable(driver, facts);
						webUtils.moveToClickableElement(facts, driver);
						
						facts.sendKeys("2/15/19");
						WebElement healthPlan = driver.findElement(By.xpath("//textarea[@name='lti1']"));
						webUtils.explicitWaitByElementToBeClickable(driver, healthPlan);
						webUtils.moveToClickableElement(healthPlan, driver);
						
						healthPlan.sendKeys("Testing");
						
						Thread.sleep(3000);
						List<WebElement> saveLOI = driver.findElements(By.xpath("//div[text()='Save']"));
						saveLOI.get(saveLOI.size()-1).click();
						Thread.sleep(3000);
						try {
							
							webUtils.explicitWaitByVisibilityofElement(driver, 10, okBtn);

							okBtn.click();

							Thread.sleep(5000); // Added wait time for flow synchronization

							if (okBtn.isDisplayed()) {

								okBtn.click();
							}

						} catch (Exception e) {
							System.out.println("okBtn validation is skipped");
						}

						
						webUtils.rightClick(driver, servicerighClickArea);

						webUtils.explicitWaitByElementToBeClickable(driver, 20,
								correspondance);

						correspondance.click();

						webUtils.explicitWaitByVisibilityofElement(driver, 20, search);

						search.sendKeys(lettertype);

						


						/*robot.keyPress(KeyEvent.VK_ENTER);

						robot.keyRelease(KeyEvent.VK_ENTER);*/

						act5.sendKeys(Keys.ENTER).build().perform();
						// webUtils.explicitWaitByPresenceofElement(driver,
						// "//div[contains(@eventproxy,'isc_CorrespondanceGrid_')]//table[@class='listTable']//tr/td[2]");

						Thread.sleep(5000); // Added wait time for flow synchronization

						// PageFactory.initElements(driver,
						// AuthAccelPriorAuthReviewPage.class);

						//for (public WebElement letterType : letterTypeList) {
							
							
							//
							
							List<WebElement> secondLetter = driver.findElements(By.xpath("//div[contains(@eventproxy,'isc_CorrespondanceGrid_')]//table[@class='listTable']//tr/td[2]/div/nobr"));
							
							
							System.out.println("The letter text is " + secondLetter.get(2).getText());

							System.out.println("The letter type from datasheet is "
									+ lettertype);
							
							
							

								System.out.println("Clicking on  member letter!!");

								webUtils.mouseOver(secondLetter.get(2), driver);

								webUtils.mouseOver(sendToCorrespondance, driver);

								sendToCorrespondance.click();

								/*
								 * webUtils.mouseOver(sendToCorrespondance, driver);
								 * 
								 * Thread.sleep(5000); // Added wait time for flow synchronization
								 */

								// webUtils.moveToTextBoxusingKeys(sendToCorrespondance,
								// Keys.ENTER, driver);

								// sendToCorrespondance.sendKeys(Keys.ENTER);
								// sendToCorrespondance.click();
								Thread.sleep(4000);
								
								
								 List<WebElement> saveLOI2 = driver.findElements(By.xpath("//div[text()='Save']"));
								saveLOI2.get(saveLOI2.size()-1).click();
								Thread.sleep(3000);
								try {
									
									webUtils.explicitWaitByVisibilityofElement(driver, 10, okBtn);

									okBtn.click();

									Thread.sleep(5000); // Added wait time for flow synchronization

									if (okBtn.isDisplayed()) {

										okBtn.click();
									}

								} catch (Exception e) {
									System.out.println("okBtn validation is skipped");
								}

								
								
							

					

					
				try {
					if (close.isDisplayed()) {
						close.click();
					}
				} catch (Exception e) {
					System.out.println("close validation is skipped");
				}

			} else {

				System.out.println("Letter generation is not required!!");
			}
		
		}
		catch(Exception e) {
			e.printStackTrace();
		}
	}
	/**
	 * Generating Denial Lettrs.
	 * 
	 * @throws InterruptedException
	 */

	public void generateRxPartialDenialLetter( WebElement letterType,String lettertype,
			WebDriver driver,ExtentTest logger) throws AWTException{

		Robot robot = new Robot();

		

			System.out
					.println("Clicking on "+letterType.getText());

			webUtils.mouseOver(letterType, driver);

			webUtils.mouseOver(sendToCorrespondance, driver);

			sendToCorrespondance.click();
			try{
				
				
				if("UM RX Partial Denial".equalsIgnoreCase(lettertype)){
			
					webUtils.explicitWaitByVisibilityofElement(driver, 10,
							letterconfirmation);
			letterconfirmation.click();

			robot.keyPress(KeyEvent.VK_TAB);
			robot.keyRelease(KeyEvent.VK_TAB);

			robot.keyPress(KeyEvent.VK_ENTER);

			robot.keyRelease(KeyEvent.VK_ENTER);

			Thread.sleep(5000); // Added wait time for flow synchronization
			robot.keyPress(KeyEvent.VK_ENTER);

			robot.keyRelease(KeyEvent.VK_ENTER);
			
				}
				else if("UM LOI Outpatient".equalsIgnoreCase(lettertype)){
					
					webUtils.explicitWaitByVisibilityofElement(driver, 10,
							infoReturnFaxNo);
					
					infoReturnFaxNo.sendKeys("1");
					
					department.click();
					
					webUtils.clickButtonOrLink(commondropdownList, "Prior Authorization Department", logger, driver);
					
					robot.keyPress(KeyEvent.VK_TAB);
					robot.keyRelease(KeyEvent.VK_TAB);

					robot.keyPress(KeyEvent.VK_ENTER);

					robot.keyRelease(KeyEvent.VK_ENTER);

					Thread.sleep(5000); // Added wait time for flow synchronization
					robot.keyPress(KeyEvent.VK_ENTER);

					robot.keyRelease(KeyEvent.VK_ENTER);
					

					
				}
					
					
		
			
			}catch(Exception e){
				
				e.printStackTrace();
				
			}
			
			

		

	}

	/**
	 * Performing Authorization.
	 * 
	 * @throws InterruptedException
	 */
	public void completeAuthorization(WebDriver driver, String status,
			String statusReason, String dischargeDateStr, String requestType,
			String lettertype, String letterRequired, String decision,
			String withdrawnby, String taskName,String cancelLetter,String cancelReason, ExtentTest logger, String bedTypeName)
			throws InterruptedException {
		
		Thread.sleep(5000); // Added wait time for flow synchronization
		if ("BSC Inpatient".equalsIgnoreCase(requestType)
				|| "FEP Inpatient".equalsIgnoreCase(requestType)
				|| "Medicare Inpatient".equalsIgnoreCase(requestType)
				|| "FEP HROB".equalsIgnoreCase(taskName) || 
					("FEP NICU").equalsIgnoreCase(taskName)
				&& !("Hospice").equalsIgnoreCase(taskName)) {
			
			webUtils.scrollUP(driver, addmissionBedTy);
			Thread.sleep(3000);
			
			addmissionBedTy.click();
			WebElement admBdType=driver.findElement(By.xpath("//*[text()='"+bedTypeName+"']"));
			Thread.sleep(2000);
			
			admBdType.click();
			
			webUtils.scrollDown(driver, SaveRequest);
			logger.log(LogStatus.INFO, "Inside the Complete Authorization");
			SaveRequest.click();

			if ("Withdrawn".equalsIgnoreCase(decision)
					|| "Void".equalsIgnoreCase(decision)) {
				logger.log(LogStatus.INFO, "::::::::::::Decision is Withdrawn or Void:::::::::::::");
				webUtils.explicitWaitByVisibilityofElement(driver, 10,
						withdrawnBy);
				withdrawnBy.click();

				webUtils.clickButtonOrLink(commondropdownList, withdrawnby,
						logger, driver);

				SaveRequest.click();

			}

		} else if ("Hospice".equalsIgnoreCase(taskName)&&requestType.contains("Inpatient")) {

			webUtils.scrollDown(driver, SaveRequest);

			SaveRequest.click();

			if ("Withdrawn".equalsIgnoreCase(decision)
					|| "Void".equalsIgnoreCase(decision)) {

				webUtils.explicitWaitByVisibilityofElement(driver, 10,
						withdrawnBy);
				withdrawnBy.click();

				webUtils.clickButtonOrLink(commondropdownList, withdrawnby,
						logger, driver);

				SaveRequest.click();

			}
		} else {
			webUtils.scrollDown(driver, serviceSaveRequest);

			serviceSaveRequest.click();

			if ("Withdrawn".equalsIgnoreCase(decision)
					|| "Void".equalsIgnoreCase(decision)) {
				webUtils.explicitWaitByVisibilityofElement(driver, 10,
						withdrawnBy);
				withdrawnBy.click();

				webUtils.clickButtonOrLink(commondropdownList, withdrawnby,
						logger, driver);

				serviceSaveRequest.click();
			}

		}

		Thread.sleep(5000); // Added wait time for flow synchronization
		webUtils.moveToClickableElement(hsplit, driver);

		/*
		 * webUtils.explicitWaitByVisibilityofElement(driver, statusDropdown);
		 * 
		 * statusDropdown.click();
		 */

		logger.log(LogStatus.INFO, "Select status dropdown");

		try {
			
			webUtils.waitUntilElementclickable(statusDropdown, driver);
			//statusDropdown.click();
			logger.log(LogStatus.INFO, "Status dropdown is selected");

		} catch (Exception e) {

			logger.log(LogStatus.INFO, "Status dropdown is not selected");
		}

		webUtils.clickButtonOrLink(commondropdownList, status, logger, driver);
		logger.log(LogStatus.INFO, "The value for Status Dropdown is : "+status);
		

		webUtils.explicitWaitByVisibilityofElement(driver, 20,
				statusReasonDropdown);

		logger.log(LogStatus.INFO, "Select Status Reason dropdown");

		webUtils.elementClickWithLogger(statusReasonDropdown,
				"Status Reason dropdown", logger, driver);

		// statusReasonDropdown.click();

		webUtils.clickButtonOrLink(commondropdownList, statusReason, logger,
				driver);
		logger.log(LogStatus.INFO, "The value for Status Reason Dropdown is : "+statusReason);

		try {

			webUtils.scrollDown(driver, dischargeDate);

			if (dischargeDate.getAttribute("value").equals("")) {

				dischargeDate.sendKeys(dischargeDateStr);
			}
		} catch (Exception e) {
			System.out.println("dischargeDate validation is skipped");
		}
		
		
		

		try {

			if ("Yes".equals(letterRequired)) {

				forward.click();

				forward.click();

				forward.click();

				forward.click();
				
				Thread.sleep(2000);
				webUtils.explicitWaitByElementToBeClickable(driver, 20,
						correspondence);
				
				correspondence.click();
				Thread.sleep(4000);
				webUtils.explicitWaitByVisibilityOfAllElements(driver, 20,
						letterVerification);
				int flag = 0;
				if (!letterVerification.isEmpty()) {

					for (WebElement letter : letterVerification) {
						
						System.out.println("The generated letter names are "
								+ letter.getText());

						if (letter
								.getText()
								.trim()
								.equalsIgnoreCase(lettertype.trim() + "_Member"))
						{
							
							if("Yes".equalsIgnoreCase(cancelLetter))
							{
								
								webUtils.fluentWait(driver, "//div[contains(@eventproxy,'isc_CorrespondanceTrackingView_')]//table/tbody/tr[@role='listitem']/td[5]/div/nobr");
								webUtils.rightClick(driver, letter);
								webUtils.explicitWaitByElementToBeClickable(driver,cancel);
								cancel.click();
								Thread.sleep(3000);
															
								webUtils.explicitWaitByElementToBeClickable(driver, cancelReasonDropdown.get(0));
								
								cancelReasonDropdown.get(0).click();
								
								webUtils.clickButtonOrLink(cancelReasonList, cancelReason, logger, driver);
								
								textArea.sendKeys("testing");
								
								webUtils.explicitWaitByElementToBeClickable(driver, saveCancelReason.get(7));
								
								saveCancelReason.get(7).click();		
								
								logger.log(LogStatus.INFO, "Member letter is cancelled successfully!!");
								
							}
							else{
							logger.log(LogStatus.INFO, letter.getText()
									+ " is sent successfully!!");
							}
								flag++;
						}
						else if (letter
								.getText()
								.trim()
								.equalsIgnoreCase(
										lettertype.trim() + "_Provider")) 
						{

							if("Yes".equalsIgnoreCase(cancelLetter))
							{
								webUtils.fluentWait(driver, "//div[contains(@eventproxy,'isc_CorrespondanceTrackingView_')]//table/tbody/tr[@role='listitem']/td[5]/div/nobr");
			
								webUtils.rightClick(driver, letter);
								webUtils.explicitWaitByElementToBeClickable(driver,cancel);
								cancel.click();
								/*Thread.sleep(3000);
								Actions act = new Actions(driver);
								act.sendKeys(Keys.TAB).build().perform();
								act.sendKeys(Keys.DOWN).build().perform();	
								act.sendKeys(Keys.ENTER).build().perform();
								act.sendKeys(Keys.TAB).build().perform();
								act.sendKeys("testing").build().perform();
								act.sendKeys(Keys.TAB).build().perform();
								act.sendKeys(Keys.ENTER).build().perform();*/
								Thread.sleep(3000);
								webUtils.explicitWaitByElementToBeClickable(driver, cancelReasonDropdown.get(0));
								
								cancelReasonDropdown.get(0).click();
								
								webUtils.clickButtonOrLink(cancelReasonList, cancelReason, logger, driver);
								
								textArea.sendKeys("testing");
								
								webUtils.explicitWaitByElementToBeClickable(driver, saveCancelReason.get(7));
								
								saveCancelReason.get(7).click();
								logger.log(LogStatus.INFO, "Provider Letter is canceled successfully!!");
				
							}
							
							else
							{
							logger.log(LogStatus.INFO, letter.getText()
									+ " is sent successfully!!");
							}
							flag++;
						}

						if (flag == 2) {

							break;
						}
					}
				} else {

					logger.log(LogStatus.INFO,
							"Letters are not generated successfully");
				}

			} 
			
			
			else {

				System.out.println("The letter verification is not required!!");
			}
		
		
		
		} catch (Exception e) {
			e.printStackTrace();
		}
		

		submitButton.click();

		Thread.sleep(3000);
		
		try{
			
			if(LOApopUp.isDisplayed()){
				logger.log(LogStatus.INFO,"LOA field mandatory check is successful!!");
				LOApopUp.click();
				LOAFacbutton.click();
				Thread.sleep(2000);
				submitButton.click();
				Thread.sleep(2000);
						
			}
		}
		catch (Exception e) {
			e.printStackTrace();
		}
		
		
		try{
			if(LOApopUp.isDisplayed()){
				logger.log(LogStatus.INFO,"LOA field mandatory check is successful!!");
				LOApopUp.click();
				Thread.sleep(2000);
				LOAServicebutton.click();
				Thread.sleep(2000);
				submitButton.click();
				Thread.sleep(2000);
				
			}
			
		}
		catch(Exception e){
			e.printStackTrace();
		}
		
		
		
		}
	

public void completeAuthorizationWithServiceStatus(WebDriver driver, String status,
		String statusReason, String dischargeDateStr, String requestType,
		String lettertype, String letterRequired, String decision,
		String withdrawnby, String taskName,String cancelLetter, ExtentTest logger)
		throws InterruptedException {
	
	Thread.sleep(5000); // Added wait time for flow synchronization
	if (("BSC Inpatient".equalsIgnoreCase(requestType)
			|| "FEP Inpatient".equalsIgnoreCase(requestType)
			|| "Medicare Inpatient".equalsIgnoreCase(requestType)
			|| "FEP HROB".equalsIgnoreCase(taskName) || 
			"FEP NICU".equalsIgnoreCase(taskName))
			&& !("Hospice").equalsIgnoreCase(taskName)) {

		webUtils.scrollDown(driver, SaveRequest);

		SaveRequest.click();

		if ("Withdrawn".equalsIgnoreCase(decision)
				|| "Void".equalsIgnoreCase(decision)) {

			webUtils.explicitWaitByVisibilityofElement(driver, 10,
					withdrawnBy);
			withdrawnBy.click();

			webUtils.clickButtonOrLink(commondropdownList, withdrawnby,
					logger, driver);

			SaveRequest.click();

		}

	} else if ("Hospice".equalsIgnoreCase(taskName)&&requestType.contains("Inpatient")) {

		webUtils.scrollDown(driver, SaveRequest);

		SaveRequest.click();

		if ("Withdrawn".equalsIgnoreCase(decision)
				|| "Void".equalsIgnoreCase(decision)) {

			webUtils.explicitWaitByVisibilityofElement(driver, 10,
					withdrawnBy);
			withdrawnBy.click();

			webUtils.clickButtonOrLink(commondropdownList, withdrawnby,
					logger, driver);

			SaveRequest.click();

		}
	} else {
		webUtils.scrollDown(driver, serviceSaveRequest);

		serviceSaveRequest.click();

		if ("Withdrawn".equalsIgnoreCase(decision)
				|| "Void".equalsIgnoreCase(decision)) {
			webUtils.explicitWaitByVisibilityofElement(driver, 10,
					withdrawnBy);
			withdrawnBy.click();

			webUtils.clickButtonOrLink(commondropdownList, withdrawnby,
					logger, driver);

			serviceSaveRequest.click();
		}

	}

	Thread.sleep(5000); // Added wait time for flow synchronization

	hsplit.click();
	
	

	/*
	 * webUtils.explicitWaitByVisibilityofElement(driver, statusDropdown);
	 * 
	 * statusDropdown.click();
	 */

//	logger.log(LogStatus.INFO, "Select status dropdown");

	try {
		
		webUtils.waitUntilElementclickable(statusDropdown, driver);
		//statusDropdown.click();
//		logger.log(LogStatus.INFO, "Status dropdown is selected");

	} catch (Exception e) {
		System.out.println("statusDropdown validation is skipped");
//		logger.log(LogStatus.INFO, "Status dropdown is not selected");
	}

	webUtils.clickButtonOrLink(commondropdownList, status, logger, driver);

	webUtils.explicitWaitByVisibilityofElement(driver, 20,
			statusReasonDropdown);

//	logger.log(LogStatus.INFO, "Select Status Reason dropdown");

	webUtils.elementClickWithLogger(statusReasonDropdown,
			statusReason, logger, driver);

	// statusReasonDropdown.click();

	webUtils.clickButtonOrLink(commondropdownList, statusReason, logger,
			driver);

	try {

		webUtils.scrollDown(driver, dischargeDate);

		if (dischargeDate.getAttribute("value").equals("")) {

			dischargeDate.sendKeys(dischargeDateStr);
		}
	} catch (Exception e) {
		System.out.println("dischargeDate validation is skipped");
	}
	
	
	try{
		webUtils.scrollDown(driver, checkBoxUnknown.get(1));
		checkBoxUnknown.get(1).click();
		Thread.sleep(2000);
		/*Actions action = new Actions(driver);
		for(int i =0; i<15;i++){
		action.sendKeys(Keys.TAB).build().perform();
		}
		Thread.sleep(3000);
		action.sendKeys("c").build().perform();*/
		//webUtils.scrollDown(driver, facilityStatus.get(4));
		webUtils.explicitWaitByElementToBeClickable(driver, facilityStatus.get(4));
		
		facilityStatus.get(4).click();
		Thread.sleep(3000);
		webUtils.clickButtonOrLink(facilityStatusList, "Contracted", logger, driver);
		
		logger.log(LogStatus.INFO,"Facility Status is changed to Contracted successful!!");
		Thread.sleep(2000);

		Thread.sleep(2000);

	}catch (Exception e) {
		e.printStackTrace();
	}

	try {

		if ("Yes".equals(letterRequired)) {

			forward.click();

			forward.click();

			forward.click();

			forward.click();
			
			Thread.sleep(2000);
			webUtils.explicitWaitByElementToBeClickable(driver, 20,
					correspondence);
			
			correspondence.click();
			Thread.sleep(4000);
			webUtils.explicitWaitByVisibilityOfAllElements(driver, 10,
					letterVerification);
			int flag = 0;
		
			if (!letterVerification.isEmpty()) {

				for (WebElement letter : letterVerification) {

					System.out.println("The generated letter names are "
							+ letter.getText());

					if (letter
							.getText()
							.trim()
							.equalsIgnoreCase(lettertype.trim() + "_Member"))
					{
						System.out.println(cancelLetter);
						if("Yes".equalsIgnoreCase(cancelLetter))
						{
							webUtils.rightClick(driver, letter);
							webUtils.explicitWaitByElementToBeClickable(driver,cancel);
							cancel.click();
							Thread.sleep(3000);
							Actions act = new Actions(driver);
							act.sendKeys(Keys.TAB).build().perform();
							act.sendKeys(Keys.DOWN).build().perform();	
							act.sendKeys(Keys.ENTER).build().perform();
							act.sendKeys(Keys.TAB).build().perform();
							act.sendKeys("testing").build().perform();
							act.sendKeys(Keys.TAB).build().perform();
							act.sendKeys(Keys.ENTER).build().perform();
							Thread.sleep(3000);
							logger.log(LogStatus.INFO, "Member letter is cancelled successfully!!");
							
						}
						else{
						logger.log(LogStatus.INFO, letter.getText()
								+ " is sent successfully!!");
						}
							flag++;
					}
					else if (letter
							.getText()
							.trim()
							.equalsIgnoreCase(
									lettertype.trim() + "_Provider")) 
					{

						if("Yes".equalsIgnoreCase(cancelLetter))
						{
							webUtils.rightClick(driver, letter);
							webUtils.explicitWaitByElementToBeClickable(driver,cancel);
							cancel.click();
							Thread.sleep(3000);
							Actions act = new Actions(driver);
							act.sendKeys(Keys.TAB).build().perform();
							act.sendKeys(Keys.DOWN).build().perform();	
							act.sendKeys(Keys.ENTER).build().perform();
							act.sendKeys(Keys.TAB).build().perform();
							act.sendKeys("testing").build().perform();
							act.sendKeys(Keys.TAB).build().perform();
							act.sendKeys(Keys.ENTER).build().perform();
							Thread.sleep(3000);
							logger.log(LogStatus.INFO, "Provider Letter is canceled successfully!!");
			
						}
						
						else
						{
						logger.log(LogStatus.INFO, letter.getText()
								+ " is sent successfully!!");
						}
						flag++;
					}

					if (flag == 2) {

						break;
					}
				}
			} else {

				logger.log(LogStatus.INFO,
						"Letters are not generated successfully");
			}

		} 
		
		
		else {

			System.out.println("The letter verification is not required!!");
		}
	
	
	
	} catch (Exception e) {
		e.printStackTrace();
	}
	/*try{
	if (!secondLetterVerification.isDisplayed()) {

		

			if (secondLetterVerification
					.getText()
					.trim()
					.equalsIgnoreCase(lettertype.trim() + "_Member"))
			{
				System.out.println(cancelLetter);
				if(cancelLetter.equalsIgnoreCase("Yes"))
				{
					webUtils.rightClick(driver, secondLetterVerification);
					webUtils.explicitWaitByElementToBeClickable(driver,cancel);
					cancel.click();
					Thread.sleep(3000);
					Actions act = new Actions(driver);
					act.sendKeys(Keys.TAB).build().perform();
					act.sendKeys(Keys.DOWN).build().perform();	
					act.sendKeys(Keys.ENTER).build().perform();
					act.sendKeys(Keys.TAB).build().perform();
					act.sendKeys("testing").build().perform();
					act.sendKeys(Keys.TAB).build().perform();
					act.sendKeys(Keys.ENTER).build().perform();
					Thread.sleep(3000);
					logger.log(LogStatus.INFO, "Member letter is cancelled successfully!!");
					
				}
				else{
				logger.log(LogStatus.INFO, secondLetterVerification.getText()
						+ " is sent successfully!!");
				}
			
			}
			else if (secondLetterVerification
					.getText()
					.trim()
					.equalsIgnoreCase(
							lettertype.trim() + "_Provider")) 
			{

				if(cancelLetter.equalsIgnoreCase("Yes"))
				{
					webUtils.rightClick(driver, secondLetterVerification);
					webUtils.explicitWaitByElementToBeClickable(driver,cancel);
					cancel.click();
					Thread.sleep(3000);
					Actions act = new Actions(driver);
					act.sendKeys(Keys.TAB).build().perform();
					act.sendKeys(Keys.DOWN).build().perform();	
					act.sendKeys(Keys.ENTER).build().perform();
					act.sendKeys(Keys.TAB).build().perform();
					act.sendKeys("testing").build().perform();
					act.sendKeys(Keys.TAB).build().perform();
					act.sendKeys(Keys.ENTER).build().perform();
					Thread.sleep(3000);
					logger.log(LogStatus.INFO, "Provider Letter is canceled successfully!!");
	
				}
				
				else
				{
				logger.log(LogStatus.INFO, secondLetterVerification.getText()
						+ " is sent successfully!!");
				}
			
			}
	}
	}
	catch(Exception e){
		
	}*/

 	submitButton.click();

	Thread.sleep(3000);
	
	try{
		
		if(LOApopUp.isDisplayed()){
			logger.log(LogStatus.INFO,"LOA field mandatory check is successful!!");
			LOApopUp.click();
			
			LOAFacbutton.click();
			submitButton.click();
			Thread.sleep(2000);
					
			if(LOApopUp.isDisplayed()){
				logger.log(LogStatus.INFO,"LOA field mandatory check is successful!!");
				LOApopUp.click();
				Thread.sleep(2000);
				LOAServicebutton.click();
				Thread.sleep(2000);
				submitButton.click();
				Thread.sleep(2000);
				
			}
							
		}
	}
	catch (Exception e) {
		e.printStackTrace();
	}
	
	
	try{
		if(LOApopUp.isDisplayed()){
			logger.log(LogStatus.INFO,"LOA field mandatory check is successful!!");
			LOApopUp.click();
			Thread.sleep(2000);
			LOAServicebutton.click();
			Thread.sleep(2000);
			submitButton.click();
			Thread.sleep(2000);
			
		}
		
	}
	catch(Exception e){
		e.printStackTrace();
	}
	
	
	
	}
public void completeAuthorizationWithFacilityStatus(WebDriver driver, String status,
		String statusReason, String dischargeDateStr, String requestType,
		String lettertype, String letterRequired, String decision,
		String withdrawnby, String taskName,String cancelLetter, ExtentTest logger,String bedTypeName)
		throws InterruptedException {
	
	Thread.sleep(5000); // Added wait time for flow synchronization
	if (("BSC Inpatient".equalsIgnoreCase(requestType)
			|| "FEP Inpatient".equalsIgnoreCase(requestType)
			|| "Medicare Inpatient".equalsIgnoreCase(requestType)
			|| "FEP HROB".equalsIgnoreCase(taskName) || 
			"FEP NICU".equalsIgnoreCase(taskName))
			&& !("Hospice").equalsIgnoreCase(taskName)) {
		

			webUtils.scrollUP(driver, addmissionBedTy);
			Thread.sleep(5000); // Added wait time for flow synchronization
			
			addmissionBedTy.click();
			WebElement admBdType=driver.findElement(By.xpath("//*[text()='"+bedTypeName+"']"));
			Thread.sleep(2000);
			
			admBdType.click();

		webUtils.scrollDown(driver, SaveRequest);

		SaveRequest.click();

		if ("Withdrawn".equalsIgnoreCase(decision)
				|| "Void".equalsIgnoreCase(decision)) {

			webUtils.explicitWaitByVisibilityofElement(driver, 10,
					withdrawnBy);
			withdrawnBy.click();

			webUtils.clickButtonOrLink(commondropdownList, withdrawnby,
					logger, driver);

			SaveRequest.click();

		}

	} else if ("Hospice".equalsIgnoreCase(taskName)&&requestType.contains("Inpatient")) {

		webUtils.scrollDown(driver, SaveRequest);

		SaveRequest.click();

		if ("Withdrawn".equalsIgnoreCase(decision)
				|| "Void".equalsIgnoreCase(decision)) {

			webUtils.explicitWaitByVisibilityofElement(driver, 10,
					withdrawnBy);
			withdrawnBy.click();

			webUtils.clickButtonOrLink(commondropdownList, withdrawnby,
					logger, driver);

			SaveRequest.click();

		}
	} else {
		webUtils.scrollDown(driver, serviceSaveRequest);

		serviceSaveRequest.click();

		if ("Withdrawn".equalsIgnoreCase(decision)
				|| "Void".equalsIgnoreCase(decision)) {
			webUtils.explicitWaitByVisibilityofElement(driver, 10,
					withdrawnBy);
			withdrawnBy.click();

			webUtils.clickButtonOrLink(commondropdownList, withdrawnby,
					logger, driver);

			serviceSaveRequest.click();
		}

	}

	Thread.sleep(5000); // Added wait time for flow synchronization

	hsplit.click();
	
	
	

	/*
	 * webUtils.explicitWaitByVisibilityofElement(driver, statusDropdown);
	 * 
	 * statusDropdown.click();
	 */

	logger.log(LogStatus.INFO, "Select status dropdown");

	try {
		
		webUtils.waitUntilElementclickable(statusDropdown, driver);
		//statusDropdown.click();
//		logger.log(LogStatus.INFO, "Status dropdown is selected");

	} catch (Exception e) {
		System.out.println("statusDropdown validation is skipped"); 
//		logger.log(LogStatus.INFO, "Status dropdown is not selected");
	}

	webUtils.clickButtonOrLink(commondropdownList, status, logger, driver);

	webUtils.explicitWaitByVisibilityofElement(driver, 20,
			statusReasonDropdown);

//	logger.log(LogStatus.INFO, "Select Status Reason dropdown");

	webUtils.elementClickWithLogger(statusReasonDropdown,
			statusReason, logger, driver);

	// statusReasonDropdown.click();

	webUtils.clickButtonOrLink(commondropdownList, statusReason, logger,
			driver);

	try {

		webUtils.scrollDown(driver, dischargeDate);

		if (dischargeDate.getAttribute("value").equals("")) {

			dischargeDate.sendKeys(dischargeDateStr);
		}
	} catch (Exception e) {
		System.out.println("dischargeDate validation is skipped");
	}
	
	
	try{
		webUtils.scrollDown(driver, checkBoxUnknown.get(1));
		checkBoxUnknown.get(2).click();
		/*Actions action = new Actions(driver);
		for(int i =0; i<14;i++){
		action.sendKeys(Keys.TAB).build().perform();
		}
		Thread.sleep(3000);
		action.sendKeys("c").build().perform();*/
		Thread.sleep(3000);
		webUtils.scrollDown(driver, facilityStatus.get(7));
		webUtils.explicitWaitByElementToBeClickable(driver, facilityStatus.get(7));
		facilityStatus.get(7).click();
		Thread.sleep(2000);
		webUtils.clickButtonOrLink(facilityStatusList, "Contracted", logger, driver);
		
		logger.log(LogStatus.INFO,"Facility Status is changed to Contracted successful!!");
		Thread.sleep(2000);

	}catch (Exception e) {
		e.printStackTrace();
	}

	try {

		if ("Yes".equals(letterRequired)) {

			forward.click();

			forward.click();

			forward.click();

			forward.click();
			
			Thread.sleep(2000);
			webUtils.explicitWaitByElementToBeClickable(driver, 20,
					correspondence);
			
			correspondence.click();
			Thread.sleep(4000);
			webUtils.explicitWaitByVisibilityOfAllElements(driver, 10,
					letterVerification);
			int flag = 0;
		
			if (!letterVerification.isEmpty()) {

				for (WebElement letter : letterVerification) {

					System.out.println("The generated letter names are "
							+ letter.getText());

					if (letter
							.getText()
							.trim()
							.equalsIgnoreCase(lettertype.trim() + "_Member"))
					{
						System.out.println(cancelLetter);
						if("Yes".equalsIgnoreCase(cancelLetter))
						{
							webUtils.rightClick(driver, letter);
							webUtils.explicitWaitByElementToBeClickable(driver,cancel);
							cancel.click();
							Thread.sleep(3000);
							Actions act = new Actions(driver);
							act.sendKeys(Keys.TAB).build().perform();
							act.sendKeys(Keys.DOWN).build().perform();	
							act.sendKeys(Keys.ENTER).build().perform();
							act.sendKeys(Keys.TAB).build().perform();
							act.sendKeys("testing").build().perform();
							act.sendKeys(Keys.TAB).build().perform();
							act.sendKeys(Keys.ENTER).build().perform();
							Thread.sleep(3000);
							logger.log(LogStatus.INFO, "Member letter is cancelled successfully!!");
							
						}
						else{
						logger.log(LogStatus.INFO, letter.getText()
								+ " is sent successfully!!");
						}
							flag++;
					}
					else if (letter
							.getText()
							.trim()
							.equalsIgnoreCase(
									lettertype.trim() + "_Provider")) 
					{

						if("Yes".equalsIgnoreCase(cancelLetter))
						{
							webUtils.rightClick(driver, letter);
							webUtils.explicitWaitByElementToBeClickable(driver,cancel);
							cancel.click();
							Thread.sleep(3000);
							Actions act = new Actions(driver);
							act.sendKeys(Keys.TAB).build().perform();
							act.sendKeys(Keys.DOWN).build().perform();	
							act.sendKeys(Keys.ENTER).build().perform();
							act.sendKeys(Keys.TAB).build().perform();
							act.sendKeys("testing").build().perform();
							act.sendKeys(Keys.TAB).build().perform();
							act.sendKeys(Keys.ENTER).build().perform();
							Thread.sleep(3000);
							logger.log(LogStatus.INFO, "Provider Letter is canceled successfully!!");
			
						}
						
						else
						{
						logger.log(LogStatus.INFO, letter.getText()
								+ " is sent successfully!!");
						}
						flag++;
					}

					else if (letter
							.getText()
							.trim()
							.equalsIgnoreCase(
									lettertype.trim() + "_Facility")) 
					{

						if("Yes".equalsIgnoreCase(cancelLetter))
						{
							webUtils.rightClick(driver, letter);
							webUtils.explicitWaitByElementToBeClickable(driver,cancel);
							cancel.click();
							Thread.sleep(3000);
							Actions act = new Actions(driver);
							act.sendKeys(Keys.TAB).build().perform();
							act.sendKeys(Keys.DOWN).build().perform();	
							act.sendKeys(Keys.ENTER).build().perform();
							act.sendKeys(Keys.TAB).build().perform();
							act.sendKeys("testing").build().perform();
							act.sendKeys(Keys.TAB).build().perform();
							act.sendKeys(Keys.ENTER).build().perform();
							Thread.sleep(3000);
							logger.log(LogStatus.INFO, "Provider Letter is canceled successfully!!");
			
						}
						
						else
						{
						logger.log(LogStatus.INFO, letter.getText()
								+ " is sent successfully!!");
						}
						flag++;
					}

					if (flag == 3) {

						break;
					}
				}
			} else {

				logger.log(LogStatus.INFO,
						"Letters are not generated successfully");
			}

		} 
		
		
		else {

			System.out.println("The letter verification is not required!!");
		}
	
	
	
	} catch (Exception e) {
		e.printStackTrace();
	}
	/*try{
	if (!secondLetterVerification.isDisplayed()) {

		

			if (secondLetterVerification
					.getText()
					.trim()
					.equalsIgnoreCase(lettertype.trim() + "_Member"))
			{
				System.out.println(cancelLetter);
				if(cancelLetter.equalsIgnoreCase("Yes"))
				{
					webUtils.rightClick(driver, secondLetterVerification);
					webUtils.explicitWaitByElementToBeClickable(driver,cancel);
					cancel.click();
					Thread.sleep(3000);
					Actions act = new Actions(driver);
					act.sendKeys(Keys.TAB).build().perform();
					act.sendKeys(Keys.DOWN).build().perform();	
					act.sendKeys(Keys.ENTER).build().perform();
					act.sendKeys(Keys.TAB).build().perform();
					act.sendKeys("testing").build().perform();
					act.sendKeys(Keys.TAB).build().perform();
					act.sendKeys(Keys.ENTER).build().perform();
					Thread.sleep(3000);
					logger.log(LogStatus.INFO, "Member letter is cancelled successfully!!");
					
				}
				else{
				logger.log(LogStatus.INFO, secondLetterVerification.getText()
						+ " is sent successfully!!");
				}
			
			}
			else if (secondLetterVerification
					.getText()
					.trim()
					.equalsIgnoreCase(
							lettertype.trim() + "_Provider")) 
			{

				if(cancelLetter.equalsIgnoreCase("Yes"))
				{
					webUtils.rightClick(driver, secondLetterVerification);
					webUtils.explicitWaitByElementToBeClickable(driver,cancel);
					cancel.click();
					Thread.sleep(3000);
					Actions act = new Actions(driver);
					act.sendKeys(Keys.TAB).build().perform();
					act.sendKeys(Keys.DOWN).build().perform();	
					act.sendKeys(Keys.ENTER).build().perform();
					act.sendKeys(Keys.TAB).build().perform();
					act.sendKeys("testing").build().perform();
					act.sendKeys(Keys.TAB).build().perform();
					act.sendKeys(Keys.ENTER).build().perform();
					Thread.sleep(3000);
					logger.log(LogStatus.INFO, "Provider Letter is canceled successfully!!");
	
				}
				
				else
				{
				logger.log(LogStatus.INFO, secondLetterVerification.getText()
						+ " is sent successfully!!");
				}
			
			}
	}
	}
	catch(Exception e){
		
	}*/

 	submitButton.click();

	Thread.sleep(3000);
	
	try{
		
		if(LOApopUp.isDisplayed()){
			logger.log(LogStatus.INFO,"LOA field mandatory check is successful!!");
			LOApopUp.click();
			
			LOAFacbutton.click();
			
			Thread.sleep(2000);
			submitButton.click();
			Thread.sleep(2000);
					
		}
	}
	catch (Exception e) {
		e.printStackTrace();
	}
	
	
	try{
		if(LOApopUp.isDisplayed()){
			logger.log(LogStatus.INFO,"LOA field mandatory check is successful!!");
			LOApopUp.click();
			Thread.sleep(2000);
			LOAServicebutton.click();
			Thread.sleep(2000);
			submitButton.click();
			Thread.sleep(2000);
			
		}
		
	}
	catch(Exception e){
		e.printStackTrace();
	}
	
	
	
	}

public void completeAuthorizationCancelLetter(WebDriver driver, String status,
		String statusReason, String dischargeDateStr, String requestType,
		String lettertype, String letterRequired, String decision,
		String withdrawnby, String taskName,String cancelLetter,String cancelReason, ExtentTest logger, String bedTypeName)
		throws InterruptedException {
	
	Thread.sleep(5000); // Added wait time for flow synchronization
	if (("BSC Inpatient".equalsIgnoreCase(requestType)
			|| "FEP Inpatient".equalsIgnoreCase(requestType)
			|| "Medicare Inpatient".equalsIgnoreCase(requestType)
			|| "FEP HROB".equalsIgnoreCase(taskName) || "FEP NICU"
				.equalsIgnoreCase(taskName))
			&& !("Hospice".equalsIgnoreCase(taskName))) {
		
		webUtils.scrollUP(driver, addmissionBedTy);
		Thread.sleep(3000);
		
		addmissionBedTy.click();
		WebElement admBdType=driver.findElement(By.xpath("//*[text()='"+bedTypeName+"']"));
		Thread.sleep(2000);
		
		admBdType.click();

		webUtils.scrollDown(driver, SaveRequest);

		SaveRequest.click();

		if ("Withdrawn".equalsIgnoreCase(decision)
				|| "Void".equalsIgnoreCase(decision)) {

			webUtils.explicitWaitByVisibilityofElement(driver, 10,
					withdrawnBy);
			withdrawnBy.click();

			webUtils.clickButtonOrLink(commondropdownList, withdrawnby,
					logger, driver);

			SaveRequest.click();

		}

	} else if ("Hospice".equalsIgnoreCase(taskName)&&requestType.contains("Inpatient")) {

		webUtils.scrollDown(driver, SaveRequest);

		SaveRequest.click();

		if ("Withdrawn".equalsIgnoreCase(decision)
				|| "Void".equalsIgnoreCase(decision)) {

			webUtils.explicitWaitByVisibilityofElement(driver, 10,
					withdrawnBy);
			withdrawnBy.click();

			webUtils.clickButtonOrLink(commondropdownList, withdrawnby,
					logger, driver);

			SaveRequest.click();

		}
	} else {
		webUtils.scrollDown(driver, serviceSaveRequest);

		serviceSaveRequest.click();

		if ("Withdrawn".equalsIgnoreCase(decision)
				|| "Void".equalsIgnoreCase(decision)) {
			webUtils.explicitWaitByVisibilityofElement(driver, 10,
					withdrawnBy);
			withdrawnBy.click();

			webUtils.clickButtonOrLink(commondropdownList, withdrawnby,
					logger, driver);

			serviceSaveRequest.click();
		}

	}

	Thread.sleep(5000); // Added wait time for flow synchronization

	hsplit.click();
	
	

	/*
	 * webUtils.explicitWaitByVisibilityofElement(driver, statusDropdown);
	 * 
	 * statusDropdown.click();
	 */

	logger.log(LogStatus.INFO, "Select status dropdown");

	try {
		
		webUtils.waitUntilElementclickable(statusDropdown, driver);
		//statusDropdown.click();
		logger.log(LogStatus.INFO, "Status dropdown is selected");

	} catch (Exception e) {

		logger.log(LogStatus.INFO, "Status dropdown is not selected");
	}

	webUtils.clickButtonOrLink(commondropdownList, status, logger, driver);

	webUtils.explicitWaitByVisibilityofElement(driver, 20,
			statusReasonDropdown);

	logger.log(LogStatus.INFO, "Select Status Reason dropdown");

	webUtils.elementClickWithLogger(statusReasonDropdown,
			"Status Reason dropdown", logger, driver);

	// statusReasonDropdown.click();

	webUtils.clickButtonOrLink(commondropdownList, statusReason, logger,
			driver);

	try {

		webUtils.scrollDown(driver, dischargeDate);

		if (dischargeDate.getAttribute("value").equals("")) {

			dischargeDate.sendKeys(dischargeDateStr);
		}
	} catch (Exception e) {
		System.out.println("dischargeDate validation is skipped");
	}
	
	
	

	try {

		if ("Yes".equals(letterRequired)) {

			forward.click();

			forward.click();

			forward.click();

			forward.click();
			
			Thread.sleep(2000);
			webUtils.explicitWaitByElementToBeClickable(driver, 20,
					correspondence);
			
			correspondence.click();
			Thread.sleep(4000);
			
		
			if (firstLetterRow.isDisplayed()) {

					if("Yes".equalsIgnoreCase(cancelLetter))
						{
							
							webUtils.fluentWait(driver, "//div[contains(@eventproxy,'isc_CorrespondanceTrackingView_')]//tr[1]//td[2]");
							webUtils.rightClick(driver, firstLetterRow);
							webUtils.explicitWaitByElementToBeClickable(driver,cancel);
							cancel.click();
							Thread.sleep(3000);
														
							webUtils.explicitWaitByElementToBeClickable(driver, cancelReasonDropdown.get(0));
							
							cancelReasonDropdown.get(0).click();
							
							webUtils.clickButtonOrLink(cancelReasonList, cancelReason, logger, driver);
							
							textArea.sendKeys("testing");
							
							//webUtils.explicitWaitByElementToBeClickable(driver, saveCancelReason.get(7));
							
							//saveCancelReason.get(7).click();	
							Actions act = new Actions(driver);
							act.sendKeys(Keys.TAB).sendKeys(Keys.ENTER).build().perform();
							Thread.sleep(5000); // Added wait time for flow synchronization
							
							if(firstLetterRow.getText().equalsIgnoreCase("Cancelled")){
							logger.log(LogStatus.INFO, "Member letter is cancelled successfully!!");
							}
							else
							{
								logger.log(LogStatus.INFO, "Member letter is not cancelled successfully!!");
							}
						}
						else{
						logger.log(LogStatus.INFO, " Member Letter is sent successfully!!");
						}
				}
 
		
		
		else {

			System.out.println("The letter verification is not required!!");
		}
	
	
		
	}		
		
	
		
			
		webUtils.fluentWait(driver, "//div[contains(@eventproxy,'isc_CorrespondanceTrackingView_')]//tr[2]//td[2]");
		WebElement secondLetterRowNew = driver.findElement(By.xpath("//div[contains(@eventproxy,'isc_CorrespondanceTrackingView_')]//tr[2]//td[2]"));	
		if (secondLetterRow.isDisplayed()) {

					if("Yes".equalsIgnoreCase(cancelLetter))
						{
							
							Thread.sleep(3000);
							webUtils.rightClick(driver, secondLetterRowNew);
							webUtils.explicitWaitByElementToBeClickable(driver,cancel);
							cancel.click();
							Thread.sleep(3000);
														
							webUtils.explicitWaitByElementToBeClickable(driver, cancelReasonDropdown.get(0));
							
							cancelReasonDropdown.get(0).click();
							
							webUtils.clickButtonOrLink(cancelReasonList, cancelReason, logger, driver);
							
							textArea.sendKeys("testing");
							
							//webUtils.explicitWaitByElementToBeClickable(driver, saveCancelReason.get(7));
							
							//saveCancelReason.get(7).click();	
							Actions act = new Actions(driver);
							act.sendKeys(Keys.TAB).sendKeys(Keys.ENTER).build().perform();
							
							
							Thread.sleep(3000);
							
							if(secondLetterRow.getText().equalsIgnoreCase("Cancelled")){
								logger.log(LogStatus.INFO, "Provider letter is cancelled successfully!!");
								}
								else
								{
									logger.log(LogStatus.INFO, "Provider letter is not cancelled successfully!!");
								}
							
							
						}
						else{
						logger.log(LogStatus.INFO, " Member Letter is sent successfully!!");
						}
				}
 
		
		
		
		else {

			System.out.println("The letter verification is not required!!");
		}
	
	submitButton.click();

	Thread.sleep(3000);
	
	try{
		
		if(LOApopUp.isDisplayed()){
			logger.log(LogStatus.INFO,"LOA field mandatory check is successful!!");
			LOApopUp.click();
			LOAFacbutton.click();
			Thread.sleep(2000);
			submitButton.click();
			Thread.sleep(2000);
					
		}
	}
	catch (Exception e) {
		e.printStackTrace();
	}
	
	
	try{
		if(LOApopUp.isDisplayed()){
			logger.log(LogStatus.INFO,"LOA field mandatory check is successful!!");
			LOApopUp.click();
			Thread.sleep(2000);
			LOAServicebutton.click();
			Thread.sleep(2000);
			submitButton.click();
			Thread.sleep(2000);
			
		}
		
	}
	catch(Exception e){
		e.printStackTrace();
	}
		

	
	}
	catch(Exception e){
		e.printStackTrace();
	}
}

public void completeAuthorizationPharmtech(WebDriver driver, String status,
		String statusReason, String dischargeDate, String requestType,
		String lettertype, String letterRequired, String decision,
		String withdrawnby, String taskName,String cancelLetter,String cancelReason, ExtentTest logger)
		throws InterruptedException {
	

		Thread.sleep(5000); // Added wait time for flow synchronization

	//hsplit.click();
	
	

	/*
	 * webUtils.explicitWaitByVisibilityofElement(driver, statusDropdown);
	 * 
	 * statusDropdown.click();
	 */

	logger.log(LogStatus.INFO, "Select status dropdown");

	try {
		
		webUtils.waitUntilElementclickable(statusDropdown, driver);
		//statusDropdown.click();
		logger.log(LogStatus.INFO, "Status dropdown is selected");

	} catch (Exception e) {

		logger.log(LogStatus.INFO, "Status dropdown is not selected");
	}

	webUtils.clickButtonOrLink(commondropdownList, status, logger, driver);

	webUtils.explicitWaitByVisibilityofElement(driver, 20,
			statusReasonDropdown);

	logger.log(LogStatus.INFO, "Select Status Reason dropdown");

	webUtils.elementClickWithLogger(statusReasonDropdown,
			"Status Reason dropdown", logger, driver);

	// statusReasonDropdown.click();

	webUtils.clickButtonOrLink(commondropdownList, statusReason, logger,
			driver);

		submitButton.click();

	Thread.sleep(3000);
	
	try{
		
		if(LOApopUp.isDisplayed()){
			logger.log(LogStatus.INFO,"LOA field mandatory check is successful!!");
			LOApopUp.click();
			LOAFacbutton.click();
			webUtils.explicitWaitByElementToBeClickable(driver, submitButton);
			submitButton.click();
			// Added wait time for flow synchronization
			Thread.sleep(2000);
					
		}
	}
	catch (Exception e) {
		e.printStackTrace();
	}
	
	
	try{
		if(LOApopUp.isDisplayed()){
			logger.log(LogStatus.INFO,"LOA field mandatory check is successful!!");
			LOApopUp.click();
			Thread.sleep(2000);
			LOAServicebutton.click();
			Thread.sleep(2000);
			submitButton.click();
			Thread.sleep(2000);
			
		}
		
	}
	catch(Exception e){
		e.printStackTrace();
	}
		

	
	}



}


