package com.bsc.qa.web.pages;

import java.util.*;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindAll;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;

import com.bsc.qa.framework.base.BasePage;
import com.gargoylesoftware.htmlunit.WebConsole.Logger;
import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;

import WebUtils.WebUtils;

public class McgDecisionTree extends BasePage {
	public WebUtils webUtils = new WebUtils();
	@FindAll({ @FindBy(how = How.XPATH, using = "//span[text()='Authorization Request']") })
	public WebElement authorizationRequestTitle;

	@FindAll({ @FindBy(how = How.XPATH, using = "//button[@ng-click='searchGuidelines()']") })
	public WebElement documentClinicalButton;

	@FindAll({ @FindBy(how = How.XPATH, using = "//button[@id='indicationCancel']") })
	public WebElement documentClinicalQuestioncancelButton;

	@FindAll({
			@FindBy(how = How.XPATH, using = "//a[contains(text(),'Required Documentation')]/preceding::input[@type='checkbox']") })
	public List<WebElement> requriedCheckboxforMCG;

	@FindAll({ @FindBy(how = How.XPATH, using = "//button[@id='indicationSave']") })
	public WebElement mcgSubmit;

	@FindAll({ @FindBy(how = How.XPATH, using = "//button[@id='requestSubmit']") })
	public WebElement mcgRequestSubmit;
	
	
	

	// span[text()='Authorization Request']

	public void verifyMCGalert(Map<String, String> data, WebDriver driver, ExtentTest logger)
			throws InterruptedException {
		//// iframe[@id='MEDICAL_QUESTION_SETS_EXTERNAL_IFRAME']
		Thread.sleep(3000);
		driver.switchTo().frame("MEDICAL_QUESTION_SETS_EXTERNAL_IFRAME");
		System.out.println("****Done");
		try {

			Thread.sleep(8000);
			webUtils.explicitWaitByVisibilityofElement(driver, authorizationRequestTitle);
			webUtils.scrollDown(driver, documentClinicalButton);
			webUtils.doubleClick(driver, documentClinicalButton);
			webUtils.javaScriptExecutorToClickElement(driver, documentClinicalButton);
			webUtils.explicitWaitByVisibilityofElement(driver, documentClinicalQuestioncancelButton);
			//webUtils.elementClickWithLogger(documentClinicalButton, "Clicking document Clinical button", logger,
				//	driver);
			
			
			webUtils.explicitWaitByVisibilityofElement(driver, documentClinicalQuestioncancelButton);
			// webUtils.scrollDown(driver, documentClinicalQuestioncancelButton);
			String mcgQuestions = data.get("McgQuestionaree");
			if (mcgQuestions != null) {

				String[] mcgCiteQuetions = mcgQuestions.split(";");
				for (String que : mcgCiteQuetions) {
					webUtils.elementClickWithLogger(
							driver.findElement(By.xpath(
									"//span[contains(text(),'" + que + "')]/preceding::input[@type='checkbox'][1]")),
							"decision question"
									+ driver.findElement(By.xpath("//span[contains(text(),'" + que + "')]")).getText(),
							logger, driver);
					Thread.sleep(2000);
				}
			} else {
				for (int i = 0; i < requriedCheckboxforMCG.size(); i++) {

					webUtils.elementClickWithLogger(requriedCheckboxforMCG.get(i),
							"Clicking the requried fields Clinical document", logger, driver); //
					logger.log(LogStatus.INFO, "Selected option is ");
					Thread.sleep(3000);
				}
			}

			webUtils.waitUntilclickable(mcgSubmit, driver);
			/*
			 * webUtils.elementClickWithLogger(mcgSubmit,
			 * "Clicking on Submit button on MCG page", logger, driver);
			 */
			webUtils.waitUntilclickable(mcgRequestSubmit, driver);
			driver.switchTo().defaultContent();
			Thread.sleep(6000);
			/*
			 * webUtils.elementClickWithLogger(mcgRequestSubmit,
			 * "Clicking on Submit button on MCG page", logger, driver);
			 */

		} catch (Exception e) {
			// TODO: handle exception
		}
	}

	public void Old_verifyMCGalert(Map<String, String> data, WebDriver driver, ExtentTest logger)
			throws InterruptedException {
		//// iframe[@id='MEDICAL_QUESTION_SETS_EXTERNAL_IFRAME']
		Thread.sleep(5000);
		driver.switchTo().frame("MEDICAL_QUESTION_SETS_EXTERNAL_IFRAME");
		System.out.println("****Done");
		try {

			Thread.sleep(5000);
			webUtils.explicitWaitByVisibilityofElement(driver, authorizationRequestTitle);
			webUtils.scrollDown(driver, documentClinicalButton);
			webUtils.elementClickWithLogger(documentClinicalButton, "Clicking document Clinical button", logger,
					driver);
			webUtils.explicitWaitByVisibilityofElement(driver, documentClinicalQuestioncancelButton);
			// webUtils.scrollDown(driver, documentClinicalQuestioncancelButton);
			for (int i = 0; i < requriedCheckboxforMCG.size(); i++) {

				webUtils.elementClickWithLogger(requriedCheckboxforMCG.get(i),
						"Clicking the requried fields Clinical document", logger, driver);
				// logger.log(LogStatus.INFO, "Selected option is ");
				Thread.sleep(3000);
			}
			webUtils.waitUntilclickable(mcgSubmit, driver);
			/*
			 * webUtils.elementClickWithLogger(mcgSubmit,
			 * "Clicking on Submit button on MCG page", logger, driver);
			 */
			webUtils.waitUntilclickable(mcgRequestSubmit, driver);
			driver.switchTo().defaultContent();
			Thread.sleep(6000);
			/*
			 * webUtils.elementClickWithLogger(mcgRequestSubmit,
			 * "Clicking on Submit button on MCG page", logger, driver);
			 */

		} catch (Exception e) {
			// TODO: handle exception
		}
	}

}
