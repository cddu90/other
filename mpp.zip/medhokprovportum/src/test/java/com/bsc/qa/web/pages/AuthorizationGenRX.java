package com.bsc.qa.web.pages;

import java.util.Map;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindAll;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.testng.asserts.SoftAssert;

import com.bsc.qa.framework.base.BasePage;
import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;

import WebUtils.WebUtils;

public class AuthorizationGenRX extends BasePage {
	
	public static String authRXCasenmb ;
	
	public WebUtils webUtils = new WebUtils();

	
	@FindAll({ @FindBy(how = How.XPATH, using = "//*[@id='AUTH_STATUS_REVIEW']") })
	public WebElement authStatus;
	
	@FindAll({ @FindBy(how = How.XPATH, using = "//*[@id='AUTH_STATUS_REASON_REVIEW']") })
	public WebElement authReason;
	
	@FindAll({ @FindBy(how = How.XPATH, using = "//span[@id='AUTH_NUMBER_REVIEW']") })
	public WebElement authRXCase;
	
	
	
	
	public  void dataCaptureForAuthorizationGenerationRX(Map<String, String> data, WebDriver driver, SoftAssert softAssertion, ExtentTest logger)
			throws InterruptedException {
		webUtils.explicitWaitByElementToBeClickable(driver, authStatus);
		if(authStatus.isDisplayed()){
			String actAuthStatus = authStatus.getText();
			System.out.println("authStatus"+authStatus.getText());
			logger.log(LogStatus.INFO, "Capturing auth status");
			   if(actAuthStatus.equalsIgnoreCase(data.get("AuthStatus"))){
				   logger.log(LogStatus.INFO, "Auth Accel status is in 'inProgress' as expected");
				   softAssertion.assertTrue(true,"Auth Accel status is in 'inProgress' as expected");
				   }
			   else{
				   logger.log(LogStatus.INFO, "Auth Accel status is not in 'inProgress' as expected");
				   softAssertion.assertTrue(false,"Auth Accel status is not in 'inProgress'");
				   }
	       }
		
		if(authReason.isDisplayed()){
			String resauthReason = authReason.getText();			
			System.out.println("Auth Accel Reason"+authReason.getText());
			logger.log(LogStatus.INFO, "Capturing auth status");
			   if(resauthReason.equalsIgnoreCase(data.get("AuthReason"))){
				   logger.log(LogStatus.INFO, "Auth Accel status is in 'Pending Review' as expected");
				   softAssertion.assertTrue(true,"Auth Accel status is in 'Pending Review' as expected");
				   }
			   else{
				   logger.log(LogStatus.INFO, "Auth Accel status is not in 'Pending Review'");
				   softAssertion.assertTrue(false,"Auth Accel status is not in 'Pending Review'");
				   }
	       }
		if(authRXCase.isDisplayed()){
			
			
			authRXCasenmb = authRXCase.getText();
			
			System.out.println("The reference no is "+authRXCasenmb);
			logger.log(LogStatus.INFO, "Capturing auth status");
			
	       }
		
		

	}

}