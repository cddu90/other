package com.bsc.qa.web.pages;

import java.util.Map;

import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindAll;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;

import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;


import WebUtils.WebUtils;

/**
 * @author SaiKiran Ayyagari
 *
 */
public class ProviderPortalHomePage {

	public static String referenceNum;
	
	public WebUtils webUtils = new WebUtils();

	@FindAll({ @FindBy(how = How.XPATH, using = "//a/span[contains(text(),'Prior Authorization')]") })
	public WebElement priorAuthorization;

	/*@FindAll({ @FindBy(how = How.XPATH, using = "//a[text()='View Authorizations Medical']") })
	public WebElement viewMedicalAuthorization;*/
	
	@FindAll({ @FindBy(how = How.XPATH, using = "//a/span[contains(text(),'View Authorizations Medical')]") })
	public WebElement viewMedicalAuthorization;

	@FindAll({ @FindBy(how = How.XPATH, using = "//input[@type='search']") })
	public WebElement search;

	@FindAll({ @FindBy(how = How.XPATH, using = "//tbody[@id='AUTH_REQUEST_STATUS_GRID']/tr[1]") })
	public WebElement searchResults;

	@FindAll({ @FindBy(how = How.XPATH, using = "//span[@id='AUTH_STATUS']") })
	public WebElement authStatus;

	@FindAll({ @FindBy(how = How.XPATH, using = "//span[@id='AUTH_DECISION']") })
	public WebElement authDecision;
	
	public String sheetName;
		
	
	public String viewStatus(WebDriver driver, ExtentTest logger,
			String typeOfFlow, Map<String, String> data,String rowNum, String testCaseName) {
		try {

			
			webUtils.fluentWait(driver, "//a/span[contains(text(),'Prior Authorization')]");

			priorAuthorization.click();

			webUtils.explicitWaitByElementToBeClickable(driver, 20,
					viewMedicalAuthorization);

			viewMedicalAuthorization.click();
			
			logger.log(LogStatus.INFO, "Verify the Portal Auth Status and Portal Decision");

			webUtils.explicitWaitByVisibilityofElement(driver, 20, searchResults);
			
			if ("NurseReview".equalsIgnoreCase(typeOfFlow)) {
				
				sheetName="NurseReview";

				Thread.sleep(5000); // Added wait time for flow synchronization

				search.sendKeys(data.get("ReferenceNo"));

				search.sendKeys(Keys.ENTER);	
			
			} 
			else {

				Thread.sleep(5000); // Added wait time for flow synchronization

				search.sendKeys(referenceNum);

				search.sendKeys(Keys.ENTER);

			}

			Thread.sleep(5000); // Added wait time for flow synchronization
			
			webUtils.takeSnapShot(driver, "target/BSC-reports/"+ testCaseName.trim() + "portalstatus.png");
			
			
			try{
				webUtils.horizontalScroll(driver, authDecision);

				System.out.println("The status is " + authStatus.getText());
			
				if ("NurseReview".equalsIgnoreCase(typeOfFlow) && data.get("ppverification").equalsIgnoreCase("Yes")){

					if(authStatus.getText().equals("Complete")){
						logger.log(LogStatus.INFO, "Portal Auth Status is Complete");
					}
					else {
						logger.log(LogStatus.INFO, "Portal Auth Status is not Complete");
					}
				
				}
			

			}catch(Exception e){
			
				logger.log(LogStatus.INFO, "The Reference Number is not present in the search list. Please verify the Requesting provider");
				
				}
			
		
		}
		catch(Exception e) {
			e.printStackTrace();
		}
		return authStatus.getText();
	}
	
		
	
	
	/*public String authDecision(WebDriver driver, ExtentTest logger){
		
		System.out.println("The decision is" + authDecision.getText());
		
		switch (authDecision.getText()) {		

			case "":
				logger.log(LogStatus.INFO, "Portal Decision is blank");
				
				break;
	
			case "Approved":
				logger.log(LogStatus.INFO, "Portal Decision is Approved");
				
				break;
	
			case "Denied":
				logger.log(LogStatus.INFO, "Portal Decision is Denied");
				
				break;
	
			case "Void":
				logger.log(LogStatus.INFO, "Portal Decision is Void");
				
				break;
	
			case "Withdrawn":
				logger.log(LogStatus.INFO, "Portal Decision is Withdrawn");
				
				break;
	
			case "Approved Overturn":
				logger.log(LogStatus.INFO, "Portal Decision is Approved Overturn");
				
				break;
			case "Partially Denied":
				logger.log(LogStatus.INFO, "Portal Decision is Partially Denied");
				
				break;
			default:
				logger.log(LogStatus.INFO,"Portal Decision is not " + authDecision.getText());
		
				
		}
		return authDecision.getText();
	}*/
	
	

}
