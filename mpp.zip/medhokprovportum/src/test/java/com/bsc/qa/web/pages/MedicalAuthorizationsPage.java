package com.bsc.qa.web.pages;

import java.awt.Robot;
import java.awt.event.KeyEvent;
import java.util.Map;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindAll;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;

import com.bsc.qa.framework.base.BasePage;
import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;

import WebUtils.WebUtils;

public class MedicalAuthorizationsPage extends BasePage {

	public WebUtils webUtils = new WebUtils();

	@FindAll({ @FindBy(how = How.XPATH, using = "//input[@type='search']") })
	public WebElement searchBox;

	@FindAll({ @FindBy(how = How.XPATH, using = "//span[@id='AUTH_NUMBER'][1]") })
	public WebElement authNumberLink;

	@FindAll({ @FindBy(how = How.XPATH, using = "//span[@id='AUTH_NUMBER'][1]") })
	public WebElement popUpTitle;

	@FindAll({ @FindBy(how = How.XPATH, using = "//a[@id='UploadMedicalDocButton']") })
	public WebElement addDoc;

	@FindAll({
			@FindBy(how = How.XPATH, using = "//span[@id='UploadMedDoc_FILE_UPLOAD_FILE_NAME']/following::input[1]") })
	public WebElement chooseFile;

	public String username;

	public void addDcumentinAuthorizationsMedicalPage(String authNumber,WebDriver driver, ExtentTest logger) throws InterruptedException {
		username = new com.sun.security.auth.module.NTSystem().getName();
		username = System.getProperty("user.dir");
		System.out.println("username:::::::" + username);

		searchBox.sendKeys(authNumber);
		webUtils.explicitWaitByPresenceofElement(driver, "//span[@id='AUTH_NUMBER'][1]");
		
		authNumberLink.click();
		webUtils.explicitWaitByVisibilityofElement(driver, popUpTitle);

		webUtils.scrollDown(driver, addDoc);
		addDoc.click();
		System.out.println("PATH:******" + username + "\\src\\test\\resources\\Test Files\\ProviderPortal.docx");
		chooseFile.sendKeys(username + "\\src\\test\\resources\\Test Files\\ProviderPortal.docx");
		logger.log(LogStatus.INFO, "Upload Document");
		Thread.sleep(2000);

		try {
			Robot rb = new Robot();
			rb.keyPress(KeyEvent.VK_ENTER);
		} catch (Exception e) {
			// TODO: handle exception
		}
		Thread.sleep(5000);

		System.out.println("*******File Uploaded sucesfully******** ");

	}

}
