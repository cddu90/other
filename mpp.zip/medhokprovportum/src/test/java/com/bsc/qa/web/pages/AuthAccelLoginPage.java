package com.bsc.qa.web.pages;

import java.awt.AWTException;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindAll;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;

import WebUtils.WebUtils;

import com.bsc.bqsa.AutomationStringUtilities;
import com.bsc.qa.framework.base.BasePage;
import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;

/**
 * @author Saikiran Ayyagari
 *
 */
public class AuthAccelLoginPage extends BasePage {
	
	public WebUtils webUtils = new WebUtils();

	@FindAll({ @FindBy(how = How.ID_OR_NAME, using = "username"), })
	@CacheLookup
	public WebElement userName;

	@FindAll({ @FindBy(how = How.NAME, using = "j_password") })
	@CacheLookup
	public WebElement passwordTextbox;

	@FindAll({ @FindBy(how = How.ID_OR_NAME, using = "_eventId_proceed") })
	@CacheLookup
	public WebElement loginButton;

	@FindAll({ @FindBy(how = How.ID_OR_NAME, using = "donotcache") })
	@CacheLookup
	public WebElement dontRemember;
	@FindAll({ @FindBy(how = How.ID_OR_NAME, using = "_shib_idp_revokeConsent") })
	@CacheLookup
	public WebElement clearGranting;
	/**
	 * Login to the Application
	 * 
	 * @throws InterruptedException
	 * @throws AWTException 
	 */
	public void applicationLogin(String username, String passWord,WebDriver driver,ExtentTest logger)
			throws InterruptedException, AWTException {
		
		
//		logger.log(LogStatus.INFO, "Log into application");
//		logger.log(LogStatus.INFO, "Enter username!!");
		webUtils.sendKeysWithLogger(userName, username, "UserName", logger, driver);
				
//		logger.log(LogStatus.INFO,"Enter password!!");
		String password = AutomationStringUtilities.decryptValue(passWord);
		passwordTextbox.sendKeys(password);
		
//		
		webUtils.elementClickWithLogger(loginButton, "Login Button", logger, driver);
		
		//loginButton.click();
		System.out.println( "login succesful!! with username: "+username);
		logger.log(LogStatus.INFO, "login succesful!! with username: "+username);

	}

}
