package com.bsc.qa.web.pages;

import java.awt.AWTException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindAll;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;

import com.bsc.qa.framework.base.BasePage;
import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;

import WebUtils.WebUtils;

/**
 * @author SaiKiran Ayyagari
 *
 */
public class ProviderPortalLoginPage extends BasePage {

	public WebUtils webUtils = new WebUtils();

	
	@FindAll({ @FindBy(how = How.XPATH, using = "//input[@id='login-username']") })
	public WebElement userName;
	
	@FindAll({ @FindBy(how = How.XPATH, using = "//a[@id='pre_submit_login']") })
	public WebElement signIn;
	

	
		public void login(String userNameStr, WebDriver driver, ExtentTest logger)throws 
		AWTException{
			try {

				// Added wait time for flow synchronization
				Thread.sleep(5000);
				
				//webUtils.openNewTab(driver);
				
				driver.get("https://UAT.medhokbsca.com/ProviderPortal/resources/Site/page-login.html");
				
			
				
				webUtils.explicitWaitByVisibilityofElement(driver,20, userName);
					
//				logger.log(LogStatus.INFO, "Log into provider portal application");
//				logger.log(LogStatus.INFO, "Enter username!!");
				userName.sendKeys(userNameStr);
				
				webUtils.explicitWaitByElementToBeClickable(driver,20, signIn);
				logger.log(LogStatus.INFO, "Logged into Provider Portal application with provider ID: "+userNameStr);
				
				//webUtils.waitUntilElementclickable(signIn, driver);
				
				webUtils.waitUntilclickable(signIn, driver);
				//signIn.click();

			
			}
			catch(Exception e) {
				e.printStackTrace();
			}
		}

}
	

	