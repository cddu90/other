package com.bsc.qa.web.pages;

import java.awt.Robot;
import java.awt.Toolkit;
import java.awt.datatransfer.StringSelection;
import java.awt.event.KeyEvent;
import java.util.Map;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindAll;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;

import com.bsc.qa.framework.base.BasePage;
import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;

import WebUtils.WebUtils;

public class MemberSearchResultsPage extends BasePage {

	public WebUtils webUtils = new WebUtils();
	@FindAll({ @FindBy(how = How.XPATH, using = "//input[@id='MEDICAL_MEMBER_FIRST_NAME']") })
	public WebElement memFirstName;

	@FindAll({ @FindBy(how = How.XPATH, using = "//input[@id='MEDICAL_MEMBER_LAST_NAME']") })
	public WebElement memLastName;

	@FindAll({ @FindBy(how = How.XPATH, using = "//input[@name='MEDICAL_MEMBER_DOB1']") })
	public WebElement memDOB;

	@FindAll({ @FindBy(how = How.XPATH, using = "//input[@id='MEDICAL_SUBSCRIBER_ID']") })
	public WebElement memID;

	@FindAll({ @FindBy(how = How.XPATH, using = "//*[@id='MEDICAL_PATIENT_SEARCH_DIV_FORM']/div[3]/a/span") })
	public WebElement memSearch;

	@FindAll({
			@FindBy(how = How.XPATH, using = "//*[@id='MEDICAL_PATIENT_SEARCH_MODAL_GRID']/div/div/div/div[2]/div/table") })
	public WebElement memSearchTable;

	@FindAll({
			@FindBy(how = How.XPATH, using = "(//a[@id='pre_medical_prior_auth_service_type_href']//span[text()='Select'])[1]") })
	public WebElement memSelect;

	@FindAll({ @FindBy(how = How.XPATH, using = "//span[text()='Prior Authorization ']") })
	public WebElement priorAuthorizationLink;

	@FindAll({ @FindBy(how = How.XPATH, using = "//span[text()='View Authorizations Medical']") })
	public WebElement authorizationsMedical;

	@FindAll({ @FindBy(how = How.XPATH, using = "//span[text()='Add Attachment']") })
	public WebElement addAttachment;

	@FindAll({ @FindBy(how = How.XPATH, using = "//h3[text()='Upload Additional Documentation']") })
	public WebElement documentUploadTitle;

	@FindAll({ @FindBy(how = How.XPATH, using = "//input[@id='file_upload_med_from_grid']") })
	public WebElement chooseFile;

//	@FindAll({ @FindBy(how = How.XPATH, using = "//span[@id='VIEW_AUTH_MEDICAL_FILE_UPLOAD_FILE_NAME']") })
//	public WebElement chooseFile;

	@FindAll({ @FindBy(how = How.XPATH, using = "//button[@id='UploadMedicalDocButtonFromGrid']") })
	public WebElement uploadDocument;

	@FindAll({ @FindBy(how = How.XPATH, using = "//input[@type='search']") })
	public WebElement searchBox;

	public String username;

	public void enterDetailsInMemeberSearchResultsPage(Map<String, String> data, WebDriver driver, ExtentTest logger)
			throws InterruptedException {
		// Entering Member Details in Member search page and selecting the first in the
		// list
		webUtils.explicitWaitByElementToBeClickable(driver, "//input[@id='MEDICAL_MEMBER_FIRST_NAME']", 60);
		logger.log(LogStatus.INFO, "Enter First Name!::::" + data.get("MemFirstName"));
		memFirstName.sendKeys(data.get("MemFirstName").toString().trim());
		logger.log(LogStatus.INFO, "Enter Last Name::::" + data.get("MemLastName"));
		memLastName.sendKeys(data.get("MemLastName").toString().trim());
//		logger.log(LogStatus.INFO, "Enter Date of Birth::::"+data.get("DOB"));
		memDOB.sendKeys(data.get("DOB").toString().trim());
		logger.log(LogStatus.INFO, "Enter Member ID::::" + data.get("MemId"));
		memID.sendKeys(data.get("MemId").toString().trim());
		System.out.println("Search Screen " + memFirstName.isDisplayed());
//		logger.log(LogStatus.INFO, "Click on Search!!");
		webUtils.explicitWaitByElementToBeClickable(driver, "//*[@id='MEDICAL_PATIENT_SEARCH_DIV_FORM']/div[3]/a/span",
				60);
		System.out.println("Before click search:::: " + memSearch.isDisplayed());
		memSearch.click();
		// Added wait time for flow synchronization
		Thread.sleep(5000);
//		logger.log(LogStatus.INFO, "Selecting Member!!");
		System.out.println("Member search results retrieved? ::::::::::::" + memSelect.isDisplayed());

		webUtils.explicitWaitByElementToBeClickable(driver,
				"(//a[@id='pre_medical_prior_auth_service_type_href']//span[text()='Select'])[1]", 60);
		if (memSelect.isDisplayed() && memSelect.isEnabled()) {
			logger.log(LogStatus.INFO, "Member search results are retrieved");
			memSelect.click();
		} else {
			System.out.println("Memeber Not found" + memSelect.isDisplayed());
			logger.log(LogStatus.INFO, "Member Not Found with the above criteria");

		}
	}

	public void retrieveAllMembers(Map<String, String> data, WebDriver driver, ExtentTest logger)
			throws InterruptedException {
		// Entering Member Details in Member search page and selecting the first in the
		// list
		webUtils.explicitWaitByElementToBeClickable(driver, "//input[@id='MEDICAL_MEMBER_FIRST_NAME']", 60);
		logger.log(LogStatus.INFO, "Enter First Name!::::" + data.get("MemFirstName"));
		memFirstName.sendKeys(data.get("MemFirstName").toString().trim());
		logger.log(LogStatus.INFO, "Enter Last Name::::" + data.get("MemLastName"));
		memLastName.sendKeys(data.get("MemLastName").toString().trim());
//			logger.log(LogStatus.INFO, "Enter Date of Birth::::"+data.get("DOB"));
		memDOB.sendKeys(data.get("DOB").toString().trim());
		logger.log(LogStatus.INFO, "Enter Member ID::::" + data.get("MemId"));
		memID.sendKeys(data.get("MemId").toString().trim());
		System.out.println("Search Screen " + memFirstName.isDisplayed());
//			logger.log(LogStatus.INFO, "Click on Search!!");
		webUtils.explicitWaitByElementToBeClickable(driver, "//*[@id='MEDICAL_PATIENT_SEARCH_DIV_FORM']/div[3]/a/span",
				60);
		System.out.println("Before click search:::: " + memSearch.isDisplayed());
		memSearch.click();
		// Added wait time for flow synchronization
		Thread.sleep(5000);
//			logger.log(LogStatus.INFO, "Selecting Member!!");
		System.out.println("Member search results retrieved? ::::::::::::" + memSelect.isDisplayed());

		webUtils.explicitWaitByElementToBeClickable(driver,
				"(//a[@id='pre_medical_prior_auth_service_type_href']//span[text()='Select'])[1]", 60);

	}

	public void navigaeToMedicalAuthPage(String authNumber, WebDriver driver, ExtentTest logger)
			throws InterruptedException {
		username = new com.sun.security.auth.module.NTSystem().getName();
		username = System.getProperty("user.dir");
		System.out.println("username:::::::" + username);
		// priorAuthorizationLink.click();
		webUtils.scrollUp(driver);
		priorAuthorizationLink.click();
		webUtils.explicitWaitByVisibilityofElement(driver, authorizationsMedical);
		authorizationsMedical.click();

		searchBox.sendKeys(authNumber);
		webUtils.explicitWaitByPresenceofElement(driver, "//span[@id='AUTH_NUMBER'][1]");

		webUtils.explicitWaitByVisibilityofElement(driver, addAttachment);
		webUtils.horizontalScroll(driver, addAttachment);
		addAttachment.click();
		webUtils.explicitWaitByVisibilityofElement(driver, documentUploadTitle);
		// chooseFile.sendKeys(username + "\\src\\test\\resources\\Test
		// Files\\ProviderPortal.docx");
		// chooseFile.sendKeys("C:\\test\\test.docx");
		// chooseFile.click();
		// chooseFile.sendKeys(username + "\\src\\test\\resources\\testFiles\\TU1.pdf");
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("arguments[0].style.display='block';", chooseFile);
		webUtils.moveToClickableElement(chooseFile, driver);
		/*
		 * js.executeScript("arguments[0].value = arguments[1];", chooseFile, username +
		 * "\\src\\test\\resources\\testFiles\\TU1.pdf");
		 */
		chooseFile.sendKeys(username + "\\src\\test\\resources\\testFiles\\TU1.pdf");
		try {
			Robot robot = new Robot();
			robot.keyPress(KeyEvent.VK_ESCAPE);
		} catch (Exception e) {
			// TODO: handle exception
		}
//		StringSelection stringSelection = new StringSelection(username + "\\src\\test\\resources\\testFiles\\TU1.pdf");
//		Toolkit.getDefaultToolkit().getSystemClipboard().setContents(stringSelection, null);
//		System.out.println("PATH:******" + username + "\\src\\test\\resources\\testFiles\\TU1.pdf");
//		Thread.sleep(2000);
//		try {
//			Robot robot = new Robot();
//			robot.setAutoDelay(10);
//			robot.keyPress(KeyEvent.VK_CONTROL);
//			robot.keyPress(KeyEvent.VK_V);
//			robot.setAutoDelay(10);
//			robot.keyRelease(KeyEvent.VK_V);
//			robot.keyRelease(KeyEvent.VK_CONTROL);
//			robot.setAutoDelay(10);
//			robot.keyPress(KeyEvent.VK_ENTER);
//			robot.keyRelease(KeyEvent.VK_ENTER);
//		} catch (Exception e) {
//			// TODO: handle exception
//		}

		uploadDocument.click();

	}
}
