package com.bsc.qa.web.pages;

import java.io.File;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Map;

import javax.print.attribute.standard.MediaName;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.Alert;
import org.openqa.selenium.Keys;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindAll;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;

import com.bsc.qa.framework.base.BasePage;
import com.gargoylesoftware.htmlunit.javascript.host.event.MediaEncryptedEvent;
import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;

import WebUtils.WebUtils;

public class RequestMedicalPriorAuthorizationsPage extends BasePage {

	public WebUtils webUtils = new WebUtils();
	@FindAll({ @FindBy(how = How.XPATH, using = "//*[@id='MD_PA_STATUS_TYPE']/div/div/div/div[1]/ins") })
	public WebElement standardRadio;

	@FindAll({ @FindBy(how = How.XPATH, using = "//select[@id='MEDICAL_REQUESTING_PROVIDER_ID']") })
	public WebElement requestingProvider;

	@FindAll({ @FindBy(how = How.XPATH, using = "//select[@id='MEDICAL_POS']") })
	public WebElement pos;

	@FindAll({ @FindBy(how = How.XPATH, using = "//input[@id='REQUESTING_CONTACT_FAX']") })
	public WebElement faxNumber;

	@FindAll({ @FindBy(how = How.XPATH, using = "//select[@id='MEDICAL_AUTH_REQUEST_TYPE']") })
	public WebElement medRequestType;

	@FindAll({
			@FindBy(how = How.XPATH, using = "//*[@id='MEDICAL_REQUESTING_PROVIDER_DIV']/div[5]/div[1]/div/div[1]/ins") })
	public WebElement requestServiceRadio;

	@FindAll({ @FindBy(how = How.XPATH, using = "//input[@id='MEDICAL_AUTH_INPATIENT_ACTUAL_ADMIT_DATE']") })
	public WebElement actualAdmitDate;

	@FindAll({ @FindBy(how = How.XPATH, using = "//input[@id='MEDICAL_AUTH_INPATIENT_REQUEST_ADMIT_DATE']") })
	public WebElement requestAdmitDate;

	@FindAll({ @FindBy(how = How.XPATH, using = "//input[@id='MEDICAL_FROM_DATE']") })
	public WebElement fromAdmitDate;

	@FindAll({ @FindBy(how = How.XPATH, using = "//input[@id='REQUESTING_CONTACT_PHONE']") })
	public WebElement phoneNumber;

	@FindAll({ @FindBy(how = How.XPATH, using = "//input[@id='MEDICAL_THRU_DATE']") })
	public WebElement thruAdmitDate;

	@FindAll({ @FindBy(how = How.XPATH, using = "//a[contains(text(),'Add Servicing/Facility Provider')]") })
	public WebElement selectServicingProvider;

	@FindAll({ @FindBy(how = How.XPATH, using = "//*[@id='PROVIDER_SEARCH_BTN_GRID']/div/div/div/div[2]/div/tabl") })
	public WebElement selectServicingTable;

	@FindAll({ @FindBy(how = How.XPATH, using = "//select[@id='MEDICAL_AUTH_INPATIENT_ADMIT_FROM']") })
	public WebElement admitFrom;

	@FindAll({ @FindBy(how = How.XPATH, using = "//select[@id='MEDICAL_AUTH_INPATIENT_ADMIT_TYPE']") })
	public WebElement admitType;

	@FindAll({ @FindBy(how = How.XPATH, using = "//select[@id='MEDICAL_BED_TYPE']") })
	public WebElement bedType;

	@FindAll({ @FindBy(how = How.XPATH, using = "//span[@id='PRESCREENING_DELEGATED_MEMBER_MESSAGE']") })
	public WebElement alertMessage;

	@FindAll({
			@FindBy(how = How.XPATH, using = "//span[@id='PRESCREENING_DELEGATED_MEMBER_MESSAGE']/following::button[1]") })
	public WebElement alertMessageOk;

	public static String username;
	// PRESCREENING_DELEGATED_MEMBER_MESSAGE

	// MEDICAL_BED_TYPE

	/* Added by Sirisha to get current date */
	public DateFormat dateFormat = new SimpleDateFormat("MM/dd/yyyy");
	public Date date = new Date();
	// Now format the date

	public String Current_Date = dateFormat.format(date);
	public String FromAdmit_DT = Current_Date;
	public String ThruAdmitDate = dateFormat.format(addDays(date, 1));
	public String ActualAdmit_DT = Current_Date;
	public String Request_DT = Current_Date;

	public static Date addDays(Date dateStr, int days) {
		dateStr.setTime(dateStr.getTime() + days * 1000 * 60 * 60 * 24);
		return dateStr;
	}

	public void enterDetailsInRMPAPage(Map<String, String> data, WebDriver driver, ExtentTest logger)
			throws InterruptedException {
		username = new com.sun.security.auth.module.NTSystem().getName();
		username = System.getProperty("user.dir");
		System.out.println("username:::::::" + username);
		// Enter details in Request member Page, Request type, actual admit date
//		logger.log(LogStatus.INFO, "Selecting Authorization Urgency Radio Button!!");

		webUtils.explicitWaitByElementToBeClickable(driver, requestingProvider);
		// standardRadio.click();
		logger.log(LogStatus.INFO, "Selecting  Requesting Provider :" + data.get("RequestingProvider"));
		// requestingProvider.sendKeys(data.get("RequestingProvider").toString());
		// Added wait time for flow synchronization
		webUtils.selectDropdownValueByIndex(requestingProvider, 1, logger, driver);
		Thread.sleep(2000);
		// logger.log(LogStatus.INFO, "Enter Phone Number:::::::::::" + phoneNumber);
		phoneNumber.sendKeys(data.get("PhoneNumber").toString());
		logger.log(LogStatus.INFO, "Enter the phone number :" + data.get("PhoneNumber"));
		Thread.sleep(2000);
		webUtils.explicitWaitByElementToBeClickable(driver, 10, faxNumber);
		faxNumber.sendKeys(data.get("FaxNumber").toString());
//		logger.log(LogStatus.INFO, "Enter request Type!!");
		// Added wait time for flow synchronization
		Thread.sleep(2000);
		medRequestType.sendKeys(data.get("RequestType").toString());
		logger.log(LogStatus.INFO, "Selected  Request Type :" + data.get("RequestType"));
		try {
			webUtils.explicitWaitByPresenceofElement(driver, 10, "//span[@id='PRESCREENING_DELEGATED_MEMBER_MESSAGE']");
			logger.log(LogStatus.INFO, "Alert Message:::::::::::::" + alertMessage.getText());
			String alertStatus = alertMessage.getText();
			webUtils.takeSnapShot(driver, username + "//test-output//BSC-reports//screenshots//"
					+ data.get("TestCaseID").trim() + "//" + data.get("TestCaseID").trim() + "AlertMessage.png");
			logger.log(LogStatus.INFO, logger.addScreenCapture(username + "//test-output//BSC-reports//screenshots//"
					+ data.get("TestCaseID").trim() + "//" + data.get("TestCaseID").trim() + "AlertMessage.png"));

			if (alertStatus.trim().replaceAll("\\s+","").equalsIgnoreCase(data.get("AlertMessage").trim().replaceAll("\\s+",""))) {
				logger.log(LogStatus.PASS, "Alert Message is matched " + alertStatus);

			} else {
				logger.log(LogStatus.FAIL, "Alert Message is not matched " + alertStatus);
			}
			alertMessageOk.click();
		} catch (Exception e) {
			// TODO: handle exception
			logger.log(LogStatus.INFO, "Alert not presented");
		}
		if (data.get("RequestType").toString().equalsIgnoreCase("InPatient")) {

			webUtils.selectDropdownValueByVisibleText(admitFrom, data.get("AdmitFrom"), logger, driver);

			webUtils.selectDropdownValueByVisibleText(admitType, data.get("AdmitType"), logger, driver);

			//webUtils.selectDropdownValueByVisibleText(bedType, data.get("BedType"), logger, driver);
			webUtils.selectDropdownValueByIndex(bedType, 1, logger, driver);

			logger.log(LogStatus.INFO, "Enter Actual Admit Date:::::::::::::" + ActualAdmit_DT);
			actualAdmitDate.sendKeys(ActualAdmit_DT);

			Thread.sleep(2000);
			webUtils.selectDropdownValueByVisibleText(pos, data.get("POS").toString(), logger, driver);
			actualAdmitDate.sendKeys(Keys.TAB);
		} else if (data.get("RequestType").toString().equalsIgnoreCase("Service Request (Prior Auth)")
				|| data.get("RequestType").toString().equalsIgnoreCase("Medication")) {
			// Added wait time for flow synchronization
			Thread.sleep(2000);
			webUtils.selectDropdownValueByVisibleText(pos, data.get("POS").toString(), logger, driver);
		}

	}

}
