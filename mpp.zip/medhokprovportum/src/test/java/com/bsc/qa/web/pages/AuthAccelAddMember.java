
package com.bsc.qa.web.pages;


import java.util.List;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindAll;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;

import com.bsc.qa.framework.base.BasePage;
import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;


import WebUtils.ExcelUtilities;
import WebUtils.WebUtils;

public class AuthAccelAddMember extends BasePage {
	public WebUtils webUtils = new WebUtils();
	
	@FindAll({ @FindBy(how = How.XPATH, using = "//label[text()='Member ID']//parent::b//ancestor::td//following-sibling::td//input[@name='subscriberId']") })
	public WebElement memberID;
	
	
	
	@FindAll({ @FindBy(how = How.XPATH, using = "//div[text()='Add Member']") })
	public WebElement addMemberButton;
	@FindAll({ @FindBy(how = How.XPATH, using = "//label[text()='Member ID']//parent::b//ancestor::td//following-sibling::td//input[@name='firstName']") })
	public WebElement firstName;
	@FindAll({ @FindBy(how = How.XPATH, using = "//label[text()='Member ID']//parent::b//ancestor::td//following-sibling::td//input[@name='lastName']") })
	public WebElement lastName;
	@FindAll({ @FindBy(how = How.XPATH, using = "//label[text()='DOB']//parent::b//ancestor::td//following-sibling::td//input[@name='dateOfBirth_dateTextField']") })
	public WebElement dob;
	
	@FindAll({ @FindBy(how = How.XPATH, using = "//b[contains(text(),'Address')]//parent::nobr//parent::td//following-sibling::td//table[@class='selectItemControl']//tbody//tr//td[1]") })
	public WebElement addressType;
	
	@FindAll({ @FindBy(how = How.XPATH, using = "//div[contains(@id,'isc_PickList')]//following-sibling::table//tbody//tr") })	
	public List<WebElement> dropDownTypes;
	
	@FindAll({ @FindBy(how = How.XPATH, using = "//label[text()='Address 1']//parent::b//ancestor::td//following-sibling::td//input[@name='address1']") })
	public WebElement address1;
	
	@FindAll({ @FindBy(how = How.XPATH, using = "//label[text()='City']//parent::b//ancestor::td//following-sibling::td//input[@name='city']") })
	public WebElement city;
	
	@FindAll({ @FindBy(how = How.XPATH, using = "//label[text()='State']//parent::b//ancestor::td//following-sibling::td//input[@name='state']") })
	public WebElement state;
	
	@FindAll({ @FindBy(how = How.XPATH, using = "//label[text()='Zip']//parent::b//ancestor::td//following-sibling::td//input[@name='zip']") })
	public WebElement zip;
	
	@FindAll({ @FindBy(how = How.XPATH, using = "//label[text()='Effective Date']//parent::b//ancestor::td//following-sibling::td//input[@name='effectivedate_dateTextField']") })
	public WebElement effectiveDate;
	
	@FindAll({ @FindBy(how = How.XPATH, using = "//label[text()='Effective Date']//parent::b//ancestor::td//following-sibling::td//input[@name='eligeffectivedate_dateTextField']") })
	public WebElement effectiveDateEligibility;
	
	@FindAll({ @FindBy(how = How.XPATH, using = "//b[contains(text(),'Company')]//parent::nobr//parent::td//following-sibling::td//table[@class='selectItemControl']//tbody//tr//td[1]") })	
	public List<WebElement> company;
	
	@FindAll({ @FindBy(how = How.XPATH, using = "//b[contains(text(),'Line')]//parent::nobr//parent::td//following-sibling::td//table[@class='selectItemControl']//tbody//tr//td[1]") })
	public WebElement lob;
	
	@FindAll({ @FindBy(how = How.XPATH, using = "//img[contains(@src,'search_picker')]") })	
	public List<WebElement> searchIcon;
	
	@FindAll({ @FindBy(how = How.XPATH, using = "//input[@name='code']") })
	public WebElement code;
	
	@FindAll({ @FindBy(how = How.XPATH, using = "//div[text()='Search']") })
	public List<WebElement> searchButton;
	
	@FindAll({ @FindBy(how = How.XPATH, using = "//div[contains(@id,'isc_L')]//following-sibling::table[@role='presentation' and @class='listTable']//tbody//tr[1]") })
	public WebElement planFirstRow;
	
	@FindAll({ @FindBy(how = How.XPATH, using = "//div[text()='Save']") })	
	public List<WebElement> save;
	@FindAll({ @FindBy(how = How.XPATH, using = "//div[text()='Erisa']//span") })	
	public WebElement erisa;
	
	@FindAll({ @FindBy(how = How.XPATH, using = "//b[contains(text(),'Gender')]//parent::nobr//parent::td//following-sibling::td//table[@class='selectItemControl']//tbody//tr//td[1]") })	
	public List<WebElement> gender;
	
	@FindAll({ @FindBy(how = How.XPATH, using = "//div[text()='Eligibility']//ancestor::div[contains(@eventproxy,'isc_Section')]//following-sibling::div//table[@role='presentation']//tr[1]") })
	public WebElement eligibilityFirstRow;
	
	@FindAll({ @FindBy(how = How.XPATH, using = "//label[text()='ERISA IND']//ancestor::td//following-sibling::td[1]//input") })
	public WebElement erisaIND;
	
	
	@FindAll({ @FindBy(how = How.XPATH, using = "//div[text()='OK']") })	
	public WebElement okBtn;
	
	@FindAll({ @FindBy(how = How.XPATH, using = "//nobr[text()='View']") })	
	public WebElement view;
	
	
	
	/**
	 * Adding new Member
	 * 
	 * @throws InterruptedException
	 */
	
	public int newMember(String effDate,int resultStr,String codeStr,String lobStr,String companyStr,String zipStr,String stateStr,String cityStr,String address1Str,String typeOfAddress,
			String genderOfMember,String dateOfBirth,String nameFirst,String nameLast,String memberId,WebDriver driver,ExtentTest logger) {
		try {

			//System.out.println("Entered Method");
			webUtils.explicitWaitByElementToBeClickable(driver, 20, addMemberButton);
			addMemberButton.click();
			//System.out.println("Add Member Button has been clicked");
			logger.log(LogStatus.INFO, "Enter the new Member ID");
			memberID.sendKeys(memberId);
			logger.log(LogStatus.INFO, "Enter the First Name for Member");
			firstName.sendKeys(nameFirst);
			logger.log(LogStatus.INFO, "Value for First Name is :"+nameFirst);
			System.out.println("First Name is :"+nameFirst);
			logger.log(LogStatus.INFO, "Enter the Last Name for Member");
			lastName.sendKeys(nameLast);
			System.out.println("Last Name is :"+nameLast);
			logger.log(LogStatus.INFO, "Value for Last Name is :"+nameLast);
			
			dob.sendKeys(dateOfBirth);
			logger.log(LogStatus.INFO, "Value for DOB is :"+dateOfBirth);
			System.out.println("DOB :"+dateOfBirth);
			
			gender.get(0).click();
			webUtils.clickButtonOrLink(dropDownTypes, genderOfMember, logger, driver);
			logger.log(LogStatus.INFO, "Value for Gender is :"+genderOfMember);
			System.out.println("Gender is :"+genderOfMember);
			
			webUtils.explicitWaitByElementToBeClickable(driver, 10, addressType);
			
			addressType.click();
			
			// Added wait time for flow synchronization
			Thread.sleep(2000);
			
			webUtils.clickButtonOrLink(dropDownTypes, typeOfAddress, logger, driver);
			logger.log(LogStatus.INFO, "Value for Address Type is :"+typeOfAddress);
			System.out.println("Value for Address Type is :"+typeOfAddress);
			
			webUtils.moveToClickableElement(address1, driver);
			webUtils.explicitWaitByElementToBeClickable(driver, 20, address1);
			address1.sendKeys(address1Str);
			logger.log(LogStatus.INFO, "Value for Address1 is :"+address1Str);
			System.out.println("Value for Address1 is :"+address1Str);
			
			
			city.sendKeys(cityStr);
			logger.log(LogStatus.INFO, "Value for City is :"+cityStr);
			System.out.println("Value for City is :"+cityStr);
			
			
			state.sendKeys(stateStr);
			logger.log(LogStatus.INFO, "Value for State is :"+stateStr);
			System.out.println("Value for State is :"+stateStr);
			
			webUtils.explicitWaitByElementToBeClickable(driver, 20, zip);
			zip.sendKeys(zipStr);
			logger.log(LogStatus.INFO, "Value for Zip is :"+zipStr);
			System.out.println("Value for Zip is :"+zipStr);
			
			//webUtils.moveToClickableElement(effectiveDate, driver);
			webUtils.moveToClickableElement(effectiveDate, driver);
			webUtils.doubleClick(driver, effectiveDate);
			
			company.get(0).click();
			// Added wait time for flow synchronization
			Thread.sleep(2000);
			webUtils.clickButtonOrLink(dropDownTypes, companyStr, logger, driver);
			logger.log(LogStatus.INFO, "Value for Company Dropdown is :"+companyStr);
			System.out.println("Value for Company Dropdown is :"+companyStr);
			
			
			lob.click();
			// Added wait time for flow synchronization
			Thread.sleep(2000);
			webUtils.clickButtonOrLink(dropDownTypes, lobStr, logger, driver);
			logger.log(LogStatus.INFO, "Value for Line Of Business Dropdown is :"+lobStr);
			System.out.println("Value for Line of Business Dropdown is :"+lobStr);
			// Added wait time for flow synchronization
			Thread.sleep(3000);
			searchIcon.get(1).click();
			webUtils.explicitWaitByElementToBeClickable(driver, 20, code);
			code.sendKeys(codeStr);
			logger.log(LogStatus.INFO, "Value for Plan Code is :"+codeStr);
			System.out.println("Value for Plan Code is :"+codeStr);
			
			searchButton.get(1).click();
			
			webUtils.explicitWaitByElementToBeClickable(driver, 40, planFirstRow);
			planFirstRow.click();
			webUtils.doubleClick(driver, planFirstRow);
			System.out.println("Plan Code Row has been selected");

			webUtils.explicitWaitByElementToBeClickable(driver, 10, effectiveDateEligibility);
			effectiveDateEligibility.sendKeys(effDate);
			System.out.println("Effective Daet Eligibility is :"+effDate);
			
			if("ASO".equalsIgnoreCase(lobStr)){
				erisa.click();
				logger.log(LogStatus.INFO, "Erisa Checkbox has been Clicked");
				
			}
			webUtils.scrollDown(driver, save.get(0));
			webUtils.mouseOver(save.get(0), driver);
			save.get(0).click();
			// Added wait time for flow synchronization
			Thread.sleep(2000);
			logger.log(LogStatus.INFO, "Save Button has been Clicked");
			
			try{
				if(okBtn.isDisplayed()){
					logger.log(LogStatus.INFO, "Member already Exists with Member ID :"+memberId);
					resultStr=resultStr+1;
					//System.out.println("Vlaue of result is : "+result );
					
				}
				
				
			}
			
			catch(Exception e){
				
			System.out.println("okBtn Validation is skipped");
			}
			
			
		
			
		
		}
		catch(Exception e) {
			e.printStackTrace();
		}
		return resultStr;
	}
	/**
	 * Verification of the new added Member
	 * 
	 * @throws InterruptedException
	 */
	
	public void verifyNewMember(String rowNum,String lob,WebDriver driver,ExtentTest logger) {
		try {

			
			
			webUtils.explicitWaitByVisibilityofElement(driver, 30, eligibilityFirstRow);
			webUtils.moveToClickableElement(eligibilityFirstRow, driver);
			webUtils.rightClick(driver, eligibilityFirstRow);
			System.out.println("Right Click");
			
			view.click();
			// Added wait time for flow synchronization
			Thread.sleep(2000);
			
			logger.log(LogStatus.INFO, "View button has been Clicked");
			
			webUtils.scrollDown(driver, erisaIND);
			webUtils.mouseOver(erisaIND, driver);
			String text=webUtils.copyTextFromTextBox(erisaIND);
			
			
			System.out.println("Row Number"+rowNum);
			System.out.println("Value for Erisa IND is :"+text);
			if("Y".equalsIgnoreCase(text) && "ASO".equalsIgnoreCase(lob)){
				logger.log(LogStatus.INFO, "Value for ERISA IND is Y");
				
				ExcelUtilities.setCellData("UmIntake", Integer.valueOf(rowNum),
						10, "Pass");
				
			}
			
			if("N".equalsIgnoreCase(text) && "SA".equalsIgnoreCase(lob)){
				logger.log(LogStatus.INFO, "Value for ERISA IND is N");
				ExcelUtilities.setCellData("UmIntake", Integer.valueOf(rowNum),
						10, "Pass");
				
			}
			
			
		
		}
		catch(Exception e) {
			e.printStackTrace();
		}
	}
	
	

}
