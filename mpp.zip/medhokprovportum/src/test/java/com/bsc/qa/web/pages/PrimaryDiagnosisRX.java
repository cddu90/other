package com.bsc.qa.web.pages;

import java.util.Map;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindAll;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;

import com.bsc.qa.framework.base.BasePage;
import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;

import WebUtils.WebUtils;

public class PrimaryDiagnosisRX extends BasePage {

	public WebUtils webUtils = new WebUtils();

	
	@FindAll({ @FindBy(how = How.XPATH, using = "//*[@id='PHARMACY_ICD_GRID_DIV']/div[2]/div/div/div[1]/ul/li/a") })
	public WebElement primaryDiagnosis;
	
	@FindAll({ @FindBy(how = How.XPATH, using = "//*[@id='icd_search_code']") })
	public WebElement diagnosisCode;

	
	@FindAll({ @FindBy(how = How.XPATH, using = "//*[@id='ICD9_SEARCH_BTN_PHARMACY']/div/div/div[2]/div[2]/div/div/a[1]") })
	public WebElement searchButton;
	
	@FindAll({ @FindBy(how = How.XPATH, using = "//*[@id='ICD_GRID']/tr[1]/td[1]/a/span") })
	public WebElement select;
	
	@FindAll({ @FindBy(how = How.XPATH, using = "//*[@id='submit_auth_btn1']") })
	public WebElement submit;
	
	@FindAll({ @FindBy(how = How.XPATH, using = "//*[@id='portel_error_div']/div/div/div[2]/div/button[text()='OK']") })
	public WebElement popUp;
	
	public void enterDetailsInPrimaryDiagnosisRXPage(Map<String, String> data, WebDriver driver, ExtentTest logger)throws InterruptedException{
		webUtils.explicitWaitByElementToBeClickable(driver, "//*[@id='PHARMACY_ICD_GRID_DIV']/div[2]/div/div/div[1]/ul/li/a",60);
		logger.log(LogStatus.INFO, "click on Primary Diagnosis!!");
		primaryDiagnosis.click();
		webUtils.explicitWaitByVisibilityofElement(driver, diagnosisCode);
		logger.log(LogStatus.INFO, "Enter Diagnosis code");
		diagnosisCode.sendKeys(data.get("DiagnosisCode"));
		logger.log(LogStatus.INFO, "Click on Search Button");
		
		logger.log(LogStatus.INFO, "Click on Search Button");
		
		searchButton.click();
		logger.log(LogStatus.INFO, "click on Select Button!!");
		webUtils.explicitWaitByElementToBeClickable(driver, select);
		select.click();
		webUtils.explicitWaitByVisibilityofElement(driver, submit);
		submit.click();
		//webUtils.explicitWaitByVisibilityofElement(driver, popUp);
		//popUp.click();
	
	}

}