package com.bsc.qa.web.pages;

import java.util.List;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindAll;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;

import com.bsc.qa.framework.base.BasePage;
import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;


import WebUtils.WebUtils;

/**
 * @author SaiKiran Ayyagari
 *
 */
public class AuthAccelMemberPage extends BasePage {

	public WebUtils webUtils = new WebUtils();

	@FindAll({ @FindBy(how = How.XPATH, using = "//input[@name='subscriberId']") })
	public WebElement memberId;

	@FindAll({ @FindBy(how = How.NAME, using = "dateOfBirth_dateTextField") })
	public WebElement dateOfBirth;

	@FindAll({ @FindBy(how = How.XPATH, using = "//td[@class='button']") })
	public List<WebElement> buttonList;

	@FindAll({ @FindBy(how = How.XPATH, using = "//div[contains(@id,'isc_MemberSearchForm_')]/following::table[@class='listTable']/tbody/tr/td") })
	public List<WebElement> bscmemberType;
	
	@FindAll({ @FindBy(how = How.XPATH, using = "//div[contains(@id,'isc_MemberSearchForm_')]/following::table[@class='listTable']/tbody/tr") })
	public List<WebElement> care1stMemberType;
		
	// img[contains(@src,'vscroll_end')]

	@FindAll({ @FindBy(how = How.XPATH, using = "//img[contains(@src,'vscroll_end')]") })
	public WebElement scrollEnd;

	@FindAll({ @FindBy(how = How.XPATH, using = "//table/tbody/tr/td/div/div[text()='HICN']") })
	public WebElement LOB;

	@FindAll({ @FindBy(how = How.XPATH, using = "//div[contains(@id,'isc_MemberSearchForm_')]/following::table/tbody/tr/td[6]/div/nobr") })
	public List<WebElement> lobname;

	@FindAll({ @FindBy(how = How.XPATH, using = "//div[text()='Search within MedHOK']") })
	public WebElement memberSearch;
	@FindAll({ @FindBy(how = How.XPATH, using = "//div[contains(@id,'isc_Mem')]//following-sibling::table[@role='presentation' and @class='listTable']//tbody//tr[1]") })
	public WebElement memberSearchFirstRow;
	
	@FindAll({ @FindBy(how = How.XPATH, using = "//nobr/label[contains(text(),'Rx Case #')]/ancestor::td/following::td/input[@name='derNumber']") })
	public WebElement rxCase;
	
	@FindAll({ @FindBy(how = How.XPATH, using = "//td/input[@name='authNumber']") })
	public WebElement authNumber;
		
	@FindAll({ @FindBy(how = How.XPATH, using = "//div[text()='Extended Search']") })
	public WebElement btnExtSearch;
	
	@FindAll({ @FindBy(how = How.XPATH, using = "//nobr/img[contains(@src,'openCase')]") })
	public WebElement openCaselink;
	
	@FindAll({ @FindBy(how = How.XPATH, using = "//td[@class='button']/div/div[contains(text(),'Yes')]") })
	public WebElement btnYes;
	
	@FindAll({ @FindBy(how = How.XPATH, using = "//td[@class='button']/div/div[contains(text(),'Yes')]") })
	public WebElement btnOK;
	
	@FindAll({ @FindBy(how = How.XPATH, using = "//tr/td[contains(text(),'Attachments')]") })
	public WebElement linkAttachments;
	
	@FindAll({ @FindBy(how = How.XPATH, using = "//div[contains(@eventproxy,'isc_ClientDocumentView_')][@class='listGrid']") })
	public WebElement listGridArea;
	
	@FindAll({ @FindBy(how = How.XPATH, using = "//div[@role='presentation']/nobr[text()='Add']") })
	public WebElement addClick;
	
	@FindAll({ @FindBy(how = How.XPATH, using = "//td/label[text()='File']/ancestor::tr/parent::tbody//td//img[contains(@src,'comboBoxPicker.gif')]") })
	public WebElement typeDropdown;
		
	@FindAll({ @FindBy(how = How.XPATH, using = "//div[contains(@eventproxy,'isc_PickListMenu')]//table/tbody/tr[@role='listitem']/td/div/nobr[text()='Additional Information ']") })
	public WebElement chooseAdditionalInfo;
	
	@FindAll({ @FindBy(how = How.XPATH, using = "//td/input[contains(@onselect,'isc_UploadItem')]") })
	public WebElement chooseFiles;
	
	@FindAll({ @FindBy(how = How.XPATH, using = "//td[@class='button']/div/div[text()='Upload']") })
	public WebElement btnUpload;
	
	@FindAll({ @FindBy(how = How.XPATH, using = "//table//td/img[@src='https://uat.medhokbsca.com/medhok/themes/Medhok/images/Scrollbar/hthumb_grip.png']") })
	public List<WebElement> scrollBar;
	
	@FindAll({ @FindBy(how = How.XPATH, using = "//td/div/div[text()='Created at']") })
	public WebElement createdAt;
	
	@FindAll({ @FindBy(how = How.XPATH, using = "//table[@class='listTable']/tbody/tr[@role='listitem'][1]/td[1]") })
	public List<WebElement> listItem;
	
	//String authorizationNumber=AuthAccelFaxPriorAuthPage.referenceNo;
				

	public void searchMembers(String memberid, String buttonName,String membertype,
			WebDriver driver, ExtentTest logger) throws InterruptedException {

		logger.log(LogStatus.INFO, "Search for member with member Id!!");
		webUtils.explicitWaitByVisibilityofElement(driver, 10, memberSearch);
		memberSearch.click();
		memberId = webUtils.explicitWaitByVisibilityofElement(driver, 10,
				memberId);
		logger.log(LogStatus.INFO, "Enter member id!!");
		//memberId.sendKeys(memberid);
		webUtils.sendKeysWithLogger(memberId, memberid, "Member Id", logger, driver);
		
		logger.log(LogStatus.INFO, "Click on search!!");
		webUtils.clickButtonOrLink(buttonList, buttonName, logger, driver);

		logger.log(LogStatus.INFO, "Select subscriber member from the list");
		webUtils.explicitWaitByPresenceofAllElements(driver, 30,
				"//div[contains(@id,'isc_MemberSearchForm_')]/following::table/tbody/tr");
		
		if("Care1st".equalsIgnoreCase(membertype)){
		
		for (WebElement memberType : care1stMemberType) {

			webUtils.horizontalScroll(driver, LOB);

			System.out.println("The member text is " + memberType.getText());

			System.out.println("The color of the text is "
					+ memberType.getCssValue("color"));

			
			 if (memberType.getText().trim().contains("Subscriber")||memberType.getText().trim().contains("SUBSCRIBER") &&
			  (!memberType.getCssValue("color").trim().equalsIgnoreCase(
			  "rgba(214, 73, 73, 1)"
			  )&&!memberType.getCssValue("color").trim().equalsIgnoreCase(
			  "rgb(214, 73, 73")) && (memberType.getText().trim()
			  .contains("MEDI.CAL")||memberType.getText().trim()
			  .contains("MAPD.IND")||memberType.getText().trim()
			  .contains("CA.CCI"))) {
			  
				 memberType.click();
			  
			  webUtils.doubleClick(driver, memberType);
			 
			  break; }
			 
			 else {

					webUtils.scrollDown(driver, memberType);
				}
		}
		}
		else if("BSC".equalsIgnoreCase(membertype)){
			
			for(WebElement bscMemberType : bscmemberType )
			{
			 if ((bscMemberType.getText().trim().contains("Subscriber")||bscMemberType.getText().trim().contains("SUBSCRIBER"))
						&& !bscMemberType.getCssValue("color").trim()
								.equalsIgnoreCase("rgba(214, 73, 73, 1)") && !bscMemberType
								.getCssValue("color").trim()
								.equalsIgnoreCase("rgba(214, 73, 73")) {
					System.out.println("clicking member!!!");
					bscMemberType.click();

					webUtils.doubleClick(driver, bscMemberType);

					break;
				}
			 else {

					webUtils.scrollDown(driver, bscMemberType);
				}
			}
			
		}
		
		/*else
			  if(membertype.getText().trim().contains("Subscriber") &&
			  (!membertype.getCssValue("color").trim().equalsIgnoreCase(
			  "rgba(214, 73, 73, 1)"
			  )&&(!membertype.getCssValue("color").trim().equalsIgnoreCase(
			  "rgb(214, 73, 73"))) && (membertype
			  .getText().trim().contains("CA.CCI")||membertype.getText().trim()
			 .contains("SA")||membertype.getText().trim()
			  .contains("DHMC.EPO")||membertype.getText().trim()
			  .contains("DMHC.HMO")||membertype.getText().trim()
			  .contains("DMHC.POS")||membertype.getText().trim()
			  .contains("DMHC.PPO")||membertype.getText().trim()
			  .contains("DOI.PPO")||membertype.getText().trim()
			  .contains("FEHBP.HMO")||membertype.getText().trim()
			  .contains("MAPD.INDV")||membertype.getText().trim()
			 .contains("MAPD.GRP")||membertype.getText().trim()
			  .contains("PDP.INDV")||membertype.getText().trim()
			  .contains("FEP.PPO.BASIC")||membertype.getText().trim()
			  .contains("FEP.PPO.STD")||membertype.getText().trim()
			  .contains("ASO"))){
			  
			  membertype.click();
			 
			  webUtils.doubleClick(driver, membertype);
			 
			 break;
			  
			  }*/
			

			

			/*
			 * else if ((membertype.getText().trim().contains("Subscriber") &&
			 * !membertype.getCssValue("color").trim().equalsIgnoreCase(
			 * "rgba(214, 73, 73, 1)")) ) {
			 * 
			 * membertype.click();
			 * 
			 * webUtils.doubleClick(driver, membertype);
			 * 
			 * break; }
			 */
		}
	
	public void memberSearch(String memberid, String buttonName,String membertype,
			WebDriver driver, ExtentTest logger) throws InterruptedException {
		
		logger.log(LogStatus.INFO, "Search for member with member Id!!");
		webUtils.explicitWaitByVisibilityofElement(driver, 10, memberSearch);
		memberSearch.click();
		memberId = webUtils.explicitWaitByVisibilityofElement(driver, 10,
				memberId);
		logger.log(LogStatus.INFO, "Enter member id!!");
		memberId.sendKeys(memberid);
		logger.log(LogStatus.INFO, "Click on search!!");

		webUtils.clickButtonOrLink(buttonList, buttonName, logger, driver);

		logger.log(LogStatus.INFO, "Select subscriber member from the list");
		webUtils.explicitWaitByPresenceofAllElements(driver, 30,
				"//div[contains(@id,'isc_MemberSearchForm_')]/following::table/tbody/tr");
		
		memberSearchFirstRow.click();
		webUtils.doubleClick(driver, memberSearchFirstRow);
		System.out.println("First Row has been Selected");
		
		
		
	}
	
	
	
	public void searchRxCase(String rxcase,String docPath,
			WebDriver driver, ExtentTest logger) throws InterruptedException {

		
		logger.log(LogStatus.INFO, "Search for member with member Id!!");
		webUtils.explicitWaitByVisibilityofElement(driver, 10, memberSearch);
		memberSearch.click();
		
		
		webUtils.explicitWaitByVisibilityofElement(driver, 10,
				rxCase);
		logger.log(LogStatus.INFO, "Enter rxcase id!!");
				
		rxCase.sendKeys(rxcase);
		
		
		
		btnExtSearch.click();
		logger.log(LogStatus.INFO, "Click on search!!");
		
		Thread.sleep(5000);// Added wait time for flow synchronization
		
		webUtils.horizontalScroll(driver,openCaselink);
				
		openCaselink.click();
		
		webUtils.explicitWaitByElementToBeClickable(driver, linkAttachments);
						
		linkAttachments.click();
		
		webUtils.explicitWaitByElementToBeClickable(driver,5, listGridArea);
		
		webUtils.rightClick(driver, listGridArea);
		
		addClick.click();
		
		webUtils.explicitWaitByElementToBeClickable(driver,5, typeDropdown);
		typeDropdown.click();
		
		webUtils.explicitWaitByElementToBeClickable(driver,5, chooseAdditionalInfo);
		chooseAdditionalInfo.click();
		
		Thread.sleep(3000);// Added wait time for flow synchronization
		
		String homeDirectory = System.getProperty("user.dir");
		
		System.out.println("the homedirectory is "+homeDirectory);
		
		webUtils.explicitWaitByElementToBeClickable(driver, chooseFiles);

		chooseFiles.sendKeys(homeDirectory+docPath);
		
		//chooseFiles.sendKeys(docPath);
		
		webUtils.explicitWaitByElementToBeClickable(driver, btnUpload);
		
		btnUpload.click();
		
		webUtils.explicitWaitByElementToBeClickable(driver, createdAt);
		
		createdAt.click();
		Thread.sleep(1000);// Added wait time for flow synchronization
		createdAt.click();
		
		Thread.sleep(3000);// Added wait time for flow synchronization
		
		if(listItem.get(0).getText().equals("TU1.pdf")){
			logger.log(LogStatus.INFO, "Verified the uploaded file");
		}
		else{
			logger.log(LogStatus.INFO, "File not uploaded succesfully");
		}
				
		
		}
		
	public void authSearch(String authorizationNumber,String buttonName,
			WebDriver driver, ExtentTest logger) throws InterruptedException {
		
		logger.log(LogStatus.INFO, "Search for member with member Id!!");
		webUtils.explicitWaitByVisibilityofElement(driver, 10, memberSearch);
		memberSearch.click();
		authNumber = webUtils.explicitWaitByVisibilityofElement(driver, 10,
				authNumber);
		logger.log(LogStatus.INFO, "Enter member id!!");
		authNumber.sendKeys(authorizationNumber);
				
		logger.log(LogStatus.INFO, "Click on search!!");

		webUtils.clickButtonOrLink(buttonList, buttonName, logger, driver);

		logger.log(LogStatus.INFO, "Select subscriber member from the list");
		webUtils.explicitWaitByPresenceofAllElements(driver, 30,
				"//div[contains(@id,'isc_MemberSearchForm_')]/following::table/tbody/tr");
		
		memberSearchFirstRow.click();
		webUtils.doubleClick(driver, memberSearchFirstRow);
		System.out.println("First Row has been Selected");
				
		
	}

	}


