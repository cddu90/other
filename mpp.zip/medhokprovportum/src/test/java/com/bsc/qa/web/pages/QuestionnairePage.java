package com.bsc.qa.web.pages;

import java.util.Map;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindAll;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;

import com.bsc.qa.framework.base.BasePage;
import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;

import WebUtils.WebUtils;

public class QuestionnairePage extends BasePage {

	public WebUtils webUtils = new WebUtils();

	@FindAll({ @FindBy(how = How.XPATH, using = "//input[@id='QUESTION_INPUT_0']") })
	public WebElement providerAddress;

	@FindAll({ @FindBy(how = How.XPATH, using = "//input[@id='QUESTION_INPUT_1']") })
	public WebElement providerCity;

	@FindAll({ @FindBy(how = How.XPATH, using = "//input[@id='QUESTION_INPUT_2']") })
	public WebElement providerState;

	@FindAll({ @FindBy(how = How.XPATH, using = "//input[@id='QUESTION_INPUT_3']") })
	public WebElement providerZipCode;

	@FindAll({ @FindBy(how = How.XPATH, using = "//select[@id='QUESTION_INPUT_4']") })
	public WebElement thisRequest;

	@FindAll({ @FindBy(how = How.XPATH, using = "//*[@id='QUESTION_INPUT_11']") })
	public WebElement administration;

	@FindAll({ @FindBy(how = How.XPATH, using = "//select[@id='QUESTION_INPUT_13']") })
	public WebElement localAdministration;

	@FindAll({ @FindBy(how = How.XPATH, using = "//select[@id='QUESTION_INPUT_15']") })
	public WebElement medications;

	@FindAll({ @FindBy(how = How.XPATH, using = "//select[@id='QUESTION_INPUT_17']") })
	public WebElement attest;

	@FindAll({ @FindBy(how = How.XPATH, using = "//span[@id='MedicalQuestionSetName']") })
	public WebElement setName;

	@FindAll({ @FindBy(how = How.XPATH, using = "//*[@id='submit_questionsets_for_medical_pre_condition']/span") })
	public WebElement questionnaireSubmit;

	@FindAll({ @FindBy(how = How.XPATH, using = "//*[@id='medical_decisionTree_close_btn']/span") })
	public WebElement questionnaireClose;

	public void enterDetailsInQuestionnairePage(Map<String, String> data, WebDriver driver, ExtentTest logger)
			throws InterruptedException {
		// Enter details in Questionnaire Page
		String string = data.get("Questionnaire");
		String[] parts = string.split(";");
		webUtils.explicitWaitByVisibilityofElement(driver, setName);

		logger.log(LogStatus.INFO, ":::::::::::::::::::::::Add Questionnaire::::::::::::::::: !!");
		if (setName.isDisplayed()) {
			webUtils.explicitWaitByVisibilityofElement(driver, providerAddress);
//		logger.log(LogStatus.INFO, "Entered provider Address!!");
			providerAddress.sendKeys(parts[0]);

			webUtils.explicitWaitByVisibilityofElement(driver, providerCity);
//		logger.log(LogStatus.INFO, "enter details provider City!!");
			providerCity.sendKeys(parts[1]);

			webUtils.explicitWaitByVisibilityofElement(driver, providerState);
//		logger.log(LogStatus.INFO, "enter details provider State!!");
			providerState.sendKeys(parts[2]);

			webUtils.explicitWaitByVisibilityofElement(driver, providerZipCode);
//		logger.log(LogStatus.INFO, "enter details providerZipCode!!");
			providerZipCode.sendKeys(parts[3]);

			webUtils.explicitWaitByVisibilityofElement(driver, thisRequest);
//		logger.log(LogStatus.INFO, "enter details thisRequest!!");

			webUtils.selectDropdownValueByVisibleText(thisRequest, parts[4], logger, driver);

			webUtils.explicitWaitByVisibilityofElement(driver, administration);
//		logger.log(LogStatus.INFO, "enter details administration!!");
			Thread.sleep(1500); // Added wait time for flow synchronization

			webUtils.selectDropdownValueByVisibleText(administration, parts[5], logger, driver);

			webUtils.explicitWaitByVisibilityofElement(driver, localAdministration);
//		logger.log(LogStatus.INFO, "enter details localAdministration!!");
			Thread.sleep(1500); // Added wait time for flow synchronization

			webUtils.selectDropdownValueByVisibleText(localAdministration, parts[6], logger, driver);

			webUtils.explicitWaitByVisibilityofElement(driver, medications);
//		logger.log(LogStatus.INFO, "enter details medications!!");
			Thread.sleep(1500); // Added wait time for flow synchronization
			webUtils.selectDropdownValueByVisibleText(medications, parts[7], logger, driver);
			webUtils.explicitWaitByVisibilityofElement(driver, attest);

//		logger.log(LogStatus.INFO, "enter details attest!!");
			Thread.sleep(1500); // Added wait time for flow synchronization
			webUtils.selectDropdownValueByVisibleText(attest, parts[8], logger, driver);
			Thread.sleep(1500);
			//webUtils.waitUntilclickable(questionnaireSubmit, driver);
//		logger.log(LogStatus.INFO, "enter details questionnaireSubmit!!");
			questionnaireSubmit.click();
			Thread.sleep(6500);
			//webUtils.waitUntilclickable(questionnaireClose, driver);
			webUtils.explicitWaitByElementToBeClickable(driver, 300, questionnaireClose);
			questionnaireClose.click();
			Thread.sleep(3500);
		}
	}

}
