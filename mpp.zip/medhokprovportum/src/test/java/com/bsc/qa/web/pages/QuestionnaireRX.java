package com.bsc.qa.web.pages;

import java.util.Map;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindAll;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;

import com.bsc.qa.framework.base.BasePage;
import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;

import WebUtils.WebUtils;

public class QuestionnaireRX extends BasePage {

	public WebUtils webUtils = new WebUtils();

	
	@FindAll({ @FindBy(how = How.XPATH, using = "//input[@id='question_input_0']") })
	public WebElement providerAddress;
	
	@FindAll({ @FindBy(how = How.XPATH, using = "//input[@id='question_input_1']") })
	public WebElement providerCity;
	
	@FindAll({ @FindBy(how = How.XPATH, using = "//input[@id='question_input_2']") })
	public WebElement providerState;
	
	@FindAll({ @FindBy(how = How.XPATH, using = "//input[@id='question_input_3']") })
	public WebElement providerZipCode;
	
	@FindAll({ @FindBy(how = How.XPATH, using = "//select[@id='question_input_4']") })
	public WebElement thisRequest;
	
	@FindAll({ @FindBy(how = How.XPATH, using = "//*[@id='question_input_11']") })
	public WebElement administration;
	
	@FindAll({ @FindBy(how = How.XPATH, using = "//select[@id='question_input_13']") })
	public WebElement localAdministration;
	
	@FindAll({ @FindBy(how = How.XPATH, using = "//select[@id='question_input_15']") })
	public WebElement medications;
	
	@FindAll({ @FindBy(how = How.XPATH, using = "//select[@id='question_input_17']") })
	public WebElement attest;

	@FindAll({ @FindBy(how = How.XPATH, using = "//span[@id='QuestionSetName']") })
	public WebElement setName;
	
	@FindAll({ @FindBy(how = How.XPATH, using = "//*[@id='submit_questionsets_for_rx_pre_condition']") })
	public WebElement questionnaireSubmit;
	
	@FindAll({ @FindBy(how = How.XPATH, using = "//*[@id='decisionTree_close_btn']") })
	public WebElement questionnaireClose;
	
	public void enterDetailsInQuestionnaireRXPage(Map<String, String> data, WebDriver driver, ExtentTest logger)throws InterruptedException{
		
		String string = data.get("Questionnaire");
		String[] parts = string.split(";");
		// Added wait time for flow synchronization
	    Thread.sleep(2000);
		if(setName.isDisplayed()){
		webUtils.explicitWaitByVisibilityofElement(driver, providerAddress);
		logger.log(LogStatus.INFO, "enter details provider Address!!");
		providerAddress.sendKeys(parts[0]);
		webUtils.explicitWaitByVisibilityofElement(driver, providerCity);
		logger.log(LogStatus.INFO, "enter details provider Address!!");
		providerCity.sendKeys(parts[1]);
		webUtils.explicitWaitByVisibilityofElement(driver, providerState);
		logger.log(LogStatus.INFO, "enter details provider State!!");
		providerState.sendKeys(parts[2]);
	    webUtils.explicitWaitByVisibilityofElement(driver, providerZipCode);
		logger.log(LogStatus.INFO, "enter details providerZipCode!!");
		providerZipCode.sendKeys(parts[3]);
		 
		webUtils.explicitWaitByVisibilityofElement(driver, thisRequest);
		logger.log(LogStatus.INFO, "enter details thisRequest!!");
		webUtils.selectDropdownValueByVisibleText(thisRequest, parts[4], logger, driver);
		webUtils.explicitWaitByVisibilityofElement(driver, administration);
		logger.log(LogStatus.INFO, "enter details administration!!");
		// Added wait time for flow synchronization
		 Thread.sleep(2000);
		webUtils.selectDropdownValueByVisibleText(administration, parts[5], logger, driver);
		webUtils.explicitWaitByVisibilityofElement(driver, localAdministration);
		logger.log(LogStatus.INFO, "enter details localAdministration!!");
		// Added wait time for flow synchronization
		 Thread.sleep(1500);
		webUtils.selectDropdownValueByVisibleText(localAdministration, parts[6], logger, driver);
		webUtils.explicitWaitByVisibilityofElement(driver, medications);
		logger.log(LogStatus.INFO, "enter details medications!!");
		// Added wait time for flow synchronization
		Thread.sleep(1500);
		webUtils.selectDropdownValueByVisibleText(medications, parts[7], logger, driver);
		webUtils.explicitWaitByVisibilityofElement(driver, attest);
		
		logger.log(LogStatus.INFO, "enter details attest!!");
		// Added wait time for flow synchronization
		Thread.sleep(1500);
		webUtils.selectDropdownValueByVisibleText(attest, parts[8], logger, driver);
	
		
		logger.log(LogStatus.INFO, "enter details questionnaireSubmit!!");
		questionnaireSubmit.click();
		// Added wait time for flow synchronization
		Thread.sleep(1500);
		if(questionnaireClose.isEnabled()){
		questionnaireClose.click();
		}
		else
		{
			// Added wait time for flow synchronization
			Thread.sleep(2000);
			questionnaireClose.click();
		}
		}
	}

}
