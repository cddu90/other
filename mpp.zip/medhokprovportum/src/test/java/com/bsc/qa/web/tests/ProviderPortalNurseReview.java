/**
 * @author vthiru03
 * @category testcase
 * @class UnAuthenicatedPageLinksTest
 * @Uses PageObject CitrixLandingPage , MemberWhyBlueShieldPage, memberFindAPlanPage
 * @since 3/24/2017
 * 
 */
package com.bsc.qa.web.tests;

import java.io.File;
import java.lang.reflect.Method;
import java.sql.Timestamp;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;
import org.testng.IHookCallBack;
import org.testng.IHookable;
import org.testng.ITestResult;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import WebUtils.CsvUtils;
import WebUtils.ExcelUtilities;

import com.bsc.qa.framework.base.BaseTest;
import com.bsc.qa.framework.factory.BrowserFactoryManager;
import com.bsc.qa.framework.factory.ReportFactory;
import com.bsc.qa.web.pages.AuthAccel360MemPage;
import com.bsc.qa.web.pages.AuthAccelAddMember;
import com.bsc.qa.web.pages.AuthAccelFaxPriorAuthPage;
import com.bsc.qa.web.pages.AuthAccelHomePage;
import com.bsc.qa.web.pages.AuthAccelLoginPage;
import com.bsc.qa.web.pages.AuthAccelMemberPage;
import com.bsc.qa.web.pages.AuthAccelPriorAuthReviewPage;
import com.bsc.qa.web.pages.ProviderPortalHomePage;
import com.bsc.qa.web.pages.ProviderPortalLoginPage;
import com.relevantcodes.extentreports.LogStatus;


public class ProviderPortalNurseReview extends BaseTest implements IHookable {

	private static String environment;
	private static String DataSheet;
	private AuthAccelLoginPage authAccelLoginPage;
	private AuthAccelAddMember authAccelAddMember;
	private AuthAccelHomePage authAccelHomePage;
	private AuthAccel360MemPage authAccel360MemPage;
	private AuthAccelMemberPage authAccelMemberPage;
	private AuthAccelFaxPriorAuthPage authAccelFaxPriorAuthPage;
	private AuthAccelPriorAuthReviewPage authAccelPriorAuthReviewPage;
	private ProviderPortalLoginPage providerPortalLoginPage;
	private ProviderPortalHomePage providerPortalHomePage;

	private File sourceDatasheet; //Variable to store for data sheet details 
	public String csvFilePath = "src/test/resources/AuthorizationNumber.csv"; //CSV file to store authorization numbers
	private List<String[]> listFromCSV = null; // Variable to store TestcaseID and Authorization number from CSV file

	
	// Generate current date
	public DateFormat dateFormat = new SimpleDateFormat("MM/dd/yyyy");
	public Date date = new Date();
	
	
	public String Current_Date= dateFormat.format(date);
	public String DischargeDate=dateFormat.format(addDays(date,2));;
	public String FromDT=Current_Date;
	public String ThruDT=dateFormat.format(addDays(date,1));
	
	
	
	// Now format the date	
	public static Date addDays(Date day, int days){
        day.setTime(day.getTime() + days * 1000 * 60 * 60 * 24);
        return day;
    }
	

	
	/**
	 *  Method to read Auth Number from CSV file / Executes from @test method
	 **/ 	
	private String getAuthNumber(String testcaseID){
		if (listFromCSV == null) {
			listFromCSV = CsvUtils.readAllDataAtOnce(csvFilePath); //Reading from CSV file and storing in a list
		}
		String testID=null; //Variable to store Testcase ID
		String auth=null; //Variable to store Auth number
		
		// Looping through the list from CSV file
        for (String[] row : listFromCSV) { 
        	
        	testID=row[0];
        	
        	if(testID.trim().equalsIgnoreCase(testcaseID.trim())){
        		
        		auth=row[1];
        	}
        }
		return auth;//Finally collecting Authorization number from CSV file
	}
	
	
	/**
	 * @param method to retrive data from datasheet
	 * @return nurse revie sheet data
	 */
	
	@DataProvider(name = "UMTestCases")
	private static Object[][] getData(Method method) {

		

		Object[][] columnArray = ExcelUtilities.getColumnArray(DataSheet,
				environment);
	
		Object[][] testDataArray = ExcelUtilities.getTableArray(DataSheet,
				environment);
		List<Object> list = new ArrayList<Object>();
		for (int i = 0; i < columnArray[0].length; i++) {

		}

		int noOfTestCases = 0;
		String runMode = "Yes";
		for (int row = 0; row <= testDataArray.length - 1; row++) {

			if (method.getName().equalsIgnoreCase(
					testDataArray[row][1].toString())
					&& runMode.equalsIgnoreCase(testDataArray[row][2]
							.toString())) {
				noOfTestCases++;

				System.out.println("TestCase Name Form Data Sheet:::"
						+ testDataArray[row][0].toString() + "and execution flag is "+ testDataArray[row][2].toString() );
				Map<String, String> rowDataMap = new HashMap<String, String>();
				for (int col = 0; col <= columnArray[0].length - 1; col++) {
										rowDataMap.put(columnArray[0][col].toString(),
							testDataArray[row][col].toString());
					rowDataMap.put("rowNum", String.valueOf(row));
					
				}
				/*rowDataMap.put("rowNum", String.valueOf(rowNum));

				rowNum++;*/
				list.add(rowDataMap);

			} 

		}

		Object[][] data = new Object[noOfTestCases][1];
		for (int row = 0; row < list.size(); row++) {
			data[row][0] = list.get(row);
		}

		return data;

	}

	/**
	 * setUp is a @BeforeMethod executed before execution of a @Test
	 * 
	 * @param browser_
	 * @param driver_
	 * @param env_
	 * @param url_
	 * @throws Exception
	 */
	@BeforeClass
	
	@Parameters({ "Browser_", "Driver_", "Env_", "URL_", "Datasheet_" })
	public void setUp(@Optional("browser") String browserStr,
			@Optional("webDriver") String driverStr,
			@Optional("Env_") String envStr, @Optional("url") String urlStr,
			@Optional("Datasheet") String datasheet)  {
		// boolean error = false;
		browser = browserStr;
		webDriver = driverStr;
		environment = envStr; // System.getenv("ENVNAME");
		System.out.print(environment);
		url = urlStr;
		DataSheet = datasheet;
		System.out.println(DataSheet);
		sourceDatasheet = new File(DataSheet);
		
		
		// ExcelUtilities.setUpExcel(DataSheet);
	}

	/**
	 * Run when the test method runs
	 */
	protected void initBrowser(String testCaseName, String testMethodName) {
		WebDriver driver = BrowserFactoryManager.getDriver();

		authAccelLoginPage = PageFactory.initElements(driver,AuthAccelLoginPage.class);
		
		authAccelLoginPage.setPage(driver, browser, environment, testCaseName);

		authAccelHomePage = PageFactory.initElements(driver,AuthAccelHomePage.class);
		
		authAccelHomePage.setPage(driver, browser, environment, testCaseName);

		authAccelMemberPage = PageFactory.initElements(driver,AuthAccelMemberPage.class);
		
		authAccelMemberPage.setPage(driver, browser, environment, testCaseName);

		authAccel360MemPage = PageFactory.initElements(driver,AuthAccel360MemPage.class);

		authAccel360MemPage.setPage(driver, browser, environment, testCaseName);
		
		authAccelAddMember = PageFactory.initElements(driver,AuthAccelAddMember.class);
		
		authAccelAddMember.setPage(driver, browser, environment, testCaseName);

		authAccelFaxPriorAuthPage = PageFactory.initElements(driver,AuthAccelFaxPriorAuthPage.class);

		authAccelFaxPriorAuthPage.setPage(driver, browser, environment,testCaseName);

		authAccelPriorAuthReviewPage = PageFactory.initElements(driver,AuthAccelPriorAuthReviewPage.class);

		authAccelPriorAuthReviewPage.setPage(driver, browser, environment,testCaseName);

		providerPortalLoginPage = PageFactory.initElements(driver,ProviderPortalLoginPage.class);
		
		providerPortalHomePage = PageFactory.initElements(driver,ProviderPortalHomePage.class);

	}
	
	
	
	

	@Test(dataProvider = "UMTestCases")
	public void testNurseReviewCancelLetters(Map<String, String> data) throws Exception {
		
		try {
			WebDriver driver = BrowserFactoryManager.getDriver();
			
			// Logging into Auth Accel page
			authAccelLoginPage.applicationLogin(data.get("UserName"),data.get("Password"),driver, logger);
			
			authAccelHomePage.selectRole(data.get("SelectRole"), driver, logger);

			authAccelHomePage.search("Member", logger, driver);
			
			authAccelHomePage.nurseMemberSelect(getAuthNumber(data.get("TestCaseName")), logger, driver);
			
			authAccelPriorAuthReviewPage.selectDecision(driver, logger,data.get("Decision"), data.get("DecisionReason"),
					data.get("Bedtype"), data.get("TestCase Type"),data.get("TaskName"),data.get("TestCase Type"),FromDT,ThruDT,data.get("Criteria"),data.get("Policy"),data.get("Rationale"));

			authAccelPriorAuthReviewPage.selectAuthorizationDecision(
					data.get("Decision"), data.get("DecisionReason"), driver,data.get("TestCase Type"),data.get("Service Category"),logger);

			if(data.get("Decision").equalsIgnoreCase("Denied") || data.get("Decision").equalsIgnoreCase("Partially Denied")){

				authAccelPriorAuthReviewPage.selectAuthorizationDecisionWithMDRecom(data.get("Decision"), data.get("DecisionReason"), driver,
					data.get("TestCase Type"),data.get("Service Category"),data.get("MD Name"),logger);

			}
			
			authAccelPriorAuthReviewPage.generateAllLetters(driver,data.get("Letter Required"), data.get("Letter Type"),logger);
			
			authAccelPriorAuthReviewPage.completeAuthorizationCancelLetter(driver,data.get("Status"), data.get("StatusReason"),DischargeDate, data.get("TestCase Type"),
					data.get("Letter Type"), data.get("Letter Required"),data.get("Decision"), data.get("Withdrawn By"),data.get("TaskName"),data.get("Cancel Letters"),data.get("Cancel Reason"), logger,data.get("Adm Bed Type"));

			providerPortalLoginPage.login(data.get("ProviderCode"), driver,logger);

			String actAuthStatus = providerPortalHomePage.viewStatus(driver, logger,"NurseReview", data,data.get("rowNum"),data.get("TestCaseName"));
			
			
		    
		    softAssert.assertEquals(actAuthStatus, data.get("Status"));

		}
		catch (InterruptedException e) {		
			 
			e.printStackTrace();
		}
	}
	
	@Test(dataProvider = "UMTestCases")
	public void testNurseReviewFEPRxCancelLetters(Map<String, String> data) throws Exception {
		
		try {
			WebDriver driver = BrowserFactoryManager.getDriver();

			// Logging into Auth Accel page
			authAccelLoginPage.applicationLogin(data.get("UserName"),data.get("Password"),driver, logger);
			
			authAccelHomePage.selectRole(data.get("SelectRole"), driver, logger);

			authAccelHomePage.search("Member", logger, driver);
			
			authAccelHomePage.nurseMemberSelect(getAuthNumber(data.get("TestCaseName")), logger, driver);
			
			authAccelPriorAuthReviewPage.selectDecisionWithLineFEPRx(driver, logger,data.get("Decision"), data.get("DecisionReason"),
					data.get("Bedtype"), data.get("TestCase Type"),data.get("TaskName"),data.get("TestCase Type"),FromDT,ThruDT,data.get("Criteria"),data.get("Policy"),data.get("Rationale"));

			authAccelPriorAuthReviewPage.selectAuthorizationDecisionWithMDRecom(data.get("Decision"), data.get("DecisionReason"), driver,data.get("TestCase Type"),data.get("Service Category"),data.get("MD Name"),logger);
			
			authAccelPriorAuthReviewPage.generateAllLetters(driver,data.get("Letter Required"), data.get("Letter Type"),logger);
			
			authAccelPriorAuthReviewPage.completeAuthorization(driver,data.get("Status"), data.get("StatusReason"),DischargeDate, data.get("TestCase Type"),
					data.get("Letter Type"), data.get("Letter Required"),data.get("Decision"), data.get("Withdrawn By"),data.get("TaskName"),data.get("Cancel Letters"),data.get("Cancel Reason"), logger,data.get("Adm Bed Type"));

			providerPortalLoginPage.login(data.get("ProviderCode"), driver,logger);

			String actAuthStatus = providerPortalHomePage.viewStatus(driver, logger,"NurseReview", data,data.get("rowNum"),data.get("TestCaseName"));
			
		    softAssert.assertEquals(actAuthStatus, data.get("Status"));

		}
		catch (InterruptedException e) {		
			 
			e.printStackTrace();
		}
	}
	
	@Test(dataProvider = "UMTestCases")
	public void testNurseReviewCancelLOILetters(Map<String, String> data) throws Exception {
		
		try {
			WebDriver driver = BrowserFactoryManager.getDriver();
			
			// Logging into Auth Accel page
			authAccelLoginPage.applicationLogin(data.get("UserName"),data.get("Password"),driver, logger);
			
			authAccelHomePage.selectRole(data.get("SelectRole"), driver, logger);

			authAccelHomePage.search("Member", logger, driver);
			
			authAccelHomePage.nurseMemberSelect(getAuthNumber(data.get("TestCaseName")), logger, driver);
			
			authAccelPriorAuthReviewPage.selectDecision(driver, logger,data.get("Decision"), data.get("DecisionReason"),data.get("Bedtype"), data.get("TestCase Type"),
					data.get("TaskName"),data.get("TestCase Type"),FromDT,ThruDT,data.get("Criteria"),data.get("Policy"),data.get("Rationale"));

			authAccelPriorAuthReviewPage.selectAuthorizationDecision(data.get("Decision"), data.get("DecisionReason"), driver,data.get("TestCase Type"),data.get("Service Category"),logger);

			authAccelPriorAuthReviewPage.generateLOILetter(driver,data.get("Letter Required"), data.get("Letter Type"),logger);
			
			authAccelPriorAuthReviewPage.completeAuthorizationCancelLetter(driver,data.get("Status"), data.get("StatusReason"),DischargeDate, data.get("TestCase Type"),
					data.get("Letter Type"), data.get("Letter Required"),data.get("Decision"), data.get("Withdrawn By"),data.get("TaskName"),data.get("Cancel Letters"),data.get("Cancel Reason"), logger,data.get("Adm Bed Type"));

			providerPortalLoginPage.login(data.get("ProviderCode"), driver,logger);

			String actAuthStatus = providerPortalHomePage.viewStatus(driver, logger,"NurseReview", data,data.get("rowNum"),data.get("TestCaseName"));
		
			
		    softAssert.assertEquals(actAuthStatus, data.get("Status"));
	
			}
			catch (InterruptedException e) {		
				 
				e.printStackTrace();
			}
	}

	@Test(dataProvider = "UMTestCases")
	public void testNurseReviewPharm(Map<String, String> data) throws Exception {
		
		try {
			WebDriver driver = BrowserFactoryManager.getDriver();
			
			// Logging into Auth Accel page
			authAccelLoginPage.applicationLogin(data.get("UserName"),data.get("Password"),driver, logger);
			
			authAccelHomePage.selectRole(data.get("SelectRole"), driver, logger);
			
			authAccelHomePage.search("Member", logger, driver);
			
			authAccelHomePage.nurseMemberSelect(getAuthNumber(data.get("TestCaseName")), logger, driver);
	
			authAccelPriorAuthReviewPage.completeAuthorizationPharmtech(driver,data.get("Status"), data.get("StatusReason"),DischargeDate, data.get("TestCase Type"),data.get("Letter Type"), data.get("Letter Required"),
					data.get("Decision"), data.get("Withdrawn By"),data.get("TaskName"),data.get("Cancel Letters"),data.get("Cancel Reason"), logger);
			
			authAccelHomePage.selectRolePharmacist("UM Pharmacist", driver, logger);
			
			authAccelPriorAuthReviewPage.taskVerification(driver,getAuthNumber(data.get("TestCaseName")), "Pharmacist Review", logger);
			
			providerPortalLoginPage.login(data.get("ProviderCode"), driver,logger);
	
			String actAuthStatus = providerPortalHomePage.viewStatus(driver, logger,"NurseReview", data,data.get("rowNum"),data.get("TestCaseName"));
			
			
		    softAssert.assertEquals(actAuthStatus, data.get("Status"));
		
			}
			catch (InterruptedException e) {		
				 
				e.printStackTrace();
			}
	}



	@Test(dataProvider = "UMTestCases")
	public void testNurseReviewWithAddLine(Map<String, String> data) throws Exception {
		
					
		try {
			WebDriver driver = BrowserFactoryManager.getDriver();
			
			// Logging into Auth Accel page
			authAccelLoginPage.applicationLogin(data.get("UserName"),data.get("Password"),driver, logger);
			
			authAccelHomePage.selectRole(data.get("SelectRole"), driver, logger);

			authAccelHomePage.search("Member", logger, driver);

			authAccelHomePage.nurseMemberSelect(getAuthNumber(data.get("TestCaseName")), logger, driver);
			
			authAccelPriorAuthReviewPage.selectDecisionWithLine(driver, logger,data.get("Decision"), data.get("DecisionReason"), data.get("Bedtype"),data.get("TestCase Type"),data.get("TaskName"),
					data.get("TestCase Type"),FromDT,ThruDT,data.get("Criteria"),data.get("Policy"),data.get("Rationale"),data.get("Procedure Code"));
		  	
			authAccelPriorAuthReviewPage.selectAuthorizationDecisionWithMDRecom(data.get("Decision"), data.get("DecisionReason"), driver,
					data.get("TestCase Type"),data.get("Service Category"),data.get("MD Name"),logger);
			
			authAccelPriorAuthReviewPage.generateAllLetters(driver,data.get("Letter Required"), data.get("Letter Type"),logger);
			
			authAccelPriorAuthReviewPage.completeAuthorization(driver,data.get("Status"), data.get("StatusReason"),DischargeDate, data.get("TestCase Type"),data.get("Letter Type"), data.get("Letter Required"),
					data.get("Decision"), data.get("Withdrawn By"),data.get("TaskName"),data.get("Cancel Letters"),data.get("Cancel reason"), logger,data.get("Adm Bed Type"));

			providerPortalLoginPage.login(data.get("ProviderCode"), driver,logger);

			String actAuthStatus = providerPortalHomePage.viewStatus(driver, logger,"NurseReview", data,data.get("rowNum"),data.get("TestCaseName"));
			
			
		    softAssert.assertEquals(actAuthStatus, data.get("Status"));

		}
		catch (InterruptedException e) {		
			 
			e.printStackTrace();
		}
	}

	@Test(dataProvider = "UMTestCases")
	public void testNurseReviewNurseRecomm(Map<String, String> data) throws Exception {
					
		try {
			WebDriver driver = BrowserFactoryManager.getDriver();
			
			// Logging into Auth Accel page
			authAccelLoginPage.applicationLogin(data.get("UserName"),data.get("Password"),driver, logger);
			
			authAccelHomePage.selectRole(data.get("SelectRole"), driver, logger);

			authAccelHomePage.search("Member", logger, driver);
			
			authAccelHomePage.nurseMemberSelect(getAuthNumber(data.get("TestCaseName")), logger, driver);
		
			authAccelPriorAuthReviewPage.selectDecisionWithLine(driver, logger,data.get("Decision"), data.get("DecisionReason"),data.get("Bedtype"), data.get("TestCase Type"),data.get("TaskName"),
					data.get("TestCase Type"),FromDT,ThruDT,data.get("Criteria"),data.get("Policy"),data.get("Rationale"),data.get("Procedure Code"));

			authAccelPriorAuthReviewPage.selectAuthorizationDecisionWithNurseRecom(data.get("Decision"), data.get("DecisionReason"), driver,
					data.get("TestCase Type"),data.get("Service Category"),data.get("MD Name"),logger);

			if(data.get("Decision").equalsIgnoreCase("Denied") || data.get("Decision").equalsIgnoreCase("Partially Denied")){
				
				authAccelPriorAuthReviewPage.selectAuthorizationDecisionWithMDRecom(data.get("Decision"), data.get("DecisionReason"), driver,
						data.get("TestCase Type"),data.get("Service Category"),data.get("MD Name"),logger);

				}
			
			authAccelPriorAuthReviewPage.generateAllLetters(driver,data.get("Letter Required"), data.get("Letter Type"),logger);
			
			authAccelPriorAuthReviewPage.completeAuthorization(driver,data.get("Status"), data.get("StatusReason"),DischargeDate, data.get("TestCase Type"),
					data.get("Letter Type"), data.get("Letter Required"),data.get("Decision"), data.get("Withdrawn By"),data.get("TaskName"),data.get("Cancel Letters"),data.get("Cancel reason"), logger,data.get("Adm Bed Type"));

			providerPortalLoginPage.login(data.get("ProviderCode"), driver,logger);

			String actAuthStatus = providerPortalHomePage.viewStatus(driver, logger,"NurseReview", data,data.get("rowNum"),data.get("TestCaseName"));
			
			
		    softAssert.assertEquals(actAuthStatus, data.get("Status"));
	
			}
			catch (InterruptedException e) {		
				 
				e.printStackTrace();
			}
		}

		@Test(dataProvider = "UMTestCases")
		public void testNurseReviewDNDLetter(Map<String, String> data) throws Exception {
						
			try {
				WebDriver driver = BrowserFactoryManager.getDriver();
				
				// Logging into Auth Accel page
				authAccelLoginPage.applicationLogin(data.get("UserName"),data.get("Password"),driver, logger);
				
				authAccelHomePage.selectRole(data.get("SelectRole"), driver, logger);
				
				authAccelHomePage.search("Member", logger, driver);
				
				authAccelHomePage.nurseMemberSelect(getAuthNumber(data.get("TestCaseName")), logger, driver);
				
				authAccelPriorAuthReviewPage.selectDecisionWithLine(driver, logger,data.get("Decision"), data.get("DecisionReason"),
						data.get("Bedtype"), data.get("TestCase Type"),data.get("TaskName"),data.get("TestCase Type"),FromDT,ThruDT,data.get("Criteria"),data.get("Policy"),data.get("Rationale"),data.get("Procedure Code"));
				
				authAccelPriorAuthReviewPage.selectAuthorizationDecisionWithNurseRecom(data.get("Decision"), data.get("DecisionReason"), driver,
						data.get("TestCase Type"),data.get("Service Category"),data.get("MD Name"),logger);

				if(data.get("Decision").equalsIgnoreCase("Denied") || data.get("Decision").equalsIgnoreCase("Partially Denied")){
					
					authAccelPriorAuthReviewPage.selectAuthorizationDecisionWithMDRecom(data.get("Decision"), data.get("DecisionReason"), driver,
							data.get("TestCase Type"),data.get("Service Category"),data.get("MD Name"),logger);
					}
				
				authAccelPriorAuthReviewPage.generateDNDLetter(driver,data.get("Letter Required"), data.get("Letter Type"),logger);
				
				authAccelPriorAuthReviewPage.completeAuthorization(driver,data.get("Status"), data.get("StatusReason"),DischargeDate, data.get("TestCase Type"),
						data.get("Letter Type"), data.get("Letter Required"),data.get("Decision"), data.get("Withdrawn By"),data.get("TaskName"),data.get("Cancel Letters"),data.get("Cancel reason"), logger,data.get("Adm Bed Type"));

				providerPortalLoginPage.login(data.get("ProviderCode"), driver,logger);

				String actAuthStatus = providerPortalHomePage.viewStatus(driver, logger,"NurseReview", data,data.get("rowNum"),data.get("TestCaseName"));
				
				
			    softAssert.assertEquals(actAuthStatus, data.get("Status"));
	
				}
				catch (InterruptedException e) {		
					 
					e.printStackTrace();
				}
			}


		@Test(dataProvider = "UMTestCases")
		public void testNurseReviewDENCLetter(Map<String, String> data) throws Exception {
						
			try {
				WebDriver driver = BrowserFactoryManager.getDriver();
				
				// Logging into Auth Accel page
				authAccelLoginPage.applicationLogin(data.get("UserName"),data.get("Password"),driver, logger);
				
				authAccelHomePage.selectRole(data.get("SelectRole"), driver, logger);
				
				authAccelHomePage.search("Member", logger, driver);
				
				authAccelHomePage.nurseMemberSelect(getAuthNumber(data.get("TestCaseName")), logger, driver);
				
				authAccelPriorAuthReviewPage.selectDecisionWithLine(driver, logger,data.get("Decision"), data.get("DecisionReason"),
						data.get("Bedtype"), data.get("TestCase Type"),data.get("TaskName"),data.get("TestCase Type"),FromDT,ThruDT,data.get("Criteria"),data.get("Policy"),data.get("Rationale"),data.get("Procedure Code"));

				authAccelPriorAuthReviewPage.selectAuthorizationDecision(data.get("Decision"), data.get("DecisionReason"), driver,data.get("TestCase Type"),data.get("Service Category"),logger);
				
				if(data.get("Decision").equalsIgnoreCase("Denied") || data.get("Decision").equalsIgnoreCase("Partially Denied")){
					
					authAccelPriorAuthReviewPage.selectAuthorizationDecisionWithMDRecom(data.get("Decision"), data.get("DecisionReason"), driver,
							data.get("TestCase Type"),data.get("Service Category"),data.get("MD Name"),logger);

					}
				
				if(data.get("Decision").equalsIgnoreCase("Denied") || data.get("Decision").equalsIgnoreCase("Partially Denied")){
					
					authAccelPriorAuthReviewPage.selectAuthorizationDecisionWithMDRecom(data.get("Decision"), data.get("DecisionReason"), driver,
							data.get("TestCase Type"),data.get("Service Category"),data.get("MD Name"),logger);

					}
				
				authAccelPriorAuthReviewPage.generateDENCLetter(driver,data.get("Letter Required"), data.get("Letter Type"),logger);
				
				authAccelPriorAuthReviewPage.completeAuthorization(driver,data.get("Status"), data.get("StatusReason"),DischargeDate, data.get("TestCase Type"),
						data.get("Letter Type"), data.get("Letter Required"),data.get("Decision"), data.get("Withdrawn By"),data.get("TaskName"),data.get("Cancel Letters"),data.get("Cancel reason"), logger,data.get("Adm Bed Type"));

				providerPortalLoginPage.login(data.get("ProviderCode"), driver,logger);
	
				String actAuthStatus = providerPortalHomePage.viewStatus(driver, logger,"NurseReview", data,data.get("rowNum"),data.get("TestCaseName"));
				
				
			    softAssert.assertEquals(actAuthStatus, data.get("Status"));
	
				}
				catch (InterruptedException e) {		
					 
					e.printStackTrace();
				}
			}
		@Test(dataProvider = "UMTestCases")
		public void testNurseReviewNOMNCLetter(Map<String, String> data) throws Exception {
						
			try {
				WebDriver driver = BrowserFactoryManager.getDriver();
				
				// Logging into Auth Accel page
				authAccelLoginPage.applicationLogin(data.get("UserName"),data.get("Password"),driver, logger);
				
				authAccelHomePage.selectRole(data.get("SelectRole"), driver, logger);
				
				authAccelHomePage.search("Member", logger, driver);
				
				authAccelHomePage.nurseMemberSelect(getAuthNumber(data.get("TestCaseName")), logger, driver);
				
				authAccelPriorAuthReviewPage.selectDecisionWithLine(driver, logger,data.get("Decision"), data.get("DecisionReason"),
						data.get("Bedtype"), data.get("TestCase Type"),data.get("TaskName"),data.get("TestCase Type"),FromDT,ThruDT,data.get("Criteria"),data.get("Policy"),data.get("Rationale"),data.get("Procedure Code"));

				if(data.get("Decision").equalsIgnoreCase("Denied") || data.get("Decision").equalsIgnoreCase("Partially Denied")){
					
					authAccelPriorAuthReviewPage.selectAuthorizationDecisionWithMDRecom(data.get("Decision"), data.get("DecisionReason"), driver,
							data.get("TestCase Type"),data.get("Service Category"),data.get("MD Name"),logger);

					}
				
				authAccelPriorAuthReviewPage.generateNOMNCLetter(driver,data.get("Letter Required"), data.get("Letter Type"),logger);
				
				authAccelPriorAuthReviewPage.completeAuthorization(driver,data.get("Status"), data.get("StatusReason"),DischargeDate, data.get("TestCase Type"),
						data.get("Letter Type"), data.get("Letter Required"),data.get("Decision"), data.get("Withdrawn By"),data.get("TaskName"),data.get("Cancel Letters"),data.get("Cancel reason"), logger,data.get("Adm Bed Type"));

				providerPortalLoginPage.login(data.get("ProviderCode"), driver,logger);
	
				String actAuthStatus = providerPortalHomePage.viewStatus(driver, logger,"NurseReview", data,data.get("rowNum"),data.get("TestCaseName"));
				
				
			    softAssert.assertEquals(actAuthStatus, data.get("Status"));
	
				}
				catch (InterruptedException e) {		
					 
					e.printStackTrace();
				}
			}
		
	
		@Test(dataProvider = "UMTestCases")
		public void testNurseReviewServiceStatus(Map<String, String> data) throws Exception {
						
			try {
				WebDriver driver = BrowserFactoryManager.getDriver();

				// Logging into Auth Accel page
				authAccelLoginPage.applicationLogin(data.get("UserName"),data.get("Password"),driver, logger);
				
				authAccelHomePage.selectRole(data.get("SelectRole"), driver, logger);
				
				authAccelHomePage.search("Member", logger, driver);
				
				authAccelHomePage.nurseMemberSelect(getAuthNumber(data.get("TestCaseName")), logger, driver);
				
				authAccelPriorAuthReviewPage.selectDecision(driver, logger,data.get("Decision"), data.get("DecisionReason"),
						data.get("Bedtype"), data.get("TestCase Type"),data.get("TaskName"),data.get("TestCase Type"),FromDT,ThruDT,data.get("Criteria"),data.get("Policy"),data.get("Rationale"));

				authAccelPriorAuthReviewPage.selectAuthorizationDecision(
						data.get("Decision"), data.get("DecisionReason"), driver,data.get("TestCase Type"),data.get("Service Category"),logger);
				
				authAccelPriorAuthReviewPage.generateAllLetters(driver,data.get("Letter Required"), data.get("Letter Type"),logger);
				
				authAccelPriorAuthReviewPage.completeAuthorizationWithServiceStatus(driver,data.get("Status"), data.get("StatusReason"),DischargeDate, data.get("TestCase Type"),
						data.get("Letter Type"), data.get("Letter Required"),data.get("Decision"), data.get("Withdrawn By"),data.get("TaskName"),data.get("Cancel Letters"), logger);

				providerPortalLoginPage.login(data.get("ProviderCode"), driver,logger);

				String actAuthStatus = providerPortalHomePage.viewStatus(driver, logger,"NurseReview", data,data.get("rowNum"),data.get("TestCaseName"));
				
				
			    softAssert.assertEquals(actAuthStatus, data.get("Status"));

				}
				catch (InterruptedException e) {		
					 
					e.printStackTrace();
				}
			}
		
		@Test(dataProvider = "UMTestCases")
		public void testNurseReviewFacilityStatus(Map<String, String> data) throws Exception {
						
			try {
				WebDriver driver = BrowserFactoryManager.getDriver();

				// Logging into Auth Accel page
				authAccelLoginPage.applicationLogin(data.get("UserName"),data.get("Password"),driver, logger);
				
				authAccelHomePage.selectRole(data.get("SelectRole"), driver, logger);
				
				authAccelHomePage.search("Member", logger, driver);
				
				authAccelHomePage.nurseMemberSelect(getAuthNumber(data.get("TestCaseName")), logger, driver);
				
				authAccelPriorAuthReviewPage.selectDecision(driver, logger,data.get("Decision"), data.get("DecisionReason"),
						data.get("Bedtype"), data.get("TestCase Type"),data.get("TaskName"),data.get("TestCase Type"),FromDT,ThruDT,data.get("Criteria"),data.get("Policy"),data.get("Rationale"));

				authAccelPriorAuthReviewPage.selectAuthorizationDecision(
						data.get("Decision"), data.get("DecisionReason"), driver,data.get("TestCase Type"),data.get("Service Category"),logger);
				
				authAccelPriorAuthReviewPage.generateAllLetters(driver,
						data.get("Letter Required"), data.get("Letter Type"),logger);
				
				authAccelPriorAuthReviewPage.completeAuthorizationWithFacilityStatus(driver,data.get("Status"), data.get("StatusReason"),DischargeDate, data.get("TestCase Type"),data.get("Letter Type"), data.get("Letter Required"),
						data.get("Decision"), data.get("Withdrawn By"),data.get("TaskName"),data.get("Cancel Letters"), logger,data.get("Adm Bed Type"));

				providerPortalLoginPage.login(data.get("ProviderCode"), driver,
						logger);

				String actAuthStatus = providerPortalHomePage.viewStatus(driver, logger,"NurseReview", data,data.get("rowNum"),data.get("TestCaseName"));
				
				/*String authDecision = providerPortalHomePage.authDecision(driver, logger);
			    
			    softAssert.assertEquals(authDecision, data.get("StatusReason"), "AuthAccel status is: " + authDecision + ". Expected status: "+data.get("StatusReason"));*/
			    
			    softAssert.assertEquals(actAuthStatus, data.get("Status"));
	
				}
				catch (InterruptedException e) {		
					 
					e.printStackTrace();
				}
			}
	
	@AfterClass(alwaysRun=true)
	public void afterClass() {
		ReportFactory.closeReport();
		
		long timeStamp = System.currentTimeMillis();
		
		Timestamp time = new Timestamp(timeStamp);
		
		String timestamp = time.toString().replace(":", "-");
		
		System.out.println("The name of datasheet is "+sourceDatasheet.getName()+ "and timestamp is "+timestamp);
		
		try {
			Thread.sleep(1000);
		} 
		catch (InterruptedException e) {			
			e.printStackTrace();
		}
		replaceInFile();	
	}
	
	

	
	/**
	 * @Override run is a hook before @Test method
	 */
	@Override
	public void run(IHookCallBack callBack, ITestResult testResult) {
		reportInit(testResult.getTestContext().getName(), testResult.getMethod().getMethodName());
		initBrowser(testResult.getTestName(), testResult.getMethod().getMethodName());
		softAssert = new SoftAssert();
		logger.log(LogStatus.INFO, "Starting test " + testResult.getName());
		callBack.runTestMethod(testResult);
		softAssert.assertAll();
	}
	

}
