/**
 * @author vthiru03
 * @category testcase
 * @class UnAuthenicatedPageLinksTest
 * @Uses PageObject CitrixLandingPage , MemberWhyBlueShieldPage, memberFindAPlanPage
 * @since 3/24/2017
 * 
 */
package com.bsc.qa.web.tests;

import java.io.File;
import java.lang.reflect.Method;
import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;
import org.testng.IHookCallBack;
import org.testng.IHookable;
import org.testng.ITestResult;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import WebUtils.CsvUtils;
import WebUtils.ExcelUtilities;

import com.bsc.qa.framework.base.BaseTest;
import com.bsc.qa.framework.factory.BrowserFactoryManager;
import com.bsc.qa.framework.factory.ReportFactory;
import com.bsc.qa.web.pages.AuthorizationGenRX;
import com.bsc.qa.web.pages.AuthorizationGeneration;
import com.bsc.qa.web.pages.FinalSubmitPage;
import com.bsc.qa.web.pages.McgDecisionTree;
import com.bsc.qa.web.pages.MedhokAdminPage;
import com.bsc.qa.web.pages.MedicalAuthorizationsPage;
import com.bsc.qa.web.pages.MedicalRequestPage;
import com.bsc.qa.web.pages.MemberSearchRX;
import com.bsc.qa.web.pages.MemberSearchResultsPage;
import com.bsc.qa.web.pages.PrimaryDiagnosis;
import com.bsc.qa.web.pages.PrimaryDiagnosisRX;
import com.bsc.qa.web.pages.PrimaryProcedure;
import com.bsc.qa.web.pages.QuestionnairePage;
import com.bsc.qa.web.pages.QuestionnaireRX;
import com.bsc.qa.web.pages.RequestMedicalPriorAuthorizationsPage;
import com.bsc.qa.web.pages.RequestPreMedicalDetailsPage;
import com.bsc.qa.web.pages.ServicingFacilityProviderInformationPage;
import com.bsc.qa.web.pages.UploadAdditionalDocs;
import com.bsc.qa.web.pages.UploadAdditionalDocsRX;
import com.bsc.qa.web.pages.PreAuthurizationPage;
import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.LogStatus;

public class ProviderPortalIntakeAuthTest extends BaseTest implements IHookable {
	private static String inputDataSheetPath;
	private static String environment;
	public static String timestamp = LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd-HHmmss"));
	// public static String resultsDestinationFolderPath = "target\\DRXResults_" +
	// timestamp;

	private MedhokAdminPage medhokAdminPage;
	private MemberSearchResultsPage memberSearchResultsPage;
	private RequestMedicalPriorAuthorizationsPage requestMedicalPriorAuthorizationsPage;
	private ServicingFacilityProviderInformationPage servicingFacilityProviderInformationPage;
	private PrimaryDiagnosis primaryDiagnosis;
	private UploadAdditionalDocs uploadAdditionalDocs;
	private AuthorizationGeneration authorizationGenerationPage;
	private AuthorizationGenRX AuthGenRX;
	private PrimaryProcedure PrimaryProcedurePage;
	private QuestionnairePage submitQuestionnairePage;
	private QuestionnaireRX submitQuestionnaireRXPage;
	private PreAuthurizationPage preAuthPage;
	private RequestPreMedicalDetailsPage requestMediDetailsPage;
	private MedicalRequestPage medRequestPage;
	private FinalSubmitPage finalPage;
	private MemberSearchRX MemSearchRX;
	private PrimaryDiagnosisRX PrimDiaRX;
	private UploadAdditionalDocsRX UpAddDocsRx;
	private McgDecisionTree mcgDecisionTree;
	private MedicalAuthorizationsPage medicalAuthPage;

	// private File sourceReport = new File("test-output/BSC-reports/Report.html");

	private File sourceDatasheet; // Variable to store for data sheet details
	public List<String[]> refNumberMap = new ArrayList<String[]>(); // variable to store test case id and their
	String[] outputData = new String[20]; // reference number
	public String csvFilePath = "src/test/resources/AuthorizationNumber.csv";
	// CSV file to store authorization numbers
	public String csvFolderPath = "src/test/resources";
	public String outputTemplalteFileName = "ProviderPortal_Output";
	public String csvfileName = "AuthorizationNumber";
	public String[] csvHeader = { "TestCase ID", "Authorization Number" }; // Variable to store CSV header
	public String testcaseName_ID, outputFileName, csvPath;

	public Map<String, String> prescreeningData = new HashMap<>();

	/**
	 * Run when the test method runs
	 */
	protected void initBrowser(String testCaseName, String testMethodName) {

		WebDriver driver = BrowserFactoryManager.getDriver();

		medhokAdminPage = PageFactory.initElements(driver, MedhokAdminPage.class);
		medhokAdminPage.setPage(driver, browser, environment, testCaseName);

		memberSearchResultsPage = PageFactory.initElements(driver, MemberSearchResultsPage.class);
		memberSearchResultsPage.setPage(driver, browser, environment, testCaseName);

		requestMedicalPriorAuthorizationsPage = PageFactory.initElements(driver,
				RequestMedicalPriorAuthorizationsPage.class);
		requestMedicalPriorAuthorizationsPage.setPage(driver, browser, environment, testCaseName);

		servicingFacilityProviderInformationPage = PageFactory.initElements(driver,
				ServicingFacilityProviderInformationPage.class);
		servicingFacilityProviderInformationPage.setPage(driver, browser, environment, testCaseName);

		primaryDiagnosis = PageFactory.initElements(driver, PrimaryDiagnosis.class);
		primaryDiagnosis.setPage(driver, browser, environment, testCaseName);

		uploadAdditionalDocs = PageFactory.initElements(driver, UploadAdditionalDocs.class);
		uploadAdditionalDocs.setPage(driver, browser, environment, testCaseName);

		authorizationGenerationPage = PageFactory.initElements(driver, AuthorizationGeneration.class);
		authorizationGenerationPage.setPage(driver, browser, environment, testCaseName);

		PrimaryProcedurePage = PageFactory.initElements(driver, PrimaryProcedure.class);
		PrimaryProcedurePage.setPage(driver, browser, environment, testCaseName);

		submitQuestionnairePage = PageFactory.initElements(driver, QuestionnairePage.class);
		submitQuestionnairePage.setPage(driver, browser, environment, testCaseName);

		preAuthPage = PageFactory.initElements(driver, PreAuthurizationPage.class);
		preAuthPage.setPage(driver, browser, environment, testCaseName);

		requestMediDetailsPage = PageFactory.initElements(driver, RequestPreMedicalDetailsPage.class);
		requestMediDetailsPage.setPage(driver, browser, environment, testCaseName);

		medRequestPage = PageFactory.initElements(driver, MedicalRequestPage.class);
		medRequestPage.setPage(driver, browser, environment, testCaseName);

		finalPage = PageFactory.initElements(driver, FinalSubmitPage.class);
		finalPage.setPage(driver, browser, environment, testCaseName);

		MemSearchRX = PageFactory.initElements(driver, MemberSearchRX.class);
		MemSearchRX.setPage(driver, browser, environment, testCaseName);

		PrimDiaRX = PageFactory.initElements(driver, PrimaryDiagnosisRX.class);
		PrimDiaRX.setPage(driver, browser, environment, testCaseName);

		UpAddDocsRx = PageFactory.initElements(driver, UploadAdditionalDocsRX.class);
		UpAddDocsRx.setPage(driver, browser, environment, testCaseName);

		submitQuestionnaireRXPage = PageFactory.initElements(driver, QuestionnaireRX.class);
		submitQuestionnaireRXPage.setPage(driver, browser, environment, testCaseName);

		AuthGenRX = PageFactory.initElements(driver, AuthorizationGenRX.class);
		AuthGenRX.setPage(driver, browser, environment, testCaseName);

		mcgDecisionTree = PageFactory.initElements(driver, McgDecisionTree.class);

		medicalAuthPage = PageFactory.initElements(driver, MedicalAuthorizationsPage.class);
		medicalAuthPage.setPage(driver, browser, environment, testCaseName);
	}

	@DataProvider(name = "DataProvider")
	private static Object[][] getData(Method method) {

		Object[][] columnArray = ExcelUtilities.getColumnArray(inputDataSheetPath, environment);

		Object[][] testDataArray = ExcelUtilities.getTableArray(inputDataSheetPath, environment);

		List<Object> list = new ArrayList<Object>();// list to store the executable rows in the test data sheet

		int noOfTestCases = 0;
		String runMode = "Yes";// declaration and initialization of runMode flag

		for (int row = 0; row <= testDataArray.length - 1; row++) {// loop through the data in test data sheet

			// below checking the method name with the keyword name in test data sheet
			if (method.getName().equalsIgnoreCase(testDataArray[row][2].toString())
					&& runMode.equalsIgnoreCase(testDataArray[row][3].toString())) {

				noOfTestCases++;// icrementing the number when ever the testcase in datasheet having Runmode as
								// Yes and keyword and method name

				Map<String, String> rowDataMap = new HashMap<String, String>();// map to handle row data in datasheet

				for (int col = 0; col < columnArray[0].length; col++) {// iterate through all columns and rows

					rowDataMap.put(columnArray[0][col].toString(), testDataArray[row][col].toString().trim());

					rowDataMap.put("rowNum", String.valueOf(row));
				}

				list.add(rowDataMap);// adding into list

			}
		}

		Object[][] data = new Object[noOfTestCases][1];// creating object array and populating data

		for (int row = 0; row < list.size(); row++) {
			data[row][0] = list.get(row);
		}

		return data;

	}

	/**
	 * setUp is a @BeforeMethod executed before execution of a @Test
	 * 
	 * @param browser_
	 * @param driver_
	 * @param env_
	 * @param url_
	 * @throws Exception
	 */
	@BeforeClass
	@Parameters({ "Browser_", "Driver_", "Env_", "URL_", "InputDataSheetPath_" })
	public void setUp(@Optional("browser") String browserStr, @Optional("webDriver") String driverStr,
			@Optional("environment") String envStr, @Optional("url") String urlStr,
			@Optional("inputDataSheetPath") String inputDataSheetPathStr) {
		// boolean error = false;
		browser = browserStr; // browser details [Chrome]
		webDriver = driverStr; // Selenium webdriver
		environment = envStr; // Sheet name in Datasheet
		System.out.print("EnviRoment" + environment);
		url = urlStr;// Provider portal URL
		inputDataSheetPath = inputDataSheetPathStr;// Datasheet
		sourceDatasheet = new File(inputDataSheetPath);// Data sheet path
		// outputFileName = outputTemplalteFileName + timestamp.replace("-", "") +
		// ".xlsx";
		outputFileName = csvfileName + timestamp.replace("-", "") + ".csv";
		csvPath = csvFolderPath + File.separator + outputFileName;
		System.out.println("*******" + outputFileName);
		String[] header = {
				" TestcaseID | Output_PAStatus | Output_StartDate |Output_EndDate| Output_ReferenceID | Output_AuthDecision | Output_ProcedureStatus | Output_MedicalStatusReason| Output_AuthStatus| TestCaseStatus " };
		CsvUtils.writeHeadersintoCSV(csvPath, header);
		/*
		 * CsvUtils.copyOutputFile(csvFolderPath + File.separator + csvfileName +
		 * ".csv", csvFolderPath + File.separator + outputFileName);
		 */

	}

	@Test(dataProvider = "DataProvider")
	public void testProviderPortalUM(Map<String, String> data) throws Exception {
		WebDriver driver = BrowserFactoryManager.getDriver();

		try {
			System.out.println("***********" + data.get("TestCaseID"));
			testcaseName_ID = data.get("TestCaseID");
			// login into provider portal suite
			medhokAdminPage.adminLogin(data, driver, logger);

			// Entering the member details
			memberSearchResultsPage.enterDetailsInMemeberSearchResultsPage(data, driver, logger);

			// Requesting for medical Prior authoziation
			requestMedicalPriorAuthorizationsPage.enterDetailsInRMPAPage(data, driver, logger);

			System.out.println("The provider id is   !!" + data.get("ProviderID"));

			// Entering the servicing details set1
			servicingFacilityProviderInformationPage.enterDetailsInServecingFacilityPage(data, driver, logger,
					data.get("ServiceType1").toString());

			// Entering the servicing details set2
			servicingFacilityProviderInformationPage.enterDetailsInServecingFacilityPage(data, driver, logger,
					data.get("ServiceType2").toString());

			// Entering diagnosis details
			primaryDiagnosis.enterDetailsInPrimaryDiagnosisPage(data, driver, logger);

			// Entering primary procedure details
			prescreeningData = PrimaryProcedurePage.enterDetailsInPrimaryProcedurePageData(data, driver, logger);

			// Entering questionnaire details
			if (!data.get("Questionnaire").equals("") && !data.get("Questionnaire").equals("")) {
				submitQuestionnairePage.enterDetailsInQuestionnairePage(data, driver, logger);
			}

			if (data.get("CiteAutoAuthFlag").equalsIgnoreCase("Yes")) {
				mcgDecisionTree.verifyMCGalert(data, driver, logger);
			}

			System.out.println("::::::::::::::::before additional docs::::::::::::::::");

			if (data.get("AuthStatus").equalsIgnoreCase("inquiry")) {

				authorizationGenerationPage.verifyInquiryPage(driver, logger, data);
				String inqueryNumber = authorizationGenerationPage.getActinqueryNumber(driver, logger);
				prescreeningData.put("ReferenceID", inqueryNumber);
				String inqueryNumberStatus = authorizationGenerationPage.getinqueryNumberstaus(driver, logger);
				prescreeningData.put("actAuthStatus", inqueryNumberStatus);
				//authorizationGenerationPage.downloadTestServiceDocument(driver, logger, data);

			} else {

				// Uploading additional documents
				uploadAdditionalDocs.enterDetailsinAdditionalDoc(data, driver, logger);

				System.out.println("::::::::::::::::After additional docs::::::::::::::::");

				// Retrieving Auth status
				String actAuthStatus = authorizationGenerationPage.getActAuthStatus(driver);

				prescreeningData.put("actAuthStatus", actAuthStatus);

				// Retrieving Auth decision
				String authDecision = authorizationGenerationPage.getAuthDecision();

				prescreeningData.put("AuthDecision", authDecision);

				// Retrieving Authorization number
				String authNumber = authorizationGenerationPage.getGeneratedAuthNumber(data);
				prescreeningData.put("ReferenceID", authNumber);
				// Retrieving Procedure Status
				String procedureStatus = authorizationGenerationPage.getProcedureStatus();
				prescreeningData.put("ProcedureStatus", procedureStatus);

				String medicalAuthReason = authorizationGenerationPage.getmedicalAuthReason();
				prescreeningData.put("MedicalAuthReason", medicalAuthReason);

				logger.log(LogStatus.INFO, "Authorization Number: " + authNumber);

				// Appending values to Reference number list
				refNumberMap.add(new String[] { data.get("Test Case ID"), authNumber });

				// Validating post conditions
				softAssert.assertEquals(authDecision, "Decision:",
						"AuthAccel status is: " + authDecision + ". Expected status: 'Decision:'");
				softAssert.assertEquals(actAuthStatus, data.get("AuthStatus"));

				Thread.sleep(2000);
				logger.log(LogStatus.INFO, "New Authorization has been created in Provider Portal");
			}
		} catch (InterruptedException e) {

			System.out.println("Test case failed :: Stacktrace followed");
			e.printStackTrace();
		}

	}

	@Test(dataProvider = "DataProvider")
	public void testviewAllMemebers(Map<String, String> data) throws Exception {
		WebDriver driver = BrowserFactoryManager.getDriver();
		try {
			System.out.println("***********" + data.get("TestCaseID"));
			testcaseName_ID = data.get("TestCaseID");
			// login into provider portal suite
			medhokAdminPage.adminLogin(data, driver, logger);

			// Entering the member details
			memberSearchResultsPage.enterDetailsInMemeberSearchResultsPage(data, driver, logger);

		} catch (Exception e) {
			// TODO: handle exception
		}
	}

	@AfterMethod()
	public void afterMethod(ITestResult testResult) {

		try {
			String testcaseStatus = null;

			if (testResult.getStatus() == ITestResult.SUCCESS && (prescreeningData.get("testcaseStatus") == ""
					|| prescreeningData.get("testcaseStatus") == null)) {
				testcaseStatus = "PASS";
			} else if (testResult.getStatus() == ITestResult.FAILURE || !(prescreeningData.get("testcaseStatus") == ""
					|| prescreeningData.get("testcaseStatus") == null)) {
				testcaseStatus = "FAILED;Reason:" + prescreeningData.get("testcaseStatus");
			} else if (testResult.getStatus() == ITestResult.SKIP) {
				testcaseStatus = "Skipped";
			}
			csvPath = csvFolderPath + File.separator + outputFileName;
			String[] outputData = { "" + testcaseName_ID + "|" + prescreeningData.get("PaStaus_actual") + "|"
					+ prescreeningData.get("StartDate") + "|" + prescreeningData.get("EndDate") + "|"
					+ prescreeningData.get("ReferenceID") + "|" + prescreeningData.get("AuthDecision") + "|"
					+ prescreeningData.get("ProcedureStatus") + "|" + prescreeningData.get("MedicalAuthReason") + "|"
					+ prescreeningData.get("actAuthStatus") + "|" + testcaseStatus + "" };
			CsvUtils.writeDataintoCSVLineByLine(csvPath, outputData);

		} catch (Exception e) {
			// TODO: handle exception
		} finally {
			prescreeningData = new HashMap<>();
		}
	}

	@AfterSuite(alwaysRun = true)
	public void afterSuite() {
		ReportFactory.closeReport();

		long timeStamp = System.currentTimeMillis();

		Timestamp time = new Timestamp(timeStamp);

		String timestamp = time.toString().replace(":", "-");

		System.out.println("The name of datasheet is " + sourceDatasheet.getName() + "and timestamp is " + timestamp);

		try {
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		replaceInFile();
	}

	/**
	 * @Override run is a hook before @Test method
	 */
	@Override
	public void run(IHookCallBack callBack, ITestResult testResult) {
		reportInit(testResult.getTestContext().getName(), testResult.getMethod().getMethodName());
		initBrowser(testResult.getTestName(), testResult.getMethod().getMethodName());
		softAssert = new SoftAssert();
		logger.log(LogStatus.INFO, "Starting test " + testResult.getName());

		callBack.runTestMethod(testResult);
		softAssert.assertAll();
	}

}
