package com.bsc.qa.web.pages;

import java.awt.AWTException;

import java.util.List;
import java.util.Map;


import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindAll;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;

import com.bsc.qa.framework.base.BasePage;
import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;

import WebUtils.WebUtils;

public class MemberSearchRX extends BasePage {

	public WebUtils webUtils = new WebUtils();
	@FindAll({ @FindBy(how = How.XPATH, using = "//input[@id='MEMBER_FIRST_NAME']") })
	public WebElement memFirstName;

	@FindAll({ @FindBy(how = How.XPATH, using = "//input[@id='MEMBER_LAST_NAME']") })
	public WebElement memLastName;
	
	@FindAll({ @FindBy(how = How.XPATH, using = "//input[@id='MEMBER_DOB1']") })
	public WebElement memDOB;
	
	@FindAll({ @FindBy(how = How.XPATH, using = "//input[@id='SUBSCRIBER_ID']") })
	public WebElement memID;
	
	@FindAll({ @FindBy(how = How.XPATH, using = "//a[@id='patient_search_btn']/span[text()='Search']") })
	public WebElement memSearch;
	
	@FindAll({ @FindBy(how = How.XPATH, using = "//*[@id='MEDICAL_PATIENT_SEARCH_MODAL_GRID']/div/div/div/div[2]/div/table") })
	public WebElement memSearchTable;
	//*[@id="pre_rx_prior_auth_service_type_href"]/span
	@FindAll({ @FindBy(how = How.XPATH, using = "(//*[@id='pre_rx_prior_auth_service_type_href']/span)[1]") })
	public List<WebElement> memSelect;
	
	@FindAll({ @FindBy(how = How.XPATH, using = "//*[@id='MEDICAL_DIAGNOSIS_INFORMATION_DIV']/div[2]/div/div/div[1]/ul/li[1]/a/b") })
	public WebElement primaryDiagnosis;
	
	@FindAll({ @FindBy(how = How.XPATH, using = "//*[@id='patient-search-modal']/div/div/div[1]/h3") })
	public WebElement memSelectPage;

	public void enterDetailsInMemberSearchRX(Map<String, String> data, WebDriver driver, ExtentTest logger)throws InterruptedException, AWTException{
		webUtils.explicitWaitByElementToBeClickable(driver, "//input[@id='MEMBER_FIRST_NAME']",20);
		logger.log(LogStatus.INFO, "Enter First Name!!");
		memFirstName.sendKeys(data.get("MemFirstName").toString().trim());
		logger.log(LogStatus.INFO,"Enter Last Name!!");
		memLastName.sendKeys(data.get("MemLastName").toString().trim());
		logger.log(LogStatus.INFO, "Enter Date of Birth!!");
		memDOB.sendKeys(data.get("DOB").toString().trim());
		webUtils.explicitWaitByElementToBeClickable(driver, "//input[@id='SUBSCRIBER_ID']",20);
		logger.log(LogStatus.INFO, "Enter Member ID!!");
		memID.sendKeys(data.get("MemId").toString().trim());
		logger.log(LogStatus.INFO, "Click on Search!!");
        webUtils.waitUntilElementclickable(memSearch,memSelectPage, driver);
	    logger.log(LogStatus.INFO, "Selecting Member!!");
	    memSelect.get(0).click();
		
		

	}

}