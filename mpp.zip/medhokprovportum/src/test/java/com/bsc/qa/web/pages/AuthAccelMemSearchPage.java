package com.bsc.qa.web.pages;

import java.util.Map;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindAll;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;

import com.bsc.qa.framework.base.BasePage;
import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;

import WebUtils.WebUtils;

public class AuthAccelMemSearchPage extends BasePage {

	public WebUtils webUtils = new WebUtils(); 
	@FindAll({ @FindBy(how = How.XPATH, using = "//*[@id='isc_12']/table/tbody/tr/td[@class='MHtoolStripButton']") })
	public WebElement memSearch;

	@FindAll({ @FindBy(how = How.XPATH, using = "//*[@id='isc_12']/table/tbody/tr/td/table/tbody/tr/td[1]") })
	public WebElement memSearch2;

	@FindAll({ @FindBy(how = How.XPATH, using = "//*[@id='isc_3Ktable']/tbody/tr[1]/td[2]/div/nobr']") })
	public WebElement memMemSearch;
	
	@FindAll({ @FindBy(how = How.XPATH, using = "//*[@id='isc_3Ktable']/tbody/tr[1]/td[2]") })
	public WebElement memMemSearch2;
	
	@FindAll({ @FindBy(how = How.XPATH, using = "//input[@name='authReviewNumber']") })
	public WebElement memAuthCaseNumb;
	
	@FindAll({ @FindBy(how = How.XPATH, using = "//*[@id='isc_5V']") })
	public WebElement memXtededSearch;
	
	@FindAll({ @FindBy(how = How.XPATH, using = "//*[@id='isc_4M']") })
	public WebElement memCheckBox;
	
	
	

	public void enterDetailsInAuthAccelMemeberSearchResultsPage(Map<String, String> data, WebDriver driver, ExtentTest logger)throws InterruptedException{
		Thread.sleep(5000); // Added wait time for flow synchronization
		//webUtils.explicitWaitByPresenceofElement(driver, "//*[@id='isc_O']/img']");
		logger.log(LogStatus.INFO, "Enter mem Search!!");
		webUtils.mouseOver(memSearch, driver);
        webUtils.moveToClickableElement(memSearch2, driver);
		
		webUtils.explicitWaitByElementToBeClickable(driver, "//*[@id='isc_3Ktable']/tbody/tr[1]/td[2]/div/nobr']",20);
		logger.log(LogStatus.INFO, "Enter mem Search!!");
		//webUtils.mouseOver(memMemSearch2, driver);
        webUtils.moveToClickableElement(memMemSearch, driver);
		webUtils.explicitWaitByElementToBeClickable(driver, "//*[@id='isc_4M']",20);
		logger.log(LogStatus.INFO, "Select Member Check Box!!");
		memCheckBox.click();
		memAuthCaseNumb.sendKeys(AuthorizationGenRX.authRXCasenmb);
		logger.log(LogStatus.INFO,"Enter Auth Case Number!!");
		Thread.sleep(1000);// Added wait time for flow synchronization
		memXtededSearch.click();
		logger.log(LogStatus.INFO,"Click on Extended Search!!");
		
		
		

	}

}