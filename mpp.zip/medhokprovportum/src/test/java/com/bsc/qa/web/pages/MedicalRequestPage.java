package com.bsc.qa.web.pages;

import java.util.Map;


import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindAll;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;

import com.bsc.qa.framework.base.BasePage;
import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;

import WebUtils.WebUtils;

public class MedicalRequestPage extends BasePage {

	public WebUtils webUtils = new WebUtils();
	
	@FindAll({ @FindBy(how = How.XPATH, using = "//*[@id='PHARMACY_MEDICATION_REQUEST_GRID_DIV']/div[2]/div/div/div[1]/ul/li/a") })
	public WebElement medicalRequest;
	
	@FindAll({ @FindBy(how = How.XPATH, using = "//INPUT[@id='med_search_med_name']") })
	public WebElement medicationName;
	
	@FindAll({ @FindBy(how = How.XPATH, using = "//*[@id='MED_GRID']/tr[1]/td[1]/a") })
	public WebElement medicationSelect;
	
	@FindAll({ @FindBy(how = How.XPATH, using = "//*[@id='MEDICATION_SEARCH_BTN']/div/div/div[2]/div[2]/div/div/a") })
	public WebElement medicationSearch;
	
	@FindAll({ @FindBy(how = How.XPATH, using = "//input[@id='med_selected_med_qty']") })
	public WebElement medicationQuantity;
	
	@FindAll({ @FindBy(how = How.XPATH, using = "//input[@id='med_selected_med_supply']") })
	public WebElement medicationSupply;
	
	@FindAll({ @FindBy(how = How.XPATH, using = "//select[@id='MED_SELECTED_MED_TOT_DURATION']") })
	public WebElement medicationDurationTherapy;
	
	@FindAll({ @FindBy(how = How.XPATH, using = "//*[@id='medication-detail-modal']/div/div/div[2]/div[4]/a[1]") })
	public WebElement addMedication;
	
	@FindAll({ @FindBy(how = How.XPATH, using = "//*[@id='MEDICAL_DIAGNOSIS_INFORMATION_DIV']/div[2]/div/div/div[1]/ul/li[1]/a/b") })
	public WebElement primaryDiagnosis;
	
	
	@FindAll({ @FindBy(how = How.XPATH, using = "//*[@id='med_search_med_code']") })
	public WebElement ndcCode;
	
	
	
	public void enterDetailsInMedicalRequestPage(Map<String, String> data, WebDriver driver, ExtentTest logger)throws 
	InterruptedException{
		webUtils.explicitWaitByElementToBeClickable(driver, medicalRequest);
		logger.log(LogStatus.INFO, "Selecting medicalRequest Button!!");
		medicalRequest.click();
		webUtils.explicitWaitByElementToBeClickable(driver, medicationName);
		logger.log(LogStatus.INFO, "Enter Medication Name!!");
		medicationName.sendKeys(data.get("MedicationName").toString());
		webUtils.explicitWaitByElementToBeClickable(driver, ndcCode);
        ndcCode.sendKeys(data.get("NDC"));
		webUtils.explicitWaitByElementToBeClickable(driver, medicationSearch);
		logger.log(LogStatus.INFO, "Select medicalSearch !!");
		medicationSearch.click();
		webUtils.explicitWaitByElementToBeClickable(driver, "//*[@id='MED_GRID']/tr[1]/td[1]/a",20);
		logger.log(LogStatus.INFO, "Select medication Select !!");
		medicationSelect.click();
		logger.log(LogStatus.INFO, "Select medication Quantity!!");
		webUtils.explicitWaitByElementToBeClickable(driver, "//input[@id='med_selected_med_qty']",20);
		webUtils.explicitWaitByElementToBeClickable(driver, medicationQuantity);
		medicationQuantity.clear();
		medicationQuantity.sendKeys(data.get("MedicationQuantity").toString());
		logger.log(LogStatus.INFO, "Select medication Supply!!");
		webUtils.explicitWaitByElementToBeClickable(driver, medicationSupply);
		medicationSupply.clear();
		medicationSupply.sendKeys(data.get("MedicationSupply").toString());
	    webUtils.selectDropdownValueByVisibleText(medicationDurationTherapy, data.get("DurationTherapy"), logger, driver);
	    logger.log(LogStatus.INFO, "Select add Medication!!");
		//webUtils.explicitWaitByElementToBeClickable(driver, "//*[@id='medication-detail-modal']/div/div/div[2]/div[4]/a[1]]",20);
	    webUtils.waitUntilElementclickableInSamePage(addMedication, driver);
	}

}
	
	
	
	