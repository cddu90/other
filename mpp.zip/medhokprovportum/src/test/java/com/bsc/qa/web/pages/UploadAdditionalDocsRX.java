package com.bsc.qa.web.pages;

import java.util.Map;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindAll;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;

import com.bsc.qa.framework.base.BasePage;
import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;

import WebUtils.WebUtils;

public class UploadAdditionalDocsRX extends BasePage {

	public WebUtils webUtils = new WebUtils();

	
	@FindAll({ @FindBy(how = How.XPATH, using = "//*[@id='PHARMACY_UPLOADED_DOCUMENTS_GRID_DIV']/div[2]/div[1]/ul/li/a") })
	public WebElement addDoc;
	
	@FindAll({ @FindBy(how = How.XPATH, using = "//form[@id='file_upload_form']//input[@id='file_upload']") })
	public WebElement chooseFile;
	
	@FindAll({ @FindBy(how = How.XPATH, using = "//*[@id='file_upload_form']/div/div/div[3]/button") })
	public WebElement uploadDoc;

	@FindAll({ @FindBy(how = How.XPATH, using = "//*[@id='SUPPORTING_INFO']/button") })
	public WebElement submit;
	public String username;
	
	@SuppressWarnings("restriction")
	public void enterDetailsinAdditionalDocRX (Map<String, String> data, WebDriver driver, ExtentTest logger)throws InterruptedException{
		username= new com.sun.security.auth.module.NTSystem().getName();
		System.out.println(username);
		
		webUtils.explicitWaitByElementToBeClickable(driver, "//*[@id='PHARMACY_UPLOADED_DOCUMENTS_GRID_DIV']/div[2]/div[1]/ul/li/a",30);
		logger.log(LogStatus.INFO, "click on AddDoc!!");
		addDoc.click();
		webUtils.explicitWaitByElementToBeClickable(driver, "//form[@id='file_upload_form']//input[@id='file_upload']",30);
		logger.log(LogStatus.INFO, "choose file");
		chooseFile.sendKeys("C:\\Users\\"+username+"\\bqsa32\\workspace\\MedhokProvPort\\src\\test\\resources\\Test Files\\ProviderPortal.docx");
		logger.log(LogStatus.INFO, "Upload Document");
		uploadDoc.click();
		logger.log(LogStatus.INFO, "click on Submit Button!!");
		webUtils.explicitWaitByElementToBeClickable(driver, "//*[@id='SUPPORTING_INFO']/button",60);
		submit.click();


	}

}