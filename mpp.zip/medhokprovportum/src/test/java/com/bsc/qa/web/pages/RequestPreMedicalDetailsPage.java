package com.bsc.qa.web.pages;

import java.util.Map;


import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindAll;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;

import com.bsc.qa.framework.base.BasePage;
import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;

import WebUtils.WebUtils;

public class RequestPreMedicalDetailsPage extends BasePage {
	public WebUtils webUtils = new WebUtils();
	@FindAll({ @FindBy(how = How.XPATH, using = "//select[@id='SUBMITTED_PROVIDER_ID']") })
	public WebElement requestingProvider;
	
	@FindAll({ @FindBy(how = How.XPATH, using = "//input[@id='REQUESTING_CONTACT_FAX']") })
	public WebElement faxNumber;
	
	@FindAll({ @FindBy(how = How.XPATH, using = "//INPUT[@id='REQUESTING_PROVIDER_NPI']") })
	public WebElement npiNumber;
	

	public void enterDetailsInPreMedicalPage(Map<String, String> data, WebDriver driver, ExtentTest logger)throws 
	InterruptedException{
		webUtils.explicitWaitByElementToBeClickable(driver, requestingProvider);
	    logger.log(LogStatus.INFO,"Selecting  Requesting Provider!!");
		requestingProvider.sendKeys(data.get("RequestingProvider").toString());
		// Added wait time for flow synchronization
		Thread.sleep(3000);
		//logger.log(LogStatus.INFO,"Selecting  NPI Number!!");
		//npiNumber.sendKeys(data.get("NPI").toString());
        logger.log(LogStatus.INFO, "Enter Fax number!!");
		faxNumber.sendKeys(data.get("FaxNumber").toString());


	}

}
	
	
	
	