package com.bsc.qa.web.pages;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindAll;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.testng.asserts.SoftAssert;

import com.bsc.qa.framework.base.BasePage;
import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;

import WebUtils.WebUtils;

public class PrimaryProcedure extends BasePage {

	public WebUtils webUtils = new WebUtils();

	@FindAll({ @FindBy(how = How.XPATH, using = "//*[@id='Add_Procedure_href_SPAN']") })
	public WebElement primaryDiagnosis;

	@FindAll({ @FindBy(how = How.XPATH, using = "//input[@id='MEDICAL_PROCEDURE_CODE_SEARCH']") })
	public WebElement procedureCode;

	@FindAll({ @FindBy(how = How.XPATH, using = "//*[@id='MEDICAL_PROCEDURE_SEARCH_FORM']/div[2]/a/span") })
	public WebElement searchButton;

	@FindAll({
			@FindBy(how = How.XPATH, using = "//*[@id='MEDICAL_PROCEDURE_CODE_SEARCH_RESULTS_GRID']/tr/td[1]/a/span") })
	public WebElement select;

	@FindAll({ @FindBy(how = How.XPATH, using = "//*[@id='medical_pre_add_procedure_code_submit_href']") })
	public WebElement submit;

	@FindAll({ @FindBy(how = How.XPATH, using = "//input[@id='MEDICAL_PROCEDURE_QUANTITY']") })
	public WebElement quantity;

	@FindAll({ @FindBy(how = How.XPATH, using = "//Select[@id='MEDICAL_PROCEDURE_UNIT_TYPE_2']") })
	public WebElement units;

	@FindAll({ @FindBy(how = How.XPATH, using = "//*[@id='medical_submit_auth_btn1']") })
	public WebElement finalSubmit;

	@FindAll({ @FindBy(how = How.XPATH, using = "//input[@id='MEDICAL_PROCEDURE_PA_STATUS']") })
	public WebElement procedurestatusReason;

	@FindAll({ @FindBy(how = How.XPATH, using = "//input[@name='MEDICAL_PROCEDURE_FROM_DATE_2']") })
	public WebElement procedureStartDate;

	@FindAll({ @FindBy(how = How.XPATH, using = "//input[@name='MEDICAL_PROCEDURE_THRU_DATE_2']") })
	public WebElement procedurertoDate;

	public static String username;

	public void enterDetailsInPrimaryProcedurePage(Map<String, String> data, WebDriver driver, ExtentTest logger)
			throws InterruptedException {
		// Selecting specific Primary Procedure code
		webUtils.explicitWaitByVisibilityofElement(driver, primaryDiagnosis);
//		logger.log(LogStatus.INFO, "click on Procedure Diagnosis!!");
		primaryDiagnosis.click();
		webUtils.explicitWaitByVisibilityofElement(driver, procedureCode);
		logger.log(LogStatus.INFO, "Enter Procedure Code :" + data.get("ProcedureCode"));
		procedureCode.sendKeys(data.get("ProcedureCode"));
//		logger.log(LogStatus.INFO, "Click on Search Button");
		searchButton.click();
//		logger.log(LogStatus.INFO, "click on Select Button!!");
		webUtils.explicitWaitByElementToBeClickable(driver, select);
		select.click();
		webUtils.explicitWaitByVisibilityofElement(driver, quantity);
//		logger.log(LogStatus.INFO, "Enter Quantity");
		quantity.sendKeys(data.get("Quantity"));

		// Added wait time for flow synchronization
		Thread.sleep(2000);
		webUtils.selectDropdownValueByVisibleText(units, data.get("Units").toString(), logger, driver);
		webUtils.explicitWaitByVisibilityofElement(driver, submit);
		logger.log(LogStatus.INFO, "click on Submit Button!!");
		webUtils.scrollDown(driver, submit);
		submit.click();
		// Added wait time for flow synchronization
		Thread.sleep(2000);
		logger.log(LogStatus.INFO, "click on final Submit Button!!");
		webUtils.scrollDown(driver, finalSubmit);
		finalSubmit.click();
		Thread.sleep(5000);

	}

	public Map<String, String> enterDetailsInPrimaryProcedurePageData(Map<String, String> data, WebDriver driver,
			ExtentTest logger) throws InterruptedException {
		// Selecting specific Primary Procedure code
		username = new com.sun.security.auth.module.NTSystem().getName();
		username = System.getProperty("user.dir");
		System.out.println("username:::::::" + username);
		HashMap<String, String> preScreeningData = new HashMap<>();
		SoftAssert softAssert = new SoftAssert();

		webUtils.explicitWaitByVisibilityofElement(driver, primaryDiagnosis);
//		logger.log(LogStatus.INFO, "click on Procedure Diagnosis!!");
		primaryDiagnosis.click();
		webUtils.explicitWaitByVisibilityofElement(driver, procedureCode);
		logger.log(LogStatus.INFO, "Enter Procedure Code :" + data.get("ProcedureCode"));
		procedureCode.sendKeys(data.get("ProcedureCode"));
//		logger.log(LogStatus.INFO, "Click on Search Button");
		searchButton.click();
//		logger.log(LogStatus.INFO, "click on Select Button!!");
		webUtils.explicitWaitByElementToBeClickable(driver, select);
		select.click();
		webUtils.explicitWaitByVisibilityofElement(driver, quantity);
		webUtils.takeSnapShot(driver, username + "//test-output//BSC-reports//screenshots//"
				+ data.get("TestCaseID").trim() + "//" + data.get("TestCaseID").trim() + "PAStatus.png");
		logger.log(LogStatus.INFO, logger.addScreenCapture(username + "//test-output//BSC-reports//screenshots//"
				+ data.get("TestCaseID").trim() + "//" + data.get("TestCaseID").trim() + "PAStatus.png"));
		logger.log(LogStatus.INFO, "Enter Quantity");
		if (Integer.valueOf(data.get("Quantity")) != 0)
			quantity.sendKeys(data.get("Quantity"));
		else {

		}

		// Added wait time for flow synchronization
		Thread.sleep(2000);
		// reading data from the application
		String paStaus = null, fromDate = null, toDate = null;
		if (procedurestatusReason.isDisplayed()) {

			paStaus = procedurestatusReason.getAttribute("value");

		}
		if (procedureStartDate.isDisplayed()) {

			fromDate = procedureStartDate.getAttribute("value");

		}
		if (procedurertoDate.isDisplayed()) {

			toDate = procedurertoDate.getAttribute("value");

		}
		try {
			Date date1 = new SimpleDateFormat("MM-dd-yyyy").parse(toDate);
			Date date2 = new SimpleDateFormat("MM-dd-yyyy").parse(fromDate);
			int diffDays = (int) ((date1.getTime() - date2.getTime()) / (1000 * 60 * 60 * 24));
			if (diffDays == Integer.valueOf(data.get("Excepted_PolicyExpDates"))) {
				logger.log(LogStatus.PASS, "The difference between start date and end date in 120 days");

			} else {
				logger.log(LogStatus.INFO,
						"The difference between start date and end date in not 120 days:" + diffDays);
				// preScreeningData.put("testcaseStatus", "Start date End date difference is not
				// matched;");

			}
		} catch (Exception e) {
			// TODO: handle exception

			// Need to add
			// logger.log(LogStatus.FAIL, "The");
		}
		System.out.println("paStatus" + paStaus);
		System.out.println("fromDate" + fromDate);
		// adding data into the map
		preScreeningData.put("PaStaus_actual", paStaus);
		if (paStaus.replaceAll("\\s+","").equalsIgnoreCase(data.get("Excepted_PAStatus").replaceAll("\\s+",""))) {
			softAssert.assertEquals(paStaus.trim(), data.get("Excepted_PAStatus").trim());
			logger.log(LogStatus.PASS, "PA Status is  macthed:" + paStaus);
		} else {
			softAssert.assertEquals(paStaus.trim(), data.get("Excepted_PAStatus").trim());
			logger.log(LogStatus.FAIL, "PA Status is excepted and actual both are not same" + paStaus);
			String testcaseStatus = preScreeningData.get("testcaseStatus");
			if (testcaseStatus != null) {
				preScreeningData.put("testcaseStatus", testcaseStatus + "PA Status is not macthed;");
			} else {
				preScreeningData.put("testcaseStatus", "PA Status is not macthed;");
			}
		}

		preScreeningData.put("StartDate", fromDate);
		preScreeningData.put("EndDate", toDate);

		webUtils.selectDropdownValueByVisibleText(units, data.get("Units").toString(), logger, driver);
		webUtils.explicitWaitByVisibilityofElement(driver, submit);
		logger.log(LogStatus.INFO, "click on Submit Button!!");
		webUtils.scrollDown(driver, submit);
		submit.click();
		// Added wait time for flow synchronization
		Thread.sleep(2000);
		logger.log(LogStatus.INFO, "click on final Submit Button!!");
		webUtils.scrollDown(driver, finalSubmit);
		finalSubmit.click();
		Thread.sleep(5000);

		return preScreeningData;
	}

}
