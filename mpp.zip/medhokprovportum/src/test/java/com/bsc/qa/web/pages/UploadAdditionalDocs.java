package com.bsc.qa.web.pages;

import java.awt.Robot;
import java.awt.event.KeyEvent;
import java.util.Map;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindAll;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;

import com.bsc.qa.framework.base.BasePage;
import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;

import WebUtils.WebUtils;

public class UploadAdditionalDocs extends BasePage {

	public WebUtils webUtils = new WebUtils();

	@FindAll({
			@FindBy(how = How.XPATH, using = "//*[@id='MEDICAL_UPLOAD_DOCUMENTS_DIV']/div[2]/div/div/div[1]/ul/li/a") })
	public WebElement addDoc;

	@FindAll({ @FindBy(how = How.XPATH, using = "//div/h1/span[@id='PAGE_PAR_MEDICAL_HEADING']") })
	public WebElement parMedicalPageHeading;

	@FindAll({ @FindBy(how = How.XPATH, using = "//form[@id='file_upload_form']//input[@id='file_upload']") })
	public WebElement chooseFile;

	@FindAll({ @FindBy(how = How.XPATH, using = "//*[@id='UploadDoc']/div/div/div[3]/button/span") })
	public WebElement uploadDoc;

	@FindAll({ @FindBy(how = How.XPATH, using = "//*[@class='btn btn-success pull-right']") })
	public WebElement submit;

	public String username;

	// @SuppressWarnings("restriction")
	public void enterDetailsinAdditionalDoc(Map<String, String> data, WebDriver driver, ExtentTest logger)
			throws InterruptedException {
		// Uploading Additional Doc
		// username= new com.sun.security.auth.module.NTSystem().getName();
//		username= System.getProperty("user.dir");
//		System.out.println("username:::::::"+ username);
//		
//		
//		webUtils.explicitWaitByPresenceofElement(driver, "//div/h1/span[@id='PAGE_PAR_MEDICAL_HEADING']");
//		
//		webUtils.scrollDown(driver, addDoc);
//		webUtils.explicitWaitByElementToBeClickable(driver, "//*[@id='MEDICAL_UPLOAD_DOCUMENTS_DIV']/div[2]/div/div/div[1]/ul/li/a",120);
//		
//		addDoc.click();
//		webUtils.explicitWaitByElementToBeClickable(driver, "//form[@id='file_upload_form']//input[@id='file_upload']",120);
//		// Added wait time for flow synchronization
//		Thread.sleep(5000);
////		logger.log(LogStatus.INFO, "choose file");
//		//chooseFile.sendKeys("C:\\Users\\akakar02\\bqsa32\\workspace\\MedhokProvPort\\src\\test\\resources\\Test Files\\ProviderPortal.docx");
//		System.out.println("PATH:******"+username+ "\\src\\test\\resources\\Test Files\\ProviderPortal.docx");
//chooseFile.sendKeys(username+ "\\src\\test\\resources\\Test Files\\ProviderPortal.docx");
////		logger.log(LogStatus.INFO, "Upload Document");
//		Thread.sleep(2000);
//		try
//		{
//		Robot rb=new Robot();
//		//rb.keyPress(KeyEvent.VK_ENTER);
//	} catch (Exception e) {
//			// TODO: handle exception
//		}
//		Thread.sleep(5000);
//		
//		System.out.println("*******File Uploaded sucesfully******** ");
//		
//		uploadDoc.click();
////		logger.log(LogStatus.INFO, "click on Submit Button!!");
//		logger.log(LogStatus.INFO, "Uploaded Additional Documents!!");
//		
//		// Added wait time for flow synchronization

		Thread.sleep(5000);
		webUtils.scrollDown(driver, submit);
		// webUtils.explicitWaitByVisibilityofElement(driver, submit);

		submit.click();
		// Added wait time for flow synchronization
		Thread.sleep(5000);
	}

}