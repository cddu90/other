package com.bsc.qa.web.pages;

import java.awt.Robot;
import java.awt.event.KeyEvent;

import java.util.List;

import org.openqa.selenium.By;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import org.openqa.selenium.support.FindAll;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;

import com.bsc.qa.framework.base.BasePage;
import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;
//import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI;











import WebUtils.WebUtils;

/**
 * @author SaiKiran Ayyagari
 *
 */
public class AuthAccelHomePage extends BasePage {

	public WebUtils webUtils = new WebUtils();

	@FindAll({ @FindBy(how = How.XPATH, using = "//img[contains(@src,'comboBoxPicker.gif')]") })
	public WebElement dropDown;

	@FindAll({ @FindBy(how = How.XPATH, using = "//td[text()='Alerts']/ancestor::div/div[1]/div[2]/following::div/img[contains(@src,'close')]") })
	public WebElement closePopup;
	@FindAll({ @FindBy(how = How.XPATH, using = "//nobr[text()='Fax Intake']") })
	public WebElement faxIntake;
	
	
	@FindAll({ @FindBy(how = How.XPATH, using = "//div[contains(@eventproxy,'isc_ListGrid')]//table[@class='listTable']//tr[1]") })
	public List<WebElement> serviceCodeList;

	@FindAll({ @FindBy(how = How.XPATH, using = "//td/div/nobr[text()='Edit']") })
	public WebElement edit;

	@FindAll({ @FindBy(how = How.XPATH, using = "//td/div/nobr[text()='0']") })
	public WebElement taskreview;

	@FindAll({ @FindBy(how = How.XPATH, using = "//div[@role='presentation']") })
	public List<WebElement> dropDownList;

	@FindAll({ @FindBy(how = How.XPATH, using = "//tr[@role='listitem']/td/div/nobr[text()='Pharmacy']") })
	public WebElement pharmacy;

	@FindAll({ @FindBy(how = How.XPATH, using = "//tr/td[text()='Search']") }) 
	//@FindAll({ @FindBy(how = How.XPATH, using = "//*[@id='isc_12']/table/tbody/tr/td/table/tbody/tr/td[2]") })
	public WebElement search;

	@FindAll({ @FindBy(how = How.XPATH, using = "//tr[@role='menuitem']/td[2]/div") })
	public List<WebElement> searchList;

	@FindAll({ @FindBy(how = How.XPATH, using = "//div[@eventproxy='isc_PortletWorkspace_1']/div[contains(@eventproxy,'isc_HLayout_')]/div/div[1]") })
	public WebElement myFax;

	@FindAll({ @FindBy(how = How.XPATH, using = "//div[contains(@eventproxy,'isc_PortletWorkspace_')]/following::div[6][contains(@eventproxy,'isc_PortletLink_')]/div/div/parent::div/parent::div/parent::div/parent::div") })
	public WebElement unassignedTasks;

	@FindAll({ @FindBy(how = How.XPATH, using = "//div[contains(@eventproxy,'isc_PagingListGrid')]/div/div/div[3]") })
	public List<WebElement> assignedReceivedDateList;

	@FindAll({ @FindBy(how = How.XPATH, using = "//div[contains(@eventproxy,'isc_PagingListGrid')]/div/div/div[3]") })
	public WebElement unassignedReceivedDate;

	@FindAll({ @FindBy(how = How.XPATH, using = "//table[@class='menuTable']/tbody/tr[2]") })
	public WebElement sortDescending;

	@FindAll({ @FindBy(how = How.XPATH, using = "//div[contains(@eventproxy,'isc_HLayout_')]/div/div/div/following::div[contains(@eventproxy,'isc_PagingListGrid_')]/div/table[@class='listTable']/tbody/tr[1]") })
	public WebElement unassignedTaskList;

	@FindAll({ @FindBy(how = How.XPATH, using = "//div[text()='Inpatient - California']") })
	public WebElement inpatientTask;

	@FindAll({ @FindBy(how = How.XPATH, using = "//div[contains(@eventproxy,'isc_HLayout_')]/div/div/div/following::div[contains(@eventproxy,'isc_PagingListGrid_')]/div/table[@class='listTable']/tbody/tr") })
	public List<WebElement> listSize;

	@FindAll({ @FindBy(how = How.XPATH, using = "//div[contains(@eventproxy,'isc_HLayout_')]/div/div/div/following::div[contains(@eventproxy,'isc_PagingListGrid_')]/div/table[@class='listTable']/tbody/tr[1]") })
	public List<WebElement> assignedTaskList;

	@FindAll({ @FindBy(how = How.XPATH, using = "//table[@class='menuTable']/tbody/tr[4]/td[2]/div/nobr[contains(text(),'Claim')]") })
	public WebElement claim;

	@FindAll({ @FindBy(how = How.XPATH, using = "//td[@class='formCell']") })
	public List<WebElement> pageNo;

	@FindAll({ @FindBy(how = How.XPATH, using = "//input[@name='currentPage']") })
	public WebElement currentPage;

	@FindAll({ @FindBy(how = How.XPATH, using = "//img[contains(@src,'action_last')]") })
	public WebElement forwardButton;

	@FindAll({ @FindBy(how = How.XPATH, using = "//img[contains(@src,'action_last')]") })
	public List<WebElement> forwardButtonList;

	@FindAll({ @FindBy(how = How.XPATH, using = "//div[contains(@eventproxy,'isc_Toolbar_1')]/div/table/tbody/tr/td/div/div[text()='Received Date']") })
	public WebElement recievedDatePharmacy;

	@FindAll({ @FindBy(how = How.XPATH, using = "//div[contains(@eventproxy,'isc_HLayout_')]/div/div/div/following::div[contains(@eventproxy,'isc_PagingListGrid_1_1_body')]/div/table[@class='listTable']/tbody/tr[1]") })
	public WebElement pharmacytaskList;

	@FindAll({ @FindBy(how = How.XPATH, using = "//div[contains(@eventproxy,'isc_Toolbar_')]/following::div[1][contains(@eventproxy,'isc_ImageRequestView_')]") })
	public WebElement addArea;

	@FindAll({ @FindBy(how = How.XPATH, using = "//table[@class='menuTable']/tbody/tr[1]/td[2]/div/nobr[contains(text(),'Add')]") })
	public WebElement add;

	@FindAll({ @FindBy(how = How.XPATH, using = "//div[contains(@eventproxy,'isc_DynamicForm_')]/form/table/tbody/tr[2]/td[2]/table/tbody/tr") })
	public List<WebElement> requestTypeDropdown;

	@FindAll({ @FindBy(how = How.XPATH, using = "//tr[@role='listitem'][3]/td/div/nobr[text()='Medical Auth New']") })
	public WebElement medicalAuthNew;

	@FindAll({ @FindBy(how = How.XPATH, using = "//td/nobr/label[contains(text(),'Name')]/preceding::td[@valign='middle'][1]/table/tbody/tr/td/span/img[contains(@src,'search_picker')]") })
	public WebElement searchPicker;

	@FindAll({ @FindBy(how = How.XPATH, using = "//td[@class='button']/div/div[text()='Extended Search']") })
	public WebElement extendedSearch;

	@FindAll({ @FindBy(how = How.XPATH, using = "//input[@name='subscriberId']") })
	public WebElement memberId;

	@FindAll({ @FindBy(how = How.XPATH, using = "//div[contains(@id,'isc_MemberSearchForm_6_0_body$28s')]/following::table/tbody/tr") })
	public List<WebElement> memberSelection;
	
	@FindAll({ @FindBy(how = How.XPATH, using = "//div[contains(@id,'isc_MemberSearchForm_')]/following::table[@class='listTable']/tbody/tr/td") })
	public List<WebElement> bscmemberType;
	
	@FindAll({ @FindBy(how = How.XPATH, using = "//div[contains(@id,'isc_MemberSearchForm_')]/following::table[@class='listTable']/tbody/tr") })
	public List<WebElement> care1stMemberType;
	
	@FindAll({ @FindBy(how = How.XPATH, using = "//div[contains(@id,'isc_MemberSearchForm_')]/following::table[@class='listTable']/tbody/tr[1]") })
	public WebElement care1stMemberTypeFirstRow;
	/*
	 * @FindAll({ @FindBy(how = How.XPATH, using =
	 * "//div[contains(@id,'isc_MemberSearchForm_')]/following::table/tbody/tr/td[8]/div/nobr[text()='Subscriber']"
	 * ) }) WebElement memberType;
	 */

	@FindAll({ @FindBy(how = How.XPATH, using = "//div[contains(@eventproxy,'isc_ImageRequestView_')]/div/div/div[2]/div/div/table/tbody/tr[1]/td/div/div[contains(text(),'Save')]") })
	public WebElement save;

	// div[@eventproxy='isc_PagingListGrid_1_0_body']/div/table/tbody/tr[1]/td[3]

	@FindAll({ @FindBy(how = How.XPATH, using = "//div[@eventproxy='isc_PagingListGrid_1_0_body']/div/table/tbody/tr[1]/td[3]") })
	public WebElement inpatientTaskList;

	@FindAll({ @FindBy(how = How.XPATH, using = "//div[contains(@id,'isc_MemberSearchForm_')]/following::table[@class='listTable']/tbody/tr/td") })
	public List<WebElement> memberType;
	
	
	
	@FindAll({ @FindBy(how = How.XPATH, using = "//img[contains(@src,'vscroll_end')]") })
	public WebElement scrollEnd;
	

	@FindAll({ @FindBy(how = How.XPATH, using = "//table/tbody/tr/td/div/div[text()='HICN']") })
	public WebElement LOB;

	@FindAll({ @FindBy(how = How.XPATH, using = "//img[contains(@src,'vsplit_snap')]") })
	public WebElement vsplit;
	
	@FindAll({ @FindBy(how = How.XPATH, using = "//td/div[contains(text(),'Search within MedHOK')]") })
	public WebElement searchWithinMedhok;
	
	@FindAll({ @FindBy(how = How.XPATH, using = "//div[text()='Search within MedHOK']//span") })
	public WebElement medhokCheckbox;
	
	@FindAll({ @FindBy(how = How.XPATH, using = "//input[@name='authNumber']") })
	public WebElement authNumber;
	
	@FindAll({ @FindBy(how = How.XPATH, using = "//div[contains(@id,'isc_MemberSearch')]//following-sibling::table//tr") })
	public WebElement searchRow;
	

	@FindAll({ @FindBy(how = How.XPATH, using = "//div[contains(@id,'isc_MemberSearch')]//following-sibling::table//tr//td[9]") })
	public WebElement openIcon;
	
	@FindAll({ @FindBy(how = How.XPATH, using = "//td//div[text()='Yes']") })
	public WebElement yesButton;

	
	

	/**
	 * Selecting the role for user.
	 * 
	 * @throws InterruptedException
	 */
	public void selectRolePharmacist(String role, WebDriver driver, ExtentTest logger)
			throws InterruptedException {

		Thread.sleep(3000);// Added wait time for flow synchronization
		logger.log(LogStatus.INFO, "Select the type of role");
		
		dropDown = webUtils.explicitWaitByElementToBeClickable(driver,15, driver.findElement(By.xpath("//img[contains(@src,'comboBoxPicker.gif')]")));
		
		//Thread.sleep(15000);
		
		webUtils.elementClickWithLogger(dropDown, "Role dropdown", logger, driver);
		/*webUtils.FluentWait(driver, "//nobr[contains(text(),'UM Pharmacist')]");
		driver.findElement(By.xpath("//nobr[contains(text(),'UM Pharmacist')]")).click();*/
		Thread.sleep(3000);// Added wait time for flow synchronization
		webUtils.clickButtonOrLink(driver.findElements(By.xpath("//div[@role='presentation']")), "UM Pharmacist", logger, driver);

	}
	public void selectRole(String role, WebDriver driver, ExtentTest logger)
			throws InterruptedException {

		Thread.sleep(3000);// Added wait time for flow synchronization
//		logger.log(LogStatus.INFO, "Select the type of role");
		
		dropDown = webUtils.explicitWaitByElementToBeClickable(driver,15, dropDown);
		
		//Thread.sleep(15000);
		
		webUtils.elementClickWithLogger(dropDown, role, logger, driver);

		webUtils.clickButtonOrLink(dropDownList, role, logger, driver);

	}
	public void selectRoleFaxIntake(String role, WebDriver driver, ExtentTest logger)
			throws InterruptedException {

		
		logger.log(LogStatus.INFO, "Select the type of role");

//		dropDown = webUtils
//				.explicitWaitByElementToBeClickable(driver,15, dropDown);
		
		//webUtils.elementClickWithLogger(dropDown, "Role dropdown", logger, driver);

		//dropDown.click();
		webUtils.explicitWaitByElementToBeClickable(driver, 40, dropDown);
		dropDown.click();
		webUtils.explicitWaitByElementToBeClickable(driver, 30, faxIntake);
		faxIntake.click();

		//webUtils.clickButtonOrLink(dropDownList, role, logger, driver);

	}

	/**
	 * Search for the Member
	 * 
	 * @throws InterruptedException
	 */
	public void search(String role, ExtentTest logger, WebDriver driver)
			throws InterruptedException {

		
		
		webUtils.explicitWaitByElementToBeClickable(driver, 15, search);
				 
		search.click();

		webUtils.clickButtonOrLink(searchList, role, logger, driver);
		logger.log(LogStatus.INFO, "Selected "+role+"in type of search!!");

	}
	
	/**
	 * Selecting Member through Auth #
	 * 
	 * @throws InterruptedException
	 */
	public void nurseMemberSelect( String reference,ExtentTest logger, WebDriver driver) throws InterruptedException {
		webUtils.explicitWaitByElementToBeClickable(driver, 15, medhokCheckbox);
		medhokCheckbox.click();
		authNumber.sendKeys(reference);
		System.out.println("Auth # is :" +reference);
		extendedSearch.click();
		System.out.println("Extended Search has been Clicked");
		webUtils.explicitWaitByVisibilityofElement(driver, 20, searchRow);
		
		webUtils.moveToClickableElement(openIcon, driver);
		try{
			if(yesButton.isDisplayed()){
				yesButton.click();
				System.out.println("Case has been opened for Editing");
			}
			
		}
		catch(Exception e){
			System.out.println("yesButton validation is skipped");
		}
		
		
		
	}

	public void finalVerification( String reference,ExtentTest logger, WebDriver driver) throws InterruptedException {
		webUtils.explicitWaitByVisibilityofElement(driver, 20, medhokCheckbox);
		medhokCheckbox.click();
		authNumber.sendKeys(reference);
		System.out.println("Auth # is :" +reference);
		extendedSearch.click();
		System.out.println("Extended Search has been Clicked");
		webUtils.explicitWaitByVisibilityofElement(driver, 20, searchRow);
		
		searchRow.click();
		webUtils.doubleClick(driver, searchRow);
		webUtils.moveToClickableElement(openIcon, driver);
		try{
			if(yesButton.isDisplayed()){
				yesButton.click();
				System.out.println("Case has been opened for Editing");
			}
			
		}
		catch(Exception e){
			System.out.println("yesButton validation is skipped");
		}
		Thread.sleep(3000);// Added wait time for flow synchronization
		
		
		
		
	}
	/**
	 * Select the task from unassigned task list
	 * 
	 * @param driver
	 * @param logger
	 * @throws Exception
	 */
	public void taskSelection(WebDriver driver, ExtentTest logger)
			{
		try {


			logger.log(LogStatus.INFO, "Select the task from unassigned tasks!!!");

			//webUtils.doubleClick(driver, unassignedTasks);
			
			webUtils.doubleClick(driver, unassignedTasks);
			

			webUtils.explicitWaitByElementToBeClickable(driver,30, unassignedTaskList);
			webUtils.moveToClickableElement(unassignedReceivedDate, driver);

			Thread.sleep(3000);// Added wait time for flow synchronization

			webUtils.moveToClickableElement(unassignedReceivedDate, driver);

			Thread.sleep(5000);// Added wait time for flow synchronization
			webUtils.moveToClickableElement(unassignedTaskList, driver);

			webUtils.doubleClick(driver, unassignedTaskList);

			logger.log(LogStatus.INFO,
					"Prior Authorization Task is selected from Unassigned task list successfully");

			Thread.sleep(5000);// Added wait time for flow synchronization
		
		}
		catch(Exception e) {
			e.printStackTrace();
		}
			}

	/**
	 * Adding Pre authorization request
	 * 
	 * @param driver
	 * @param memberid
	 * @param logger
	 * @throws Exception
	 */
	public void addPreAuthRequest(WebDriver driver, String memberid,String membertype,
			ExtentTest logger)  {
		try {

			
			
			Robot robot = new Robot();

			logger.log(LogStatus.INFO, "Adding PreAuth Request!!");

			webUtils.rightClick(driver, addArea);

			add.click();

			webUtils.explicitWaitByElementToBeClickable(driver,15,
					requestTypeDropdown.get(2));
			
			robot.keyPress(KeyEvent.VK_TAB);
			robot.keyRelease(KeyEvent.VK_TAB);
			
			robot.keyPress(KeyEvent.VK_DOWN);
			Thread.sleep(2000);// Added wait time for flow synchronization
			robot.keyPress(KeyEvent.VK_DOWN);
			Thread.sleep(2000);// Added wait time for flow synchronization
			robot.keyPress(KeyEvent.VK_DOWN);
			robot.keyRelease(KeyEvent.VK_DOWN);

			searchPicker.click();
					
			robot.keyPress(KeyEvent.VK_CONTROL);
			robot.keyPress(KeyEvent.VK_T);
			
			robot.keyRelease(KeyEvent.VK_CONTROL);
			robot.keyRelease(KeyEvent.VK_T);
			
			Thread.sleep(2000);// Added wait time for flow synchronization
			searchPicker.click();
					
			//driver.switchTo().window(tabs.get(0));
			
			robot.keyPress(KeyEvent.VK_CONTROL);
			robot.keyPress(KeyEvent.VK_W);
			
			robot.keyRelease(KeyEvent.VK_CONTROL);
			robot.keyRelease(KeyEvent.VK_W);
			
			Thread.sleep(3000);// Added wait time for flow synchronization
						
			webUtils.moveToClickableElement(memberId, driver);

			memberId.sendKeys(memberid);
			
			Thread.sleep(3000);// Added wait time for flow synchronization
			
			robot.keyPress(KeyEvent.VK_TAB);
			Thread.sleep(1000);// Added wait time for flow synchronization
			
			robot.keyPress(KeyEvent.VK_TAB);
			Thread.sleep(1000);// Added wait time for flow synchronization
			
			robot.keyPress(KeyEvent.VK_TAB);
			Thread.sleep(1000);// Added wait time for flow synchronization
			
			robot.keyPress(KeyEvent.VK_TAB);
			Thread.sleep(1000);// Added wait time for flow synchronization
			
			robot.keyPress(KeyEvent.VK_TAB);
			Thread.sleep(1000);// Added wait time for flow synchronization
			
			robot.keyPress(KeyEvent.VK_SPACE);
			Thread.sleep(2000);		// Added wait time for flow synchronization
			
			robot.keyPress(KeyEvent.VK_TAB);
			Thread.sleep(1000);// Added wait time for flow synchronization
			
			robot.keyPress(KeyEvent.VK_TAB);
			Thread.sleep(1000);// Added wait time for flow synchronization
			
			robot.keyPress(KeyEvent.VK_SPACE);
			Thread.sleep(3000);// Added wait time for flow synchronization

			
			if("Care1st".equalsIgnoreCase(membertype)){
				
				for (WebElement memberType : care1stMemberType) {

					webUtils.horizontalScroll(driver, LOB);

					System.out.println("The member text is " + memberType.getText());

					System.out.println("The color of the text is "
							+ memberType.getCssValue("color"));

					
					 if (memberType.getText().trim().contains("Subscriber")||memberType.getText().trim().contains("SUBSCRIBER")&&
							  (!memberType.getCssValue("color").trim().equalsIgnoreCase(
							  "rgba(214, 73, 73, 1)"
							  )&&!memberType.getCssValue("color").trim().equalsIgnoreCase(
							  "rgb(214, 73, 73")) && (memberType.getText().trim()
							  .contains("MEDI.CAL")||memberType.getText().trim()
							  .contains("MAPD.IND")||memberType.getText().trim()
							  .contains("CA.CCI"))) {
					  
						 memberType.click();
					  
					  webUtils.doubleClick(driver, memberType);
					 
					  break; }
					 
					 else {

							webUtils.scrollDown(driver, memberType);
						}
				}
				}
				else if("BSC".equalsIgnoreCase(membertype)){
					
					for(WebElement bscMemberType : bscmemberType ){
					
						 if (bscMemberType.getText().trim().contains("Subscriber")||bscMemberType.getText().trim().contains("SUBSCRIBER")
									&& !bscMemberType.getCssValue("color").trim()
											.equalsIgnoreCase("rgba(214, 73, 73, 1)") && (!bscMemberType
											.getCssValue("color").trim()
											.equalsIgnoreCase("rgba(214, 73, 73"))) {
							System.out.println("clicking member!!!");
							bscMemberType.click();

							webUtils.doubleClick(driver, bscMemberType);

							break;
						}
						 
						 
					 else {

							webUtils.scrollDown(driver, bscMemberType);
						}
					
				}

				// save.click();

			}
			Thread.sleep(2000);// Added wait time for flow synchronization
					

			try {
				webUtils.explicitWaitByElementToBeClickable(driver,20, closePopup);
				if (closePopup.isDisplayed()) {

					closePopup.click();
				}
			} catch (Exception e) {
				System.out.println("unable to click on closePopup");

			}

			Thread.sleep(2000);// Added wait time for flow synchronization

			try{
				
				webUtils.explicitWaitByVisibilityOfAllElements(driver, 10, serviceCodeList);
				
				serviceCodeList.get(0).click();
				
				webUtils.doubleClick(driver, serviceCodeList.get(0));
			}catch(Exception e){
				System.out.println("unable to retrive serviceCodeList");
				
			}
			
			webUtils.moveToClickableElement(save, driver);
			save.click();
			
			robot.keyPress(KeyEvent.VK_CONTROL);
			robot.keyPress(KeyEvent.VK_T);
			
			robot.keyRelease(KeyEvent.VK_CONTROL);
			robot.keyRelease(KeyEvent.VK_T);
			
			Thread.sleep(2000);// Added wait time for flow synchronization
			save.click();
					
			//driver.switchTo().window(tabs.get(0));
			
			robot.keyPress(KeyEvent.VK_CONTROL);
			robot.keyPress(KeyEvent.VK_W);
			
			robot.keyRelease(KeyEvent.VK_CONTROL);
			robot.keyRelease(KeyEvent.VK_W);
			
			
			
			Thread.sleep(3000);// Added wait time for flow synchronization
			System.out.println("clicked on save button");
			
			try{
				
				webUtils.explicitWaitByVisibilityOfAllElements(driver, 10, serviceCodeList);
				
				serviceCodeList.get(0).click();
				
				webUtils.doubleClick(driver, serviceCodeList.get(0));
			}catch(Exception e){
				System.out.println("unable to retrive serviceCodeList");
				
			} 
			
			
			
			vsplit.click();

		
		}
		catch(Exception e) {
			e.printStackTrace();
		}
	}

	public void addPreAuthRequestForNewMember(WebDriver driver, String memberid,String membertype,
			ExtentTest logger) {
		try {

			
			
			Robot robot = new Robot();

			logger.log(LogStatus.INFO, "Adding PreAuth Request!!");

			webUtils.rightClick(driver, addArea);

			add.click();

			webUtils.explicitWaitByElementToBeClickable(driver,15,
					requestTypeDropdown.get(2));
			
			robot.keyPress(KeyEvent.VK_TAB);
			robot.keyRelease(KeyEvent.VK_TAB);
			
			robot.keyPress(KeyEvent.VK_DOWN);
			Thread.sleep(2000);// Added wait time for flow synchronization
			robot.keyPress(KeyEvent.VK_DOWN);
			Thread.sleep(2000);
			robot.keyPress(KeyEvent.VK_DOWN);
			robot.keyRelease(KeyEvent.VK_DOWN);

			searchPicker.click();
					
			robot.keyPress(KeyEvent.VK_CONTROL);
			robot.keyPress(KeyEvent.VK_T);
			
			robot.keyRelease(KeyEvent.VK_CONTROL);
			robot.keyRelease(KeyEvent.VK_T);
			
			Thread.sleep(2000);// Added wait time for flow synchronization
			searchPicker.click();
					
			//driver.switchTo().window(tabs.get(0));
			
			robot.keyPress(KeyEvent.VK_CONTROL);
			robot.keyPress(KeyEvent.VK_W);
			
			robot.keyRelease(KeyEvent.VK_CONTROL);
			robot.keyRelease(KeyEvent.VK_W);
			
			Thread.sleep(3000);// Added wait time for flow synchronization
						
			webUtils.moveToClickableElement(memberId, driver);

			memberId.sendKeys(memberid);
			
			Thread.sleep(3000);// Added wait time for flow synchronization
			
			robot.keyPress(KeyEvent.VK_TAB);
			Thread.sleep(1000);// Added wait time for flow synchronization
			
			robot.keyPress(KeyEvent.VK_TAB);
			Thread.sleep(1000);// Added wait time for flow synchronization
			
			robot.keyPress(KeyEvent.VK_TAB);
			Thread.sleep(1000);// Added wait time for flow synchronization
			
			robot.keyPress(KeyEvent.VK_TAB);
			Thread.sleep(1000);// Added wait time for flow synchronization
			
			robot.keyPress(KeyEvent.VK_TAB);
			Thread.sleep(1000);// Added wait time for flow synchronization
			
			robot.keyPress(KeyEvent.VK_SPACE);
			Thread.sleep(2000);	// Added wait time for flow synchronization	
			
			robot.keyPress(KeyEvent.VK_TAB);
			Thread.sleep(1000);// Added wait time for flow synchronization
			
			robot.keyPress(KeyEvent.VK_TAB);
			Thread.sleep(1000);// Added wait time for flow synchronization
			
			robot.keyPress(KeyEvent.VK_SPACE);
			Thread.sleep(3000);// Added wait time for flow synchronization
			
			care1stMemberTypeFirstRow.click();

			webUtils.doubleClick(driver, care1stMemberTypeFirstRow);
			
		// save.click();

			
			Thread.sleep(2000);// Added wait time for flow synchronization
					
			try {
				webUtils.explicitWaitByElementToBeClickable(driver,20, closePopup);
				if (closePopup.isDisplayed()) {

					closePopup.click();
				}
			} catch (Exception e) {
				System.out.println("unable to click on closePopup");

			}

			Thread.sleep(2000);// Added wait time for flow synchronization

			try{
				
				webUtils.explicitWaitByVisibilityOfAllElements(driver, 10, serviceCodeList);
				
				serviceCodeList.get(0).click();
				
				webUtils.doubleClick(driver, serviceCodeList.get(0));
			}catch(Exception e){
				System.out.println("unable to retrive serviceCodeList");
				
			}
			
			webUtils.moveToClickableElement(save, driver);
			save.click();
			
			robot.keyPress(KeyEvent.VK_CONTROL);
			robot.keyPress(KeyEvent.VK_T);
			
			robot.keyRelease(KeyEvent.VK_CONTROL);
			robot.keyRelease(KeyEvent.VK_T);
			
			save.click();
			Thread.sleep(1000);// Added wait time for flow synchronization
			//driver.switchTo().window(tabs.get(0));
			
			robot.keyPress(KeyEvent.VK_CONTROL);
			robot.keyPress(KeyEvent.VK_W);
			
			robot.keyRelease(KeyEvent.VK_CONTROL);
			robot.keyRelease(KeyEvent.VK_W);
			///////////////////////////////////////////////////
			try{
				webUtils.moveToClickableElement(save, driver);
				save.click();
				
				robot.keyPress(KeyEvent.VK_CONTROL);
				robot.keyPress(KeyEvent.VK_T);
				
				robot.keyRelease(KeyEvent.VK_CONTROL);
				robot.keyRelease(KeyEvent.VK_T);
				
				save.click();
				Thread.sleep(1000);// Added wait time for flow synchronization
				//driver.switchTo().window(tabs.get(0));
				
				robot.keyPress(KeyEvent.VK_CONTROL);
				robot.keyPress(KeyEvent.VK_W);
				
				robot.keyRelease(KeyEvent.VK_CONTROL);
				robot.keyRelease(KeyEvent.VK_W);
			}
			catch(Exception e){
				e.printStackTrace();
			}
			////////////////////////////////////////////////////////////
			
			Thread.sleep(3000);// Added wait time for flow synchronization
			System.out.println("clicked on save button");
			try{
				webUtils.moveToClickableElement(save, driver);
			}
			catch(Exception e){
				System.out.println("save validation is skipped");
			}
					
			webUtils.explicitWaitByElementToBeClickable(driver, 30, vsplit);
			vsplit.click();


		
		}
		catch(Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * Edit the prior authorization request
	 * 
	 * @param driver
	 * @param logger
	 * @throws Exception
	 */
	public void editPriorAuth(WebDriver driver, ExtentTest logger)
			 {
		try {


			logger.log(LogStatus.INFO,
					"Select the task to deny the case from pharmacy task list!!!");

			webUtils.explicitWaitByVisibilityofElement(driver,30, pharmacytaskList);

			webUtils.scrollDown(driver, pharmacytaskList);

			Thread.sleep(3000);// Added wait time for flow synchronization

			webUtils.moveToClickableElement(recievedDatePharmacy, driver);

			webUtils.explicitWaitByVisibilityofElement(driver,30, pharmacytaskList);

			webUtils.moveToClickableElement(recievedDatePharmacy, driver);

			webUtils.explicitWaitByVisibilityofElement(driver,30, pharmacytaskList);

			pharmacytaskList.click();

			webUtils.doubleClick(driver, pharmacytaskList);

		
		}
		catch(Exception e) {
			e.printStackTrace();
		}
			 }

}
