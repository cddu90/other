package com.bsc.qa.web.pages;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindAll;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;

import com.bsc.qa.framework.base.BasePage;
import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;

import WebUtils.ExcelUtilities;
import WebUtils.WebUtils;

/**
 * @author SaiKiran Ayyagari
 *
 */
public class AuthAccelFaxPriorAuthPage extends BasePage {

	public WebUtils webUtils = new WebUtils();
	
	public static String referenceNo;
	public static String referenceDerNo;

	@FindAll({ @FindBy(how = How.XPATH, using = ".//td[contains(@class,'formTitle')]/b[contains(text(),'Request Type')]/following::div[contains(@class,'selectItemText')]") })
	public List<WebElement> dropDownList;
	
	@FindAll({ @FindBy(how = How.XPATH, using = "//td[text()='Alerts']/ancestor::div/div[1]/div[2]/following::div/img[contains(@src,'close')]") })
	public WebElement closePopup;

	@FindAll({ @FindBy(how = How.XPATH, using = "//div[contains(@id,'isc_PickListMenu_0_body$28s')]/following::table/tbody/tr") })
	public List<WebElement> dropdownNames;

	@FindAll({ @FindBy(how = How.XPATH, using = "//input[@name='manualReceivedDate_dateTextField']") })
	public WebElement manualReceivedDate;

	@FindAll({ @FindBy(how = How.XPATH, using = "//input[@name='nextReviewDate_dateTextField']") })
	public WebElement nextReviewDate;

	@FindAll({ @FindBy(how = How.XPATH, using = "//*[text()='Diagnosis Codes']//preceding::tr[@role='listitem']/td[1]") })
	public WebElement diagcodeAreaList;
	
	
	@FindAll({ @FindBy(how = How.XPATH, using = "//tr[@aria-posinset='2']//img[contains(@src,'delete')]") })
	public WebElement delete;
	
	
	@FindAll({ @FindBy(how = How.XPATH, using = "//*[text()='Inpatient Days']/following::tr[@role='listitem'][1]/td[1]") })
	public WebElement inpatientcodeAreaList;
	
	
	@FindAll({ @FindBy(how = How.XPATH, using = "//*[text()='Service Codes']/preceding::tr[@role='listitem'][1]/td[1]") })
	public WebElement servicecodeAreaList;

	@FindAll({ @FindBy(how = How.XPATH, using = "//*[text()='Inpatient Days']/following::tr[@role='listitem'][1]/td[2]") })
	public WebElement codeAreaList1;

	@FindAll({ @FindBy(how = How.XPATH, using = "//*[text()='Inpatient Days']/following::tr[@role='listitem'][1]/td[3]") })
	public WebElement codeAreaList2;

	@FindAll({ @FindBy(how = How.XPATH, using = "//*[text()='Inpatient Days']/following::tr[@role='listitem'][1]/td[4]") })
	public WebElement codeAreaList3;

	@FindAll({ @FindBy(how = How.XPATH, using = "//*[text()='Inpatient Days']/following::tr[@role='listitem'][1]/td[5]") })
	public WebElement codeAreaList4;

	@FindAll({ @FindBy(how = How.XPATH, using = "//input[@name='requestingProvId']/parent::td/parent::tr/td[2]/table/tbody/tr/td/span/img[contains(@src,'search_picker')]") })
	public WebElement requestingProvIdsearchPicker;
	
	@FindAll({ @FindBy(how = How.XPATH, using = "//input[@name='servicingProvId']/parent::td/parent::tr/td[2]/table/tbody/tr/td/span/img[contains(@src,'search_picker')]") })
	public WebElement servicingProvIdsearchPicker;
	
	@FindAll({ @FindBy(how = How.XPATH, using = "//input[@name='facilityProvId']/parent::td/parent::tr/td[2]/table/tbody/tr/td/span/img[contains(@src,'search_picker')]") })
	public WebElement facilityProvIdsearchPicker;
	
	@FindAll({ @FindBy(how = How.XPATH, using = "//span//input[@name='code']") })
	public WebElement hiddenTextbox;
	
	
	
	@FindAll({ @FindBy(how = How.XPATH, using = "//div[contains(@eventproxy,'isc_ListGrid')]//table[@class='listTable']//tr[1]") })
	public List<WebElement> serviceCodeList;
	
	
	@FindAll({ @FindBy(how = How.XPATH, using = "//td[@class='tallCellSelected']/div/nobr/span/table/tbody/tr/td[2]") })
	public WebElement hiddenSearchPicker;
	

	@FindAll({ @FindBy(how = How.NAME, using = "description") })
	public WebElement description;

	@FindAll({ @FindBy(how = How.XPATH, using = "//input[@name='description']/following::div[contains(text(),'Search')]") })
	public WebElement search;

	@FindAll({ @FindBy(how = How.XPATH, using = "//input[@name='description']/following::div[contains(text(),'Cancel')]") })
	public WebElement cancel;

	@FindAll({ @FindBy(how = How.XPATH, using = "//input[@name='description']/following::div[contains(text(),'Cancel')]/following::table[@class='listTable']/tbody/tr[1]") })
	public WebElement codeSelect;

	@FindAll({ @FindBy(how = How.XPATH, using = "//input[@name='ipfrom_dateTextField']") })
	public WebElement fromdate;

	@FindAll({ @FindBy(how = How.XPATH, using = "//input[@name='ipthru_dateTextField']") })
	public WebElement thru;

	@FindAll({ @FindBy(how = How.XPATH, using = "//span[contains(@eventproxy,'isc_DynamicForm_')]/table/tbody") })
	public WebElement dropdown;

	@FindAll({ @FindBy(how = How.XPATH, using = "//td[@class='pickListCell']") })
	public List<WebElement> bedTypeDropdownList;

	@FindAll({ @FindBy(how = How.XPATH, using = "//div[contains(@class,'pickListMenuBody')]/div/table/tbody/tr") })
	public List<WebElement> commondropdownList;

	@FindAll({ @FindBy(how = How.XPATH, using = "//input[@name='admissionDate_dateTextField']") })
	public WebElement admissionDate;

	@FindAll({ @FindBy(how = How.XPATH, using = "//input[@name='dischargeDate_dateTextField']") })
	public WebElement dischargeDate;

	@FindAll({ @FindBy(how = How.XPATH, using = "//input[@name='provid']") })
	public WebElement providerId;

	@FindAll({ @FindBy(how = How.XPATH, using = "//td[@class='button']") })
	public List<WebElement> buttonList;

	@FindAll({ @FindBy(how = How.XPATH, using = "//tr[1][@role='listitem']/td/div/nobr[text()='PG0044930001']") })
	public WebElement providerSearch;

	@FindAll({ @FindBy(how = How.XPATH, using = "//input[@name='serviceProviderSame_id']") })
	public List<WebElement> radioButtonList;

	@FindAll({ @FindBy(how = How.XPATH, using = "//td[@class='button']/div/div[contains(text(),'Submit')]") })
	public WebElement submitButton;

	@FindAll({ @FindBy(how = How.XPATH, using = "//div[text()='Facility']") })
	public WebElement facility;

	@FindAll({ @FindBy(how = How.XPATH, using = "//div[contains(@eventproxy,'isc_DynamicForm_')]/form/table/tbody/tr[2]/td/nobr[contains(text(),'Reference #')]/following::td/div") })
	public WebElement referenceNumber;

	@FindAll({ @FindBy(how = How.XPATH, using = "//div[contains(text(),'CSC Follow Up')]") })
	public WebElement statusReasonDropdown;

	@FindAll({ @FindBy(how = How.XPATH, using = "//td[@class='button']/div/div[text()='Submit']") })
	public WebElement submit;
	
//	@FindAll({ @FindBy(how = How.XPATH, using = "//div[contains(@eventproxy,'isc_ImageRequestView_')]/div/table/tbody/tr/td[5]/div") })
//	WebElement derNo;
	
	@FindAll({ @FindBy(how = How.XPATH, using = "//div[text()='OK']") })
	public WebElement LOAOK;
	
	
	
	
	@FindAll({ @FindBy(how = How.XPATH, using = "//input[@name='facilityLoa_id']/parent::td/following-sibling::td/label[text()='Yes']") })
	public WebElement Yes;
	
	@FindAll({ @FindBy(how = How.XPATH, using = "//input[@name='servicingLoa_id']") })
	public List<WebElement> LOARadioButton;
	
	@FindAll({ @FindBy(how = How.XPATH, using = "//input[@name='facilityLoa_id']") })
	public List<WebElement> facilityLOARadioButton;
	

	@FindAll({ @FindBy(how = How.XPATH, using = "//input[@name='requestingFax']") })
	public WebElement fax;
	
	
	
	@FindAll({ @FindBy(how = How.XPATH, using = "//input[@name='facilityLoa_id']/parent::td/following-sibling::td/label[text()='Yes']") })
	public WebElement LOARadiobutton;
	
	
	
	// input[@name='servicingFax']

	@FindAll({ @FindBy(how = How.XPATH, using = "//input[@name='servicingFax']") })
	public WebElement servicingFax;

	@FindAll({ @FindBy(how = How.XPATH, using = "//input[@name='facilityFax']") })
	public WebElement facilityFax;

	@FindAll({ @FindBy(how = How.XPATH, using = "// div[contains(@eventproxy,'isc_globalWarn_closeButton')]/img[contains(@src,'close')]") })
	public WebElement close;

	@FindAll({ @FindBy(how = How.XPATH, using = ".//span[contains(@class,'formTitle')]/b[contains(text(),'Source')]/following::td[1]") })
	public WebElement source;

	@FindAll({ @FindBy(how = How.XPATH, using = ".//span[contains(@class,'formTitle')]/b[contains(text(),'Place of Service')]/following::td[1]") })
	public WebElement placeOfService;

	@FindAll({ @FindBy(how = How.XPATH, using = ".//span[contains(text(),'Place of Service')]/following::td[1]") })
	public WebElement medicationPOS;

	@FindAll({ @FindBy(how = How.XPATH, using = ".//span[contains(@class,'formTitle')]/b[contains(text(),'Request Type')]/following::td[1]") })
	public WebElement requestTypeDropdown;

	@FindAll({ @FindBy(how = How.XPATH, using = ".//span[contains(text(),'Requester')]/following::td[1]") })
	public WebElement requesterTypeDropdown;

	@FindAll({ @FindBy(how = How.XPATH, using = ".//span[contains(text(),'Review Type')]/following::td[1]") })
	public WebElement reviewTypeDropdown;

	@FindAll({ @FindBy(how = How.XPATH, using = ".//span[contains(text(),'Priority')]/following::td[1]") })
	public WebElement PriorityDropdown;

	@FindAll({ @FindBy(how = How.XPATH, using = ".//span/b[contains(text(),'Admission BedType')]/following::td[1]") })
	public WebElement admissionBedTypeDropdown;

	@FindAll({ @FindBy(how = How.XPATH, using = ".//span[contains(text(),'Service Category')]/following::td[1]") })
	public WebElement serviceCategoryDropdown;

	@FindAll({ @FindBy(how = How.XPATH, using = ".//span[contains(text(),'Sub Category')]/following::td[1]") })
	public WebElement subCategoryDropdown;

	@FindAll({ @FindBy(how = How.XPATH, using = ".//span/b[contains(text(),'Inquiry Outcome')]/following::td[1]") })
	public WebElement inquiryOutcomeDropdown;

	@FindAll({ @FindBy(how = How.XPATH, using = ".//span[contains(text(),'Outcome Reason')]/following::td[1]") })
	public WebElement outcomeReasonDropdown;

	@FindAll({ @FindBy(how = How.XPATH, using = ".//span[contains(text(),'Admit From')]/following::td[1]") })
	public WebElement admitFromDropdown;

	@FindAll({ @FindBy(how = How.XPATH, using = ".//span/b[contains(text(),'Admit Type')]/following::td[1]") })
	public WebElement admitTypeDropdown;

	@FindAll({ @FindBy(how = How.XPATH, using = "//tr/td[text()='Enter valid Data']") })
	public WebElement validDataPopUp;
	
	@FindAll({ @FindBy(how = How.XPATH, using = "//div[text()='Completed']") })
	public WebElement completedCheckbox;

	@FindAll({ @FindBy(how = How.XPATH, using = "//img[contains(@src,'hsplit_snap')]") })
	public WebElement hsplit;

	@FindAll({ @FindBy(how = How.XPATH, using = "//tr/td[text()='The requested facility is out of service area']") })
	public WebElement outOfService;
	
	@FindAll({ @FindBy(how = How.XPATH, using = "//div[contains(@eventproxy,'isc_ImageRequestWorkSpace_0')]/div/div[3]//td[@class='button']/div/div[text()='Save']") })
	public WebElement savePreAuth;
	
	@FindAll({ @FindBy(how = How.XPATH, using = "//td/span/b/label[text()='Provider ID']//ancestor::tr//div[text()='Unknown']") })
	public WebElement unknownProviderID;
	
	@FindAll({ @FindBy(how = How.XPATH, using = "//td/span/b/label[text()='Facility Provider ID']//ancestor::tr//div[text()='Unknown']") })
	public WebElement unknownFacilityID;
	
	@FindAll({ @FindBy(how = How.XPATH, using = "//td/input[@name='requestingNPI']") })
	public WebElement unknownProviderNPI;
	
	@FindAll({ @FindBy(how = How.XPATH, using = "//td/input[@name='requestingFax']") })
	public WebElement unknownProviderFAX;
	
	@FindAll({ @FindBy(how = How.XPATH, using = "//td/input[@name='facilityAddress1']") })
	public WebElement unknownFacilityAddress1;
	
	@FindAll({ @FindBy(how = How.XPATH, using = "//td/input[@name='facilityCity']") })
	public WebElement unknownFacilityCity;
		
	@FindAll({ @FindBy(how = How.XPATH, using = "//td/input[@name='facilityState']") })
	public WebElement unknownFacilityState;
		
	@FindAll({ @FindBy(how = How.XPATH, using = "//td/input[@name='facilityZip']") })
	public WebElement unknownFacilityZip;
	
	@FindAll({ @FindBy(how = How.XPATH, using = "//div[contains(@eventproxy,'isc_ImageRequestView_')]//tbody/tr[@role='listitem']/td[5]") })
	public WebElement derNo;
	
	
	//td/input[@name='facilityOrganization']
	//td/input[@name='facilityPhone']
	//td/input[@name='facilityFax']
	//td/input[@name='facilityState']
	
	

	public void eventIntake(String requestTypeName, String placeOfServiceName,
			String sourceName, String receivedDate, WebDriver driver,
			ExtentTest logger) {
		try {

			
			
			webUtils.explicitWaitByElementToBeClickable(driver,15, hsplit);
			
			hsplit.click();
			
			logger.log(LogStatus.INFO, "Provide the details for Event Intake");
			webUtils.explicitWaitByElementToBeClickable(driver,10, requestTypeDropdown);

			logger.log(LogStatus.INFO, "Select the request type name!!");
			requestTypeDropdown.click();

			webUtils.clickButtonOrLink(dropdownNames, requestTypeName, logger,
					driver);
			logger.log(LogStatus.INFO, "Select the place of service");
			if ("Medication".equalsIgnoreCase(requestTypeName)
					|| "Service Post Review".equalsIgnoreCase(requestTypeName)
					|| "Inpatient Post Review".equalsIgnoreCase(requestTypeName)) {
				webUtils.explicitWaitByElementToBeClickable(driver,10, medicationPOS);

				medicationPOS.click();
			} else if ("Inpatient".equalsIgnoreCase(requestTypeName)
					|| 
					"Service Request (Prior Auth)".equalsIgnoreCase(requestTypeName)) {
				webUtils.explicitWaitByElementToBeClickable(driver,10, placeOfService);

				placeOfService.click();

			}
			// Added wait time for flow synchronization
			Thread.sleep(3000);
			webUtils.clickButtonOrLink(dropdownNames, placeOfServiceName, logger,
					driver);

			logger.log(LogStatus.INFO, "Select the source!!");
			source.click();

			webUtils.clickButtonOrLink(dropdownNames, sourceName, logger, driver);

			logger.log(LogStatus.INFO,
					"Enter the manual received date and next reaview date!!");
			//manualReceivedDate.sendKeys(receivedDate);

			// nextReviewDate.sendKeys(reviewDate);

		
		}
		catch(Exception e) {
			e.printStackTrace();
		}
	}

	public void addDiagnosisCodes(WebDriver driver,String diagnosisCode,
			ExtentTest logger) {
		try {


			logger.log(LogStatus.INFO, "Add diagnosis codes!!");
			
			

			webUtils.explicitWaitByElementToBeClickable(driver,10, diagcodeAreaList);

			diagcodeAreaList.click();
			// Added wait time for flow synchronization
			Thread.sleep(3000);
			

			webUtils.moveToTextBox(hiddenTextbox, diagnosisCode, driver);
			
			webUtils.moveToTextBoxusingKeys(hiddenTextbox, Keys.ENTER, driver);
			
			logger.log(LogStatus.INFO, "Diagnosis Codes are entered successfully");
			
		
			//webUtils.waitUntilElementclickable(hiddenSearchPicker,driver);
			
			//hiddenSearchPicker.click();
			
			/*webUtils.explicitWaitByVisibilityofElement(driver, description);

			description.sendKeys(diagnosisDesc);

			search.click();

			webUtils.explicitWaitByElementToBeClickable(driver, codeSelect);

			codeSelect.click();

			webUtils.doubleClick(driver, codeSelect);*/

		
		}
		catch(Exception e) {
			e.printStackTrace();
		}
	}

	public void addServiceCodes(String serviceCode, WebDriver driver,
			ExtentTest logger){
		try {


			logger.log(LogStatus.INFO, "Add service codes!!");
			
			if(serviceCode.contains(",")){
				
				String[] serviceCodes = serviceCode.split(",");
				
				webUtils.explicitWaitByElementToBeClickable(driver,10, servicecodeAreaList);

				webUtils.moveToClickableElement(servicecodeAreaList, driver);
				

				boolean isPresent = false;

				try {
					webUtils.explicitWaitByVisibilityofElement(driver,10, validDataPopUp);
					isPresent = validDataPopUp.isDisplayed();

				} catch (Exception e) {
					System.out.println("validDataPopUp validation is skipped");

				}

				if (isPresent) {

					close.click();

					webUtils.moveToClickableElement(servicecodeAreaList, driver);
				} else {

					System.out.println("Popup is not displayed!!");
				}
				
				/*webUtils.mouseOver(hiddenTextbox, driver);
				hiddenTextbox.sendKeys(serviceCode);
				webUtils.mouseOver(hiddenTextbox, driver);
				
				hiddenTextbox.sendKeys(Keys.TAB);*/
				// Added wait time for flow synchronization
				Thread.sleep(3000);
				
				webUtils.moveToTextBox(hiddenTextbox, serviceCodes[0], driver);
				
				webUtils.moveToTextBoxusingKeys(hiddenTextbox, Keys.ENTER, driver);
				
				try{
					webUtils.explicitWaitByVisibilityOfAllElements(driver, 15, serviceCodeList);
					
					serviceCodeList.get(0).click();
					
					webUtils.doubleClick(driver, serviceCodeList.get(0));
				}catch(Exception e){
					System.out.println("serviceCodeList validation is skipped");
					
				}
				

				webUtils.explicitWaitByElementToBeClickable(driver,10, servicecodeAreaList);

				webUtils.moveToClickableElement(servicecodeAreaList, driver);
				
				webUtils.moveToTextBox(hiddenTextbox, serviceCodes[1], driver);
				
				webUtils.moveToTextBoxusingKeys(hiddenTextbox, Keys.ENTER, driver);	
				try{
					webUtils.explicitWaitByVisibilityOfAllElements(driver, 15, serviceCodeList);
					
					serviceCodeList.get(0).click();
					
					webUtils.doubleClick(driver, serviceCodeList.get(0));
				}catch(Exception e){
					System.out.println("serviceCodeList validation is skipped");
					
				}
				
				
			}else{
			webUtils.explicitWaitByElementToBeClickable(driver,10, servicecodeAreaList);

			webUtils.moveToClickableElement(servicecodeAreaList, driver);
			

			boolean isPresent = false;

			try {
				webUtils.explicitWaitByVisibilityofElement(driver,10, validDataPopUp);
				isPresent = validDataPopUp.isDisplayed();

			} catch (Exception e) {
				System.out.println("validDataPopUp validation is skipped");
			}

			if (isPresent) {

				close.click();

				webUtils.moveToClickableElement(servicecodeAreaList, driver);
			} else {

				System.out.println("Popup is not displayed!!");
			}
			
			
			// Added wait time for flow synchronization
			Thread.sleep(3000);
			
			webUtils.moveToTextBox(hiddenTextbox, serviceCode, driver);
			
			webUtils.moveToTextBoxusingKeys(hiddenTextbox, Keys.ENTER, driver);
			
			logger.log(LogStatus.INFO, "Service codes are added successfully");
			
			try{
				webUtils.explicitWaitByVisibilityOfAllElements(driver, 15, serviceCodeList);
				
				serviceCodeList.get(0).click();
				
				webUtils.doubleClick(driver, serviceCodeList.get(0));
			}catch(Exception e){
				System.out.println("serviceCodeList validation is skipped");
				
			}
			
			}
			
			/*try{
				
				if(delete.isDisplayed()){
					
					delete.click();
				}
			}catch(Exception E){
				
				
			}*/
			
			
			

			//webUtils.explicitWaitByElementToBeClickable(driver, hiddenSearchPicker);

			//hiddenSearchPicker.click();

			/*description.sendKeys(serviceDesc);

			search.click();

			webUtils.explicitWaitByElementToBeClickable(driver, codeSelect);

			codeSelect.click();

			webUtils.doubleClick(driver, codeSelect);*/

		
		}
		catch(Exception e) {
			e.printStackTrace();
		}
	}

	public void inPatientDays(String fromDate, String toDate, String bedType,
			String revCode, String drgCode, WebDriver driver, ExtentTest logger)
			{

		// webUtils.explicitWaitByVisibilityofElement(driver,
		// codeAreaList.get(4));

		// webUtils.scrollDown(driver, codeAreaList.get(4));
		
		webUtils.scrollDown(driver, codeAreaList1);

		webUtils.moveToClickableElement(inpatientcodeAreaList, driver);

		webUtils.explicitWaitByVisibilityofElement(driver,15, fromdate);

		fromdate.sendKeys(fromDate);
		
		
	
		webUtils.explicitWaitByElementToBeClickable(driver,15, codeAreaList1);
		
		webUtils.moveToClickableElement(codeAreaList1, driver);
		
		webUtils.moveToClickableElement(codeAreaList1, driver);
		
		webUtils.moveToTextBox(thru, toDate, driver);
		
	
	/*	//thru.sendKeys(toDate);
		
		Thread.sleep(5000);

		webUtils.moveToClickableElement(codeAreaList2, driver);
		
		

		webUtils.explicitWaitByVisibilityofElement(driver, dropdown);

		dropdown.click();

		webUtils.explicitWaitByPresenceofAllElements(driver,
				"//div[contains(@class,'pickListMenuBody')]/div/table/tbody/tr");

		webUtils.clickButtonOrLink(commondropdownList, bedType, logger, driver);

		Thread.sleep(5000);

		webUtils.moveToClickableElement(codeAreaList3, driver);
	

		webUtils.explicitWaitByVisibilityofElement(driver, dropdown);

		dropdown.click();

		webUtils.explicitWaitByPresenceofAllElements(driver,
				"//div[contains(@class,'pickListMenuBody')]/div/table/tbody/tr");

		webUtils.clickButtonOrLink(commondropdownList, revCode, logger, driver);

		Thread.sleep(5000);

		webUtils.moveToClickableElement(codeAreaList4, driver);
		

		webUtils.explicitWaitByVisibilityofElement(driver, dropdown);

		dropdown.click();

		webUtils.explicitWaitByPresenceofAllElements(driver,
				"//div[contains(@class,'pickListMenuBody')]/div/table/tbody/tr");

		webUtils.clickButtonOrLink(commondropdownList, drgCode, logger, driver);*/

	}

	public void inPatient(String admissiondate, String requestTypeName,
			String admitType, String admitFrom, WebDriver driver,
			ExtentTest logger) {
		try {


			logger.log(LogStatus.INFO, "Provide admission date!!");

			webUtils.moveToClickableElement(admissionDate, driver);

			admissionDate.sendKeys(admissiondate);

			logger.log(LogStatus.INFO, "Select the admit Type!!");

			// Added wait time for flow synchronization
			Thread.sleep(3000);

			webUtils.moveToClickableElement(admitTypeDropdown, driver);

			webUtils.clickButtonOrLink(commondropdownList, admitType, logger,
					driver);
			/*
			 * Robot robot = new Robot();
			 * 
			 * robot.keyPress(KeyEvent.VK_TAB);
			 * 
			 * robot.keyRelease(KeyEvent.VK_TAB);
			 * 
			 * robot.keyPress(KeyEvent.VK_TAB);
			 * 
			 * robot.keyRelease(KeyEvent.VK_TAB);
			 * 
			 * robot.keyPress(KeyEvent.VK_DOWN); robot.keyRelease(KeyEvent.VK_DOWN);
			 * 
			 * robot.keyPress(KeyEvent.VK_DOWN);
			 * 
			 * robot.keyRelease(KeyEvent.VK_DOWN);
			 */

			logger.log(LogStatus.INFO, "Select the admit from!!");

			webUtils.moveToClickableElement(admitFromDropdown, driver);

			webUtils.clickButtonOrLink(commondropdownList, admitFrom, logger,
					driver);

			/*
			 * logger.log(LogStatus.INFO, "Provide the discharge date");
			 * 
			 * webUtils.moveToClickableElement(dischargeDate, driver);
			 * 
			 * // dischargeDate.sendKeys(dischargedate);
			 */
		
		}
		catch(Exception e) {
			e.printStackTrace();
		}
	}

	public void requestingProvider(String organisation,String providerCode, WebDriver driver,
			String requester, String serviceType, ExtentTest logger)
			 {
		
		try{
		logger.log(LogStatus.INFO, "Select the requester!!!");

		webUtils.moveToClickableElement(requesterTypeDropdown, driver);
		// Added wait time for flow synchronization
		Thread.sleep(3000);
		webUtils.clickButtonOrLink(commondropdownList, requester, logger,
				driver);
		
		webUtils.scrollDown(driver, requestingProvIdsearchPicker);

		/*
		 * if (serviceType.equalsIgnoreCase("Inpatient") ||
		 * serviceType.equalsIgnoreCase("Inpatient Post Review")) {
		 * 
		 * webUtils.moveToClickableElement(dropDownList.get(12), driver);
		 * 
		 * webUtils.clickButtonOrLink(commondropdownList, requester, logger,
		 * driver); }
		 * 
		 * else if (serviceType.equalsIgnoreCase("Medication") ||
		 * serviceType.equalsIgnoreCase("Service Post Review") ||
		 * serviceType.equalsIgnoreCase("Service Request (Prior Auth)")) {
		 * webUtils.moveToClickableElement(dropDownList.get(11), driver);
		 * 
		 * webUtils.clickButtonOrLink(commondropdownList, requester, logger,
		 * driver); }
		 */

		webUtils.explicitWaitByElementToBeClickable(driver,10, requestingProvIdsearchPicker);

		logger.log(LogStatus.INFO, "Select the provider!!!");

		webUtils.moveToClickableElement(requestingProvIdsearchPicker, driver);

		providerId.sendKeys(providerCode);

		webUtils.clickButtonOrLink(buttonList, "Extended Search", logger,
				driver);
		
		webUtils.explicitWaitByPresenceofElement(driver,30, "//tr[@role='listitem'][1]/td/div/nobr[text()="+"'"+providerCode+"']/parent::div");
		
		WebElement search = driver.findElement(By.xpath("//tr[@role='listitem'][1]/td/div/nobr[text()="+"'"+providerCode+"']/parent::div"));
		
		search.click();

		webUtils.doubleClick(driver, search);

		webUtils.explicitWaitByElementToBeClickable(driver,10, fax);

		// webUtils.explicitWait(driver, fax);

		webUtils.moveToClickableElement(fax, driver);
		
		fax.clear();

		fax.sendKeys("1000000000");

	}
		catch(Exception e) {
			e.printStackTrace();
		}
			 }

	public void servicingProviderSame(String servicingProviderSame,String providerCode,
			WebDriver driver, ExtentTest logger) {

		try {
			logger.log(LogStatus.INFO,
					"Select the answer for servicing provider same!!");
			if ("No".equalsIgnoreCase(servicingProviderSame)) {

				servicingProvider(driver, "adventis",providerCode, "Extended Search", logger);
			} else {

				webUtils.moveToClickableElement(radioButtonList.get(0), driver);
				// Added wait time for flow synchronization
				Thread.sleep(3000);
			}
		}
		catch(Exception e) {
			e.printStackTrace();
		}
	}

	public void servicingProvider(WebDriver driver, String organisation,String providerCode,
			String searchType, ExtentTest logger)  {
		try {


			logger.log(LogStatus.INFO, "Select the servicing provider!!");

			webUtils.moveToClickableElement(radioButtonList.get(1), driver);

			webUtils.explicitWaitByElementToBeClickable(driver,10, servicingProvIdsearchPicker);

			webUtils.moveToClickableElement(servicingProvIdsearchPicker, driver);

			providerId.sendKeys(providerCode);

			webUtils.clickButtonOrLink(buttonList, searchType, logger, driver);

			// webUtils.explicitWait(driver, providerSearch);

			webUtils.explicitWaitByPresenceofElement(driver,30, "//tr[1][@role='listitem']/td/div/nobr[text()="+"'"+providerCode+"']");
			
			System.out.println("The xpath is "+"//tr[1][@role='listitem']/td/div/nobr[text()="+"'"+providerCode+"']/parent::div");
			
			WebElement search = driver.findElement(By.xpath("//tr[1][@role='listitem']/td/div/nobr[text()="+"'"+providerCode+"']/parent::div"));
			search.click();

			webUtils.doubleClick(driver, search);
			// Added wait time for flow synchronization
			Thread.sleep(3000);

			// webUtils.explicitWait(driver, fax);

			webUtils.moveToClickableElement(servicingFax, driver);
			
			servicingFax.clear();

			servicingFax.sendKeys("1000000000");

		
		}
		catch(Exception e) {
			e.printStackTrace();
		}
	}

	public void facilityProvider(WebDriver driver, String organisation,String providerCode,
			ExtentTest logger) {
		try {


			logger.log(LogStatus.INFO, "Select the facility provider!!");
			webUtils.moveToClickableElement(facility, driver);
			
			webUtils.scrollDown(driver, facilityProvIdsearchPicker);
			
			if ("Unknown".equalsIgnoreCase(providerCode)){
				
				unknownFacilityID.click();
				// Added wait time for flow synchronization
				Thread.sleep(1000);
										
				unknownFacilityAddress1.sendKeys("P O BOX 618");
				
				unknownFacilityCity.sendKeys("NOVATO");
				
				unknownFacilityState.sendKeys("CA");
				
				unknownFacilityZip.sendKeys("949480618");
			}
			
			else{
			
			webUtils.explicitWaitByElementToBeClickable(driver,10, facilityProvIdsearchPicker);
			
			webUtils.moveToClickableElement(facilityProvIdsearchPicker, driver);

			providerId.sendKeys(providerCode);

			webUtils.clickButtonOrLink(buttonList, "Extended Search", logger,
					driver);

			webUtils.explicitWaitByPresenceofElement(driver,30, "//tr[1][@role='listitem']/td/div/nobr[text()="+"'"+providerCode+"']/parent::div");
			
			WebElement search = driver.findElement(By.xpath("//tr[1][@role='listitem']/td/div/nobr[text()="+"'"+providerCode+"']/parent::div"));
			search.click();

			webUtils.doubleClick(driver, search);

			boolean isPresent = false;

			try {
				webUtils.explicitWaitByVisibilityofElement(driver,30, outOfService);
				isPresent = outOfService.isDisplayed();

			} catch (Exception e) {
				System.out.println("outOfService validation is skipped");

			}

			if (isPresent) {

				close.click();

			} else {

				System.out.println("Popup is not displayed!!");
			}

			webUtils.explicitWaitByElementToBeClickable(driver,20, facilityFax);

			// webUtils.explicitWait(driver, fax);

			webUtils.moveToClickableElement(facilityFax, driver);
			
			facilityFax.clear();

			facilityFax.sendKeys("1000000000");
			
			}

		
		}
		catch(Exception e) {
			e.printStackTrace();
		}
	}

	public void reviewIntake(WebDriver driver, String reviewType,
			String priority, String admissionBedType, String serviceType,
			String serviceCategory, String subCategory, ExtentTest logger)
			{
		try {


			if ("Inpatient".equalsIgnoreCase(serviceType)
					|| "Inpatient Post Review".equalsIgnoreCase(serviceType)) {
				webUtils.moveToClickableElement(reviewTypeDropdown, driver);

				logger.log(LogStatus.INFO, "Select the review type!!");

				webUtils.clickButtonOrLink(commondropdownList, reviewType, logger,
						driver);
				// Added wait time for flow synchronization
				Thread.sleep(1000);
				
				logger.log(LogStatus.INFO, "Select the priority!!");

				webUtils.moveToClickableElement(PriorityDropdown, driver);

				webUtils.clickButtonOrLink(commondropdownList, priority, logger,
						driver);
				// Added wait time for flow synchronization
				Thread.sleep(1000);
				
				logger.log(LogStatus.INFO, "Select the admission bed type!!");

				if ("Inpatient".equalsIgnoreCase(serviceType)) {
					webUtils.moveToClickableElement(admissionBedTypeDropdown,
							driver);

					webUtils.clickButtonOrLink(commondropdownList,
							admissionBedType, logger, driver);
				}
			} else if ("Medication".equalsIgnoreCase(serviceType)
					|| "Service Post Review".equalsIgnoreCase(serviceType)
					|| "Service Request (Prior Auth)".equalsIgnoreCase(serviceType)) {

				logger.log(LogStatus.INFO, "Select the review type!!");

				webUtils.moveToClickableElement(reviewTypeDropdown, driver);

				webUtils.clickButtonOrLink(commondropdownList, reviewType, logger,
						driver);

				logger.log(LogStatus.INFO, "Select the priority!!");

				webUtils.moveToClickableElement(PriorityDropdown, driver);

				webUtils.clickButtonOrLink(commondropdownList, priority, logger,
						driver);

				logger.log(LogStatus.INFO, "Select the serviceCategory!!");

				webUtils.moveToClickableElement(serviceCategoryDropdown, driver);

				webUtils.clickButtonOrLink(commondropdownList, serviceCategory,
						logger, driver);

				if(!("").equals(subCategory)){
				  logger.log(LogStatus.INFO, "Select the subCategory!!");
				  
				  webUtils.moveToClickableElement(subCategoryDropdown, driver);
				  
				  webUtils.clickButtonOrLink(commondropdownList, subCategory,
				  logger, driver);
				} 

			}

		
		}
		catch(Exception e) {
			e.printStackTrace();
		}
			}

	public void inquiryOutcome(WebDriver driver, String inquiryOutcome,
			String outcomeReason, String buttonType, String serviceType,
			ExtentTest logger)  {
		try {

			if ("Inpatient".equalsIgnoreCase(serviceType)
					|| "Inpatient Post Review".equalsIgnoreCase(serviceType)) {

				logger.log(LogStatus.INFO, "Select the inquiry outcome!!");

				webUtils.moveToClickableElement(inquiryOutcomeDropdown, driver);

				webUtils.clickButtonOrLink(commondropdownList, inquiryOutcome,
						logger, driver);

				logger.log(LogStatus.INFO, "Select the outcomeReason!!");

				webUtils.moveToClickableElement(outcomeReasonDropdown, driver);

				webUtils.clickButtonOrLink(commondropdownList, outcomeReason,
						logger, driver);

				webUtils.moveToClickableElement(submitButton, driver);
				// Added wait time for flow synchronization
				Thread.sleep(3000);
				
			} else if ("Medication".equalsIgnoreCase(serviceType)
					|| "Service Post Review".equalsIgnoreCase(serviceType)
					|| "Service Request (Prior Auth)".equalsIgnoreCase(serviceType)) {
				webUtils.moveToClickableElement(inquiryOutcomeDropdown, driver);

				logger.log(LogStatus.INFO, "Select the inquiry outcome!!");

				webUtils.clickButtonOrLink(commondropdownList, inquiryOutcome,
						logger, driver);

				webUtils.moveToClickableElement(outcomeReasonDropdown, driver);

				logger.log(LogStatus.INFO, "Select the outcomeReason!!");

				webUtils.clickButtonOrLink(commondropdownList, outcomeReason,
						logger, driver);

				webUtils.moveToClickableElement(submitButton, driver);
				
				Thread.sleep(60000);// Added wait time for flow synchronization
				
			}

		
		}
		catch(Exception e) {
			e.printStackTrace();
		}
	}
	
	public void completeAuthorization(String testCaseName,String rowNum,WebDriver driver,ExtentTest logger) {
		try {

			
			webUtils.explicitWaitByElementToBeClickable(driver, 30,
					derNo);

			webUtils.explicitWaitByElementToBeClickable(driver, 15, derNo);
			
			referenceDerNo = derNo.getText(); 

			logger.log(LogStatus.INFO,
					"The Rx no is " + referenceDerNo); 

			//ExcelUtilities.setCellData("Homepage", Integer.valueOf(rowNum),
				//	8, RXNo);
			
			ExcelUtilities.setCellData("UmIntake", Integer.valueOf(rowNum),
					10, referenceDerNo); 
			System.out.println("Auth No is :"+referenceDerNo); 
			
			webUtils.takeSnapShot(
					driver,
					"test-output/BSC-reports/screenshots/"
							+ testCaseName.trim()
							+ "PriorAUthorization.png");
			
			webUtils.explicitWaitByElementToBeClickable(driver, 10, completedCheckbox);
			completedCheckbox.click();

			webUtils.explicitWaitByElementToBeClickable(driver, 10, savePreAuth);
			savePreAuth.click();
			
			// Added wait time for flow synchronization
			Thread.sleep(3000);
			
			if(" ".equalsIgnoreCase(referenceDerNo)){ 
				logger.log(LogStatus.INFO, "Authorization has not been created");
				
			}
			else{
				logger.log(LogStatus.INFO, "Authorization has been created");
			}
		
		}
		catch(Exception e) {
			e.printStackTrace();
		}
	}

	public void assignToNurseReview(String reason, WebDriver driver,
			String rowNum, ExtentTest logger, String testCaseName)
			 {
		try {


			// webUtils.explicitWait(driver, "//div[@class='staticTextItem']");
			Thread.sleep(3000);// Added wait time for flow synchronization
			logger.log(LogStatus.INFO, "Assign the case to Nurse review!!");
			

			try{
				webUtils.explicitWaitByElementToBeClickable(driver,20, closePopup);
				if(closePopup.isDisplayed()){
					
					closePopup.click();
				}
			}catch(Exception e){
				System.out.println("closePopup validation is skipped");
				
			}
			try{
			webUtils.explicitWaitByElementToBeClickable(driver,20, hsplit);
			
			hsplit.click();
			
			
			}catch(Exception e){
				System.out.println("hsplit validation is skipped");
			}
			webUtils.fluentWait(driver, "//div[contains(@eventproxy,'isc_DynamicForm_')]/form/table/tbody/tr[2]/td/nobr[contains(text(),'Reference #')]/following::td/div");
			/*
			Wait<WebDriver> Wait = new FluentWait<WebDriver>(driver)
					.withTimeout(30, TimeUnit.SECONDS)
					.pollingEvery(5, TimeUnit.SECONDS)
					.ignoring(NoSuchElementException.class)
					.ignoring(StaleElementReferenceException.class);

			WebElement referenceNumber = Wait
					.until(new Function<WebDriver, WebElement>() {
						public WebElement apply(WebDriver driver) {
							return driver.findElement(By
									.xpath("//div[contains(@eventproxy,'isc_DynamicForm_')]/form/table/tbody/tr[2]/td/nobr[contains(text(),'Reference #')]/following::td/div"));
						}
					});*/
			 referenceNo = referenceNumber.getText();
			 ProviderPortalHomePage.referenceNum = referenceNumber.getText();
			logger.log(LogStatus.INFO, "The reference number is " + referenceNo);

			System.out.println("The reference no is " + referenceNo);
			ExcelUtilities.setCellData("UmIntake", Integer.valueOf(rowNum),
					9, referenceNo);
			
			try{
				webUtils.scrollDown(driver, LOARadiobutton);
				
				LOARadiobutton.click();
			}
			catch(Exception e){
				
				System.out.println("LOARadiobutton validation is skipped");
			}

			webUtils.moveToClickableElement(statusReasonDropdown, driver);
			
			webUtils.fluentWait(driver, "//div[contains(@id,'isc_PickListMenu_0_body$28s')]/following::table/tbody/tr[1]/td/div/nobr[text()='Nurse Review']");

			/*Wait<WebDriver> stubbornWait = new FluentWait<WebDriver>(driver)
					.withTimeout(30, TimeUnit.SECONDS)
					.pollingEvery(5, TimeUnit.SECONDS)
					.ignoring(NoSuchElementException.class)
					.ignoring(StaleElementReferenceException.class);

			WebElement foo = stubbornWait
					.until(new Function<WebDriver, WebElement>() {
						public WebElement apply(WebDriver driver) {
							return driver.findElement(By
									.xpath("//div[contains(@id,'isc_PickListMenu_0_body$28s')]/following::table/tbody/tr[1]/td/div/nobr[text()='Nurse Review']"));
						}
					});*/
			// Thread.sleep(5000);

			webUtils.clickButtonOrLink(dropdownNames, reason, logger, driver);

			ExcelUtilities.setCellData("UmIntake", Integer.valueOf(rowNum),
					9, referenceNo);

			webUtils.takeSnapShot(driver, "target/BSC-reports/"
					+ testCaseName.trim() + "ReferenceNumber.png");

			submit.click();
			
			try{
				
				webUtils.explicitWaitByVisibilityofElement(driver, 10, LOAOK);
				
				if(LOAOK.isDisplayed()){
					
					LOAOK.click();
					try{
						if(facilityLOARadioButton.get(0).isDisplayed()){
							
							facilityLOARadioButton.get(0).click();
						}
					}catch(Exception e){
						System.out.println("facilityLOARadioButton validation is skipped");
					}
					
					try{
					webUtils.scrollUP(driver,LOARadioButton.get(0));
					LOARadioButton.get(0).click();
					}catch(Exception e){
						System.out.println("LOARadioButton validation is skipped");
					}
					
					webUtils.explicitWaitByElementToBeClickable(driver, submit);
					
					submit.click();
				}
			}catch(Exception e){
				e.printStackTrace();
				
			}
			
			logger.log(LogStatus.INFO, "Prior Authorization request is assigned to Nurse Review successfully");
			
			webUtils.explicitWaitByElementToBeClickable(driver,10, savePreAuth);
			
			savePreAuth.click();
			
			
			

		
		}
		catch(Exception e) {
			e.printStackTrace();
		}
			 }
}
