package com.bsc.qa.web.pages;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindAll;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;

import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;

import WebUtils.ExcelUtilities;
import WebUtils.WebUtils;

/**
 * @author SaiKiran Ayyagari
 *
 */
public class AuthAccelPriorAuthPage  {

	public WebUtils webUtils = new WebUtils();
	public static String referenceNo;

	@FindAll({ @FindBy(how = How.XPATH, using = ".//td[contains(@class,'formTitle')]/b[contains(text(),'Request Type')]/following::div[contains(@class,'selectItemText')]") })
	public List<WebElement> dropDownList;

	@FindAll({ @FindBy(how = How.XPATH, using = "//div[contains(@id,'isc_PickListMenu_0_body$28s')]/following::table/tbody/tr") })
	public List<WebElement> dropdownNames;

	@FindAll({ @FindBy(how = How.XPATH, using = "//input[@name='manualReceivedDate_dateTextField']") })
	 public WebElement manualReceivedDate;

	@FindAll({ @FindBy(how = How.XPATH, using = "//input[@name='nextReviewDate_dateTextField']") })
	 public WebElement nextReviewDate;

	@FindAll({ @FindBy(how = How.XPATH, using = "//div[contains(@id,'isc_UmAuthShortIntake_22_0_body$28s')]/following::table[@class='listTable']/tbody/tr/td[1]") })
	 public List<WebElement> codeAreaList;
	
	@FindAll({ @FindBy(how = How.XPATH, using = "//div[contains(@id,'isc_L')]//following-sibling::table[@role='presentation' and @class='listTable']//tbody//tr[1]") })
	 public WebElement eligFirstRow;
	

	@FindAll({ @FindBy(how = How.XPATH, using = "//div[@eventproxy='isc_UmAuthShortIntake_71_0_body']/div/table/tbody/tr/td[2]") })
	 public WebElement codeAreaList1;

	@FindAll({ @FindBy(how = How.XPATH, using = "//div[@eventproxy='isc_UmAuthShortIntake_71_0_body']/div/table/tbody/tr/td[3]") })
	 public WebElement codeAreaList2;

	@FindAll({ @FindBy(how = How.XPATH, using = "//div[@eventproxy='isc_UmAuthShortIntake_71_0_body']/div/table/tbody/tr/td[4]") })
	 public WebElement codeAreaList3;

	@FindAll({ @FindBy(how = How.XPATH, using = "//div[@eventproxy='isc_UmAuthShortIntake_71_0_body']/div/table/tbody/tr/td[5]") })
	 public WebElement codeAreaList4;

	@FindAll({ @FindBy(how = How.XPATH, using = "//td[@class='formCell']/following::img[contains(@src,'search_picker')]") })
	 public List<WebElement> searchPicker;

	@FindAll({ @FindBy(how = How.NAME, using = "description") })
	 public WebElement description;
	
	
	@FindAll({ @FindBy(how = How.NAME, using = "code") })
	 public WebElement code;
	
	@FindAll({ @FindBy(how = How.XPATH, using = "//div[contains(@eventproxy,'isc_ListGrid')]//table[@class='listTable']//tr[1]") })
	public List<WebElement> serviceCodeList;

	/*@FindAll({ @FindBy(how = How.XPATH, using = "//input[@name='description']/following::div[contains(text(),'Search')]") })
	public WebElement search;*/

	@FindAll({ @FindBy(how = How.XPATH, using = "//input[@name='description']/following::div[contains(text(),'Cancel')]") })
	 public WebElement cancel;

	@FindAll({ @FindBy(how = How.XPATH, using = "//input[@name='description']/following::div[contains(text(),'Cancel')]/following::table[@class='listTable']/tbody/tr[1]") })
	 public WebElement codeSelect;

	@FindAll({ @FindBy(how = How.XPATH, using = "//input[@name='ipfrom_dateTextField']") })
	 public WebElement fromdate;

	@FindAll({ @FindBy(how = How.XPATH, using = "//input[@name='ipthru_dateTextField']") })
	 public WebElement thru;

	@FindAll({ @FindBy(how = How.XPATH, using = "//span[contains(@eventproxy,'isc_DynamicForm_')]/table/tbody") })
	 public WebElement dropdown;

	@FindAll({ @FindBy(how = How.XPATH, using = "//td[@class='pickListCell']") })
	public List<WebElement> bedTypeDropdownList;

	@FindAll({ @FindBy(how = How.XPATH, using = "//div[contains(@class,'pickListMenuBody')]/div/table/tbody/tr") })
	public List<WebElement> commondropdownList;

	@FindAll({ @FindBy(how = How.XPATH, using = "//input[@name='admissionDate_dateTextField']") })
	 public WebElement admissionDate;

	@FindAll({ @FindBy(how = How.XPATH, using = "//input[@name='dischargeDate_dateTextField']") })
	 public WebElement dischargeDate;

	@FindAll({ @FindBy(how = How.XPATH, using = "//input[@name='provid']") })
	 public WebElement providerId;
	@FindAll({ @FindBy(how = How.XPATH, using = "//div[contains(@id,'isc_Paging')]//following-sibling::table[@role='presentation' and @class='listTable']//tbody//tr[@role='listitem'][1]//td[3]") })
	 public WebElement firstRowPostSubmit;
	

	@FindAll({ @FindBy(how = How.XPATH, using = "//td[@class='button']") })
	public List<WebElement> buttonList;

	@FindAll({ @FindBy(how = How.XPATH, using = "//div[contains(@eventproxy,'isc_ListGrid_')]/div/table/tbody/tr[1]") })
	 public WebElement providerSearch;

	@FindAll({ @FindBy(how = How.XPATH, using = "//input[@name='serviceProviderSame_id']") })
	 public List<WebElement> radioButtonList;

	@FindAll({ @FindBy(how = How.XPATH, using = "//td[@class='button']/div/div[contains(text(),'Submit')]") })
	 public WebElement submitButton;

	@FindAll({ @FindBy(how = How.XPATH, using = "//div[text()='Facility']") })
	 public WebElement facility;
	
	@FindAll({ @FindBy(how = How.XPATH, using = "//input[@name='facilityAddress1']") })
	 public WebElement facilityAddress1;
	
	
	@FindAll({ @FindBy(how = How.XPATH, using = "//input[@name='facilityCity']") })
	 public WebElement facilityCity;
	@FindAll({ @FindBy(how = How.XPATH, using = "//input[@name='facilityState']") })
	 public WebElement facilityState;
	@FindAll({ @FindBy(how = How.XPATH, using = "//input[@name='facilityZip']") })
	 public WebElement facilityZip;
	

	@FindAll({ @FindBy(how = How.XPATH, using = "//div[contains(@eventproxy,'isc_DynamicForm_')]/form/table/tbody/tr[2]/td/nobr[contains(text(),'Reference #')]/following::td/div") })
	 public WebElement referenceNumber;

	@FindAll({ @FindBy(how = How.XPATH, using = "//div[contains(text(),'CSC Follow Up')]") })
	 public WebElement statusReasonDropdown;
	
	@FindAll({ @FindBy(how = How.XPATH, using = "//div[contains(text(),'Nurse Review')]") })
	 public WebElement statusReasonNurseReview;

	@FindAll({ @FindBy(how = How.XPATH, using = "//td[@class='button']/div/div[text()='Submit']") })
	 public WebElement submit;
	
	@FindAll({ @FindBy(how = How.XPATH, using = "//input[@name='servicingLoa_id']") })
	public List<WebElement> LOARadioButton;
	@FindAll({ @FindBy(how = How.XPATH, using = "//td[@class='button']/div/div[text()='Save']") })
	public List<WebElement> save;
	@FindAll({ @FindBy(how = How.XPATH, using = "//img[contains(@src,'search')]") })
	public List<WebElement> searchIcon;
	@FindAll({ @FindBy(how = How.XPATH, using = "//input[@name='provid']") })
	public List<WebElement> provID;
	
	@FindAll({ @FindBy(how = How.XPATH, using = "//div[text()='Extended Search']") })
	public List<WebElement> extSearch;
	@FindAll({ @FindBy(how = How.XPATH, using = "//div[contains(@id,'isc_List')]//following-sibling::table[@role='presentation' and @class='listTable']//tbody//tr[1]") })
	public List<WebElement> provFirstRow;
	
	
	
	
	
	@FindAll({ @FindBy(how = How.XPATH, using = "//input[@name='facilityLoa_id']") })
	public List<WebElement> facilityLOARadioButton;
	
	@FindAll({ @FindBy(how = How.XPATH, using = "//div[text()='OK']") })
	 public WebElement LOAOK;
	
	
	
	
	@FindAll({ @FindBy(how = How.XPATH, using = "//input[@name='facilityLoa_id']/parent::td/following-sibling::td/label[text()='Yes']") })
	 public WebElement Yes;
	

	@FindAll({ @FindBy(how = How.XPATH, using = "//input[@name='requestingFax']") })
	 public WebElement fax;

	// input[@name='servicingFax']

	@FindAll({ @FindBy(how = How.XPATH, using = "//input[@name='servicingFax']") })
	 public WebElement servicingFax;

	@FindAll({ @FindBy(how = How.XPATH, using = "//input[@name='facilityFax']") })
	 public WebElement facilityFax;

	@FindAll({ @FindBy(how = How.XPATH, using = "// div[contains(@eventproxy,'isc_globalWarn_closeButton')]/img[contains(@src,'close')]") })
	 public WebElement close;

	@FindAll({ @FindBy(how = How.XPATH, using = ".//td[contains(@class,'formTitle')]/b[contains(text(),'Source')]/following::td[1]") })
	 public WebElement source;

	@FindAll({ @FindBy(how = How.XPATH, using = ".//td[contains(@class,'formTitle')]/b[contains(text(),'Place of Service')]/following::td[1]") })
	 public WebElement placeOfService;
	
	@FindAll({ @FindBy(how = How.XPATH, using = "//td[contains(text(),'Place of')]//parent::td//parent::td//following-sibling::td[1]//td[1]") })
	 public WebElement placeOfService1;
	

	@FindAll({ @FindBy(how = How.XPATH, using = ".//td[contains(text(),'Place of Service')]/following::td[1]") })
	 public WebElement medicationPOS;

	@FindAll({ @FindBy(how = How.XPATH, using = ".//td[contains(@class,'formTitle')]/b[contains(text(),'Request Type')]/following::td[1]") })
	 public WebElement requestTypeDropdown;

	@FindAll({ @FindBy(how = How.XPATH, using = ".//tr[2]/td[contains(text(),'Requester')]/following-sibling::td") })
	public WebElement requesterTypeDropdown;

	@FindAll({ @FindBy(how = How.XPATH, using = ".//td[contains(text(),'Review Type')]/following::td[1]") })
	public WebElement reviewTypeDropdown;

	@FindAll({ @FindBy(how = How.XPATH, using = ".//td[contains(text(),'Priority')]/following::td[1]") })
	public WebElement PriorityDropdown;

	@FindAll({ @FindBy(how = How.XPATH, using = ".//td/b[contains(text(),'Admission BedType')]/following::td[1]") })
	public WebElement admissionBedTypeDropdown;

	@FindAll({ @FindBy(how = How.XPATH, using = ".//td[contains(text(),'Service Category')]/following::td[1]") })
	public WebElement serviceCategoryDropdown;

	@FindAll({ @FindBy(how = How.XPATH, using = ".//td[contains(text(),'Sub Category')]/following::td[1]") })
	public WebElement subCategoryDropdown;

	@FindAll({ @FindBy(how = How.XPATH, using = ".//td/b[contains(text(),'Inquiry Outcome')]/following::td[1]") })
	public WebElement inquiryOutcomeDropdown;

	@FindAll({ @FindBy(how = How.XPATH, using = ".//td[contains(text(),'Outcome Reason')]/following::td[1]") })
	public WebElement outcomeReasonDropdown;

	@FindAll({ @FindBy(how = How.XPATH, using = ".//td[contains(text(),'Admit From')]/following::td[1]") })
	public WebElement admitFromDropdown;

	@FindAll({ @FindBy(how = How.XPATH, using = ".//td/b[contains(text(),'Admit Type')]/following::td[1]") })
	public WebElement admitTypeDropdown;

	@FindAll({ @FindBy(how = How.XPATH, using = "//tr/td[text()='Enter valid Data']") })
	public WebElement validDataPopUp;

	@FindAll({ @FindBy(how = How.XPATH, using = "//img[contains(@src,'hsplit_snap')]") })
	public WebElement hsplit;

	@FindAll({ @FindBy(how = How.XPATH, using = "//tr/td[text()='The requested facility is out of service area']") })
	public WebElement outOfService;
	
	@FindAll({ @FindBy(how = How.XPATH, using = "//td[text()='Alerts']/ancestor::div/div[1]/div[2]/following::div/img[contains(@src,'close')]") })
	public WebElement closePopup;
	
	@FindAll({ @FindBy(how = How.XPATH, using = "//input[@name='requestingProviderFirstName']") })
	public WebElement requestingProviderFName;
	@FindAll({ @FindBy(how = How.XPATH, using = "//input[@name='requestingProvId']") })
	public WebElement requestingProviderID;
	
	
	@FindAll({ @FindBy(how = How.XPATH, using = "//input[@name='requestingProviderLastName']") })
	public WebElement requestingProviderLName;
	
	@FindAll({ @FindBy(how = How.XPATH, using = "//input[@name='requestingProviderAddress1']") })
	public WebElement requestingProviderAddress1;
	
	@FindAll({ @FindBy(how = How.XPATH, using = "//input[@name='requestingProviderCity']") })
	public WebElement requestingProviderCity;
	@FindAll({ @FindBy(how = How.XPATH, using = "//input[@name='requestingProviderState']") })
	public WebElement requestingProviderState;
	@FindAll({ @FindBy(how = How.XPATH, using = "//input[@name='requestingProviderZip']") })
	public WebElement requestingProviderZip;
	
	@FindAll({ @FindBy(how = How.XPATH, using = "//input[@name='requestingProviderPhone']") })
	public WebElement requestingProviderPhone;
	@FindAll({ @FindBy(how = How.XPATH, using = "//input[@name='requestingProviderFax']") })
	public WebElement requestingProviderFax;

	@FindAll({ @FindBy(how = How.XPATH, using = "//div[text()='Unknown']//span") })
	public WebElement requestingUnknownCheckbox;
	
	@FindAll({ @FindBy(how = How.XPATH, using = "//span//parent::div[text()='Unknown']") })
	public List<WebElement> facilityUnknownCheckbox;
	
	@FindAll({ @FindBy(how = How.XPATH, using = "//input[@name='requestingNPI']") })
	public WebElement requestingProviderNPI;
	
	@FindAll({ @FindBy(how = How.XPATH, using = "//td[contains(text(),'Status')]//parent::td//parent::td//following-sibling::td//table//td") })
	public WebElement requestingProviderStatus;
	
	@FindAll({ @FindBy(how = How.XPATH, using = "	//b[contains(text(),'Status')]//parent::nobr//parent::td//following-sibling::td//table//td") })
	public List<WebElement> statusList;
	
	@FindAll({ @FindBy(how = How.XPATH, using = "//input[@name='requestingSame_id']") })
	public List<WebElement> requestingSameID;
	
	

	
	
	

	public void eventIntake(String requestTypeName, String placeOfServiceName,
			String sourceName, String receivedDate, WebDriver driver,
			ExtentTest logger) {
		try {

			
			
			
			try{
				webUtils.explicitWaitByElementToBeClickable(driver,20, closePopup);
				if(closePopup.isDisplayed()){
					
					closePopup.click();
				}
			}catch(Exception e){
				
				System.out.println("closePopup validation is skipped");
			}
			
			try{
				
				webUtils.explicitWaitByVisibilityOfAllElements(driver, 10, serviceCodeList);
				
				serviceCodeList.get(1).click();
				
				webUtils.doubleClick(driver, serviceCodeList.get(1));
			}catch(Exception e){
				System.out.println("serviceCodeList validation is skipped");
			}
			
			Thread.sleep(3000); // Added wait time for flow synchronization
			
			//webUtils.explicitWaitByElementToBeClickable(driver,15, hsplit);
			
			hsplit.click();
			
			webUtils.scrollUP(driver, requestTypeDropdown);

			logger.log(LogStatus.INFO, "Provide the details for Event Intake");
			webUtils.explicitWaitByElementToBeClickable(driver,10, requestTypeDropdown);

			logger.log(LogStatus.INFO, "Select the request type name!!");
			requestTypeDropdown.click();

			webUtils.clickButtonOrLink(dropdownNames, requestTypeName, logger,
					driver);
			logger.log(LogStatus.INFO, "Select the place of service");
			if ("Medication".equalsIgnoreCase(requestTypeName)
					|| "Service Post Review".equalsIgnoreCase(requestTypeName)
					|| "Inpatient Post Review".equalsIgnoreCase(requestTypeName)) {
				webUtils.explicitWaitByElementToBeClickable(driver,10, medicationPOS);

				medicationPOS.click();
			} else if ("Inpatient".equalsIgnoreCase(requestTypeName)
					|| 
				"Service Request (Prior Auth)".equalsIgnoreCase(requestTypeName)) {
				webUtils.explicitWaitByElementToBeClickable(driver,10, placeOfService);

				placeOfService.click();

			}

			Thread.sleep(3000); // Added wait time for flow synchronization// Added wait time for flow synchronization
			webUtils.clickButtonOrLink(dropdownNames, placeOfServiceName, logger,
					driver);

			logger.log(LogStatus.INFO, "Select the source!!");
			source.click();

			webUtils.clickButtonOrLink(dropdownNames, sourceName, logger, driver);

			logger.log(LogStatus.INFO,
					"Enter the manual received date and next reaview date!!");
			//manualReceivedDate.sendKeys(receivedDate);

			// nextReviewDate.sendKeys(reviewDate);

		
		}
		catch(Exception e) {
			e.printStackTrace();
		}
	}
	
	public void valueAuth(String reason,String requestTypeName, String placeOfServiceName,
			String sourceName, String receivedDate, WebDriver driver,
			ExtentTest logger)  {
		try {

			
			
			try{
				if (eligFirstRow.isDisplayed())
				{
					eligFirstRow.click();
					webUtils.doubleClick(driver, eligFirstRow);
					Thread.sleep(3000); // Added wait time for flow synchronization
				}
			}
			catch(Exception e){
				System.out.println("eligFirstRow validation is skipped");
			}
				
				logger.log(LogStatus.INFO, "Provide the details for Event Intake");
				

				webUtils.explicitWaitByElementToBeClickable(driver,10, requestTypeDropdown);

				logger.log(LogStatus.INFO, "Select the request type name!!");
				requestTypeDropdown.click();

				webUtils.clickButtonOrLink(dropdownNames, requestTypeName, logger,
						driver);
				
				System.out.println("Select Status Reason");
				webUtils.moveToClickableElement(statusReasonDropdown, driver);
				
				//statusReasonDropdown.click();
				
				webUtils.fluentWait(driver, "//div[contains(@id,'isc_PickListMenu_0_body$28s')]/following::table/tbody/tr[1]/td/div/nobr[text()='Nurse Review']");

				webUtils.clickButtonOrLink(dropdownNames, reason, logger, driver);
				Thread.sleep(3000); // Added wait time for flow synchronization
				System.out.println("Status Reason has been Selected");	
				logger.log(LogStatus.INFO, "Select the place of service");
				
				Thread.sleep(3000); // Added wait time for flow synchronization
				
				
				if ("Inpatient".equalsIgnoreCase(requestTypeName)
						|| "Service Request (Prior Auth)"
								.equalsIgnoreCase(requestTypeName)) {
					webUtils.explicitWaitByElementToBeClickable(driver,10, placeOfService);

					placeOfService.click();

				}
				if ("Medication".equalsIgnoreCase(requestTypeName)) {
					webUtils.explicitWaitByElementToBeClickable(driver,10, placeOfService1);

					placeOfService1.click();

				}

				Thread.sleep(3000); // Added wait time for flow synchronization
				webUtils.clickButtonOrLink(dropdownNames, placeOfServiceName, logger,
						driver);
				Thread.sleep(2000); // Added wait time for flow synchronization
				logger.log(LogStatus.INFO, "Select the source!!");
				source.click();

				webUtils.clickButtonOrLink(dropdownNames, sourceName, logger, driver);
				
				
			
			
		}
		catch(Exception e) {
			e.printStackTrace();
		}
	}

	public void addDiagnosisCodes(WebDriver driver, String diagCode,
			ExtentTest logger) {

		logger.log(LogStatus.INFO, "Add diagnosis codes!!");

		webUtils.explicitWaitByPresenceofAllElements(
				driver,30,
				"//div[contains(@id,'isc_UmAuthShortIntake_22_0_body$28s')]/following::table[@class='listTable']/tbody/tr/td[1]");

		codeAreaList.get(0).click();

		/*webUtils.explicitWaitByVisibilityofElement(driver, searchPicker.get(2));

		searchPicker.get(2).click();*/

		code.sendKeys(diagCode);
		code.sendKeys(Keys.TAB);

	/*	search.click();

		webUtils.explicitWaitByElementToBeClickable(driver, codeSelect);

		codeSelect.click();

		webUtils.doubleClick(driver, codeSelect);*/

	}

	public void addServiceCodes(String serviceCode, WebDriver driver,
			ExtentTest logger) {

		logger.log(LogStatus.INFO, "Add service codes!!");
		
		if(serviceCode.contains(",")){
			
			String[] serviceCodes = serviceCode.split(",");

			webUtils.moveToClickableElement(codeAreaList.get(2), driver);
			
			code.sendKeys(serviceCodes[0]);
			
			code.sendKeys(Keys.ENTER);
			try{
				webUtils.explicitWaitByVisibilityOfAllElements(driver, 15, serviceCodeList);
				
				serviceCodeList.get(0).click();
				
				webUtils.doubleClick(driver, serviceCodeList.get(0));
			}catch(Exception e){
				
				System.out.println("serviceCodeList validation is skipped");
			}
			

			webUtils.moveToClickableElement(codeAreaList.get(3), driver);
			
			code.sendKeys(serviceCodes[1]);
			
			code.sendKeys(Keys.ENTER);
			try{
				webUtils.explicitWaitByVisibilityOfAllElements(driver, 15, serviceCodeList);
				
				serviceCodeList.get(0).click();
				
				webUtils.doubleClick(driver, serviceCodeList.get(0));
			}catch(Exception e){
				
				System.out.println("serviceCodeList validation is skipped");
			}
			
		
			
		}else{
			
			

		webUtils.moveToClickableElement(codeAreaList.get(2), driver);

		/*boolean isPresent = false;

		try {
			webUtils.explicitWaitByVisibilityofElement(driver, validDataPopUp);
			isPresent = validDataPopUp.isDisplayed();

		} catch (Exception E) {

		}

		if (isPresent) {

			close.click();

			webUtils.moveToClickableElement(codeAreaList.get(2), driver);
		} else {

			System.out.println("Popup is not displayed!!");
		}

		webUtils.explicitWaitByElementToBeClickable(driver, searchPicker.get(2));

		searchPicker.get(2).click();
		
		webUtils.explicitWaitByElementToBeClickable(driver, code);*/

		code.sendKeys(serviceCode);
		
		code.sendKeys(Keys.TAB);
		try{
			webUtils.explicitWaitByVisibilityOfAllElements(driver, 15, serviceCodeList);
			
			serviceCodeList.get(0).click();
			
			webUtils.doubleClick(driver, serviceCodeList.get(0));
		}catch(Exception e){
			System.out.println("serviceCodeList validation is skipped");
			
		}
		
		}
		
		
		/*search.click();

		webUtils.explicitWaitByElementToBeClickable(driver, codeSelect);

		codeSelect.click();

		webUtils.doubleClick(driver, codeSelect);*/

	}
	
	public void unknownFacilityID(WebDriver driver, ExtentTest logger)
			 {
		
		logger.log(LogStatus.INFO, "Select the facility provider!!");
		webUtils.moveToClickableElement(facility, driver);

		webUtils.explicitWaitByPresenceofAllElements(driver,20,
				"//td[@class='formCell']/following::img[contains(@src,'search_picker')]");
		
		webUtils.moveToClickableElement(facilityUnknownCheckbox.get(2), driver);
		System.out.println("Facility Checkbox has been Clicked");

		
	}
	
	public void unknownFacilityIDVerification(String providerID,String rowNum,String zip,String state,String city,String address1,WebDriver driver, ExtentTest logger)
			 {
		try {

			try{
				if(LOAOK.isDisplayed()){
					logger.log(LogStatus.INFO, "Provider's Address1,City,State,Zip details are mandatory.");
					LOAOK.click();
					System.out.println("First Verification Completed");
					
				}
				
			}
			
			
			catch(Exception e){
				System.out.println("LOAOK validation is skipped");
			}
			webUtils.moveToClickableElement(facilityAddress1, driver);
			facilityAddress1.sendKeys(address1);
			System.out.println("Address1 :"+address1);
			logger.log(LogStatus.INFO, " Value for Address1:"+ address1);
			
			webUtils.moveToClickableElement(facilityCity, driver);
			facilityCity.sendKeys(city);
			System.out.println("City :"+city);
			logger.log(LogStatus.INFO, " Value for City:"+ city);
			
			webUtils.moveToClickableElement(facilityState, driver);
			facilityState.sendKeys(state);
			System.out.println("State :"+state);
			logger.log(LogStatus.INFO, " Value for State:"+ state);
			
			webUtils.moveToClickableElement(facilityZip, driver);
			facilityZip.sendKeys(zip);
			System.out.println("Zip :"+zip);
			logger.log(LogStatus.INFO, " Value for Zip:"+ zip);
			
			webUtils.moveToClickableElement(submitButton, driver);
			System.out.println("Submit has been Clicked");
			
			
			webUtils.fluentWait(driver, "//div[contains(@eventproxy,'isc_DynamicForm_')]/form/table/tbody/tr[2]/td/nobr[contains(text(),'Reference #')]/following::td/div");		
			 referenceNo = referenceNumber.getText();

			logger.log(LogStatus.INFO, "The reference number is " + referenceNo);

			System.out.println("The reference no is " + referenceNo);
			
			ExcelUtilities.setCellData("UmIntake", Integer.valueOf(rowNum),
					9, referenceNo);
			submit.click();
			System.out.println("Submit has been Clicked !!!!!");
			///////////////////////////////////////////////////////////////////////////////////
			
			
			try{
				
				webUtils.explicitWaitByVisibilityofElement(driver, 10, LOAOK);
				
				if(LOAOK.isDisplayed()){
					logger.log(LogStatus.INFO, "Provider's First Name,Phone,Fax,Status are mandatory Fields.");
					
					LOAOK.click();
					
					
					try{
						if(facilityLOARadioButton.get(0).isDisplayed()){
							
							facilityLOARadioButton.get(0).click();
						}
					}catch(Exception e){
						System.out.println("facilityLOARadioButton validation is skipped");
					}
					
					try{
					/*webUtils.scrollUP(driver,LOARadioButton.get(0));
					LOARadioButton.get(0).click();*/
					Thread.sleep(3000); // Added wait time for flow synchronization
					webUtils.moveToClickableElement(searchIcon.get(2), driver);
					
					//webUtils.elementClickWithLogger(searchIcon.get(0), "Search", logger, driver);
					webUtils.waitUntilElementclickable(provID.get(0), driver);
					provID.get(0).sendKeys(providerID);
					Thread.sleep(3000); // Added wait time for flow synchronization
					webUtils.moveToClickableElement(extSearch.get(2), driver);
					//webUtils.waitUntilElementclickable(extSearch.get(1), driver);
					//webUtils.elementClickWithLogger(extSearch.get(1), "Extended Search", logger, driver);
					try{
						extSearch.get(1).click();
					}
					catch(Exception e){
						System.out.println("extSearch validation is skipped");
					}
					
					
					Thread.sleep(4000); // Added wait time for flow synchronization
					//webUtils.elementClickWithLogger(provFirstRow.get(1), "Provider", logger, driver);
					webUtils.moveToClickableElement(provFirstRow.get(1), driver);
					try{
						provFirstRow.get(1).click();
					webUtils.doubleClick(driver, provFirstRow.get(1));
					}
					catch(Exception e){
						System.out.println("provFirstRow validation is skipped");
					}
					
					
					webUtils.elementClickWithLogger(save.get(0), "Save", logger, driver);
					System.out.println("Save is clicked");
					webUtils.explicitWaitByElementToBeClickable(driver, submit);
					submit.click();
					System.out.println("Submit Clicked After Mandatory Fields");
					Thread.sleep(3000); // Added wait time for flow synchronization
					}catch(Exception e){
						e.printStackTrace();
					}
					
					
					
				}
			}catch(Exception e){
				e.printStackTrace();
			}
			
			
			
			
		
		}
		catch(Exception e) {
			e.printStackTrace();
		}
			 }
	
	
		
	
	
	

	public void inPatientDays(String fromDate, String toDate, String bedType,
			String revCode, String drgCode, WebDriver driver, ExtentTest logger)
			 {
		try {


			// webUtils.explicitWaitByVisibilityofElement(driver,
			// codeAreaList.get(4));

			// webUtils.scrollDown(driver, codeAreaList.get(4));

			webUtils.moveToClickableElement(codeAreaList.get(4), driver);

			webUtils.explicitWaitByVisibilityofElement(driver,10, fromdate);

			fromdate.sendKeys(fromDate);

			Thread.sleep(5000); // Added wait time for flow synchronization

			webUtils.moveToClickableElement(codeAreaList1, driver);

			// webUtils.explicitWaitByVisibilityofElement(driver, thru);

			thru.sendKeys(toDate);
			Thread.sleep(5000); // Added wait time for flow synchronization

			webUtils.moveToClickableElement(codeAreaList2, driver);

			webUtils.explicitWaitByVisibilityofElement(driver,10, dropdown);

			dropdown.click();

			webUtils.explicitWaitByPresenceofAllElements(driver,30,
					"//div[contains(@class,'pickListMenuBody')]/div/table/tbody/tr");

			webUtils.clickButtonOrLink(commondropdownList, bedType, logger, driver);

			Thread.sleep(5000); // Added wait time for flow synchronization

			webUtils.moveToClickableElement(codeAreaList3, driver);

			webUtils.explicitWaitByVisibilityofElement(driver,10, dropdown);

			dropdown.click();

			webUtils.explicitWaitByPresenceofAllElements(driver,30,
					"//div[contains(@class,'pickListMenuBody')]/div/table/tbody/tr");

			webUtils.clickButtonOrLink(commondropdownList, revCode, logger, driver);

			Thread.sleep(5000); // Added wait time for flow synchronization

			webUtils.moveToClickableElement(codeAreaList4, driver);

			webUtils.explicitWaitByVisibilityofElement(driver,10, dropdown);

			dropdown.click();

			webUtils.explicitWaitByPresenceofAllElements(driver,10,
					"//div[contains(@class,'pickListMenuBody')]/div/table/tbody/tr");

			webUtils.clickButtonOrLink(commondropdownList, drgCode, logger, driver);

		
		}
		catch(Exception e) {
			e.printStackTrace();
		}
			 }

	public void inPatient(String admissiondate, String requestTypeName,
			String admitType, String admitFrom, WebDriver driver,
			ExtentTest logger) {
		try {


			logger.log(LogStatus.INFO, "Provide admission date!!");

			webUtils.moveToClickableElement(admissionDate, driver);

			admissionDate.sendKeys(admissiondate);

			logger.log(LogStatus.INFO, "Select the admit Type!!");

			Thread.sleep(5000); // Added wait time for flow synchronization

			webUtils.moveToClickableElement(admitTypeDropdown, driver);

			webUtils.clickButtonOrLink(commondropdownList, admitType, logger,
					driver);
			/*
			 * Robot robot = new Robot();
			 * 
			 * robot.keyPress(KeyEvent.VK_TAB);
			 * 
			 * robot.keyRelease(KeyEvent.VK_TAB);
			 * 
			 * robot.keyPress(KeyEvent.VK_TAB);
			 * 
			 * robot.keyRelease(KeyEvent.VK_TAB);
			 * 
			 * robot.keyPress(KeyEvent.VK_DOWN); robot.keyRelease(KeyEvent.VK_DOWN);
			 * 
			 * robot.keyPress(KeyEvent.VK_DOWN);
			 * 
			 * robot.keyRelease(KeyEvent.VK_DOWN);
			 */

			logger.log(LogStatus.INFO, "Select the admit from!!");

			webUtils.moveToClickableElement(admitFromDropdown, driver);

			webUtils.clickButtonOrLink(commondropdownList, admitFrom, logger,
					driver);

			/*
			 * logger.log(LogStatus.INFO, "Provide the discharge date");
			 * 
			 * webUtils.moveToClickableElement(dischargeDate, driver);
			 * 
			 * // dischargeDate.sendKeys(dischargedate);
			 */
		
		}
		catch(Exception e) {
			e.printStackTrace();
		}
	}
	
	public void addValuesForAuth(String rowNum,String inquiryOutcome,String servicingProviderSame,String providerCode,String reviewType,	
			String priority,String serviceCategory, WebDriver driver,
			 ExtentTest logger)
			{
		try {

			
			logger.log(LogStatus.INFO, "Select the provider!!!");

			webUtils.moveToClickableElement(searchPicker.get(0), driver);

			providerId.sendKeys(providerCode);

			webUtils.clickButtonOrLink(buttonList, "Extended Search", logger,
					driver);
			
			webUtils.explicitWaitByPresenceofElement(driver,20, "//tr[1][@role='listitem']/td/div/nobr[text()="+"'"+providerCode+"']/parent::div");
			
			 WebElement search = driver.findElement(By.xpath("//tr[1][@role='listitem']/td/div/nobr[text()="+"'"+providerCode+"']/parent::div"));
			
			search.click();

			webUtils.doubleClick(driver, search);
			System.out.println("Provider has been selected as :"+providerCode);
			
			System.out.println("Select Wether Servicing privider is same or not");
			if ("Yes".equalsIgnoreCase(servicingProviderSame)) {
			
			webUtils.moveToClickableElement(radioButtonList.get(0), driver);
			Thread.sleep(5000); // Added wait time for flow synchronization
			System.out.println("Servicing Provider is selected as :"+servicingProviderSame);
			}
			logger.log(LogStatus.INFO, "Select the review type!!");

			webUtils.moveToClickableElement(reviewTypeDropdown, driver);

			webUtils.clickButtonOrLink(commondropdownList, reviewType, logger,
					driver);

			logger.log(LogStatus.INFO, "Select the priority!!");

			webUtils.moveToClickableElement(PriorityDropdown, driver);

			webUtils.clickButtonOrLink(commondropdownList, priority, logger,
					driver);

			logger.log(LogStatus.INFO, "Select the serviceCategory!!");

			webUtils.moveToClickableElement(serviceCategoryDropdown, driver);

			webUtils.clickButtonOrLink(commondropdownList, serviceCategory,
					logger, driver);
			
			webUtils.moveToClickableElement(inquiryOutcomeDropdown, driver);

			logger.log(LogStatus.INFO, "Select the inquiry outcome!!");

			webUtils.clickButtonOrLink(commondropdownList, inquiryOutcome,
					logger, driver);
			webUtils.scrollDown(driver, submitButton);
			submitButton.click();
			System.out.println("Submit button has been clicked");
			Thread.sleep(5000); // Added wait time for flow synchronization
			
			webUtils.fluentWait(driver, "//div[contains(@eventproxy,'isc_DynamicForm_')]/form/table/tbody/tr[2]/td/nobr[contains(text(),'Reference #')]/following::td/div");		
			 referenceNo = referenceNumber.getText();

			logger.log(LogStatus.INFO, "The reference number is " + referenceNo);

			System.out.println("The reference no is " + referenceNo);
			
			ExcelUtilities.setCellData("UmIntake", Integer.valueOf(rowNum),
					9, referenceNo);
			submit.click();
			
			try{
				
				webUtils.explicitWaitByVisibilityofElement(driver, 10, LOAOK);
				
				if(LOAOK.isDisplayed()){
					
					LOAOK.click();
					
					
					try{
						if(facilityLOARadioButton.get(0).isDisplayed()){
							
							facilityLOARadioButton.get(0).click();
						}
					}catch(Exception e){
						System.out.println("facilityLOARadioButton validation is skipped");
					}
					
					try{
					webUtils.scrollUP(driver,LOARadioButton.get(0));
					LOARadioButton.get(0).click();
					System.out.println("LOA Radio Button has been Checked.");
					}catch(Exception e){
						System.out.println("LOARadioButton validation is skipped");
					}
					
					Thread.sleep(5000); // Added wait time for flow synchronization
					
					submit.click();
					System.out.println("Auth has been Submitted");
					
				}
			}catch(Exception e){
				e.printStackTrace();
			}
			
			Thread.sleep(5000); // Added wait time for flow synchronization
			String ref = firstRowPostSubmit.getText();
			System.out.println("Value for Ref for Validation is :"+ref);
			if(referenceNo.equalsIgnoreCase(ref)){
				logger.log(LogStatus.INFO, "Authorization has been Created Successfully");
				
				ExcelUtilities.setCellData("UmIntake", Integer.valueOf(rowNum),
						10, "Pass");
				
			}
			else{
				logger.log(LogStatus.INFO, "Authorization has not been Created ");
				
				ExcelUtilities.setCellData("UmIntake", Integer.valueOf(rowNum),
						10, "Fail");
				
			}
		
		}
		catch(Exception e) {
			e.printStackTrace();
		}
			}
	
	public void nurseAssign(String rowNum,ExtentTest logger,WebDriver driver){
		try {


			
			webUtils.fluentWait(driver, "//div[contains(@eventproxy,'isc_DynamicForm_')]/form/table/tbody/tr[2]/td/nobr[contains(text(),'Reference #')]/following::td/div");		
			 referenceNo = referenceNumber.getText();

			logger.log(LogStatus.INFO, "The reference number is " + referenceNo);

			System.out.println("The reference no is " + referenceNo);
			
			ExcelUtilities.setCellData("UmIntake", Integer.valueOf(rowNum),
					9, referenceNo);
			
			ExcelUtilities.setCellData("UmIntake", Integer.valueOf(rowNum),
					10, "Pass");
			submit.click();
			
			try{
				
				webUtils.explicitWaitByVisibilityofElement(driver, 10, LOAOK);
				
				if(LOAOK.isDisplayed()){
					
					LOAOK.click();
					
					
					try{
						if(facilityLOARadioButton.get(0).isDisplayed()){
							
							facilityLOARadioButton.get(0).click();
						}
					}catch(Exception e){
						System.out.println("facilityLOARadioButton validation is skipped");
					}
					
					try{
					webUtils.scrollUP(driver,LOARadioButton.get(0));
					LOARadioButton.get(0).click();
					System.out.println("LOA Radio Button has been Checked.");
					}catch(Exception e){
						System.out.println("LOARadioButton validation is skipped");
					}
					
					Thread.sleep(5000); // Added wait time for flow synchronization
					
					submit.click();
					System.out.println("Auth has been Submitted");
					
				}
			}catch(Exception e){
				e.printStackTrace();
			}
			
		
		}
		catch(Exception e) {
			e.printStackTrace();
		}
	}

	public void requestingProvider(String organisation,String providerCode, WebDriver driver,
			String requester, String serviceType, ExtentTest logger)
			 {try{

					
					Thread.sleep(5000); // Added wait time for flow synchronization
					
					

					logger.log(LogStatus.INFO, "Select the requester!!!");

					webUtils.moveToClickableElement(requesterTypeDropdown, driver);

					webUtils.clickButtonOrLink(commondropdownList, requester, logger,
							driver);

					/*
					 * if (serviceType.equalsIgnoreCase("Inpatient") ||
					 * serviceType.equalsIgnoreCase("Inpatient Post Review")) {
					 * 
					 * webUtils.moveToClickableElement(dropDownList.get(12), driver);
					 * 
					 * webUtils.clickButtonOrLink(commondropdownList, requester, logger,
					 * driver); }
					 * 
					 * else if (serviceType.equalsIgnoreCase("Medication") ||
					 * serviceType.equalsIgnoreCase("Service Post Review") ||
					 * serviceType.equalsIgnoreCase("Service Request (Prior Auth)")) {
					 * webUtils.moveToClickableElement(dropDownList.get(11), driver);
					 * 
					 * webUtils.clickButtonOrLink(commondropdownList, requester, logger,
					 * driver); }
					 */

					webUtils.explicitWaitByPresenceofAllElements(driver,20,
							"//td[@class='formCell']/following::img[contains(@src,'search_picker')]");

					logger.log(LogStatus.INFO, "Select the provider!!!");

					webUtils.moveToClickableElement(searchPicker.get(0), driver);

					providerId.sendKeys(providerCode);

					webUtils.clickButtonOrLink(buttonList, "Extended Search", logger,
							driver);
					
					webUtils.explicitWaitByPresenceofElement(driver,20, "//tr[1][@role='listitem']/td/div/nobr[text()="+"'"+providerCode+"']/parent::div");
					
					WebElement search = driver.findElement(By.xpath("//tr[1][@role='listitem']/td/div/nobr[text()="+"'"+providerCode+"']/parent::div"));
					
					search.click();

					webUtils.doubleClick(driver, search);

					/*Thread.sleep(5000); // Added wait time for flow synchronization

					providerSearch.click();

					webUtils.doubleClick(driver, providerSearch);*/

					webUtils.explicitWaitByElementToBeClickable(driver,20, fax);

					// webUtils.explicitWait(driver, fax);

					webUtils.moveToClickableElement(fax, driver);
					
					fax.clear();

					fax.sendKeys("1000000000");

				}
			 catch(Exception e) {
				 e.printStackTrace();
			 }
			 }

	public void servicingProviderSame(String servicingProviderSame,String providerCode,
			WebDriver driver, ExtentTest logger) {
		try
		{


			logger.log(LogStatus.INFO,
					"Select the answer for servicing provider same!!");
			if ("No".equalsIgnoreCase(servicingProviderSame)) {

				servicingProvider(driver, "adventis", "Extended Search",providerCode, logger);
			} else {

				webUtils.moveToClickableElement(radioButtonList.get(0), driver);

				Thread.sleep(5000); // Added wait time for flow synchronization
			}

		
		}
		catch(Exception e) {
			e.printStackTrace();
		}
	}

	public void servicingProvider(WebDriver driver, String organisation,
			String searchType,String providerCode, ExtentTest logger) {
		try{


			logger.log(LogStatus.INFO, "Select the servicing provider!!");

			webUtils.moveToClickableElement(radioButtonList.get(1), driver);

			webUtils.explicitWaitByPresenceofAllElements(driver,20,
					"//td[@class='formCell']/following::img[contains(@src,'search_picker')]");

			webUtils.moveToClickableElement(searchPicker.get(1), driver);

			providerId.sendKeys(providerCode);

			webUtils.clickButtonOrLink(buttonList, searchType, logger, driver);

			
	/*
			Thread.sleep(5000); // Added wait time for flow synchronization

			providerSearch.click();

			webUtils.doubleClick(driver, providerSearch);

			Thread.sleep(5000); // Added wait time for flow synchronization*/

			webUtils.explicitWaitByPresenceofElement(driver,20, "//tr[1][@role='listitem']/td/div/nobr[text()="+"'"+providerCode+"']");
			
			System.out.println("The xpath is "+"//tr[1][@role='listitem']/td/div/nobr[text()="+"'"+providerCode+"']/parent::div");
			
			WebElement search = driver.findElement(By.xpath("//tr[1][@role='listitem']/td/div/nobr[text()="+"'"+providerCode+"']/parent::div"));
			search.click();

			webUtils.doubleClick(driver, search);

			Thread.sleep(5000); // Added wait time for flow synchronization

			webUtils.moveToClickableElement(servicingFax, driver);
			
			servicingFax.clear();

			servicingFax.sendKeys("1000000000");

		
				}
		catch(Exception e) {
			e.printStackTrace();
		}
			}

	public void facilityProvider(WebDriver driver, String organisation,String providerCode,
			ExtentTest logger){
		try {


			logger.log(LogStatus.INFO, "Select the facility provider!!");
			webUtils.moveToClickableElement(facility, driver);

			webUtils.explicitWaitByPresenceofAllElements(driver,20,
					"//td[@class='formCell']/following::img[contains(@src,'search_picker')]");

			webUtils.moveToClickableElement(searchPicker.get(2), driver);

			providerId.sendKeys(providerCode);

			webUtils.clickButtonOrLink(buttonList, "Extended Search", logger,
					driver);
			webUtils.explicitWaitByPresenceofElement(driver,30, "//tr[1][@role='listitem']/td/div/nobr[text()="+"'"+providerCode+"']");
			
			System.out.println("The xpath is "+"//tr[1][@role='listitem']/td/div/nobr[text()="+"'"+providerCode+"']/parent::div");
			
			WebElement search = driver.findElement(By.xpath("//tr[1][@role='listitem']/td/div/nobr[text()="+"'"+providerCode+"']/parent::div"));
			search.click();

			webUtils.doubleClick(driver, search);

			boolean isPresent = false;

			try {
				webUtils.explicitWaitByVisibilityofElement(driver,30, outOfService);
				isPresent = outOfService.isDisplayed();

			} catch (Exception e) {
				System.out.println("outOfService validation is skipped");
			}

			if (isPresent) {

				close.click();

			} else {

				System.out.println("Popup is not displayed!!");
			}
			
			webUtils.scrollUP(driver, facilityFax);

			webUtils.explicitWaitByElementToBeClickable(driver,20, facilityFax);

			// webUtils.explicitWait(driver, fax);

			webUtils.moveToClickableElement(facilityFax, driver);
			
			facilityFax.clear();

			facilityFax.sendKeys("1000000000");

		
		}
		catch(Exception e) {
			e.printStackTrace();
		}
	}

	public void reviewIntake(WebDriver driver, String reviewType,
			String priority, String admissionBedType, String serviceType,
			String serviceCategory, String subCategory, ExtentTest logger)
			 {
		try {


			if ("Inpatient".equalsIgnoreCase(serviceType)
					|| "Inpatient Post Review".equalsIgnoreCase(serviceType)) {
				webUtils.moveToClickableElement(reviewTypeDropdown, driver);

				logger.log(LogStatus.INFO, "Select the review type!!");

				webUtils.clickButtonOrLink(commondropdownList, reviewType, logger,
						driver);

				logger.log(LogStatus.INFO, "Select the priority!!");

				webUtils.moveToClickableElement(PriorityDropdown, driver);

				webUtils.clickButtonOrLink(commondropdownList, priority, logger,
						driver);
				logger.log(LogStatus.INFO, "Select the admission bed type!!");

				if ("Inpatient".equalsIgnoreCase(serviceType)) {
					webUtils.moveToClickableElement(admissionBedTypeDropdown,
							driver);

					webUtils.clickButtonOrLink(commondropdownList,
							admissionBedType, logger, driver);
				}
			} else if ("Medication".equalsIgnoreCase(serviceType)
					|| "Service Post Review".equalsIgnoreCase(serviceType)
					|| "Service Request (Prior Auth)".equalsIgnoreCase(serviceType)) {

				logger.log(LogStatus.INFO, "Select the review type!!");

				webUtils.moveToClickableElement(reviewTypeDropdown, driver);

				webUtils.clickButtonOrLink(commondropdownList, reviewType, logger,
						driver);

				logger.log(LogStatus.INFO, "Select the priority!!");

				webUtils.moveToClickableElement(PriorityDropdown, driver);

				webUtils.clickButtonOrLink(commondropdownList, priority, logger,
						driver);

				logger.log(LogStatus.INFO, "Select the serviceCategory!!");

				webUtils.moveToClickableElement(serviceCategoryDropdown, driver);

				webUtils.clickButtonOrLink(commondropdownList, serviceCategory,
						logger, driver);

				if(!"".equals(subCategory)){
				 logger.log(LogStatus.INFO, "Select the subCategory!!");
				  
				  webUtils.moveToClickableElement(subCategoryDropdown, driver);
				  
				  webUtils.clickButtonOrLink(commondropdownList, subCategory,
				  logger, driver);
				 
				}
			}

		
		}
		catch(Exception e) {
			e.printStackTrace();
		}
			 }

	public void inquiryOutcome(WebDriver driver, String inquiryOutcome,
			String outcomeReason, String buttonType, String serviceType,
			ExtentTest logger) {
		try {

			if ("Inpatient".equalsIgnoreCase(serviceType)
					|| "Inpatient Post Review".equalsIgnoreCase(serviceType)) {

				logger.log(LogStatus.INFO, "Select the inquiry outcome!!");

				webUtils.moveToClickableElement(inquiryOutcomeDropdown, driver);

				webUtils.clickButtonOrLink(commondropdownList, inquiryOutcome,
						logger, driver);

				logger.log(LogStatus.INFO, "Select the outcomeReason!!");

				webUtils.moveToClickableElement(outcomeReasonDropdown, driver);

				webUtils.clickButtonOrLink(commondropdownList, outcomeReason,
						logger, driver);

				webUtils.moveToClickableElement(submitButton, driver);

				Thread.sleep(5000); // Added wait time for flow synchronization
			} else if ("Medication".equalsIgnoreCase(serviceType)
					|| "Service Post Review".equalsIgnoreCase(serviceType)
					|| "Service Request (Prior Auth)".equalsIgnoreCase(serviceType)) {
				webUtils.moveToClickableElement(inquiryOutcomeDropdown, driver);

				logger.log(LogStatus.INFO, "Select the inquiry outcome!!");

				webUtils.clickButtonOrLink(commondropdownList, inquiryOutcome,
						logger, driver);

				webUtils.moveToClickableElement(outcomeReasonDropdown, driver);

				logger.log(LogStatus.INFO, "Select the outcomeReason!!");

				webUtils.clickButtonOrLink(commondropdownList, outcomeReason,
						logger, driver);

				webUtils.moveToClickableElement(submitButton, driver);

				Thread.sleep(5000); // Added wait time for flow synchronization
			}

		
		}
		catch(Exception e) {
			e.printStackTrace();
		}
	}

	public void assignToNurseReview(String reason, WebDriver driver,
			String rowNum, ExtentTest logger, String testCaseName)
			{
		try {


			// webUtils.explicitWait(driver, "//div[@class='staticTextItem']");
			

			try{
				webUtils.explicitWaitByElementToBeClickable(driver,20, closePopup);
				if(closePopup.isDisplayed()){
					
					closePopup.click();
				}
			}catch(Exception e){
				System.out.println("closePopup validation is skipped");
				
			}

			logger.log(LogStatus.INFO, "Assign the case to Nurse review!!");

			webUtils.explicitWaitByElementToBeClickable(driver,30, hsplit);
			
			
			hsplit.click();
			
			webUtils.fluentWait(driver, "//div[contains(@eventproxy,'isc_DynamicForm_')]/form/table/tbody/tr[2]/td/nobr[contains(text(),'Reference #')]/following::td/div");

			
			 referenceNo = referenceNumber.getText();
			 ProviderPortalHomePage.referenceNum = referenceNumber.getText();
			logger.log(LogStatus.INFO, "The reference number is " + referenceNo);

			System.out.println("The reference no is " + referenceNo);

			webUtils.moveToClickableElement(statusReasonDropdown, driver);
			
			webUtils.fluentWait(driver, "//div[contains(@id,'isc_PickListMenu_0_body$28s')]/following::table/tbody/tr[1]/td/div/nobr[text()='Nurse Review']");

			
			// Thread.sleep(5000); // Added wait time for flow synchronization

			webUtils.clickButtonOrLink(dropdownNames, reason, logger, driver);

			ExcelUtilities.setCellData("UmIntake", Integer.valueOf(rowNum),
					9, referenceNo);

			webUtils.takeSnapShot(driver, "test-output/BSC-reports/screenshots/"
					+ testCaseName.trim() + ".png");

			submit.click();
			

			try{
				
				webUtils.explicitWaitByVisibilityofElement(driver, 10, LOAOK);
				
				if(LOAOK.isDisplayed()){
					
					LOAOK.click();
					
					
					try{
						if(facilityLOARadioButton.get(0).isDisplayed()){
							
							facilityLOARadioButton.get(0).click();
						}
					}catch(Exception e){
						System.out.println("facilityLOARadioButton validation is skipped");
					}
					
					try{
					webUtils.scrollUP(driver,LOARadioButton.get(0));
					LOARadioButton.get(0).click();
					}catch(Exception e){
						System.out.println("LOARadioButton validation is skipped");
					}
					
					Thread.sleep(5000); // Added wait time for flow synchronization
					
					submit.click();
				}
			}catch(Exception e){
				e.printStackTrace();
			}

			Thread.sleep(5000); // Added wait time for flow synchronization

		
		}
		catch(Exception e) {
			e.printStackTrace();
		}
			}
	
	
	public void providerUnknownDetails(String rowNum,String inquiryOutcome,String serviceCategory,String priority,String reviewType,String servicingProviderSame,String providerStatus,String npi,String providerID,
			WebDriver driver, ExtentTest logger, String fName, String lName, String address1, 
			String city, String state, String zip, String phone, String fax)
			 {
		try {

			System.out.println("Filling Details for Provider");
			Thread.sleep(3000); // Added wait time for flow synchronization
			webUtils.scrollDown(driver, requestingUnknownCheckbox);
			webUtils.explicitWaitByElementToBeClickable(driver, 30, requestingUnknownCheckbox);
			webUtils.moveToClickableElement(requestingUnknownCheckbox, driver);
			
			System.out.println("Enter Values for Provider ID");
			requestingUnknownCheckbox.click();
			System.out.println("Checkbox Clicked");
			logger.log(LogStatus.INFO, "Unknown Provider Id Checkbox has been Selected ");
			Thread.sleep(3000); // Added wait time for flow synchronization
			webUtils.moveToClickableElement(requestingProviderID, driver);
			requestingProviderID.sendKeys(providerID);
			logger.log(LogStatus.INFO, "Provider ID is :"+providerID);
			System.out.println("Provider ID is :"+providerID);
			Thread.sleep(3000); // Added wait time for flow synchronization
			webUtils.moveToClickableElement(requestingProviderNPI, driver);
			requestingProviderNPI.sendKeys(npi);
			logger.log(LogStatus.INFO, "NPI is :"+npi);
			System.out.println("NPI is :"+npi);
			
			webUtils.moveToClickableElement(requestingProviderStatus, driver);
			webUtils.scrollDown(driver, requestingProviderStatus);
			//webUtils.moveToClickableElement(requestingUnknownCheckbox, driver);
			logger.log(LogStatus.INFO, "Select Status for Requesting Provider");
			requestingProviderStatus.click();
			webUtils.clickButtonOrLink(commondropdownList, providerStatus, logger, driver);
			System.out.println("Status for Provider is  :"+providerStatus);
			
			
			System.out.println("Select Wether Servicing privider is same or not");
			if ("Yes".equalsIgnoreCase(servicingProviderSame)) {
			
			webUtils.moveToClickableElement(radioButtonList.get(0), driver);
			Thread.sleep(5000); // Added wait time for flow synchronization
			System.out.println("Servicing Provider is selected as :"+servicingProviderSame);
			}
			logger.log(LogStatus.INFO, "Select the review type!!");

			webUtils.moveToClickableElement(reviewTypeDropdown, driver);

			webUtils.clickButtonOrLink(commondropdownList, reviewType, logger,
					driver);

			logger.log(LogStatus.INFO, "Select the priority!!");

			webUtils.moveToClickableElement(PriorityDropdown, driver);

			webUtils.clickButtonOrLink(commondropdownList, priority, logger,
					driver);

			logger.log(LogStatus.INFO, "Select the serviceCategory!!");

			webUtils.moveToClickableElement(serviceCategoryDropdown, driver);

			webUtils.clickButtonOrLink(commondropdownList, serviceCategory,
					logger, driver);
			
			webUtils.moveToClickableElement(inquiryOutcomeDropdown, driver);

			logger.log(LogStatus.INFO, "Select the inquiry outcome!!");

			webUtils.clickButtonOrLink(commondropdownList, inquiryOutcome,
					logger, driver);
			webUtils.scrollDown(driver, submitButton);
			submitButton.click();
			System.out.println("Submit button has been clicked");
			
			
			webUtils.fluentWait(driver, "//div[contains(@eventproxy,'isc_DynamicForm_')]/form/table/tbody/tr[2]/td/nobr[contains(text(),'Reference #')]/following::td/div");		
			 referenceNo = referenceNumber.getText();
			ProviderPortalHomePage.referenceNum = referenceNumber.getText();

			logger.log(LogStatus.INFO, "The reference number is " + referenceNo);

			System.out.println("The reference no is " + referenceNo);
			
			ExcelUtilities.setCellData("UmIntake", Integer.valueOf(rowNum),
					9, referenceNo);
			submit.click();
			System.out.println("Submit has been Clicked !!!!!");
			
			
			try{
				
				webUtils.explicitWaitByVisibilityofElement(driver, 10, LOAOK);
				
				if(LOAOK.isDisplayed()){
					logger.log(LogStatus.INFO, "Provider's First Name,Address1,City,State,Zip,Phone,Fax,Status are mandatory Fields.");
					
					LOAOK.click();
					
					
					try{
						if(facilityLOARadioButton.get(0).isDisplayed()){
							
							facilityLOARadioButton.get(0).click();
						}
					}catch(Exception e){
						System.out.println("facilityLOARadioButton validation is skipped");
					}
					
					try{
					webUtils.scrollUP(driver,LOARadioButton.get(0));
					LOARadioButton.get(0).click();
					Thread.sleep(3000); // Added wait time for flow synchronization
					webUtils.moveToClickableElement(searchIcon.get(0), driver);
					//webUtils.elementClickWithLogger(searchIcon.get(0), "Search", logger, driver);
					webUtils.waitUntilElementclickable(provID.get(0), driver);
					provID.get(0).sendKeys(providerID);
					Thread.sleep(3000); // Added wait time for flow synchronization
					webUtils.moveToClickableElement(extSearch.get(0), driver);
					//webUtils.waitUntilElementclickable(extSearch.get(1), driver);
					//webUtils.elementClickWithLogger(extSearch.get(1), "Extended Search", logger, driver);
					try{
						extSearch.get(1).click();
					}
					catch(Exception e){
						System.out.println("extSearch validation is skipped");
					}
					
					
					Thread.sleep(3000); // Added wait time for flow synchronization
					//webUtils.elementClickWithLogger(provFirstRow.get(1), "Provider", logger, driver);
					webUtils.moveToClickableElement(provFirstRow.get(1), driver);
					try{
						provFirstRow.get(1).click();
					webUtils.doubleClick(driver, provFirstRow.get(1));
					}
					catch(Exception e){
						System.out.println("provFirstRow validation is skipped");
					}
					
					
					Thread.sleep(5000); // Added wait time for flow synchronization
					//save.get(0).click();
					webUtils.moveToClickableElement(requestingSameID.get(1), driver);
					webUtils.elementClickWithLogger(requestingSameID.get(1), "No", logger, driver);
					Thread.sleep(3000); // Added wait time for flow synchronization
					webUtils.moveToClickableElement(requestingSameID.get(0), driver);
					webUtils.elementClickWithLogger(requestingSameID.get(0), "Yes", logger, driver);
					
					webUtils.elementClickWithLogger(save.get(0), "Save", logger, driver);
					System.out.println("Save is clicked");
					webUtils.explicitWaitByElementToBeClickable(driver, submit);
					submit.click();
					System.out.println("Submit Clicked After Mandatory Fields");
					Thread.sleep(5000); // Added wait time for flow synchronization
					}catch(Exception e){
						e.printStackTrace();
					}
					
					
					
				}
			}catch(Exception e){
				e.printStackTrace();
			}
			
			
			
			
		
		}
		catch(Exception e) {
			e.printStackTrace();
		}
			 }
	
	
}
