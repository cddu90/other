package com.bsc.qa.web.pages;

import java.util.Map;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindAll;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;

import com.bsc.qa.framework.base.BasePage;
import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;

import WebUtils.WebUtils;

public class FinalSubmitPage extends BasePage {

	public WebUtils webUtils = new WebUtils();


	@FindAll({ @FindBy(how = How.XPATH, using = "//*[@id='medical_submit_auth_btn1']") })
	public WebElement finalSubmit;
	
	
	
	public void enterDetailsInFinalSubmitPage(Map<String, String> data, WebDriver driver, ExtentTest logger)throws InterruptedException{
		
	
		webUtils.explicitWaitByElementToBeClickable(driver, finalSubmit);
		logger.log(LogStatus.INFO, "click on final Submit Button!!");
		// Added wait time for flow synchronization
		finalSubmit.click();
		Thread.sleep(3000);
	

	}

}
