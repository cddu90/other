package com.bsc.qa.web.pages;

import java.awt.Robot;
import java.io.IOException;
import java.util.Map;
import java.util.Set;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindAll;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;

import com.bsc.qa.framework.base.BasePage;
import com.gargoylesoftware.htmlunit.WebConsole.Logger;
import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;

import WebUtils.ExcelUtilities;
import WebUtils.WebUtils;

public class AuthorizationGeneration extends BasePage {

	public WebUtils webUtils = new WebUtils();

	public static String authNum;
	@FindAll({ @FindBy(how = How.XPATH, using = "//span[@id='MEDICAL_AUTH_STATUS']") })
	public WebElement authStatus;

	@FindAll({ @FindBy(how = How.XPATH, using = "//span[@id='MEDICAL_AUTH_STATUS_REASON']") })
	public WebElement authReason;

	@FindAll({ @FindBy(how = How.XPATH, using = "//span[@id='MEDICAL_AUTH_NUMBER']") })
	public WebElement authNumb;

	@FindAll({ @FindBy(how = How.XPATH, using = "//*[@id='MD_FINAL_STATUS_FOR_PRINT']/div[3]") })
	public WebElement authDecission;

	@FindAll({ @FindBy(how = How.XPATH, using = "//span[@id='MEDICAL_AUTH_INQUIRY_NUMBER']") })
	public WebElement inquiryNumber;

	@FindAll({ @FindBy(how = How.XPATH, using = "//span[@id='MEDICAL_AUTH_NOT_REQUIRED_MESSAGE']") })
	public WebElement authNotrequried;

	@FindAll({ @FindBy(how = How.XPATH, using = "//span[@id='MEDICAL_AUTH_PROCEDURE_STATUS']") })
	public WebElement procedureStatus;

	@FindAll({ @FindBy(how = How.XPATH, using = "//span[@id='MEDICAL_AUTH_INQUIRY_NUMBER']") })
	public WebElement inqueryNumber;

	@FindAll({ @FindBy(how = How.XPATH, using = "//span[@id='MEDICAL_AUTH_INQUIRY_NUMBER']/preceding::strong[1]") })
	public WebElement inqueryNumberstaus;

	@FindAll({ @FindBy(how = How.XPATH, using = "//span[@id='MEDICAL_PRINT_INQUIRY_BUTTON_MESSAGE']") })
	public WebElement printInquery;

	public static String username;

	// Verifying Auth Status and Auth Decision
	public String getActAuthStatus(WebDriver driver) {

		String actAuthStatus = null;
		webUtils.explicitWaitByElementToBeClickable(driver, authStatus);
		if (authStatus.isDisplayed()) {
			actAuthStatus = authStatus.getText().trim();
		}
		return actAuthStatus;
	}

	public String getinqueryNumberstaus(WebDriver driver, ExtentTest logger) {

		String inquerynumberStatus = null;
		webUtils.explicitWaitByElementToBeClickable(driver, inqueryNumberstaus);
		if (inqueryNumberstaus.isDisplayed()) {
			inquerynumberStatus = inqueryNumberstaus.getText().trim();
			logger.log(LogStatus.INFO, "Account Status is" + inquerynumberStatus);
		}
		return inquerynumberStatus;
	}

	public String getActinqueryNumber(WebDriver driver, ExtentTest logger) {

		String actinqueryNumber = null;
		webUtils.explicitWaitByElementToBeClickable(driver, inqueryNumber);
		if (inqueryNumber.isDisplayed()) {
			actinqueryNumber = inqueryNumber.getText().trim();
			logger.log(LogStatus.INFO, "Account inquery number is" + actinqueryNumber);
		}
		return actinqueryNumber;
	}

	public String verifyInquiryPage(WebDriver driver, ExtentTest logger, Map<String, String> data) {
		String inquiryNum = null;
		try {
			username = new com.sun.security.auth.module.NTSystem().getName();
			username = System.getProperty("user.dir");
			System.out.println("username:::::::" + username);
			webUtils.explicitWaitByVisibilityofElement(driver, authNotrequried);
			// String ss=authNotrequried.getText();
			// System.out.println("***"+ss);
			if (authNotrequried.getText().equalsIgnoreCase("Auth is not created.")) {
				logger.log(LogStatus.INFO, "Authorization will not create for this LOB");

				inquiryNum = inquiryNumber.getText().trim();
				logger.log(LogStatus.INFO, "inquiryNumber" + inquiryNum);
				String status = inqueryNumberstaus.getText().trim();
				System.out.println("**********" + status);
				String authStatus = status.substring(0, status.length() - 2);
				System.out.println("**********" + authStatus);
				if (data.get("AuthStatus").trim().equalsIgnoreCase(authStatus)) {
					logger.log(LogStatus.PASS, "Status Matched");

				} else {
					logger.log(LogStatus.FAIL, "Status not Matched");
				}

				webUtils.takeSnapShot(driver, username + "//test-output//BSC-reports//screenshots//"
						+ data.get("TestCaseID").trim() + "//" + data.get("TestCaseID").trim() + "Authstatus.png");
				logger.log(LogStatus.INFO,
						logger.addScreenCapture(
								username + "//test-output//BSC-reports//screenshots//" + data.get("TestCaseID").trim()
										+ "//" + data.get("TestCaseID").trim() + "Authstatus.png"));
			}
		} catch (Exception e) {
			// TODO: handle exception
		}
		return inquiryNum;

	}

	public void downloadTestServiceDocument(WebDriver driver, ExtentTest logger, Map<String, String> data)
			throws InterruptedException {
		username = new com.sun.security.auth.module.NTSystem().getName();
		username = System.getProperty("user.dir");
		System.out.println("username:::::::" + username);
		webUtils.explicitWaitByVisibilityofElement(driver, printInquery);
		printInquery.click();
		Thread.sleep(2000);
		String handle = driver.getWindowHandle();
		System.out.println("parent" + handle);
		Set handles = driver.getWindowHandles();
		System.out.println(handles);
		for (String handle1 : driver.getWindowHandles()) {
			System.out.println(handle1);
			if (handle1.equalsIgnoreCase(handle)) {

			} else {
				System.out.println("Switched");
				driver.switchTo().window(handle1);
			}
		}
		Thread.sleep(2000);
		webUtils.takeSnapShot(driver, username + "//test-output//BSC-reports//screenshots//"
				+ data.get("TestCaseID").trim() + "//" + data.get("TestCaseID").trim() + "inquiryPdfScreenShot.png");
		logger.log(LogStatus.INFO, logger.addScreenCapture(username + "//test-output//BSC-reports//screenshots//"
				+ data.get("TestCaseID").trim() + "//" + data.get("TestCaseID").trim() + "inquiryPdfScreenShot.png"));

	}

	public String getAuthDecision() {
		String actDeci = null;

		if (authDecission.isDisplayed()) {
			actDeci = authDecission.getText().trim();
		}
		return actDeci;
	}

	public String getmedicalAuthReason() {
		String authreason = null;

		if (authReason.isDisplayed()) {
			authreason = authReason.getText().trim();
		}
		return authreason;
	}

	public String getProcedureStatus() {
		String procedurestatus = null;

		if (procedureStatus.isDisplayed()) {
			procedurestatus = procedureStatus.getText().trim();
		}
		return procedurestatus;
	}

	public String getGeneratedAuthNumber(Map<String, String> data) throws IOException {
		String authNumber = null;
		if (authNumb.isDisplayed()) {
			authNumber = authNumb.getText();
		}

		if (authNumb.isDisplayed()) {
			authNum = authNumb.getText();
//			 logger.log(LogStatus.INFO, "Auth# generated"+authNum);
			ExcelUtilities.setCellData("NurseReview", Integer.valueOf(data.get("rowNum")) + 1, 9, authNum);

			/*
			 * try { ExcelUtilities.setCellData("NurseReview", 2, 10, authNum); } catch
			 * (IOException e) {
			 * 
			 * e.printStackTrace(); }
			 */
			System.out.println("AuthNum:" + authNumb.getText());
//			logger.log(LogStatus.INFO, "Capturing auth Number");
		}

		return authNumber;
	}

}