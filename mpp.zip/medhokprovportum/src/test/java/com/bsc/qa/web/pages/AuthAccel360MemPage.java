package com.bsc.qa.web.pages;


import java.util.List;


import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindAll;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;

import com.bsc.qa.framework.base.BasePage;
import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;

import WebUtils.WebUtils;

/**
 * @author SaiKiran Ayyagari
 * 
 * 
 *
 */
public class AuthAccel360MemPage extends BasePage {

	public WebUtils webUtils = new WebUtils();

	@FindAll({ @FindBy(how = How.XPATH, using = "//td[@class='toolbarButton']") })
	
	public List<WebElement> serviceType;

	@FindAll({ @FindBy(how = How.XPATH, using = "//td[@class='sectionHeaderclosed']/div/div") })
	
	public List<WebElement> authorizationTypes;
	
	@FindAll({ @FindBy(how = How.XPATH, using = "//div[contains(@eventproxy,'isc_PagingListGrid_')]/div/table/tbody/tr[1]/td[2]/div/nobr[text()='Inpatient']/ancestor::tr") })
	
	public WebElement listTable;
	
	@FindAll({ @FindBy(how = How.XPATH, using = "//div[contains(@eventproxy,'isc_PagingListGrid_')]/div/table/tbody/tr[1]/td[2]/div/nobr[text()='Service Request (Prior Auth)']/ancestor::tr") })
	
	public WebElement servicelistTable;
	
	
	@FindAll({ @FindBy(how = How.XPATH, using = "//div[contains(@eventproxy,'isc_PagingListGrid_')]//following-sibling::table/tbody/tr[1]") })
	
	public WebElement listTableMed;
	
	
	@FindAll({ @FindBy(how = How.XPATH, using = "//table[contains(@id,'table')]/tbody/tr") })
	//@FindAll({ @FindBy(how = How.CSS, using = "#isc_CKtable > tbody > tr:nth-child(1) > td:nth-child(3)") })
	public List<WebElement> faxlistTable;
	//public WebElement faxlistTable;

	@FindAll({ @FindBy(how = How.XPATH, using = "//div[contains(@id,'isc_ContextMenu_1_0_body$28s')]/following::tr") })
	
	public List<WebElement> contextMenu;
	
	@FindAll({ @FindBy(how = How.XPATH, using = "//div[contains(@id,'isc_')]//following-sibling::table[@role='presentation']//tr[1]") })
	public List<WebElement> careCommunicationTable;
	
	
	@FindAll({ @FindBy(how = How.XPATH, using = "//td[(text()='No items to show.')]") })
	public WebElement noItems;
	
	@FindAll({ @FindBy(how = How.XPATH, using = "//img[contains(@src,'opener_opened')]") })
	
	public WebElement opener;
	
	@FindAll({ @FindBy(how = How.XPATH, using = "//div[@role='presentation'][@cellclipdiv='true']/nobr[text()='Add']") })
	//@FindAll({ @FindBy(how = How.CSS, using = "#isc_D2table > tbody > tr:nth-child(3) > td:nth-child(2) > div > nobr") })
	public WebElement Add;

	@FindAll({ @FindBy(how = How.XPATH, using = "//div[contains(@id,'isc_ContextMenu_')]/following::table/tbody/tr[10]") })
	public WebElement sendToIntake;

	@FindAll({ @FindBy(how = How.XPATH, using = "//table[@class='selectItemControl']/tbody/tr/td/div") })
	public List<WebElement> dropDownList;

	@FindAll({ @FindBy(how = How.XPATH, using = "//div[@id='isc_PickListMenu_0_body$28s']/following::table[@class='listTable']/tbody/tr[15]/td/div") })
	public WebElement option;

	@FindAll({ @FindBy(how = How.XPATH, using = "//div[@id='isc_PickListMenu_0_body$28s']/following::table[@class='listTable']/tbody/tr") })
	public List<WebElement> queue;

	@FindAll({ @FindBy(how = How.XPATH, using = "//div[@id='isc_PickListMenu_0_body$28s']/following::table[@class='listTable']/tbody/tr[6]/td/div") })
	public WebElement pharmacyRXIntake;

	@FindAll({ @FindBy(how = How.XPATH, using = "//input[@name='file']") })
	public WebElement choseFiles;

	@FindAll({ @FindBy(how = How.XPATH, using = "//td[@class='button']/div/div[contains(text(),'Upload')]") })
	public WebElement upload;

	@FindAll({ @FindBy(how = How.XPATH, using = "//div[@class='windowBody']/div/div/div/following::div/div/table/tbody/tr/td/div/div[contains(text(),'Save')]") })
	public List<WebElement> saveButton;

	@FindAll({ @FindBy(how = How.XPATH, using = "//div[contains(@id,'isc_PagingListGrid')]/following::table/tbody/tr[1]/td[6]/div/nobr[text()='View']/preceding::td[5]/parent::tr") })
	public WebElement selectDocument;

	@FindAll({ @FindBy(how = How.XPATH, using = "//div[contains(@eventproxy,'EnhancedMemberProfile_headerLabelParent')]//following::div[contains(@eventproxy,'EnhancedMemberProfile_closeButton')]/img[contains(@src,'close.gif')]") })
	public WebElement close;

	@FindAll({ @FindBy(how = How.XPATH, using = "//span[@role='button']/img[contains(@src,'help')]") })
	public WebElement questionaire;

	@FindAll({ @FindBy(how = How.XPATH, using = "//td[@class='button']/div/div[text()='OK']") })
	public WebElement okBtn;

	@FindAll({ @FindBy(how = How.XPATH, using = "//div[contains(@eventproxy,'DERMainForm0')]/form/table/tbody/tr[17]/td[2]/table") })
	public WebElement statusDropdown;

	@FindAll({ @FindBy(how = How.XPATH, using = "//tr[@role='listitem']/td[1]/div/nobr[text()='Denied']") })
	public WebElement denied;

	@FindAll({ @FindBy(how = How.XPATH, using = "//div[contains(@eventproxy,'DERMainForm0')]/form/table/tbody/tr[17]/td[4]/table") })
	public WebElement statusReasonDropdown;

	@FindAll({ @FindBy(how = How.XPATH, using = "//div[@class='pickListMenuBody']/div/table/tbody/tr") })
	public List<WebElement> statusReasonList;

	@FindAll({ @FindBy(how = How.XPATH, using = "//tr[21]/td[3]/table/tbody/tr/td[1]/textarea") })
	public WebElement denialText;

	@FindAll({ @FindBy(how = How.XPATH, using = "//input[@name='pharmacistDecision_id']/following::td[1]/label[text()='Agree']") })
	public WebElement agree;

	@FindAll({ @FindBy(how = How.XPATH, using = "//td[@class='button']/div/div[text()='Submit']") })
	public WebElement submit;

	@FindAll({ @FindBy(how = How.XPATH, using = "//div[contains(@eventproxy,'isc_globalWarn_closeButton')]/img") })
	public WebElement closeQuestionaire;

	@FindAll({ @FindBy(how = How.XPATH, using = "//td[@class='formCellDisabled']/div[@style='min-width:146px;white-space:normal;']") })
	public WebElement rxCaseNo;

	@FindAll({ @FindBy(how = How.XPATH, using = "//div[contains(@eventproxy,'isc_ContextMenu_')]/div/div/table/tbody/tr[2]") })
	public WebElement editRXPreAuth;

	@FindAll({ @FindBy(how = How.XPATH, using = "//div[contains(@eventproxy,'isc_DERWorkSpace_')]/div[contains(@eventproxy,'isc_MemberClientInterface_')]") })
	public WebElement blueArea;

	@FindAll({ @FindBy(how = How.XPATH, using = "//span/input[@name='name']") })
	public WebElement textBox;

	@FindAll({ @FindBy(how = How.XPATH, using = "//img[contains(@src,'preview')]") })
	public WebElement preview;

	@FindAll({ @FindBy(how = How.XPATH, using = "//div[contains(@eventproxy,'isc_CorrespondanceGrid_')]/div/table/tbody/tr[1]/td[2]/div/nobr[contains(text(),'PRx MediCal')]") })
	public WebElement denialLetter;

	@FindAll({ @FindBy(how = How.XPATH, using = "//div[contains(@eventproxy,'isc_Toolbar_')]/div[2]/table/tbody/tr/td/div/div[text()='Request Type']") })
	public WebElement requestType;

	@FindAll({ @FindBy(how = How.XPATH, using = "//div[contains(@eventproxy,'isc_Toolbar_')]/div[1]/table/tbody/tr/td/div/div[text()='Name']") })
	public WebElement Name;
	@FindAll({ @FindBy(how = How.XPATH, using = "//div[contains(@eventproxy,'isc_Toolbar_')]/div[1]/table/tbody/tr/td/div/div[text()='Name']") })
	public WebElement fileUpload;

	@FindAll({ @FindBy(how = How.XPATH, using = "//tr[21]/td[@class='formTitle']") })
	public WebElement letterTemplate;

	@FindAll({ @FindBy(how = How.XPATH, using = "//input[@name='drugQuantity']") })
	public WebElement drugQuantity;
	
	
	
	@FindAll({ @FindBy(how = How.XPATH, using = "//td[text()='Communication']") })
	public WebElement communication;
	
	public void verifyPreAuthorization(String buttonName, String authType,
			WebDriver driver,ExtentTest logger) throws InterruptedException {
		
		logger.log(LogStatus.INFO, "Verifying the Prior Authorization!!");
		
		webUtils.explicitWaitByPresenceofElement(driver,15, "//td[@class='toolbarButton']");
		
		logger.log(LogStatus.INFO, "Click on Authorization!!");
		
		webUtils.clickButtonOrLink(serviceType, buttonName,logger,driver);
		
		webUtils.scrollDown(driver, communication);
		
		logger.log(LogStatus.INFO, "Click on Authorization type!!");
		for (WebElement authorizationType : authorizationTypes) {

			System.out.println("The authorization types are !!!"
					+ authorizationType.getText());

			if (authorizationType.getText().equalsIgnoreCase(authType)) {

				authorizationType.click();
				
				break;
			}
					

		}
		
		webUtils.explicitWaitByElementToBeClickable(driver,30, listTable);
		
		webUtils.rightClick(driver, listTable);
		
		webUtils.explicitWaitByVisibilityOfAllElements(driver,10, contextMenu);
		
		webUtils.clickButtonOrLink(contextMenu,"Edit",logger,driver);
		
		// Added wait time for flow synchronization
		Thread.sleep(2000);

		

	}

	public void initiatePreAuthorization(String buttonName, String authType,
			WebDriver driver,ExtentTest logger) throws InterruptedException {
		
		logger.log(LogStatus.INFO, "Initiating Prior Authorization!!");
		
		webUtils.explicitWaitByPresenceofElement(driver,15, "//td[@class='toolbarButton']");
		
		logger.log(LogStatus.INFO, "Click on Authorization!!");
		
		webUtils.clickButtonOrLink(serviceType, buttonName,logger,driver);
		
		webUtils.scrollDown(driver, communication);
		
		logger.log(LogStatus.INFO, "Click on Authorization type!!");
		for (WebElement authorizationType : authorizationTypes) {

			System.out.println("The authorization types are !!!"
					+ authorizationType.getText());

			if (authorizationType.getText().equalsIgnoreCase(authType)) {

				authorizationType.click();
				
				
				
				break;
			}

		}

		

	}
	
	/**
	 * Creating Pre Authorization
	 * 
	 * @throws InterruptedException
	 */
	
	public void createPreAuthorization(String requestType,String menuName, WebDriver driver,ExtentTest logger)
			 {
		try {

			
			logger.log(LogStatus.INFO, "Create Pre Authorization request!!");
			boolean isPresent = false;
		
			try{
				
			webUtils.explicitWaitByVisibilityofElement(driver,25, noItems);
			 isPresent = noItems.isDisplayed();
			 
			 System.out.println("No Items is present "+isPresent);
			 
			}catch(Exception e){
				System.out.println("noItems Validation is skipped");
			}
			
			
				
			if(isPresent){
				
				webUtils.rightClick(driver, noItems);
				
//				JavascriptExecutor js = (JavascriptExecutor)driver;
//				js.executeScript("arguments[0].rightclick();", noItems);
				
				webUtils.clickButtonOrLink(contextMenu, menuName,logger,driver);
			}
			
			else{
				
				if("Service Request (Prior Auth)".equalsIgnoreCase(requestType)||"Service Post Review".equalsIgnoreCase(requestType)    ){
					
					webUtils.explicitWaitByElementToBeClickable(driver,30, servicelistTable);
					
					
					webUtils.rightClick(driver, servicelistTable);
					
					webUtils.explicitWaitByVisibilityOfAllElements(driver,10, contextMenu);
					
					webUtils.clickButtonOrLink(contextMenu, menuName,logger,driver);
				}
				
				else if("Medication".equalsIgnoreCase(requestType)){
					
					webUtils.explicitWaitByElementToBeClickable(driver,30, listTableMed);
					
					
					webUtils.rightClick(driver, listTableMed);
					
					webUtils.explicitWaitByVisibilityOfAllElements(driver,10, contextMenu);
					
					webUtils.clickButtonOrLink(contextMenu, menuName,logger,driver);
				}
				else{
				
				webUtils.explicitWaitByElementToBeClickable(driver,30, listTable);
				
				
				webUtils.rightClick(driver, listTable);
				
				webUtils.explicitWaitByVisibilityOfAllElements(driver,10, contextMenu);
				
				webUtils.clickButtonOrLink(contextMenu, menuName,logger,driver);
			}
			}
		
		}catch(Exception e) {
			e.printStackTrace();
		}
			 }
	
	/**
	 * Checking if the Correspondence is not generated.
	 * 
	 * @throws InterruptedException
	 */

	public void correspondanceEmptyCheck(WebDriver driver,ExtentTest logger)
			 {
		if(careCommunicationTable.get(2).getText().equalsIgnoreCase("No items to show.")){
			logger.log(LogStatus.INFO, "No Correspondence has been generated ");
			System.out.println("fail");
			
		}
		else{
			logger.log(LogStatus.INFO, "Correspondence has been generated");
			System.out.println("Pass");
		}
	}
	
	/**
	 * Create Prior Authorization Request
	 * @param menuName
	 * @param doc
	 * @param driver
	 * @param logger
	 * @throws Exception
	 */
	public void createPreAuthorizationByFax(String menuName, String doc,String requestType,
			WebDriver driver, ExtentTest logger)  {
		try {

			
			
			
			webUtils.explicitWaitByVisibilityofElement(driver,10, opener);
		
			boolean isPresent = false;
			logger.log(LogStatus.INFO, "Rightclik and select Add");
			try{
				
			webUtils.explicitWaitByVisibilityofElement(driver,25, noItems);
			 isPresent = noItems.isDisplayed();
			 
			 System.out.println("No Items is present "+isPresent);
			 
			}catch(Exception e){
				System.out.println("noItems Validation is skipped");
			}
			
			
				
			if(isPresent){
				
				webUtils.rightClick(driver, noItems);
				
				webUtils.clickButtonOrLink(contextMenu, menuName,logger,driver);
			}else{

			

			webUtils.rightClick(driver, faxlistTable.get(0));
			System.out.println("Right click on first row");
			//Thread.sleep(3000);
			

			Add.click();
			
			}
			
			

			logger.log(LogStatus.INFO, "Click on drop down and select the option!!");

			dropDownList.get(1).click();

			option.click();
			logger.log(LogStatus.INFO, "Chose file to upload!!");
			
			String homeDirectory = System.getProperty("user.dir");
			
			System.out.println("the homedirectory is "+homeDirectory);

			choseFiles.sendKeys(homeDirectory+doc);

			// Added wait time for flow synchronization
			Thread.sleep(5000);

			upload.click();

			// Added wait time for flow synchronization
			Thread.sleep(3000);

			webUtils.scrollDown(driver, Name);

			webUtils.explicitwaitByinvisibilityOfElementLocated(driver,30,
					"//img[contains(@src,'loadingSmall')]");


			webUtils.waitUntilElementclickable(selectDocument,driver);
			

			logger.log(LogStatus.INFO,
					"Right click and select sendtointake option!!");

			webUtils.rightClick(driver, selectDocument);

			webUtils.explicitWaitByVisibilityofElement(driver,10, sendToIntake);

			webUtils.moveToClickableElement(sendToIntake, driver);

			

			logger.log(LogStatus.INFO,
					"Click on dropdown and select Promise UM IN Inpatient!!");

			webUtils.explicitWaitByVisibilityofElement(driver,15, dropDownList.get(2));

			dropDownList.get(2).click();
			
			
			
			
			/*if(requestType.equals("Medication")){
				
				webUtils.clickButtonOrLink(queue, "UM IN- Medication Request", logger, driver);
				Thread.sleep(5000);
				
			}else{*/
			
			webUtils.clickButtonOrLink(queue, "UM IN- Inpatient Request", logger, driver);
			
			logger.log(LogStatus.INFO, "Click on save button!!");

			saveButton.get(0).click();

			
			webUtils.explicitWaitByElementToBeClickable(driver, 20, close);

			webUtils.moveToClickableElement(close, driver);
			
			logger.log(LogStatus.INFO, "Prior authorization request through FaxIntake is initiated successfully");

		
		}
		catch (Exception e) {
			e.printStackTrace();
		}
	}
	
		

	}


