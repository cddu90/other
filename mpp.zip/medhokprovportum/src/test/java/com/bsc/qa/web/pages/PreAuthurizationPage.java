package com.bsc.qa.web.pages;

import java.util.Map;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindAll;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;

import com.bsc.qa.framework.base.BasePage;
import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;

import WebUtils.WebUtils;

public class PreAuthurizationPage extends BasePage {

	public WebUtils webUtils = new WebUtils();

	
	@FindAll({ @FindBy(how = How.XPATH, using = "//*[@id='LEFT_SUB_MENU_NAV_PRIOR_AUTHORIZATION']/a") })
	public WebElement preAuth;
	
	@FindAll({ @FindBy(how = How.XPATH, using = "//*[@id='LEFT_NAV_ORDER_PA_PHARMACY']/a") })
	public WebElement prePharma;
	
	
	public void enterDetailsInPreAuthPage(Map<String, String> data, WebDriver driver, ExtentTest logger)throws InterruptedException{
		webUtils.explicitWaitByElementToBeClickable(driver, "//*[@id='LEFT_SUB_MENU_NAV_PRIOR_AUTHORIZATION']/a",20);
		logger.log(LogStatus.INFO, "enter details for preAuth");
		preAuth.click();
		webUtils.explicitWaitByElementToBeClickable(driver, "//*[@id='LEFT_NAV_ORDER_PA_PHARMACY']/a",20);
		logger.log(LogStatus.INFO, "to click Pre Pharmacy IPA");
		prePharma.click();
		
		
	}

}
