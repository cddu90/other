package WebUtils;

import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.List;

import com.opencsv.CSVReader;
import com.opencsv.CSVReaderBuilder;
import com.opencsv.CSVWriter;

public class CsvUtils {

	public static void writeDataintoCSV(String folderPath, String fileName, String timestamp, String[] header,
			List<String[]> data) {

		// first create file object for file placed at location
		// specified by filepath

		String filePath = folderPath + File.separator + fileName + timestamp + ".csv";
		File file = new File(filePath);
		try {
			if (file.createNewFile()) {
				System.out.println("New file is created");
			}

			// create FileWriter object with file as parameter
			FileWriter outputfile = new FileWriter(file);

			// create CSVWriter object filewriter object as parameter
			CSVWriter writer = new CSVWriter(outputfile);

			// Write a List into csv which contains header and String arrays

			writer.writeNext(header);

			for (String[] a : data) {
				System.out.println(data);
			}
			writer.writeAll(data);

			// closing writer connection
			writer.close();
		} catch (IOException e) {

			e.printStackTrace();
		}
	}

	public static void writeDataintoCSVLineByLine(String folderPath, String[] data) {

		// first create file object for file placed at location
		// specified by filepath

		// String filePath = folderPath + File.separator + fileName + timestamp +
		// ".csv";
		File file = new File(folderPath);
		try {
			if (file.createNewFile()) {
				System.out.println("New file is created");
			}

			// create FileWriter object with file as parameter
			FileWriter outputfile = new FileWriter(file, true);

			// create CSVWriter object filewriter object as parameter
			CSVWriter writer = new CSVWriter(outputfile);

			// Write a List into csv which contains header and String arrays

			// writer.writeNext(header);

			writer.writeNext(data);

			// closing writer connection
			writer.close();
		} catch (IOException e) {

			e.printStackTrace();
		}
	}

	public static void writeHeadersintoCSV(String folderPath, String[] header) {

		// first create file object for file placed at location
		// specified by filepath

		// String filePath = folderPath + File.separator + fileName + timestamp +
		// ".csv";
		File file = new File(folderPath);
		try {
			if (file.createNewFile()) {
				System.out.println("New file is created");
			}

			// create FileWriter object with file as parameter
			FileWriter outputfile = new FileWriter(file, true);

			// create CSVWriter object filewriter object as parameter
			CSVWriter writer = new CSVWriter(outputfile);

			// Write a List into csv which contains header and String arrays

			writer.writeNext(header);

			// writer.writeNext(data);

			// closing writer connection
			writer.close();
		} catch (IOException e) {

			e.printStackTrace();
		}
	}

	public static void copyOutputFile(String sourecePath, String targetPath) {
		try {
			Path temp = Files.copy(Paths.get(sourecePath), Paths.get(targetPath));

			if (temp != null) {
				System.out.println("File Copied");
			} else {
				System.out.println("Failed to move the file");
			}
		} catch (Exception e) {
			// TODO: handle exception
		}
	}

	public static void writeDataAtOnce(String filePath, String[] header, List<String[]> data) {

		// first create file object for file placed at location
		// specified by filepath

		File file = new File(filePath);

		try {
			// create FileWriter object with file as parameter
			FileWriter outputfile = new FileWriter(file);

			// create CSVWriter object filewriter object as parameter
			CSVWriter writer = new CSVWriter(outputfile);

			// Write a List into csv which contains header and String arrays

			writer.writeNext(header);
			writer.writeAll(data);

			// closing writer connection
			writer.close();
		} catch (IOException e) {

			e.printStackTrace();
		}
	}

	// Java code to illustrate reading a
	// all data at once
	public static List<String[]> readAllDataAtOnce(String file) {
		List<String[]> allData = null;
		try {
			// Create an object of file reader
			// class with CSV file as a parameter.
			FileReader filereader = new FileReader(file);

			// create csvReader object and skip first Line
			CSVReader csvReader = new CSVReaderBuilder(filereader).withSkipLines(1).build();

			allData = csvReader.readAll();
			System.out.println(allData.get(0));
		} catch (Exception e) {
			e.printStackTrace();
		}
		return allData;
	}

}
