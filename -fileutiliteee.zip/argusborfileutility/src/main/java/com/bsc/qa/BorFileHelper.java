package com.bsc.qa;

import java.io.File;
import java.io.IOException;
import java.math.BigDecimal;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;
import java.util.Random;
import java.util.TimeZone;
import java.util.concurrent.ThreadLocalRandom;

import com.bsc.qa.framework.utility.DBUtils;

public class BorFileHelper {

	private static String dd;
	private static String mm;
	private static String hh;
	private static String mn;
	private static String sc;

	public static String padRight(String string, int length) {
		return String.format("%-" + length + "s", string);
	}

	public static String padLeft(String string, int length) {
		return String.format("%" + length + "s", string);
	}

	public static String blankOnNull(String string) {
		if (string == null) {
			return "";
		}
		return string;
	}
	
	public static String getBorFileName() {
		Date d = new Date();
		Calendar cal = Calendar.getInstance(Locale.US);
		cal.setTime(d);
		TimeZone tz = TimeZone.getTimeZone("America/Los_Angeles");
		cal.setTimeZone(tz);

		int dd_i = cal.get(Calendar.DATE);
		if (dd_i < 10) {
			dd = "0" + dd_i;
		} else {
			dd = "" + dd_i;
		}

		int mm_i = cal.get(Calendar.MONTH);
		mm_i += 1;
		if (mm_i < 10) {
			mm = "0" + mm_i;
		} else {
			mm = "" + mm_i;
		}

		int clm_id = 0;
		Random r = new Random();
		int x = r.nextInt(999999);
		if (x < 100000) {
			x = x + 100000;
		}
		clm_id = x;
		int yy = cal.get(Calendar.YEAR);
		int hh_i = cal.get(Calendar.HOUR);
		if (hh_i < 10) {
			hh = "0" + hh_i;
		} else {
			hh = "" + hh_i;
		}

		int mn_i = cal.get(Calendar.MINUTE);
		if (mn_i < 10) {
			mn = "0" + mn_i;
		} else {
			mn = "" + mn_i;
		}

		int sc_i = cal.get(Calendar.SECOND);
		if (sc_i < 10) {
			sc = "0" + sc_i;
		} else {
			sc = "" + sc_i;
		}

		yy = yy % 100;
		File dir = new File("Output files");
		if (!dir.exists())
			dir.mkdir();
		String borFileName = "FACETS_PCT_AFAGL." + "#" + mm + dd + yy + "." + hh + mn + sc + ".txt";
		return borFileName;
	}

	public static String getTodaysDateFake(Date dbCheckDate) {
		long DAY_IN_MS = 1000 * 60 * 60 * 24;
		Date checkDate = new Date(dbCheckDate.getTime() + (2 * DAY_IN_MS));
//		Date d = new Date();
//		Calendar cal = Calendar.getInstance(Locale.US);
//		cal.setTime(d);
//		TimeZone tz = TimeZone.getTimeZone("America/Los_Angeles");
//		cal.setTimeZone(tz);
//		
		SimpleDateFormat dateFormat = new SimpleDateFormat("dd-MMM-yy");
		String send = dateFormat.format(checkDate);
//		System.out.println(dateFormat.format(d).toUpperCase());
		return send;
	}

	public static String getTodaysDate() {
		Date d = new Date();
		Calendar cal = Calendar.getInstance(Locale.US);
		cal.setTime(d);
		TimeZone tz = TimeZone.getTimeZone("America/Los_Angeles");
		cal.setTimeZone(tz);
		String returnString = "";
		SimpleDateFormat dateFormat = new SimpleDateFormat("dd-MMM-yy");
		try {
			Date sysDate = dateFormat.parse(dateFormat.format(d).toUpperCase());
			Date send = dateFormat.parse("25-JUL-19");
			if (sysDate.before(send) == true) {
				returnString = "25-JUL-19";
			} else {
				returnString = dateFormat.format(sysDate).toUpperCase();
			}
		} catch (ParseException e) {
			System.out.println("Unable to parse sysDate");
			e.printStackTrace();
		}
//		System.out.println(dateFormat.format(d).toUpperCase());
		return returnString;
	}

	public static String getLastYearsDate() {
		Date d = new Date();
		Calendar cal = Calendar.getInstance(Locale.US);
		cal.setTime(d);

		TimeZone tz = TimeZone.getTimeZone("America/Los_Angeles");
		cal.setTimeZone(tz);

		SimpleDateFormat dateFormat = new SimpleDateFormat("dd-MMM-");
		SimpleDateFormat dateFormat1 = new SimpleDateFormat("yy");
		String yearString = String.valueOf((Integer.parseInt(dateFormat1.format(d)) - 1));
//		System.out.println(dateFormat.format(d).toUpperCase());
		return dateFormat.format(d).toUpperCase().concat(yearString);
	}

	public static int getDecimalForAmountFields() {
		int randomDecimals = ThreadLocalRandom.current().nextInt(10, 99 + 1);
		return randomDecimals;

	}

	public static String generateCheckNumber() {
		Integer zb = 1000000 + new Random().nextInt(9000000);
		String zbs = zb.toString();

		if (checknumberExits(zbs)) {
			zbs = generateCheckNumber();
		}
		return zbs;
	}

	public static boolean checknumberExits(String checkNumber) {
		String query = "SELECT BPID_CK_NO FROM FACETS.CMC_BPID_INDIC WHERE BPID_CK_NO='" + checkNumber + "'";
		Object[][] results = new DBUtils().getFacetsTableArray(query);
		return results.length > 0;
	}

	public static String generateUniqueClaimId() {
		String claimNumber = new String();
		Random r = new Random();
		Integer za = 100000 + r.nextInt(900000);
		String zas = za.toString();
		Integer zb = 10000 + r.nextInt(90000);
		String zbs = zb.toString();
		claimNumber = "R" + zas + zbs;

		if (claimIdExists(claimNumber)) {
			claimNumber = generateUniqueClaimId();
		}
		return claimNumber;
	}

	public static boolean claimIdExists(String claimId) {
		String query = "Select * from FACETS_CUSTOM.AFA_RECONNET_TRNS_HIST where CLM_ID ='" + claimId + "'";
		Object[][] results = new DBUtils().getFacetsTableArray(query);
		return results.length > 0;
	}

	public static Map<String, String> getAmountFields(BigDecimal billedAmount) {
		Map<String, String> amountFieldsMap = new HashMap<String, String>();

		BigDecimal ingredientCost = billedAmount;// .divide(new BigDecimal(2)).setScale(2, BigDecimal.ROUND_HALF_UP);
		BigDecimal allowedAmount = billedAmount.multiply((new BigDecimal(0.6))).setScale(2, BigDecimal.ROUND_HALF_UP);
		BigDecimal deductible = billedAmount.multiply((new BigDecimal(0.2))).setScale(2, BigDecimal.ROUND_HALF_UP);
		BigDecimal copay = billedAmount.multiply((new BigDecimal(0.1))).setScale(2, BigDecimal.ROUND_HALF_UP);
		BigDecimal coinsurance = billedAmount.multiply((new BigDecimal(0.1))).setScale(2, BigDecimal.ROUND_HALF_UP);
		BigDecimal claimAmount = ingredientCost.subtract(deductible).subtract(copay).setScale(2,BigDecimal.ROUND_HALF_UP);
		BigDecimal clientPrice = billedAmount;
		BigDecimal bscRevenueAmount = clientPrice.subtract(claimAmount).setScale(2, BigDecimal.ROUND_HALF_UP);

		amountFieldsMap.put("ClaimAmount", String.valueOf(claimAmount).trim());
		amountFieldsMap.put("BilledAmount", String.valueOf(billedAmount).trim());
		amountFieldsMap.put("Deductible", String.valueOf(deductible).trim());
		amountFieldsMap.put("Copay", String.valueOf(copay).trim());
		amountFieldsMap.put("CoInsurance", String.valueOf(coinsurance).trim());
		amountFieldsMap.put("ClientPrice", String.valueOf(clientPrice).trim());
		amountFieldsMap.put("BscRevenueAmount", String.valueOf(bscRevenueAmount).trim());
		amountFieldsMap.put("AllowedAmount", String.valueOf(allowedAmount).trim());
		
		return amountFieldsMap;
	}

	 public static void modifyFile(String fileName) throws IOException{

	        Path path = Paths.get(fileName);
	        Charset charset = StandardCharsets.UTF_8;

	        String content = new String(Files.readAllBytes(path), charset);
	        content = content.replaceAll("\r\n", "\n");
	        content = content.replaceAll("\r", "\n");
	        Files.write(path, content.getBytes(charset));
	    }
	
	
}
