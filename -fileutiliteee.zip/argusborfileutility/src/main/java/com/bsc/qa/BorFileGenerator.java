package com.bsc.qa;

import java.io.File;
import java.io.IOException;
import java.math.BigDecimal;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.Set;
import java.util.SortedMap;
import java.util.concurrent.ThreadLocalRandom;

import org.apache.commons.io.FileUtils;

import com.bsc.qa.framework.utility.DBUtils;
import com.bsc.qa.framework.utility.ExcelUtils;

/**
 * Hello world!
 *
 */
public class BorFileGenerator {

	private static String borFileName = BorFileHelper.getBorFileName();

	private static String[] pharmacies = { "0107777,EXPO PHARMACY", "5600742,CVS PHARMACY 16748",
			"5664316,LOYALTY PHARMACY 2", "5621188,CVS PHARMACY 08895", "0107777,EXPO PHARMACY",
			"1167976,ROCKDALE PHARMACY", "1023768,NORTH FLORIDA PHARMA", "5660584,OMNI FAMILY HEALTH 3",
			"0517459,RITE AID PHARMACY 05", "5619943,CVS PHARMACY 09627", "2591990,PEOPLE'S PHARMACY",
			"5600665,CVS PHARMACY 16040", "5619690,CVS PHARMACY 09774", "4408705,LOWE'S DRUGS",
			"5633448,RITE AID PHARMACY 06", "5916258,MANOR PHARMACY 1", "2803509,WANEK PHARMACY" };

	public static void main(String[] args) {
		String queriesXlsx = null;
		int subscriberCount = 8;
		int adjustmentCount = 6;
		if (args.length > 0 && args[0] != null) {
			queriesXlsx = args[0];
		} else {
			queriesXlsx = "src/test/resources/bor-queries.xlsx";
		}

		if (args.length > 0 && args[1] != null) {
			subscriberCount = Integer.parseInt(args[1]);
		}

		Object[][] queryArray= new ExcelUtils().getTableArray(queriesXlsx, "Sheet1");
		String subscriberSelectionQuery = (String) queryArray[0][0];
		String adjustmentRecordQuery = (String) queryArray[0][1];
		

		SortedMap<String, SortedMap<String, String>> selectedSubscriberDataMapOfMaps = new DBUtils()
				.getMultiRowsFromPreparedQuery("facets", subscriberSelectionQuery, "SUBID",
						subscriberCount);

		SortedMap<String, SortedMap<String, String>> adjustmentClaimMapOfMaps = new DBUtils()
				.getMultiRowsFromPreparedQuery("facets", adjustmentRecordQuery, "CLM_NBR",
						adjustmentCount);

		BorFileGenerator borFileGenerator = new BorFileGenerator();
		List<String> paidScenarioList = borFileGenerator.getPaidScenarioList(selectedSubscriberDataMapOfMaps);
		List<String> adjustmentClaimList = borFileGenerator.getAdjustmentScenarioList(adjustmentClaimMapOfMaps);
		List fileDataList = new ArrayList();
		fileDataList.addAll(paidScenarioList);
		fileDataList.addAll(adjustmentClaimList);
		Object encoding;
		try {
			String folder = System.getenv("ARGUS_BOR_INPUT_PATH")+"/";
			FileUtils.writeLines(new File(folder+borFileName), fileDataList);
			BorFileHelper.modifyFile(folder+borFileName);
			System.out.println(folder+borFileName);
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	

	/**
	 * Paid Scenarios
	 * 
	 * @param selectedSubscriberDataMapOfMaps
	 * @return
	 */
	private List<String> getPaidScenarioList(
			SortedMap<String, SortedMap<String, String>> selectedSubscriberDataMapOfMaps) {
		List<String> paidScenarioList = new ArrayList<String>();
		Set<String> subscriberIdKeySet = selectedSubscriberDataMapOfMaps.keySet();
		int i = 1;
		for (String subscriberIdKey : subscriberIdKeySet) {
			SortedMap<String, String> selectedSubscriberDataMap = selectedSubscriberDataMapOfMaps.get(subscriberIdKey);
			String paidScenario = getPaidScenarioForSubscriber(selectedSubscriberDataMap);
			
			if(i==1) {
				//Scenario 1 : Adding duplicate paid record
				paidScenarioList.add(paidScenario);
				paidScenarioList.add(paidScenario);
				i++;
			}else if(i==2) {
				//Scenario 2 : Changing BSC Revenue amount position 111-120 to Zero amount
				StringBuffer buf = new StringBuffer(paidScenario);
			    int startIndex = 110;
			    int endIndex = 119;
			    buf.replace(startIndex, endIndex, BorFileHelper.padRight("0.00", 9)); 
				paidScenarioList.add(buf.toString());
				i++;
			}else if(i==3) {
				//Scenario 3 : Changing Net amount position 91-100 to Zero amount
				StringBuffer buf = new StringBuffer(paidScenario);
			    int startIndex = 90;
			    int endIndex = 99;
			    buf.replace(startIndex, endIndex, BorFileHelper.padRight("0.00", 9)); 
				paidScenarioList.add(buf.toString());
				i++;
			}else if(i==4) {
				//Scenario 4 : Changing CheckDate and ServiceDate one year less at positions 128-136 and 137-145  to Zero amount
				Calendar cal = Calendar.getInstance();
				cal.add(Calendar.YEAR, -1);
				Date lastYearDate= cal.getTime();
				
				SimpleDateFormat dateFormat = new SimpleDateFormat("dd-MMM-yy");
				String lastYearDay = dateFormat.format(lastYearDate).toUpperCase();
				
				StringBuffer buf = new StringBuffer(paidScenario);
			    int startIndexCheckDate = 127;
			    int endIndexCheckDate = 136;
			     
			    int startIndexServiceDate = 136;
			    int endIndexServiceDate = 145;
			    
			    buf.replace(startIndexCheckDate, endIndexCheckDate, BorFileHelper.padRight(lastYearDay, 8));
			    buf.replace(startIndexServiceDate, endIndexServiceDate, BorFileHelper.padRight(lastYearDay, 8)); 
			    paidScenarioList.add(buf.toString());
				i++;
			}else {
				
				paidScenarioList.add(paidScenario);
				i++;
			}
		}
		return paidScenarioList;
	}
	
	/**
	 * Adjustment Scenarios
	 * 
	 * @param adjustmentClaimMapOfMaps
	 * @return
	 */
	private List<String> getAdjustmentScenarioList(
			SortedMap<String, SortedMap<String, String>> adjustmentClaimMapOfMaps) {
		List<String> AdjustmentScenarioList = new ArrayList<String>();
		Set<String> claimNumberKeySet = adjustmentClaimMapOfMaps.keySet();
		int i = 1;
		for (String claimIdKey : claimNumberKeySet) {
			SortedMap<String, String> selectedClaimDataMap = adjustmentClaimMapOfMaps.get(claimIdKey);
			String adjustmentScenario = getAdjustmentForClaim(selectedClaimDataMap);
			
			if(i==1) {

				/*
				 * Scenario 1 : Reversal Scenario 1 :
				 * 
				 * •Adjustment indicator as 'P'
				 * •Check date =System date
				 * •Version number =version number return form DB +1
				 * •Amount fields = 10% of amount received from DB with positive sign
				 */
				StringBuffer buf = new StringBuffer(adjustmentScenario);
				buf.replace(328, 329, "P");
				
				SimpleDateFormat dateFormat = new SimpleDateFormat("dd-MMM-yy");
				String today = dateFormat.format(new Date()).toUpperCase();
				buf.replace(127, 136, today);
				
				Integer claimVersionNumber = Integer.parseInt(adjustmentScenario.substring(89,90))+1;
				buf.replace(89, 90, String.valueOf(claimVersionNumber));
				
				BigDecimal dbBilledAmount = new BigDecimal(adjustmentScenario.substring(100,109).trim());
				Map<String, String> amountFieldsMap = BorFileHelper.getAmountFields(dbBilledAmount.multiply(new BigDecimal("0.1")).setScale(2, BigDecimal.ROUND_HALF_UP).abs());
				buf.replace(90, 99, BorFileHelper.padRight(amountFieldsMap.get("ClaimAmount"), 9));
				buf.replace(100, 109, BorFileHelper.padRight(amountFieldsMap.get("ClientPrice"), 9));
				buf.replace(110, 119, BorFileHelper.padRight(amountFieldsMap.get("BscRevenueAmount"), 9));
				
				buf.replace(240, 249, BorFileHelper.padRight(amountFieldsMap.get("BilledAmount").trim(), 9));
				buf.replace(250, 259, BorFileHelper.padRight(amountFieldsMap.get("AllowedAmount"), 9));
				buf.replace(260, 269, BorFileHelper.padRight(amountFieldsMap.get("Deductible"), 9));
				buf.replace(270, 279, BorFileHelper.padRight(amountFieldsMap.get("CoInsurance"), 9));
				buf.replace(280, 289, BorFileHelper.padRight(amountFieldsMap.get("Copay"), 9));
				
				AdjustmentScenarioList.add(buf.toString());
				i++;
			
			}else if(i==2) {

				/*
				 * Scenario 2 : Reversal Scenario 2 :
				 * 
				 * •Adjustment indicator as 'A'
				 * •Check date =System date
				 * •Version number =version number return form DB +1
				 * •Amount fields = 10% of amount received from DB with negative sign
				 */
				StringBuffer buf = new StringBuffer(adjustmentScenario);
			    
				buf.replace(328, 329, "A");
				
				SimpleDateFormat dateFormat = new SimpleDateFormat("dd-MMM-yy");
				String today = dateFormat.format(new Date()).toUpperCase();
				buf.replace(127, 136, today);
				
				Integer claimVersionNumber = Integer.parseInt(adjustmentScenario.substring(89,90))+1;
				buf.replace(89, 90, String.valueOf(claimVersionNumber));
				
				BigDecimal dbBilledAmount = new BigDecimal(adjustmentScenario.substring(100,109).trim()).abs().multiply(new BigDecimal("-1.00"));
				Map<String, String> amountFieldsMap = BorFileHelper.getAmountFields(dbBilledAmount.multiply(new BigDecimal("0.1")).setScale(2, BigDecimal.ROUND_HALF_UP));
				buf.replace(90, 99, BorFileHelper.padRight(amountFieldsMap.get("ClaimAmount"), 9));
				buf.replace(100, 109, BorFileHelper.padRight(amountFieldsMap.get("ClientPrice"), 9));
				buf.replace(110, 119, BorFileHelper.padRight(amountFieldsMap.get("BscRevenueAmount"), 9));
				
				buf.replace(240, 249, BorFileHelper.padRight(amountFieldsMap.get("BilledAmount").trim(), 9));
				buf.replace(250, 259, BorFileHelper.padRight(amountFieldsMap.get("AllowedAmount"), 9));
				buf.replace(260, 269, BorFileHelper.padRight(amountFieldsMap.get("Deductible"), 9));
				buf.replace(270, 279, BorFileHelper.padRight(amountFieldsMap.get("CoInsurance"), 9));
				buf.replace(280, 289, BorFileHelper.padRight(amountFieldsMap.get("Copay"), 9));
				
			    AdjustmentScenarioList.add(buf.toString());
				i++;
			
				
			}else if(i==3) {
				/*
				 * Scenario 3 : Reversion Scenario claim with Claim check date =date received from DB - 1
				 */
				Calendar cal = Calendar.getInstance();
				cal.add(Calendar.DATE, -1);
				Date lastYearDate= cal.getTime();
				
				SimpleDateFormat dateFormat = new SimpleDateFormat("dd-MMM-yy");
				String lastYearDay = dateFormat.format(lastYearDate).toUpperCase();
				
				StringBuffer buf = new StringBuffer(adjustmentScenario);
			    int startIndexCheckDate = 127;
			    int endIndexCheckDate = 136;
				
			    buf.replace(startIndexCheckDate, endIndexCheckDate, BorFileHelper.padRight(lastYearDay, 8));
			    
			    AdjustmentScenarioList.add(buf.toString());
				i++;
			    
			}
			else if(i==4) {
				/*
				 * Scenario 4 : create 2 claim records with same details from query with following changes
				 * For first record
				 * •Adjustment indicator as 'A'
				 * •Same amount with -ve sign
				 * For second record
				 * •Adjustment indicator as 'P'
				 * •Check date =System date
				 * •Version number =version number return form DB +1
				 * •Amount fields = (10% of amount received from DB) + (amount received form DB) with positive sign
				 * 
				 */
				
				StringBuffer buf = new StringBuffer(adjustmentScenario);
				buf.replace(328, 329, "A");
				BigDecimal claimAmount = new BigDecimal(adjustmentScenario.substring(90,99).trim()).abs().multiply(new BigDecimal("-1.00")).setScale(2, BigDecimal.ROUND_HALF_UP);
				BigDecimal clientPrice = new BigDecimal(adjustmentScenario.substring(100,109).trim()).abs().multiply(new BigDecimal("-1.00")).setScale(2, BigDecimal.ROUND_HALF_UP);
				BigDecimal bscRevenueAmount = new BigDecimal(adjustmentScenario.substring(110,119).trim()).abs().multiply(new BigDecimal("-1.00")).setScale(2, BigDecimal.ROUND_HALF_UP);
				BigDecimal billedAmount = new BigDecimal(adjustmentScenario.substring(240,249).trim()).abs().multiply(new BigDecimal("-1.00")).setScale(2, BigDecimal.ROUND_HALF_UP);
				BigDecimal allowedAmount = new BigDecimal(adjustmentScenario.substring(250,259).trim()).abs().multiply(new BigDecimal("-1.00")).setScale(2, BigDecimal.ROUND_HALF_UP);
				BigDecimal deductible = new BigDecimal(adjustmentScenario.substring(260,269).trim()).abs().multiply(new BigDecimal("-1.00")).setScale(2, BigDecimal.ROUND_HALF_UP);
				BigDecimal coInsurance = new BigDecimal(adjustmentScenario.substring(270,279).trim().trim()).abs().multiply(new BigDecimal("-1.00")).setScale(2, BigDecimal.ROUND_HALF_UP);
				BigDecimal copay =new BigDecimal(adjustmentScenario.substring(280,289).trim().trim()).abs().multiply(new BigDecimal("-1.00")).setScale(2, BigDecimal.ROUND_HALF_UP);
				
				StringBuffer buf1 = buf;
				String billedAmt = adjustmentScenario.substring(110,119).trim();
				
				buf.replace(90, 99, BorFileHelper.padRight(String.valueOf(claimAmount).trim(), 9));
				buf.replace(100, 109, BorFileHelper.padRight(String.valueOf(clientPrice).trim(), 9));
				buf.replace(110, 119, BorFileHelper.padRight(String.valueOf(bscRevenueAmount).trim(), 9));
				buf.replace(240, 249, BorFileHelper.padRight(String.valueOf(billedAmount).trim().trim(), 9));
				buf.replace(250, 259, BorFileHelper.padRight(String.valueOf(allowedAmount).trim(), 9));
				buf.replace(260, 269, BorFileHelper.padRight(String.valueOf(deductible).trim(), 9));
				buf.replace(270, 279, BorFileHelper.padRight(String.valueOf(coInsurance).trim(), 9));
				buf.replace(280, 289, BorFileHelper.padRight(String.valueOf(copay).trim(), 9));
				
			    AdjustmentScenarioList.add(buf.toString());
				
				buf1.replace(328, 329, "A");
				SimpleDateFormat dateFormat = new SimpleDateFormat("dd-MMM-yy");
				String today = dateFormat.format(new Date()).toUpperCase();
				buf1.replace(127, 136, today);
				
				Integer claimVersionNumber = Integer.parseInt(adjustmentScenario.substring(89,90))+1;
				buf1.replace(89, 90, String.valueOf(claimVersionNumber));
				
				BigDecimal dbBilledAmount1 = new BigDecimal(billedAmt).abs().multiply(new BigDecimal("-1.00"));
				Map<String, String> amountFieldsMap1 = BorFileHelper.getAmountFields(dbBilledAmount1.add(dbBilledAmount1.multiply(new BigDecimal("0.1"))).setScale(2, BigDecimal.ROUND_HALF_UP).abs());
				buf1.replace(90, 99, BorFileHelper.padRight(amountFieldsMap1.get("ClaimAmount"), 9));
				buf1.replace(100, 109, BorFileHelper.padRight(amountFieldsMap1.get("ClientPrice"), 9));
				buf1.replace(110, 119, BorFileHelper.padRight(amountFieldsMap1.get("BscRevenueAmount"), 9));
				buf1.replace(240, 249, BorFileHelper.padRight(amountFieldsMap1.get("BilledAmount").trim(), 9));
				buf1.replace(250, 259, BorFileHelper.padRight(amountFieldsMap1.get("AllowedAmount"), 9));
				buf1.replace(260, 269, BorFileHelper.padRight(amountFieldsMap1.get("Deductible"), 9));
				buf1.replace(270, 279, BorFileHelper.padRight(amountFieldsMap1.get("CoInsurance"), 9));
				buf1.replace(280, 289, BorFileHelper.padRight(amountFieldsMap1.get("Copay"), 9));
				
			    AdjustmentScenarioList.add(buf1.toString());
				i++;
			    
			}else if(i==5) {

				/*
				 * Scenario 5 : create 2 claim records with same details from query with following changes
				 * For first record
				 * •Adjustment indicator as 'A'
				 * •Same amount with -ve sign
				 * For second record
				 * •Adjustment indicator as 'P'
				 * •Check date =System date
				 * •Version number =version number return form DB +1
				 * •Amount fields = (10% of amount received from DB) - (amount received form DB) with positive sign
				 * 
				 */
				
				StringBuffer buf = new StringBuffer(adjustmentScenario);
				buf.replace(328, 329, "A");
				BigDecimal claimAmount = new BigDecimal(adjustmentScenario.substring(90,99).trim()).abs().multiply(new BigDecimal("-1.00")).setScale(2, BigDecimal.ROUND_HALF_UP);
				BigDecimal clientPrice = new BigDecimal(adjustmentScenario.substring(100,109).trim()).abs().multiply(new BigDecimal("-1.00")).setScale(2, BigDecimal.ROUND_HALF_UP);
				BigDecimal bscRevenueAmount = new BigDecimal(adjustmentScenario.substring(110,119).trim()).abs().multiply(new BigDecimal("-1.00")).setScale(2, BigDecimal.ROUND_HALF_UP);
				BigDecimal billedAmount = new BigDecimal(adjustmentScenario.substring(240,249).trim()).abs().multiply(new BigDecimal("-1.00")).setScale(2, BigDecimal.ROUND_HALF_UP);
				BigDecimal allowedAmount = new BigDecimal(adjustmentScenario.substring(250,259).trim()).abs().multiply(new BigDecimal("-1.00")).setScale(2, BigDecimal.ROUND_HALF_UP);
				BigDecimal deductible = new BigDecimal(adjustmentScenario.substring(260,269).trim()).abs().multiply(new BigDecimal("-1.00")).setScale(2, BigDecimal.ROUND_HALF_UP);
				BigDecimal coInsurance = new BigDecimal(adjustmentScenario.substring(270,279).trim().trim()).abs().multiply(new BigDecimal("-1.00")).setScale(2, BigDecimal.ROUND_HALF_UP);
				BigDecimal copay =new BigDecimal(adjustmentScenario.substring(280,289).trim().trim()).abs().multiply(new BigDecimal("-1.00")).setScale(2, BigDecimal.ROUND_HALF_UP);
				
				StringBuffer buf1 = buf;
				String billedAmt = adjustmentScenario.substring(110,119).trim();
				
				buf.replace(90, 99, BorFileHelper.padRight(String.valueOf(claimAmount).trim(), 9));
				buf.replace(100, 109, BorFileHelper.padRight(String.valueOf(clientPrice).trim(), 9));
				buf.replace(110, 119, BorFileHelper.padRight(String.valueOf(bscRevenueAmount).trim(), 9));
				buf.replace(240, 249, BorFileHelper.padRight(String.valueOf(billedAmount).trim().trim(), 9));
				buf.replace(250, 259, BorFileHelper.padRight(String.valueOf(allowedAmount).trim(), 9));
				buf.replace(260, 269, BorFileHelper.padRight(String.valueOf(deductible).trim(), 9));
				buf.replace(270, 279, BorFileHelper.padRight(String.valueOf(coInsurance).trim(), 9));
				buf.replace(280, 289, BorFileHelper.padRight(String.valueOf(copay).trim(), 9));
				
			    AdjustmentScenarioList.add(buf.toString());
				
				buf1.replace(328, 329, "A");
				SimpleDateFormat dateFormat = new SimpleDateFormat("dd-MMM-yy");
				String today = dateFormat.format(new Date()).toUpperCase();
				buf1.replace(127, 136, today);
				
				Integer claimVersionNumber = Integer.parseInt(adjustmentScenario.substring(89,90))+1;
				buf1.replace(89, 90, String.valueOf(claimVersionNumber));
				
				BigDecimal dbBilledAmount1 = new BigDecimal(billedAmt).abs().multiply(new BigDecimal("-1.00"));
				Map<String, String> amountFieldsMap1 = BorFileHelper.getAmountFields(dbBilledAmount1.subtract(dbBilledAmount1.multiply(new BigDecimal("0.1"))).setScale(2, BigDecimal.ROUND_HALF_UP).abs());
				buf1.replace(90, 99, BorFileHelper.padRight(amountFieldsMap1.get("ClaimAmount"), 9));
				buf1.replace(100, 109, BorFileHelper.padRight(amountFieldsMap1.get("ClientPrice"), 9));
				buf1.replace(110, 119, BorFileHelper.padRight(amountFieldsMap1.get("BscRevenueAmount"), 9));
				buf1.replace(240, 249, BorFileHelper.padRight(amountFieldsMap1.get("BilledAmount").trim(), 9));
				buf1.replace(250, 259, BorFileHelper.padRight(amountFieldsMap1.get("AllowedAmount"), 9));
				buf1.replace(260, 269, BorFileHelper.padRight(amountFieldsMap1.get("Deductible"), 9));
				buf1.replace(270, 279, BorFileHelper.padRight(amountFieldsMap1.get("CoInsurance"), 9));
				buf1.replace(280, 289, BorFileHelper.padRight(amountFieldsMap1.get("Copay"), 9));
				
			    AdjustmentScenarioList.add(buf1.toString());
				i++;
			    
			
			}else if(i==6) {
				/*
				 * Scenario 6 : Duplicate Adjustment Record : (Duplicate Reversal Scenario 1)
				 */
				StringBuffer buf = new StringBuffer(adjustmentScenario);
				buf.replace(328, 329, "P");
				
				SimpleDateFormat dateFormat = new SimpleDateFormat("dd-MMM-yy");
				String today = dateFormat.format(new Date()).toUpperCase();
				buf.replace(127, 136, today);
				
				Integer claimVersionNumber = Integer.parseInt(adjustmentScenario.substring(89,90))+1;
				buf.replace(89, 90, String.valueOf(claimVersionNumber));
				
				BigDecimal dbBilledAmount = new BigDecimal(adjustmentScenario.substring(100,109).trim());
				Map<String, String> amountFieldsMap = BorFileHelper.getAmountFields(dbBilledAmount.multiply(new BigDecimal("0.1")).setScale(2, BigDecimal.ROUND_HALF_UP).abs());
				buf.replace(90, 99, BorFileHelper.padRight(amountFieldsMap.get("ClaimAmount"), 9));
				buf.replace(100, 109, BorFileHelper.padRight(amountFieldsMap.get("ClientPrice"), 9));
				buf.replace(110, 119, BorFileHelper.padRight(amountFieldsMap.get("BscRevenueAmount"), 9));
				
				buf.replace(240, 249, BorFileHelper.padRight(amountFieldsMap.get("BilledAmount").trim(), 9));
				buf.replace(250, 259, BorFileHelper.padRight(amountFieldsMap.get("AllowedAmount"), 9));
				buf.replace(260, 269, BorFileHelper.padRight(amountFieldsMap.get("Deductible"), 9));
				buf.replace(270, 279, BorFileHelper.padRight(amountFieldsMap.get("CoInsurance"), 9));
				buf.replace(280, 289, BorFileHelper.padRight(amountFieldsMap.get("Copay"), 9));
				
				AdjustmentScenarioList.add(buf.toString());
				AdjustmentScenarioList.add(buf.toString());
				
				i++;
				
			}
			
			else {
				//Default
				i++;
			}
			
		}
		return AdjustmentScenarioList;
	}

	

	private String getAdjustmentForClaim(SortedMap<String, String> adjustmentRecord) {

		SimpleDateFormat sdf = new SimpleDateFormat("dd-MMM-yy");
		DateFormat inputFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.S");
		
		String checkDate = adjustmentRecord.get("CHK_DT");
		String svcDate = adjustmentRecord.get("SVC_DT");
		
		try {
			checkDate = sdf.format(inputFormat.parse(checkDate)).toUpperCase();
			svcDate = sdf.format(inputFormat.parse(svcDate)).toUpperCase();
		} catch (ParseException e) {
			System.out.println("Unable to parse the dates!");
			e.printStackTrace();
		}
		
		StringBuilder builder = new StringBuilder();
		builder.append(BorFileHelper.padRight(adjustmentRecord.get("FICT_CLM_ID"),12))
		.append(BorFileHelper.padRight(borFileName,35))
		.append(BorFileHelper.padRight(adjustmentRecord.get("VEND_NM"),4))
		.append(BorFileHelper.padRight(adjustmentRecord.get("GRP_NBR"),8))
		.append(BorFileHelper.padRight(adjustmentRecord.get("SBGRP_ID"), 6))
		.append(BorFileHelper.padRight(adjustmentRecord.get("SBSCR_ID"),9))
		.append(BorFileHelper.padRight(adjustmentRecord.get("PERS_NBR"),2))
		.append(BorFileHelper.padRight(adjustmentRecord.get("CLM_NBR"),12))
		.append("01")
		.append(BorFileHelper.padRight(String.valueOf(new BigDecimal(adjustmentRecord.get("CLM_AMT")).setScale(2, BigDecimal.ROUND_HALF_UP)),10))
		.append(BorFileHelper.padRight(String.valueOf(new BigDecimal(adjustmentRecord.get("CLI_PRC_AMT")).setScale(2, BigDecimal.ROUND_HALF_UP)),10))
		.append(BorFileHelper.padRight(String.valueOf(new BigDecimal(adjustmentRecord.get("BSC_RVNU_AMT")).setScale(2, BigDecimal.ROUND_HALF_UP)),10))
		.append(BorFileHelper.padRight(adjustmentRecord.get("CHK_NBR"),7))
		.append(BorFileHelper.padRight(checkDate,9))
		.append(BorFileHelper.padRight(svcDate,9))
		.append(BorFileHelper.padRight(adjustmentRecord.get("PAYE_ID"),9))
		.append(BorFileHelper.padRight(adjustmentRecord.get("PAYE_NM"),50))
		.append(BorFileHelper.padRight(adjustmentRecord.get("PLN_ID"),8))
		.append(BorFileHelper.padRight(adjustmentRecord.get("PRDCT_ID"),8))
		.append(BorFileHelper.padRight(adjustmentRecord.get("PRDCT_CATEG_CD"),1))
		.append(BorFileHelper.padRight(adjustmentRecord.get("CLS_ID"),4))
		.append(BorFileHelper.padRight(adjustmentRecord.get("PRDCT_BUS_CATEG_CD"),4))
		.append(BorFileHelper.padRight(adjustmentRecord.get("PRDCT_VAL1_CD"),4))
		.append(BorFileHelper.padRight(adjustmentRecord.get("LOB_ID"),4))
		.append(BorFileHelper.padRight(adjustmentRecord.get("LGL_ENTY_CD"),4))
		.append(BorFileHelper.padRight(String.valueOf(new BigDecimal(adjustmentRecord.get("BIL_AMT")).setScale(2, BigDecimal.ROUND_HALF_UP)),10))
		.append(BorFileHelper.padRight(String.valueOf(new BigDecimal(adjustmentRecord.get("ALLOW_AMT")).setScale(2, BigDecimal.ROUND_HALF_UP)),10))
		.append(BorFileHelper.padRight(String.valueOf(new BigDecimal(adjustmentRecord.get("DED_AMT")).setScale(2, BigDecimal.ROUND_HALF_UP)),10))
		.append(BorFileHelper.padRight(String.valueOf(new BigDecimal(adjustmentRecord.get("COINS_AMT")).setScale(2, BigDecimal.ROUND_HALF_UP)),10))
		.append(BorFileHelper.padRight(String.valueOf(new BigDecimal(adjustmentRecord.get("COPAY_AMT")).setScale(2, BigDecimal.ROUND_HALF_UP)),10))
		.append(BorFileHelper.padRight(adjustmentRecord.get("DIAG_CD"),10))
		.append(" ")
		.append(BorFileHelper.padRight(adjustmentRecord.get("PROC_CD"),7))
		.append(BorFileHelper.padRight(" ",19))
		.append("A");

		return builder.toString();
	}

	private String getPaidScenarioForSubscriber(SortedMap<String, String> selectedSubscriberDataMap) {

		StringBuilder builder = new StringBuilder();
		int payeeIndex = new Random().nextInt(16);
		String[] payee = pharmacies[payeeIndex].split(",");
		String payeeId = payee[0];
		String payeeName = payee[1];
		String todayDate = BorFileHelper.getTodaysDate();
		String claimId = BorFileHelper.generateUniqueClaimId();
		String checkNumber = BorFileHelper.generateCheckNumber();
		String fictClmId = claimId.replace("R", "2");
		BigDecimal billedAmount = new BigDecimal(ThreadLocalRandom.current().nextInt(400, 999 + 1)).setScale(2,
				BigDecimal.ROUND_HALF_UP).abs();
		Map<String, String> amountFields = BorFileHelper.getAmountFields(billedAmount);
		String personNumber = "0" + String.valueOf(selectedSubscriberDataMap.get("MEMSFX"));

		builder.append(BorFileHelper.padRight(claimId,12))
		.append(BorFileHelper.padRight(borFileName,35))
		.append( "ARGS")
		.append(BorFileHelper.padRight(selectedSubscriberDataMap.get("GRPID"),8))
		.append(BorFileHelper.padRight(selectedSubscriberDataMap.get("SUBGRPID"), 6))
		.append(BorFileHelper.padRight(selectedSubscriberDataMap.get("SUBID"),9))
		.append(BorFileHelper.padRight(personNumber,2))
		.append(BorFileHelper.padRight(fictClmId,12))
		.append("00")
		.append(BorFileHelper.padRight(amountFields.get("ClaimAmount"),10))
		.append(BorFileHelper.padRight(amountFields.get("ClientPrice"),10))
		.append(BorFileHelper.padRight(amountFields.get("BscRevenueAmount"),10))
		.append(BorFileHelper.padRight(checkNumber,7))
		.append(BorFileHelper.padRight(todayDate,9))
		.append(BorFileHelper.padRight(todayDate,9))
		.append(BorFileHelper.padRight(payeeId,9))
		.append(BorFileHelper.padRight(payeeName,50))
		.append(BorFileHelper.padRight(selectedSubscriberDataMap.get("PLANID"),8))
		.append(BorFileHelper.padRight(selectedSubscriberDataMap.get("PRDID"),8))
		.append(BorFileHelper.padRight(selectedSubscriberDataMap.get("PRDCAT"),1))
		.append(BorFileHelper.padRight(selectedSubscriberDataMap.get("CLASSID"),4))
		.append(BorFileHelper.padRight(selectedSubscriberDataMap.get("PRDBUSCAT"),4))
		.append(BorFileHelper.padRight(selectedSubscriberDataMap.get("PRDVALCD"),4))
		.append(BorFileHelper.padRight(selectedSubscriberDataMap.get("LOBDID"),4))
		.append(BorFileHelper.padRight(selectedSubscriberDataMap.get("LOBDTYPE"),4))
		.append(BorFileHelper.padRight(amountFields.get("BilledAmount"),10))
		.append(BorFileHelper.padRight(amountFields.get("AllowedAmount"),10))
		.append(BorFileHelper.padRight(amountFields.get("Deductible"),10))
		.append(BorFileHelper.padRight(amountFields.get("CoInsurance"),10))
		.append(BorFileHelper.padRight(amountFields.get("Copay"),10))
		.append(BorFileHelper.padRight("9999",10))
		.append(" ")
		.append(BorFileHelper.padRight("99199",7))
		.append(BorFileHelper.padRight(" ",19))
		.append( "P");

		return builder.toString();
	}

}
