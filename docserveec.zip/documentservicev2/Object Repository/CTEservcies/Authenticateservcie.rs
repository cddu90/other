<?xml version="1.0" encoding="UTF-8"?>
<WebServiceRequestEntity>
   <description></description>
   <name>Authenticateservcie</name>
   <tag></tag>
   <elementGuidId>cd7f27df-f716-4a6d-9b19-3aef4f9826f7</elementGuidId>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <followRedirects>false</followRedirects>
   <httpBody></httpBody>
   <httpBodyContent>{
  &quot;text&quot;: &quot;{\n    \&quot;requestBody\&quot;: {\n        \&quot;authenticationCredentials\&quot;: {\n            \&quot;authenticationCredential\&quot;: [\n                {\n                    \&quot;parameterName\&quot;: \&quot;USERNAME\&quot;,\n                    \&quot;parameterValue\&quot;: \&quot;${userid}\&quot;\n                },\n                {\n                    \&quot;parameterName\&quot;: \&quot;PASSWORD\&quot;,\n                    \&quot;parameterValue\&quot;: \&quot;Blue$hield1\&quot;\n                }\n            ]\n        },\n        \&quot;authenticationType\&quot;: \&quot;USERNAME_PASSWORD\&quot;\n    },\n    \&quot;requestHeader\&quot;: {\n        \&quot;consumer\&quot;: {\n            \&quot;businessTransactionType\&quot;: \&quot;AUTHENTICATION\&quot;,\n            \&quot;businessUnit\&quot;: \&quot;CHANNELS\&quot;,\n            \&quot;clientVersion\&quot;: \&quot;V1\&quot;,\n            \&quot;contextId\&quot;: \&quot;\&quot;,\n            \&quot;hostName\&quot;: \&quot;MOBILE\&quot;,\n            \&quot;id\&quot;: \&quot;MEMBER\&quot;,\n            \&quot;name\&quot;: \&quot;MOBILE\&quot;,\n            \&quot;requestDateTime\&quot;: \&quot;2017-12-08 08:41:47\&quot;,\n            \&quot;secondContextId\&quot;: \&quot;\&quot;,\n            \&quot;thirdContextId\&quot;: \&quot;\&quot;,\n            \&quot;type\&quot;: \&quot;INTERNAL\&quot;\n        },\n        \&quot;credentials\&quot;: {\n            \&quot;password\&quot;: \&quot;\&quot;,\n            \&quot;token\&quot;: \&quot;eyJhbGciOiJIUzI1NiJ9.eyJqdGkiOiJTZXJ2aWNlRGVza3RvcF9CbHVlc2hpZWxkQ0EiLCJpYXQiOjE0OTQyODY0NTMsInN1YiI6IkJsdWUgU2hpbGVkIG9mIENhbGlmb3JuaWEiLCJpc3MiOiJCbHVlc2hpZWxkQ0EiLCJleHAiOjE0OTQ1MDU0NTN9.7Pds-xLnZXkt7eWMhMSUyt0KQZmgNsrL8RMrUUENZCk\&quot;,\n            \&quot;type\&quot;: \&quot;JWT\&quot;,\n            \&quot;userName\&quot;: \&quot;\&quot;\n        },\n        \&quot;transactionId\&quot;: \&quot;2424c6fd-9dbe-4a56-aaee-b4a5514464f3\&quot;\n    }\n}\n&quot;,
  &quot;contentType&quot;: &quot;application/json&quot;,
  &quot;charset&quot;: &quot;UTF-8&quot;
}</httpBodyContent>
   <httpBodyType>text</httpBodyType>
   <httpHeaderProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>Content-Type</name>
      <type>Main</type>
      <value>application/json</value>
   </httpHeaderProperties>
   <httpHeaderProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>X-IBM-Client-Id</name>
      <type>Main</type>
      <value>${clientid}</value>
   </httpHeaderProperties>
   <httpHeaderProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>X-IBM-Client-Secret</name>
      <type>Main</type>
      <value>${clientsecret}</value>
   </httpHeaderProperties>
   <migratedVersion>5.4.1</migratedVersion>
   <restRequestMethod>POST</restRequestMethod>
   <restUrl>${AuthenticateservcieEndpoint}</restUrl>
   <serviceType>RESTful</serviceType>
   <soapBody></soapBody>
   <soapHeader></soapHeader>
   <soapRequestMethod></soapRequestMethod>
   <soapServiceFunction></soapServiceFunction>
   <verificationScript>import static org.assertj.core.api.Assertions.*

import com.kms.katalon.core.testobject.RequestObject
import com.kms.katalon.core.testobject.ResponseObject
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WS
import com.kms.katalon.core.webservice.verification.WSResponseManager

import groovy.json.JsonSlurper
import internal.GlobalVariable as GlobalVariable

RequestObject request = WSResponseManager.getInstance().getCurrentRequest()

ResponseObject response = WSResponseManager.getInstance().getCurrentResponse()



ResponseObject response = WSResponseManager.getInstance().getCurrentResponse()


ResponseObject response = WSResponseManager.getInstance().getCurrentResponse()
WS.verifyElementPropertyValue(response, 'responseBody.planMember.memberIdentifierSuffixNumber', &quot;91021217400&quot;)


WS.verifyElementPropertyValue(response, 'issues[0].fields.project.key', 'KTP')


WS.verifyElementPropertyValue(response, 'issues[0].fields.project.key', 'KTP')


WS.verifyElementPropertyValue(response, 'responseBody.planMember.memberEmailAddress', &quot;20000101&quot;)
WS.verifyElementPropertyValue(response, 'responseBody.planMember.memberEmailAddress', &quot;20000101&quot;)
WS.verifyElementPropertyValue(response, 'responseBody.planMember.memberEmailAddress', &quot;20000101&quot;)
WS.verifyElementPropertyValue(response, 'responseBody.planMember.memberBirthDate', &quot;&quot;)</verificationScript>
   <wsdlAddress></wsdlAddress>
</WebServiceRequestEntity>
