<?xml version="1.0" encoding="UTF-8"?>
<WebServiceRequestEntity>
   <description></description>
   <name>MessagecenterCreate</name>
   <tag></tag>
   <elementGuidId>d1826d20-d581-4271-8844-678830eeef51</elementGuidId>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <followRedirects>false</followRedirects>
   <httpBody></httpBody>
   <httpBodyContent>{
  &quot;text&quot;: &quot; \n{\n\t\&quot;requestHeader\&quot;: {\n\t\t\&quot;consumer\&quot;: {\n\t\t\t\&quot;name\&quot;: \&quot;MemberAutoDelegationService\&quot;,\n\t\t\t\&quot;id\&quot;: \&quot;MemberAutoDelegationService\&quot;,\n\t\t\t\&quot;businessUnit\&quot;: null,\n\t\t\t\&quot;type\&quot;: \&quot;INTERNAL\&quot;,\n\t\t\t\&quot;clientVersion\&quot;: null,\n\t\t\t\&quot;requestDateTime\&quot;: null,\n\t\t\t\&quot;hostName\&quot;: \&quot;BSCWL800343\&quot;,\n\t\t\t\&quot;businessTransactionType\&quot;: \&quot;MessageCenter\&quot;,\n\t\t\t\&quot;contextId\&quot;: null,\n\t\t\t\&quot;secondContextId\&quot;: null,\n\t\t\t\&quot;thirdContextId\&quot;: null\n\t\t},\n\t\t\&quot;credentials\&quot;: {\n\t\t\t\&quot;userName\&quot;: null,\n\t\t\t\&quot;password\&quot;: null,\n\t\t\t\&quot;token\&quot;: \&quot;eyJhbGciOiJIUzI1NiJ9.eyJqdGkiOiJTZXJ2aWNlRGVza3RvcF9CbHVlc2hpZWxkQ0EiLCJpYXQiOjE0OTQyODY0NTMsInN1YiI6IkJsdWUgU2hpbGVkIG9mIENhbGlmb3JuaWEiLCJpc3MiOiJCbHVlc2hpZWxkQ0EiLCJleHAiOjE0OTQ1MDU0NTN9.7Pds-xLnZXkt7eWMhMSUyt0KQZmgNsrL8RMrUUENZCk\&quot;,\n\t\t\t\&quot;type\&quot;: \&quot;\&quot;\n\t\t},\n\t\t\&quot;transactionId\&quot;: \&quot;string\&quot;\n\t},\n\t\&quot;requestBody\&quot;: {\n\t\t\&quot;planMember\&quot;: {\n\t\t\t\&quot;memberIdentifier\&quot;: \&quot;${memberIdentifier}\&quot;,\n\t\t\t\&quot;groupNumber\&quot;: \&quot;${groupNumber}\&quot;,\n\t\t\t\&quot;userId\&quot;: \&quot;436109693\&quot;,\n\t\t\t\&quot;emailAddress\&quot;: \&quot;90000002300@abc.com\&quot;,\n\t\t\t\&quot;offset\&quot;: null,\n\t\t\t\&quot;limit\&quot;: null,\n\t\t\t\&quot;sortBy\&quot;: null,\n\t\t\t\&quot;sortOrder\&quot;: null,\n\t\t\t\&quot;messages\&quot;: {\n\t\t\t\t\&quot;message\&quot;: [\n\t\t\t\t\t{\n\t\t\t\t\t\t\&quot;messageId\&quot;: null,\n\t\t\t\t\t\t\&quot;subjectText\&quot;: \&quot;${subjectText}\&quot;,\n\t\t\t\t\t\t\&quot;messageBodyVarText\&quot;: \&quot;${messageBodyVarText}\&quot;,\n\t\t\t\t\t\t\&quot;messageTypeCode\&quot;: \&quot;${messageTypeCode}\&quot;,\n\t\t\t\t\t\t\&quot;versionNumber\&quot;: \&quot;1\&quot;,\n\t\t\t\t\t\t\&quot;profileDelegationId\&quot;: null,\n\t\t\t\t\t\t\&quot;pdRequestId\&quot;: null,\n\t\t\t\t\t\t\&quot;acknowledgeTokenIndicator\&quot;: \&quot;N\&quot;,\n\t\t\t\t\t\t\&quot;documentId\&quot;: \&quot;${documentId}\&quot;,\n\t\t\t\t\t\t\&quot;documentName\&quot;: \&quot;ageout-ifp-md-or-spc-91191174300-06192110164240246.pdf\&quot;,\n\t\t\t\t\t\t\&quot;documentType\&quot;: \&quot;${documentType}\&quot;,\n\t\t\t\t\t\t\&quot;additionalInfo\&quot;: [\n\t\t\t\t\t\t\t{\n\t\t\t\t\t\t\t\t\n\t\t\t\t\t\t\t\t\&quot;custAttributeName\&quot;: \&quot;memberId\&quot;,\n\t\t\t\t\t\t\t\t\&quot;custAttributeValue\&quot;: \&quot;${memberIdentifier}\&quot;\n\t\t\t\t\t\t\t}\n\t\t\t\t\t\t\n\t\t\t\t\t\t]\n\t\t\t\t\t}\n\t\t\t\t]\n\t\t\t}\n\t\t}\n\t}\n}&quot;,
  &quot;contentType&quot;: &quot;application/json&quot;,
  &quot;charset&quot;: &quot;UTF-8&quot;
}</httpBodyContent>
   <httpBodyType>text</httpBodyType>
   <httpHeaderProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>Content-Type</name>
      <type>Main</type>
      <value>application/json</value>
   </httpHeaderProperties>
   <migratedVersion>5.4.1</migratedVersion>
   <restRequestMethod>POST</restRequestMethod>
   <restUrl>${MessagecreateEndpoint}</restUrl>
   <serviceType>RESTful</serviceType>
   <soapBody></soapBody>
   <soapHeader></soapHeader>
   <soapRequestMethod></soapRequestMethod>
   <soapServiceFunction></soapServiceFunction>
   <verificationScript>import static org.assertj.core.api.Assertions.*

import com.kms.katalon.core.testobject.RequestObject
import com.kms.katalon.core.testobject.ResponseObject
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WS
import com.kms.katalon.core.webservice.verification.WSResponseManager

import groovy.json.JsonSlurper
import internal.GlobalVariable as GlobalVariable

RequestObject request = WSResponseManager.getInstance().getCurrentRequest()

ResponseObject response = WSResponseManager.getInstance().getCurrentResponse()



</verificationScript>
   <wsdlAddress></wsdlAddress>
</WebServiceRequestEntity>
