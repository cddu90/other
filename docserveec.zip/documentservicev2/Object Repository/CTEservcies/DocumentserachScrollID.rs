<?xml version="1.0" encoding="UTF-8"?>
<WebServiceRequestEntity>
   <description></description>
   <name>DocumentserachScrollID</name>
   <tag></tag>
   <elementGuidId>e3b27a9d-59c9-4415-b9a7-79f8229032cf</elementGuidId>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <followRedirects>false</followRedirects>
   <httpBody></httpBody>
   <httpBodyContent>{
  &quot;text&quot;: &quot; \t{\n\t\t\n\t\&quot;requestHeader\&quot;: {\n\t\t\&quot;consumer\&quot;: {\n\t\t\t\&quot;name\&quot;: \&quot;INFORMATICA\&quot;,\n\t\t\t\&quot;id\&quot;: \&quot;INFORMATICA\&quot;,\n\t\t\t\&quot;businessUnit\&quot;: \&quot;CHANNELS\&quot;,\n\t\t\t\&quot;type\&quot;: \&quot;INTERNAL\&quot;,\n\t\t\t\&quot;clientVersion\&quot;: \&quot;\&quot;,\n\t\t\t\&quot;requestDateTime\&quot;: \&quot;2019-04-23 16:39:10:839\&quot;,\n\t\t\t\&quot;hostName\&quot;: \&quot;uapp9022h\&quot;,\n\t\t\t\&quot;businessTransactionType\&quot;: \&quot;BILL_MSG_EMAIL_NOTIFICATION\&quot;,\n\t\t\t\&quot;contextId\&quot;: \&quot;\&quot;,\n\t\t\t\&quot;secondContextId\&quot;: \&quot;\&quot;,\n\t\t\t\&quot;thirdContextId\&quot;: \&quot;\&quot;\n\t\t},\n\t\t\&quot;credentials\&quot;: {\n\t\t\t\&quot;userName\&quot;: \&quot;\&quot;,\n\t\t\t\&quot;password\&quot;: \&quot;\&quot;,\n\t\t\t\&quot;token\&quot;: \&quot;\&quot;,\n\t\t\t\&quot;type\&quot;: \&quot;\&quot;\n\t\t},\n\t\t\&quot;transactionId\&quot;: \&quot;38dc1fc3-be54-4270-8d00-916331bb926d::723492432::0000sVYa7qmjZTfSaX08ULjf0pQ:1c78ivi2i\&quot;\n\t},\n\t\&quot;requestBody\&quot;: {\n\t\t\&quot;searchCriteria\&quot;: {\n\t\t\t\&quot;criteria\&quot;: [\n\t\t\t\t\t{\n\t\t\t\t\t\&quot;key\&quot;: \&quot;scrollId\&quot;,\n\t\t\t\t\t\&quot;value\&quot;: \&quot;${scrollId}\&quot;\n\t\t\t\t}\n\t\t\t]\n\t\t}\n\t}\n} &quot;,
  &quot;contentType&quot;: &quot;application/json&quot;,
  &quot;charset&quot;: &quot;UTF-8&quot;
}</httpBodyContent>
   <httpBodyType>text</httpBodyType>
   <httpHeaderProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>Content-Type</name>
      <type>Main</type>
      <value>application/json</value>
   </httpHeaderProperties>
   <httpHeaderProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>x-ibm-client-id</name>
      <type>Main</type>
      <value>${clientid}</value>
   </httpHeaderProperties>
   <httpHeaderProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>x-ibm-client-secret</name>
      <type>Main</type>
      <value>${clientsecret}</value>
   </httpHeaderProperties>
   <migratedVersion>5.4.1</migratedVersion>
   <restRequestMethod>POST</restRequestMethod>
   <restUrl>${INFDocumentServiceV2Endpoint}</restUrl>
   <serviceType>RESTful</serviceType>
   <soapBody></soapBody>
   <soapHeader></soapHeader>
   <soapRequestMethod></soapRequestMethod>
   <soapServiceFunction></soapServiceFunction>
   <verificationScript>import static org.assertj.core.api.Assertions.*

import com.kms.katalon.core.testobject.RequestObject
import com.kms.katalon.core.testobject.ResponseObject
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WS
import com.kms.katalon.core.webservice.verification.WSResponseManager

import groovy.json.JsonSlurper
import internal.GlobalVariable as GlobalVariable

RequestObject request = WSResponseManager.getInstance().getCurrentRequest()

ResponseObject response = WSResponseManager.getInstance().getCurrentResponse()
</verificationScript>
   <wsdlAddress></wsdlAddress>
</WebServiceRequestEntity>
