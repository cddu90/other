<?xml version="1.0" encoding="UTF-8"?>
<WebServiceRequestEntity>
   <description></description>
   <name>MessageReadIOS</name>
   <tag></tag>
   <elementGuidId>efcdc420-e4bc-472b-a2bd-b920b7873a95</elementGuidId>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <followRedirects>false</followRedirects>
   <httpBody></httpBody>
   <httpBodyContent>{
  &quot;text&quot;: &quot;\n{\n\t\&quot;requestHeader\&quot;: {\n\t\t\&quot;consumer\&quot;: {\n\t\t\t\&quot;name\&quot;: \&quot;MOBILE\&quot;,\n\t\t\t\&quot;id\&quot;: \&quot;MOBILE\&quot;,\n\t\t\t\&quot;businessUnit\&quot;: null,\n\t\t\t\&quot;type\&quot;: \&quot;INTERNAL\&quot;,\n\t\t\t\&quot;clientVersion\&quot;: \&quot;dw\&quot;,\n\t\t\t\&quot;requestDateTime\&quot;: \&quot;ssf\&quot;,\n\t\t\t\&quot;hostName\&quot;: \&quot;BSCWL800343\&quot;,\n\t\t\t\&quot;businessTransactionType\&quot;: \&quot;MESSAGE_ALL_READ\&quot;,\n\t\t\t\&quot;contextId\&quot;: \&quot;dgs\&quot;,\n\t\t\t\&quot;secondContextId\&quot;: \&quot;sahcd\&quot;,\n\t\t\t\&quot;thirdContextId\&quot;: \&quot;dahd\&quot;\n\t\t},\n\t\t\&quot;credentials\&quot;: {\n\t\t\t\&quot;userName\&quot;: \&quot;dvsd\&quot;,\n\t\t\t\&quot;password\&quot;: \&quot;dcsdg\&quot;,\n\t\t\t\&quot;token\&quot;: \&quot;eyJhbGciOiJIUzI1NiJ9.eyJqdGkiOiJTZXJ2aWNlRGVza3RvcF9CbHVlc2hpZWxkQ0EiLCJpYXQiOjE0OTQyODY0NTMsInN1YiI6IkJsdWUgU2hpbGVkIG9mIENhbGlmb3JuaWEiLCJpc3MiOiJCbHVlc2hpZWxkQ0EiLCJleHAiOjE0OTQ1MDU0NTN9.7Pds-xLnZXkt7eWMhMSUyt0KQZmgNsrL8RMrUUENZCk\&quot;,\n\t\t\t\&quot;type\&quot;: \&quot;\&quot;\n\t\t},\n\t\t\&quot;transactionId\&quot;: \&quot;wdqtweqt\&quot;\n\t},\n\t\&quot;requestBody\&quot;: {\n\t\t\&quot;planMember\&quot;: {\n\t\t\t\&quot;memberIdentifier\&quot;: \&quot;${memberIdentifier}\&quot;,\n\t\t\t\&quot;groupNumber\&quot;: \&quot;${groupNumber}\&quot;,\n\t\t\t\&quot;offset\&quot;: \&quot;\&quot;,\n\t\t\t\&quot;limit\&quot;: \&quot;\&quot;,\n\t\t\t\&quot;sortBy\&quot;: \&quot;DATE\&quot;,\n\t\t\t\&quot;sortOrder\&quot;: \&quot;DESC\&quot;,\n\t\t\t\&quot;filter\&quot;: {\n\t\t\t\t\&quot;folderName\&quot;: \&quot; \&quot;\n\t\t\t}\n\t\t}\n\t}\n} \n &quot;,
  &quot;contentType&quot;: &quot;application/json&quot;,
  &quot;charset&quot;: &quot;UTF-8&quot;
}</httpBodyContent>
   <httpBodyType>text</httpBodyType>
   <httpHeaderProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>Content-Type</name>
      <type>Main</type>
      <value>application/json</value>
   </httpHeaderProperties>
   <httpHeaderProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>X-IBM-Client-Id</name>
      <type>Main</type>
      <value>${iosclientidread}</value>
   </httpHeaderProperties>
   <httpHeaderProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>X-IBM-Client-Secret</name>
      <type>Main</type>
      <value>${iosclientsecret}</value>
   </httpHeaderProperties>
   <httpHeaderProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>x-bsc-ltpa-token</name>
      <type>Main</type>
      <value>${respLTPAtoken}</value>
   </httpHeaderProperties>
   <httpHeaderProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>mbrNum</name>
      <type>Main</type>
      <value>${memberIdentifier}</value>
   </httpHeaderProperties>
   <httpHeaderProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>birthDate</name>
      <type>Main</type>
      <value>${memberBirthDate}</value>
   </httpHeaderProperties>
   <migratedVersion>5.4.1</migratedVersion>
   <restRequestMethod>POST</restRequestMethod>
   <restUrl>${MessageReadIOSEndpoint}</restUrl>
   <serviceType>RESTful</serviceType>
   <soapBody></soapBody>
   <soapHeader></soapHeader>
   <soapRequestMethod></soapRequestMethod>
   <soapServiceFunction></soapServiceFunction>
   <verificationScript>import static org.assertj.core.api.Assertions.*

import com.kms.katalon.core.testobject.RequestObject
import com.kms.katalon.core.testobject.ResponseObject
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WS
import com.kms.katalon.core.webservice.verification.WSResponseManager

import groovy.json.JsonSlurper
import internal.GlobalVariable as GlobalVariable

RequestObject request = WSResponseManager.getInstance().getCurrentRequest()

ResponseObject response = WSResponseManager.getInstance().getCurrentResponse()
</verificationScript>
   <wsdlAddress></wsdlAddress>
</WebServiceRequestEntity>
