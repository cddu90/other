<?xml version="1.0" encoding="UTF-8"?>
<WebServiceRequestEntity>
   <description></description>
   <name>Elasticsearch</name>
   <tag></tag>
   <elementGuidId>d554c141-7150-4c62-9c9b-b3d1394049f5</elementGuidId>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <followRedirects>false</followRedirects>
   <httpBody></httpBody>
   <httpBodyContent>{
  &quot;text&quot;: &quot; {\n\t\&quot;requestHeader\&quot;: {\n\t\t\&quot;consumer\&quot;: {\n\t\t\t\&quot;name\&quot;: \&quot;internal\&quot;,\n\t\t\t\&quot;id\&quot;: \&quot;internal\&quot;,\n\t\t\t\&quot;businessUnit\&quot;: \&quot;\&quot;,\n\t\t\t\&quot;type\&quot;: \&quot;internal\&quot;,\n\t\t\t\&quot;clientVersion\&quot;: \&quot;\&quot;,\n\t\t\t\&quot;requestDateTime\&quot;: \&quot;\&quot;,\n\t\t\t\&quot;hostName\&quot;: \&quot;internal\&quot;,\n\t\t\t\&quot;businessTransactionType\&quot;: \&quot;internal\&quot;,\n\t\t\t\&quot;contextId\&quot;: \&quot;\&quot;,\n\t\t\t\&quot;secondContextId\&quot;: \&quot;\&quot;,\n\t\t\t\&quot;thirdContextId\&quot;: \&quot;\&quot;\n\t\t},\n\t\t\&quot;credentials\&quot;: {\n\t\t\t\&quot;userName\&quot;: \&quot;\&quot;,\n\t\t\t\&quot;password\&quot;: \&quot;\&quot;,\n\t\t\t\&quot;token\&quot;: \&quot;\&quot;,\n\t\t\t\&quot;type\&quot;: \&quot;\&quot;\n\t\t},\n\t\t\&quot;transactionId\&quot;: \&quot;internal\&quot;\n\t},\n\t\&quot;requestBody\&quot;: {\n\t\t\&quot;indexes\&quot;: [\n\t\t\t\&quot;digitaldocs-bill-*\&quot;\n\t\t],\n\t\t\&quot;scrollId\&quot;: \&quot;\&quot;,\n\t\t\&quot;query\&quot;: {\n\t\t\t\&quot;size\&quot;: 10,\n\t\t\t\&quot;min_score\&quot;: 0.01,\n\t\t\t\&quot;query\&quot;: {\n\t\t\t\t\&quot;bool\&quot;: {\n\t\t\t\t\t\&quot;must\&quot;: [\n\t\t\t\t\t\t{\n\t\t\t\t\t\t\t\&quot;range\&quot;: {\n\t\t\t\t\t\t\t\t\&quot;lastUpdate2Date\&quot;: {\n\t\t\t\t\t\t\t\t\t\&quot;gte\&quot;: \&quot;${lastUpdate2Dateminusoneday}\&quot;\n\t\t\t\t\t\t\t\t}\n\t\t\t\t\t\t\t}\n\t\t\t\t\t\t},\n\t\t\t\t\t\t{\n\t\t\t\t\t\t\t\&quot;range\&quot;: {\n\t\t\t\t\t\t\t\t\&quot;lastUpdate2Date\&quot;: {\n\t\t\t\t\t\t\t\t\t\&quot;lte\&quot;: \&quot;${lastUpdate2Date}\&quot;\n\t\t\t\t\t\t\t\t}\n\t\t\t\t\t\t\t}\n\t\t\t\t\t\t}\n\t\t\t\t\t],\n\t\t\t\t\t\&quot;must_not\&quot;: [\n\t\t\t\t\t\t{\n\t\t\t\t\t\t\t\&quot;match\&quot;: {\n\t\t\t\t\t\t\t\t\&quot;billTypeInd\&quot;: \&quot;SPCBILL\&quot;\n\t\t\t\t\t\t\t}\n\t\t\t\t\t\t}\n\t\t\t\t\t]\n\t\t\t\t}\n\t\t\t},\n\t\t\t\&quot;_source\&quot;: {\n\t\t\t\t\&quot;includes\&quot;: [],\n\t\t\t\t\&quot;excludes\&quot;: [\n\t\t\t\t]\n\t\t\t}\n\t\t},\n\t\t\&quot;scroll\&quot;: true\n\t}\n}&quot;,
  &quot;contentType&quot;: &quot;application/json&quot;,
  &quot;charset&quot;: &quot;UTF-8&quot;
}</httpBodyContent>
   <httpBodyType>text</httpBodyType>
   <httpHeaderProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>Content-Type</name>
      <type>Main</type>
      <value>application/json</value>
   </httpHeaderProperties>
   <httpHeaderProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>x-ibm-client-id</name>
      <type>Main</type>
      <value>${clientid}</value>
   </httpHeaderProperties>
   <httpHeaderProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>x-ibm-client-secret</name>
      <type>Main</type>
      <value>${clientsecret}</value>
   </httpHeaderProperties>
   <migratedVersion>5.4.1</migratedVersion>
   <restRequestMethod>POST</restRequestMethod>
   <restUrl>${ElasticsearchEndpoint}</restUrl>
   <serviceType>RESTful</serviceType>
   <soapBody></soapBody>
   <soapHeader></soapHeader>
   <soapRequestMethod></soapRequestMethod>
   <soapServiceFunction></soapServiceFunction>
   <verificationScript>import static org.assertj.core.api.Assertions.*

import com.kms.katalon.core.testobject.RequestObject
import com.kms.katalon.core.testobject.ResponseObject
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WS
import com.kms.katalon.core.webservice.verification.WSResponseManager

import groovy.json.JsonSlurper
import internal.GlobalVariable as GlobalVariable

RequestObject request = WSResponseManager.getInstance().getCurrentRequest()

ResponseObject response = WSResponseManager.getInstance().getCurrentResponse()
</verificationScript>
   <wsdlAddress></wsdlAddress>
</WebServiceRequestEntity>
