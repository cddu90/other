<?xml version="1.0" encoding="UTF-8"?>
<WebServiceRequestEntity>
   <description></description>
   <name>AndroiddocumentSearch</name>
   <tag></tag>
   <elementGuidId>11a76575-3d30-4502-9283-0b4eca283f08</elementGuidId>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <followRedirects>false</followRedirects>
   <httpBody></httpBody>
   <httpBodyContent>{
  &quot;text&quot;: &quot;{\n\t\&quot;requestHeader\&quot;: {\n\t\t\&quot;consumer\&quot;: {\n\t\t\t\&quot;name\&quot;: \&quot;INFORMATICA\&quot;,\n\t\t\t\&quot;id\&quot;: \&quot;INFORMATICA\&quot;,\n\t\t\t\&quot;businessUnit\&quot;: \&quot;CHANNELS\&quot;,\n\t\t\t\&quot;type\&quot;: \&quot;INTERNAL\&quot;,\n\t\t\t\&quot;clientVersion\&quot;: \&quot;\&quot;,\n\t\t\t\&quot;requestDateTime\&quot;: \&quot;2019-04-23 16:39:10:839\&quot;,\n\t\t\t\&quot;hostName\&quot;: \&quot;uapp9022h\&quot;,\n\t\t\t\&quot;businessTransactionType\&quot;: \&quot;BILL_MSG_EMAIL_NOTIFICATION\&quot;,\n\t\t\t\&quot;contextId\&quot;: \&quot;\&quot;,\n\t\t\t\&quot;secondContextId\&quot;: \&quot;\&quot;,\n\t\t\t\&quot;thirdContextId\&quot;: \&quot;\&quot;\n\t\t},\n\t\t\&quot;credentials\&quot;: {\n\t\t\t\&quot;userName\&quot;: \&quot;\&quot;,\n\t\t\t\&quot;password\&quot;: \&quot;\&quot;,\n\t\t\t\&quot;token\&quot;: \&quot;\&quot;,\n\t\t\t\&quot;type\&quot;: \&quot;\&quot;\n\t\t},\n\t\t\&quot;transactionId\&quot;: \&quot;38dc1fc3-be54-4270-8d00-916331bb926d::723492432::0000sVYa7qmjZTfSaX08ULjf0pQ:1c78ivi2i\&quot;\n\t},\n\t\&quot;requestBody\&quot;: {\n\t\t\&quot;searchCriteria\&quot;: {\n\t\t\t\&quot;criteria\&quot;: [\n\t\t\t\t\n\n\t\t\t\t{\n\t\t\t\t\t\&quot;key\&quot;: \&quot;documentOwner\&quot;,\n\t\t\t\t\t\&quot;value\&quot;: \&quot;${memberIdentifier}\&quot;\n\t\t\t\t}\n\t\t\t\t\n\t\t\t\t\t\n\t\t\t\t\n\t\t\t\n\t\t\t]\n\t\t}\n\t}\n}&quot;,
  &quot;contentType&quot;: &quot;application/json&quot;,
  &quot;charset&quot;: &quot;UTF-8&quot;
}</httpBodyContent>
   <httpBodyType>text</httpBodyType>
   <httpHeaderProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>Content-Type</name>
      <type>Main</type>
      <value>application/json</value>
   </httpHeaderProperties>
   <httpHeaderProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>X-IBM-Client-Id</name>
      <type>Main</type>
      <value>${Andriodmobileclientid}</value>
   </httpHeaderProperties>
   <httpHeaderProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>X-IBM-Client-Secret</name>
      <type>Main</type>
      <value>${Andriodmobileclientsecret}</value>
   </httpHeaderProperties>
   <httpHeaderProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>x-bsc-ltpa-token</name>
      <type>Main</type>
      <value>${respLTPAtoken}</value>
   </httpHeaderProperties>
   <httpHeaderProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>mbrNum</name>
      <type>Main</type>
      <value>${memberIdentifier}</value>
   </httpHeaderProperties>
   <httpHeaderProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>birthDate</name>
      <type>Main</type>
      <value>${memberBirthDate}</value>
   </httpHeaderProperties>
   <migratedVersion>5.4.1</migratedVersion>
   <restRequestMethod>POST</restRequestMethod>
   <restUrl>${DocumentsearchAndriodmobileEndpoint}</restUrl>
   <serviceType>RESTful</serviceType>
   <soapBody></soapBody>
   <soapHeader></soapHeader>
   <soapRequestMethod></soapRequestMethod>
   <soapServiceFunction></soapServiceFunction>
   <verificationScript>import static org.assertj.core.api.Assertions.*

import com.kms.katalon.core.testobject.RequestObject
import com.kms.katalon.core.testobject.ResponseObject
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WS
import com.kms.katalon.core.webservice.verification.WSResponseManager

import groovy.json.JsonSlurper
import internal.GlobalVariable as GlobalVariable

RequestObject request = WSResponseManager.getInstance().getCurrentRequest()

ResponseObject response = WSResponseManager.getInstance().getCurrentResponse()
</verificationScript>
   <wsdlAddress></wsdlAddress>
</WebServiceRequestEntity>
