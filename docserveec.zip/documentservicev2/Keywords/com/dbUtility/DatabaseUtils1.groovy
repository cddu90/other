package com.dbUtility
/*
 import static com.kms.katalon.core.checkpoint.CheckpointFactory.findCheckpoint
 import static com.kms.katalon.core.testcase.TestCaseFactory.findTestCase
 import static com.kms.katalon.core.testdata.TestDataFactory.findTestData
 import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject
 import static com.kms.katalon.core.testobject.ObjectRepository.findWindowsObject
 import com.kms.katalon.core.annotation.Keyword
 import com.kms.katalon.core.checkpoint.Checkpoint
 import com.kms.katalon.core.cucumber.keyword.CucumberBuiltinKeywords as CucumberKW
 import com.kms.katalon.core.mobile.keyword.MobileBuiltInKeywords as Mobile
 import com.kms.katalon.core.model.FailureHandling
 import com.kms.katalon.core.testcase.TestCase
 import com.kms.katalon.core.testdata.TestData
 import com.kms.katalon.core.testobject.TestObject
 import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WS
 import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI
 import com.kms.katalon.core.windows.keyword.WindowsBuiltinKeywords as Windows */

import internal.GlobalVariable
//test


import java.sql.Connection

import java.sql.DriverManager

import java.sql.SQLException

import java.util.stream.Collectors



import org.apache.commons.dbutils.QueryRunner

import org.apache.commons.dbutils.handlers.ColumnListHandler

import org.apache.commons.dbutils.handlers.MapListHandler

import org.apache.commons.lang.StringUtils



import com.kms.katalon.util.CryptoUtil



import internal.GlobalVariable



public class DatabaseUtils1 {



	//Declare Variables

	String username, groupID, groupSubgroupID

	QueryRunner runner = new QueryRunner()

	Connection wprConnection

	//Session session

	//Connection facetsConnection







	/**
	 * Get connection based on WPR and Facets
	 * @param connectionType
	 * @return
	 */

	public Connection setUp(String dbSource) {

		//String facetsDB =  GlobalVariable.FACETS_DB



		/*
		 * Encrypt Facets and WPR Password using CryptoUtil package
		 */

		//def FacetsPasswd = (CryptoUtil.decode(CryptoUtil.getDefault(GlobalVariable.FACETS_PWD)))

		def WPR_PWD = (CryptoUtil.decode(CryptoUtil.getDefault(GlobalVariable.WPR_PWD)))

		println WPR_PWD



		//String facetsUser = GlobalVariable.FACETS_USER

		//String facetsServer =  GlobalVariable.FACETS_SERVER

		//String facetsPort =  GlobalVariable.FACETS_PORT

		//String facetsConnectionString = "jdbc:oracle:thin:" + facetsUser.trim() + "/" + FacetsPasswd.trim() + "@" + facetsServer.trim() + ":" + facetsPort.trim() + ":" + facetsDB.trim()



		String wprDB = GlobalVariable.WPR_DB

		println wprDB

		String wprUser = GlobalVariable.WPR_USER
		println wprUser
		//String wprPassword =(WPR_PWD)

		String wprServer = GlobalVariable.WPR_SERVER
		println wprServer


		String wprPort = GlobalVariable.WPR_PORT
		println wprPort

		// String WPR_PWD= GlobalVariable.WPR_PWD

		//String wprConnectionString = "jdbc:oracle:thin:" + wprServer.trim() + ":" + wprPort + "/" + wprDB

		String wprConnectionString = "jdbc:oracle:thin:" + wprUser.trim() + "/" + WPR_PWD.trim() + "@" + wprServer.trim() + ":" + wprPort.trim() + ":" + wprDB.trim()

		//		if(wprConnection != null && wprConnection.isClosed())
		//		{
		//			wprConnection.closed()
		//		}

		this.wprConnection = DriverManager.getConnection(wprConnectionString, wprUser.trim(),WPR_PWD.trim())



		/* if (!"".equals(facetsDB)) {
		 try {
		 this.facetsConnection = DriverManager.getConnection(facetsConnectionString)
		 } catch (SQLException var16) {
		 System.out.println("ERROR: SQL Exception when connecting to the database: " + facetsDB)
		 var16.printStackTrace();
		 }
		 } */


		if (!"".equals(wprDB)) {
			try {
				this.wprConnection = DriverManager.getConnection(wprConnectionString)
				if (this.wprConnection != null) {
				}
			}
			catch (SQLException var15) {
				System.out.println("ERROR: SQL Exception when connecting to the database: " + wprDB)
				var15.printStackTrace()
			}

		}

		return this.wprConnection;


		//return dbSource.equals('wpr') ? this.wprConnection : this.facetsConnection;

	}






	List<Map<String,String>>getData(String dbSource, String sql){

		'Get Login Details from DB'
		List<Map<String, String>> resultList = runner.query(setUp(dbSource),sql, new MapListHandler())

		return resultList
	}




	/* Get Facets Data based on SQL and column name
	 * @param inputParameter
	 * @param sql
	 * @return query result
	 */
	String getDataBasedOnColumnName(String dbSource, String sql,String columnName){

		'Get Login Details from DB'
		List<Map<String, String>> list = runner.query(setUp(dbSource),sql, new MapListHandler());

		String columnValue = list.get(0).get(columnName)



		runner.close(setUp(dbSource))

		return columnValue
	}



	Map<String,String> getDataFromFirstRow(String dbSource, String sql){
		Map<String,String>dataMap = getData(dbSource,sql).get(0)

		return dataMap


	}


	public void closeConnection(){

		runner.close(setUp("wprDB"))
		wprConnection.close()
	}


	public void tearDown() {
		if (this.wprConnection != null) {
			try {
				// System.out.println("Closing Facets Database Connection...");
				runner.close(setUp("wprDB"))
				this.wprConnection.close();
				this.wprConnection = null;
			} catch (SQLException ex) {
				ex.printStackTrace();
			}
			//			finally{
			//
			//				if(session !=null){
			//					session.close()
			//				}
			//			}
		}
	}

}





