package com.dbUtility
import java.sql.Connection
import java.sql.DriverManager
import java.sql.SQLException
import org.apache.commons.dbutils.QueryRunner
import org.apache.commons.dbutils.handlers.MapListHandler
import com.kms.katalon.util.CryptoUtil
import internal.GlobalVariable
public class DatabaseUtils {

	//Declare Variables

	String username, groupID, groupSubgroupID

	QueryRunner runner = new QueryRunner()

	private static Connection wprConnection =null

	/**
	 * Get connection based on WPR and Facets
	 * @param connectionType
	 * @return
	 */

	public Connection setUp(String dbSource) {

		/*
		 * Encrypt Facets and WPR Password using CryptoUtil package
		 */

		def WPR_PWD = (CryptoUtil.decode(CryptoUtil.getDefault(GlobalVariable.WPR_PWD)))

		//String WPR_PWD1 = GlobalVariable.WPR_PWD

		String wprDB = GlobalVariable.WPR_DB

		String wprUser = GlobalVariable.WPR_USER

		//String wprPassword =(WPR_PWD)

		String wprServer = GlobalVariable.WPR_SERVER

		String wprPort = GlobalVariable.WPR_PORT

		// String WPR_PWD= GlobalVariable.WPR_PWD

		//String wprConnectionString = "jdbc:oracle:thin:" + wprServer.trim() + ":" + wprPort + "/" + wprDB

		if (GlobalVariable.glblWPRConnection!= null && GlobalVariable.glblWPRConnection!=''){

			this.wprConnection= GlobalVariable.glblWPRConnection

		}else{

			String wprConnectionString = "jdbc:oracle:thin:" + wprUser.trim() + "/" + WPR_PWD.trim() + "@" + wprServer.trim() + ":" + wprPort.trim() + ":" + wprDB.trim()

			this.wprConnection= DriverManager.getConnection(wprConnectionString, wprUser.trim(),WPR_PWD.trim())

			if (!"".equals(wprDB)){

				try {

					this.wprConnection= DriverManager.getConnection(wprConnectionString)

					if (this.wprConnection!= null) {

					}

				}

				catch (SQLException var15) {

					System.out.println("ERROR:SQL Exception when connecting to the database: " + wprDB)

					var15.printStackTrace()

				}
			}

			// 8/27/20 Serhiy

			GlobalVariable.glblWPRConnection= this.wprConnection;
		}

		return this.wprConnection;
		//return dbSource.equals('wpr') ? this.wprConnection : this.facetsConnection;

	}
	List<Map<String,String>>getData(String dbSource, String sql){

		'Get Login Details from DB'

		List<Map<String, String>> resultList = runner.query(setUp(dbSource),sql, new MapListHandler())

		return resultList
	}

	/* Get Facets Data based on SQL and column name
	 * @param inputParameter
	 * @param sql
	 * @return query result
	 */

	String getDataBasedOnColumnName(String dbSource, String sql,String columnName){

		'Get Login Details from DB'

		List<Map<String, String>> list = runner.query(setUp(dbSource),sql, new MapListHandler());

		String columnValue = list.get(0).get(columnName)

		//runner.close(setUp(dbSource)) // 8/27/20 Serhiy

		return columnValue

	}

	public void tearDown() {

		if (wprConnection!= null) {

			try {

				// System.out.println("Closing WPR Database Connection...");

				//                         wprConnection.close();

				//                         wprConnection = null;

			} catch (SQLException ex) {

				ex.printStackTrace();

			}

		}

	}

}


