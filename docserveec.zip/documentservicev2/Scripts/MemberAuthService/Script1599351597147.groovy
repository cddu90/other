import static com.kms.katalon.core.checkpoint.CheckpointFactory.findCheckpoint
import static com.kms.katalon.core.testcase.TestCaseFactory.findTestCase
import static com.kms.katalon.core.testdata.TestDataFactory.findTestData
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject
import static com.kms.katalon.core.testobject.ObjectRepository.findWindowsObject
import com.kms.katalon.core.checkpoint.Checkpoint as Checkpoint
import com.kms.katalon.core.cucumber.keyword.CucumberBuiltinKeywords as CucumberKW
import com.kms.katalon.core.mobile.keyword.MobileBuiltInKeywords as Mobile
import com.kms.katalon.core.model.FailureHandling as FailureHandling
import com.kms.katalon.core.testcase.TestCase as TestCase
import com.kms.katalon.core.testdata.TestData as TestData
import com.kms.katalon.core.testobject.TestObject as TestObject
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WS
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI
import com.kms.katalon.core.windows.keyword.WindowsBuiltinKeywords as Windows
import internal.GlobalVariable as GlobalVariable
import com.kms.katalon.core.testobject.RequestObject as RequestObject
import com.kms.katalon.core.testobject.ResponseObject as ResponseObject
import com.dbUtility.DatabaseUtils as DatabaseUtils
import com.kms.katalon.core.webservice.verification.WSResponseManager as WSResponseManager
import groovy.json.JsonSlurper as JsonSlurper
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WS
import com.kms.katalon.core.webservice.verification.WSResponseManager


Map<String, String> data = new HashMap<String, String>()
//commit

data.put('clientid', GlobalVariable.authenticateservcieclientid)

data.put('clientsecret', GlobalVariable.authenticateservcieclientsecret)

data.put('AuthenticateservcieEndpoint', GlobalVariable.AuthenticateservcieEndpoint)


data = WS.callTestCase(findTestCase('Digitaldocumentsearch'), [('datamap') : data], FailureHandling.CONTINUE_ON_FAILURE)

RequestObject reqmessageread = findTestObject('CTEservcies/Authenticateservcie',data)

String jsonRequestmessageread = reqmessageread.getHttpBody()

println('request is ' + jsonRequestmessageread)

ResponseObject responsemessageread = WS.sendRequest(reqmessageread)

String respmessageread = responsemessageread.getResponseBodyContent()

String memberIdentifier=WS.getElementPropertyValue(responsemessageread, 'responseBody.planMember.memberIdentifier')

String memberBirthDate=WS.getElementPropertyValue(responsemessageread, 'responseBody.planMember.memberBirthDate')

println('memberBirthDate is '+memberBirthDate) 

String groupNumber=WS.getElementPropertyValue(responsemessageread, 'responseBody.planMember.groupNumber')

String respLTPAtoken=responsemessageread.getHeaderField('X-BSC-LTPA-Token')

Map<String, String> headerdatamap = new HashMap<String, String>()

headerdatamap.put('respLTPAtoken', respLTPAtoken)

headerdatamap.put('memberBirthDate', memberBirthDate)

headerdatamap.put('memberIdentifier', memberIdentifier)

headerdatamap.put('groupNumber', groupNumber)

println('memberIdentifier printed' + memberIdentifier)

println( 'groupNumber printed ' + groupNumber)

println('response is messagread' + respmessageread)

println('response of LTPA TOKEN' + respLTPAtoken)

 headerdatamap.putAll(datamap)

return headerdatamap


