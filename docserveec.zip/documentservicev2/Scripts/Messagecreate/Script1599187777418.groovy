import static com.kms.katalon.core.checkpoint.CheckpointFactory.findCheckpoint
import static com.kms.katalon.core.testcase.TestCaseFactory.findTestCase
import static com.kms.katalon.core.testdata.TestDataFactory.findTestData
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject
import static com.kms.katalon.core.testobject.ObjectRepository.findWindowsObject
import com.kms.katalon.core.checkpoint.Checkpoint as Checkpoint
import com.kms.katalon.core.cucumber.keyword.CucumberBuiltinKeywords as CucumberKW
import com.kms.katalon.core.mobile.keyword.MobileBuiltInKeywords as Mobile
import com.kms.katalon.core.model.FailureHandling as FailureHandling
import com.kms.katalon.core.testcase.TestCase as TestCase
import com.kms.katalon.core.testdata.TestData as TestData
import com.kms.katalon.core.testobject.TestObject as TestObject
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WS
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI
import com.kms.katalon.core.windows.keyword.WindowsBuiltinKeywords as Windows
import internal.GlobalVariable as GlobalVariable
import com.kms.katalon.core.testobject.RequestObject as RequestObject
import com.kms.katalon.core.testobject.ResponseObject as ResponseObject
import com.dbUtility.DatabaseUtils as DatabaseUtils
import com.kms.katalon.core.webservice.verification.WSResponseManager as WSResponseManager
import groovy.json.JsonSlurper as JsonSlurper

String updatedmessagetypecodesql = messageTypeCode.toString().replace('?', documentTypeInput)
//commit


println(updatedmessagetypecodesql)

DatabaseUtils datautils = new DatabaseUtils()

String msgtypecd = datautils.getDataBasedOnColumnName('wprDB', updatedmessagetypecodesql, 'MSG_TYP_CD')

println('value extracted ' + msgtypecd)

Random r = new Random()

long memberIdentifier = 10000000000 + ((r.nextDouble() * 999999999) as long)

println('number is ' + memberIdentifier)

String documentId = System.currentTimeMillis().toString()

println("documentId is " + documentId)

Map<String, String> headerdatamap = new HashMap<String, String>()

headerdatamap.put('MessagecreateEndpoint', GlobalVariable.MessagecreateEndpoint)

headerdatamap.put('MessageReadEndpoint', GlobalVariable.MessageReadEndpoint)

headerdatamap.put('memberIdentifier', memberIdentifier)

headerdatamap.put('groupNumber', groupNumber)

headerdatamap.put('subjectText', subjectText)

headerdatamap.put('messageBodyVarText', messageBodyVarText)

headerdatamap.put('messageTypeCode', msgtypecd)

headerdatamap.put('documentType', documentType)

headerdatamap.put('documentId', documentId)

RequestObject req = findTestObject('CTEservcies/MessagecenterCreate', headerdatamap)

String jsonRequest = req.getHttpBody()

println('reuest is ' + jsonRequest)

ResponseObject response = WS.sendRequest(req)

String resp = response.getResponseBodyContent()

println('response is ' + resp)

WS.verifyElementPropertyValue(response, 'responseBody.messageCreateStatus', 'SUCCESS')

String documentIdvalue = ((headerdatamap.get('documentId')) as String)

println('created documentId value' + documentIdvalue)

String documentIdverify = documentIdverfication.toString().replace('?', documentIdvalue)

println(documentIdverify)

String DOCID = datautils.getDataBasedOnColumnName('wprDB', documentIdverify, 'DOC_ID')

println('DOCID value extracted ' + DOCID)

assert documentIdvalue == DOCID

println('Actualvalue value ' + documentIdvalue)

println('Document Table value ' + DOCID)

datautils.tearDown()

RequestObject reqmessageread = findTestObject('CTEservcies/MessageRead', headerdatamap)

String jsonRequestmessageread = reqmessageread.getHttpBody()

println('reuest is ' + jsonRequestmessageread)

ResponseObject responsemessageread = WS.sendRequest(reqmessageread)

String respmessageread = responsemessageread.getResponseBodyContent()

println('response is messagread' + respmessageread)

WS.verifyElementPropertyValue(responsemessageread, 'responseBody.planMember.messages.message[0].documentId', documentIdvalue)

WS.verifyElementPropertyValue(responsemessageread, 'responseHeader.transactionNotification.status', 'SUCCESS')