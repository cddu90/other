import static com.kms.katalon.core.checkpoint.CheckpointFactory.findCheckpoint
import static com.kms.katalon.core.testcase.TestCaseFactory.findTestCase
import static com.kms.katalon.core.testdata.TestDataFactory.findTestData
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject
import static com.kms.katalon.core.testobject.ObjectRepository.findWindowsObject
import com.kms.katalon.core.checkpoint.Checkpoint as Checkpoint
import com.kms.katalon.core.cucumber.keyword.CucumberBuiltinKeywords as CucumberKW
import com.kms.katalon.core.mobile.keyword.MobileBuiltInKeywords as Mobile
import com.kms.katalon.core.model.FailureHandling as FailureHandling
import com.kms.katalon.core.testcase.TestCase as TestCase
import com.kms.katalon.core.testdata.TestData as TestData
import com.kms.katalon.core.testobject.TestObject as TestObject
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WS
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI
import com.kms.katalon.core.windows.keyword.WindowsBuiltinKeywords as Windows
import internal.GlobalVariable as GlobalVariable
import com.kms.katalon.core.testobject.RequestObject as RequestObject
import com.kms.katalon.core.testobject.ResponseObject as ResponseObject
import com.dbUtility.DatabaseUtils as DatabaseUtils
import com.kms.katalon.core.webservice.verification.WSResponseManager as WSResponseManager
import groovy.json.JsonSlurper as JsonSlurper
import java.text.DateFormat as DateFormat
import java.text.SimpleDateFormat as SimpleDateFormat
import java.util.Date as Date

//commit

//"2020-08-28T16:02:29.154Z"
String format = 'yyyy-MM-dd\'T\'hh:mm:ss.SSS\'Z\''

SimpleDateFormat sdf = new SimpleDateFormat(format)

Date date = new Date()

String lastUpdate2Date = sdf.format(date)

println('time ' + lastUpdate2Date)

String lastUpdate2Dateminusoneday = sdf.format(date-9)

println('1 day minus ' + lastUpdate2Dateminusoneday)

println('time ' + lastUpdate2Date)

Map<String, String> headerdatamap = new HashMap<String, String>()

headerdatamap.put('INFDocumentServiceV2Endpoint', GlobalVariable.INFDocumentServiceV2Endpoint)

headerdatamap.put('clientid', GlobalVariable.infclientidportaldcoumentsearch)

headerdatamap.put('clientsecret', GlobalVariable.infclientsecretportaldocumentsearch)

headerdatamap.put('lastUpdate2Date', lastUpdate2Date)

headerdatamap.put('lastUpdate2Dateminusoneday', lastUpdate2Dateminusoneday)

RequestObject req = findTestObject('CTEservcies/DocumentSearchInformaticaservice', headerdatamap)

String jsonRequest = req.getHttpBody()

println('reuest is ' + jsonRequest)

ResponseObject resp1=WS.sendRequest(req)

String resp2 = resp1.getResponseBodyContent()

println('response is ' + resp2)

String documentCount=WS.getElementPropertyValue(resp1, 'responseBody.documentSearchResults.documentCount')

println( 'responseBody.documentSearchResults.documentCount printed ' + documentCount)

Map<String, String> data = new HashMap<String, String>()

data.put('ElasticsearchEndpoint', GlobalVariable.ElasticsearchEndpoint)

data.put('clientid', GlobalVariable.elasticclientid)

data.put('clientsecret', GlobalVariable.elasticclientsecret)

data.put('lastUpdate2Date', lastUpdate2Date)

data.put('lastUpdate2Dateminusoneday', lastUpdate2Dateminusoneday)

RequestObject reqmessageread = findTestObject('CTEservcies/Elasticsearch', data)

String jsonRequestmessageread = reqmessageread.getHttpBody()

println('reuest is ' + jsonRequestmessageread)

ResponseObject responsemessageread = WS.sendRequest(reqmessageread)

String respmessageread = responsemessageread.getResponseBodyContent()

WS.verifyElementPropertyValue(responsemessageread, 'responseHeader.transactionNotification.status', "SUCCESS")

println('response is messagread' + respmessageread)

String documentcountfromelastic=WS.getElementPropertyValue(responsemessageread, 'responseBody.searchResult.totalHits')

println( 'documentcountfromelastic printed ' + documentcountfromelastic)

assert documentCount == documentcountfromelastic
