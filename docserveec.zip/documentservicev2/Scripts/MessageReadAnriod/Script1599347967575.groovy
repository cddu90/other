import static com.kms.katalon.core.checkpoint.CheckpointFactory.findCheckpoint
import static com.kms.katalon.core.testcase.TestCaseFactory.findTestCase
import static com.kms.katalon.core.testdata.TestDataFactory.findTestData
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject
import static com.kms.katalon.core.testobject.ObjectRepository.findWindowsObject
import com.kms.katalon.core.checkpoint.Checkpoint as Checkpoint
import com.kms.katalon.core.cucumber.keyword.CucumberBuiltinKeywords as CucumberKW
import com.kms.katalon.core.mobile.keyword.MobileBuiltInKeywords as Mobile
import com.kms.katalon.core.model.FailureHandling as FailureHandling
import com.kms.katalon.core.testcase.TestCase as TestCase
import com.kms.katalon.core.testdata.TestData as TestData
import com.kms.katalon.core.testobject.TestObject as TestObject
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WS
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI
import com.kms.katalon.core.windows.keyword.WindowsBuiltinKeywords as Windows
import internal.GlobalVariable as GlobalVariable
import com.kms.katalon.core.testobject.RequestObject as RequestObject
import com.kms.katalon.core.testobject.ResponseObject as ResponseObject
import com.dbUtility.DatabaseUtils as DatabaseUtils
import com.kms.katalon.core.webservice.verification.WSResponseManager as WSResponseManager
import groovy.json.JsonSlurper as JsonSlurper


Map<String, String> data = new HashMap<String, String>()
//commit


data.put('andriodclientidread', GlobalVariable.andriodclientidread)

data.put('andriodclientsecret', GlobalVariable.andriodclientsecret)

data.put('MessageReadAndriodEndpoint', GlobalVariable.MessageReadAndriodEndpoint)

data = WS.callTestCase(findTestCase('MemberAuthService'), [('datamap') : data], FailureHandling.STOP_ON_FAILURE)

RequestObject req = findTestObject('CTEservcies/MessageReadAndriod', data)

String jsonRequest = req.getHttpBody()

println('reuest is ' + jsonRequest)

ResponseObject response = WS.sendRequest(req)

String resp = response.getResponseBodyContent()

println('response is ' + resp)

WS.verifyElementPropertyValue(response, 'responseHeader.transactionNotification.status', "SUCCESS")