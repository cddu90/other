import static com.kms.katalon.core.checkpoint.CheckpointFactory.findCheckpoint
import static com.kms.katalon.core.testcase.TestCaseFactory.findTestCase
import static com.kms.katalon.core.testdata.TestDataFactory.findTestData
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject
import static com.kms.katalon.core.testobject.ObjectRepository.findWindowsObject
import com.kms.katalon.core.checkpoint.Checkpoint as Checkpoint
import com.kms.katalon.core.cucumber.keyword.CucumberBuiltinKeywords as CucumberKW
import com.kms.katalon.core.mobile.keyword.MobileBuiltInKeywords as Mobile
import com.kms.katalon.core.model.FailureHandling as FailureHandling
import com.kms.katalon.core.testcase.TestCase as TestCase
import com.kms.katalon.core.testdata.TestData as TestData
import com.kms.katalon.core.testobject.TestObject as TestObject
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WS
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI
import com.kms.katalon.core.windows.keyword.WindowsBuiltinKeywords as Windows
import internal.GlobalVariable as GlobalVariable
import com.kms.katalon.core.testobject.RequestObject as RequestObject
import com.kms.katalon.core.testobject.ResponseObject as ResponseObject
import com.dbUtility.DatabaseUtils as DatabaseUtils
import com.kms.katalon.core.webservice.verification.WSResponseManager as WSResponseManager
import groovy.json.JsonSlurper as JsonSlurper
import java.text.DateFormat as DateFormat
import java.text.SimpleDateFormat as SimpleDateFormat
import java.util.Date as Date


String format = 'yyyy-MM-dd\'T\'hh:mm:ss.SSS\'Z\''

SimpleDateFormat sdf = new SimpleDateFormat(format)

Date date = new Date()

String lastUpdate2Date = sdf.format(date)
//commit with

String lastUpdate2Dateminusoneday = sdf.format(date-5)

println('1 day minus ' + lastUpdate2Dateminusoneday)

Map<String, String> data = new HashMap<String, String>()

data.put('lastUpdate2Date',lastUpdate2Date)

data.put('lastUpdate2Dateminusoneday',lastUpdate2Dateminusoneday)

println('lastUpdate2Date'+lastUpdate2Date)

println('lastUpdate2Dateminusoneday'+lastUpdate2Dateminusoneday)

data.put('infclientidportaldcoumentsearch', GlobalVariable.infclientidportaldcoumentsearch)

data.put('infclientsecretportaldocumentsearch', GlobalVariable.infclientsecretportaldocumentsearch)

data.put('INFDocumentServiceV2Endpoint', GlobalVariable.INFDocumentServiceV2Endpoint)

RequestObject reqmessageread = findTestObject('CTEservcies/documentsearchdigitalized',data)

String jsonRequestmessageread = reqmessageread.getHttpBody()

println('request is ' + jsonRequestmessageread)

ResponseObject responsemessageread = WS.sendRequest(reqmessageread)

String respmessageread = responsemessageread.getResponseBodyContent()


println('response is ' + respmessageread)

String memberIdentifier=WS.getElementPropertyValue(responsemessageread, 'responseBody.documentSearchResults.documentSearchResult[0].documentOwner')

println( 'memberIdentifier printed ' + memberIdentifier)

String documentPath=WS.getElementPropertyValue(responsemessageread, 'responseBody.documentSearchResults.documentSearchResult[0].documentPath')

println( 'documentPath printed ' + documentPath)

String scrollId=WS.getElementPropertyValue(responsemessageread, 'responseBody.documentSearchResults.scrollId')

println( 'scrollId printed ' + scrollId)

GlobalVariable.documentPath1=documentPath

println(" Global value path " +GlobalVariable.documentPath1)

String updatedmessagetypecodesql = subsciberid.toString().replace('?', memberIdentifier)

println(updatedmessagetypecodesql)

DatabaseUtils datautils1 = new DatabaseUtils()

String userid = datautils1.getDataBasedOnColumnName('wprDB', updatedmessagetypecodesql, 'LOGIN')

println('value extracted ' + userid)

Map<String, String> headerdatamap = new HashMap<String, String>()

headerdatamap.put('userid', userid)

headerdatamap.put('documentPath', documentPath)

headerdatamap.put('memberIdentifier', memberIdentifier)

headerdatamap.put('scrollId', scrollId)

headerdatamap.putAll(datamap)
 
return headerdatamap