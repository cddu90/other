package internal

import com.kms.katalon.core.configuration.RunConfiguration
import com.kms.katalon.core.main.TestCaseMain


/**
 * This class is generated automatically by Katalon Studio and should not be modified or deleted.
 */
public class GlobalVariable {
     
    /**
     * <p></p>
     */
    public static Object INFDocumentServiceV2Endpoint
     
    /**
     * <p></p>
     */
    public static Object infclientidportaldcoumentsearch
     
    /**
     * <p></p>
     */
    public static Object infclientsecretportaldocumentsearch
     
    /**
     * <p></p>
     */
    public static Object groupNumber
     
    /**
     * <p></p>
     */
    public static Object subjectText
     
    /**
     * <p></p>
     */
    public static Object messageBodyVarText
     
    /**
     * <p></p>
     */
    public static Object messageTypeCode
     
    /**
     * <p></p>
     */
    public static Object documentType
     
    /**
     * <p></p>
     */
    public static Object documentId
     
    /**
     * <p></p>
     */
    public static Object currentBillAutopay
     
    /**
     * <p></p>
     */
    public static Object currentBillNonAutopay
     
    /**
     * <p></p>
     */
    public static Object billIfpOnxSubsidyStartOfGracePeriod
     
    /**
     * <p></p>
     */
    public static Object billIfpOnxSubsidyDeliquency1
     
    /**
     * <p></p>
     */
    public static Object billIfpOnxSubsidyDeliquency2
     
    /**
     * <p></p>
     */
    public static Object billIfpOnxSubsidyDeliquency3
     
    /**
     * <p></p>
     */
    public static Object billIfpOnxNonSubsidyOffxMdspDeliquency
     
    /**
     * <p></p>
     */
    public static Object billIfpMedsupPastDueNotice
     
    /**
     * <p></p>
     */
    public static Object dependentsSuspensionNotice
     
    /**
     * <p></p>
     */
    public static Object billIfpOnxTerminationNotice
     
    /**
     * <p></p>
     */
    public static Object billIfpOffxMedsupTerminationNotice
     
    /**
     * <p></p>
     */
    public static Object billGracePeriodEndNotice
     
    /**
     * <p></p>
     */
    public static Object WPR_SERVER
     
    /**
     * <p></p>
     */
    public static Object WPR_USER
     
    /**
     * <p></p>
     */
    public static Object WPR_PWD
     
    /**
     * <p></p>
     */
    public static Object WPR_DB
     
    /**
     * <p></p>
     */
    public static Object WPR_PORT
     
    /**
     * <p></p>
     */
    public static Object glblWPRConnection
     
    /**
     * <p></p>
     */
    public static Object portalclientiddocumentsearch
     
    /**
     * <p></p>
     */
    public static Object portalclientsecretdocuemtsearch
     
    /**
     * <p></p>
     */
    public static Object memberIdentifier
     
    /**
     * <p></p>
     */
    public static Object Clientidauthenticat
     
    /**
     * <p></p>
     */
    public static Object Clientidsecreatauthenticat
     
    /**
     * <p></p>
     */
    public static Object IOSmobileclientiddocumentserach
     
    /**
     * <p></p>
     */
    public static Object IOSmobileclientsecretdocumentserach
     
    /**
     * <p></p>
     */
    public static Object Andriodmobileclientid
     
    /**
     * <p></p>
     */
    public static Object Andriodmobileclientsecret
     
    /**
     * <p></p>
     */
    public static Object portalclientidread
     
    /**
     * <p></p>
     */
    public static Object portalclientsecret
     
    /**
     * <p></p>
     */
    public static Object iosclientidread
     
    /**
     * <p></p>
     */
    public static Object iosclientsecret
     
    /**
     * <p></p>
     */
    public static Object andriodclientidread
     
    /**
     * <p></p>
     */
    public static Object andriodclientsecret
     
    /**
     * <p></p>
     */
    public static Object iosclientiddownload
     
    /**
     * <p></p>
     */
    public static Object iosclientsecretdownload
     
    /**
     * <p></p>
     */
    public static Object documentPath1
     
    /**
     * <p></p>
     */
    public static Object andriodclientiddownload
     
    /**
     * <p></p>
     */
    public static Object andriodcleintsecretdownload
     
    /**
     * <p></p>
     */
    public static Object Bulksendnotificationclientid
     
    /**
     * <p></p>
     */
    public static Object Bulksendnotificationclientsecret
     
    /**
     * <p></p>
     */
    public static Object authenticateservcieclientid
     
    /**
     * <p></p>
     */
    public static Object authenticateservcieclientsecret
     
    /**
     * <p></p>
     */
    public static Object DocumentDownloadclientid
     
    /**
     * <p></p>
     */
    public static Object DocumentDownloadclientsecret
     
    /**
     * <p></p>
     */
    public static Object sendnottificationlrsclientid
     
    /**
     * <p></p>
     */
    public static Object sendnottificationlrsclientsecret
     
    /**
     * <p></p>
     */
    public static Object elasticclientid
     
    /**
     * <p></p>
     */
    public static Object elasticclientsecret
     
    /**
     * <p></p>
     */
    public static Object InfDocumentdownloadendpoint
     
    /**
     * <p></p>
     */
    public static Object DocumentDownloadAndriodEndpoint
     
    /**
     * <p></p>
     */
    public static Object DocumentDownloadIOSEndpoint
     
    /**
     * <p></p>
     */
    public static Object DocumentsearchAndriodmobileEndpoint
     
    /**
     * <p></p>
     */
    public static Object DocumentsearchIOSmobileEndpoint
     
    /**
     * <p></p>
     */
    public static Object AuthenticateservcieEndpoint
     
    /**
     * <p></p>
     */
    public static Object MessagecreateEndpoint
     
    /**
     * <p></p>
     */
    public static Object MessageReadEndpoint
     
    /**
     * <p></p>
     */
    public static Object MessageReadAndriodEndpoint
     
    /**
     * <p></p>
     */
    public static Object MessageReadIOSEndpoint
     
    /**
     * <p></p>
     */
    public static Object MessageportalEndpoint
     
    /**
     * <p></p>
     */
    public static Object DocumentDownloadEndpoint
     
    /**
     * <p></p>
     */
    public static Object ElasticsearchEndpoint
     
    /**
     * <p></p>
     */
    public static Object PortalMessageReadClientid
     
    /**
     * <p></p>
     */
    public static Object PortalMessageReadClientsecret
     
    /**
     * <p></p>
     */
    public static Object SendBulkNotificationEndpoint
     
    /**
     * <p></p>
     */
    public static Object SendNotificationLRS
     
    /**
     * <p></p>
     */
    public static Object sendnottificationlrssingleclientid
     
    /**
     * <p></p>
     */
    public static Object sendnottificationlrssingleclientsecret
     
    /**
     * <p></p>
     */
    public static Object sendnotficationendpoint
     

    static {
        try {
            def selectedVariables = TestCaseMain.getGlobalVariables("default")
			selectedVariables += TestCaseMain.getGlobalVariables(RunConfiguration.getExecutionProfile())
            selectedVariables += RunConfiguration.getOverridingParameters()
    
            INFDocumentServiceV2Endpoint = selectedVariables['INFDocumentServiceV2Endpoint']
            infclientidportaldcoumentsearch = selectedVariables['infclientidportaldcoumentsearch']
            infclientsecretportaldocumentsearch = selectedVariables['infclientsecretportaldocumentsearch']
            groupNumber = selectedVariables['groupNumber']
            subjectText = selectedVariables['subjectText']
            messageBodyVarText = selectedVariables['messageBodyVarText']
            messageTypeCode = selectedVariables['messageTypeCode']
            documentType = selectedVariables['documentType']
            documentId = selectedVariables['documentId']
            currentBillAutopay = selectedVariables['currentBillAutopay']
            currentBillNonAutopay = selectedVariables['currentBillNonAutopay']
            billIfpOnxSubsidyStartOfGracePeriod = selectedVariables['billIfpOnxSubsidyStartOfGracePeriod']
            billIfpOnxSubsidyDeliquency1 = selectedVariables['billIfpOnxSubsidyDeliquency1']
            billIfpOnxSubsidyDeliquency2 = selectedVariables['billIfpOnxSubsidyDeliquency2']
            billIfpOnxSubsidyDeliquency3 = selectedVariables['billIfpOnxSubsidyDeliquency3']
            billIfpOnxNonSubsidyOffxMdspDeliquency = selectedVariables['billIfpOnxNonSubsidyOffxMdspDeliquency']
            billIfpMedsupPastDueNotice = selectedVariables['billIfpMedsupPastDueNotice']
            dependentsSuspensionNotice = selectedVariables['dependentsSuspensionNotice']
            billIfpOnxTerminationNotice = selectedVariables['billIfpOnxTerminationNotice']
            billIfpOffxMedsupTerminationNotice = selectedVariables['billIfpOffxMedsupTerminationNotice']
            billGracePeriodEndNotice = selectedVariables['billGracePeriodEndNotice']
            WPR_SERVER = selectedVariables['WPR_SERVER']
            WPR_USER = selectedVariables['WPR_USER']
            WPR_PWD = selectedVariables['WPR_PWD']
            WPR_DB = selectedVariables['WPR_DB']
            WPR_PORT = selectedVariables['WPR_PORT']
            glblWPRConnection = selectedVariables['glblWPRConnection']
            portalclientiddocumentsearch = selectedVariables['portalclientiddocumentsearch']
            portalclientsecretdocuemtsearch = selectedVariables['portalclientsecretdocuemtsearch']
            memberIdentifier = selectedVariables['memberIdentifier']
            Clientidauthenticat = selectedVariables['Clientidauthenticat']
            Clientidsecreatauthenticat = selectedVariables['Clientidsecreatauthenticat']
            IOSmobileclientiddocumentserach = selectedVariables['IOSmobileclientiddocumentserach']
            IOSmobileclientsecretdocumentserach = selectedVariables['IOSmobileclientsecretdocumentserach']
            Andriodmobileclientid = selectedVariables['Andriodmobileclientid']
            Andriodmobileclientsecret = selectedVariables['Andriodmobileclientsecret']
            portalclientidread = selectedVariables['portalclientidread']
            portalclientsecret = selectedVariables['portalclientsecret']
            iosclientidread = selectedVariables['iosclientidread']
            iosclientsecret = selectedVariables['iosclientsecret']
            andriodclientidread = selectedVariables['andriodclientidread']
            andriodclientsecret = selectedVariables['andriodclientsecret']
            iosclientiddownload = selectedVariables['iosclientiddownload']
            iosclientsecretdownload = selectedVariables['iosclientsecretdownload']
            documentPath1 = selectedVariables['documentPath1']
            andriodclientiddownload = selectedVariables['andriodclientiddownload']
            andriodcleintsecretdownload = selectedVariables['andriodcleintsecretdownload']
            Bulksendnotificationclientid = selectedVariables['Bulksendnotificationclientid']
            Bulksendnotificationclientsecret = selectedVariables['Bulksendnotificationclientsecret']
            authenticateservcieclientid = selectedVariables['authenticateservcieclientid']
            authenticateservcieclientsecret = selectedVariables['authenticateservcieclientsecret']
            DocumentDownloadclientid = selectedVariables['DocumentDownloadclientid']
            DocumentDownloadclientsecret = selectedVariables['DocumentDownloadclientsecret']
            sendnottificationlrsclientid = selectedVariables['sendnottificationlrsclientid']
            sendnottificationlrsclientsecret = selectedVariables['sendnottificationlrsclientsecret']
            elasticclientid = selectedVariables['elasticclientid']
            elasticclientsecret = selectedVariables['elasticclientsecret']
            InfDocumentdownloadendpoint = selectedVariables['InfDocumentdownloadendpoint']
            DocumentDownloadAndriodEndpoint = selectedVariables['DocumentDownloadAndriodEndpoint']
            DocumentDownloadIOSEndpoint = selectedVariables['DocumentDownloadIOSEndpoint']
            DocumentsearchAndriodmobileEndpoint = selectedVariables['DocumentsearchAndriodmobileEndpoint']
            DocumentsearchIOSmobileEndpoint = selectedVariables['DocumentsearchIOSmobileEndpoint']
            AuthenticateservcieEndpoint = selectedVariables['AuthenticateservcieEndpoint']
            MessagecreateEndpoint = selectedVariables['MessagecreateEndpoint']
            MessageReadEndpoint = selectedVariables['MessageReadEndpoint']
            MessageReadAndriodEndpoint = selectedVariables['MessageReadAndriodEndpoint']
            MessageReadIOSEndpoint = selectedVariables['MessageReadIOSEndpoint']
            MessageportalEndpoint = selectedVariables['MessageportalEndpoint']
            DocumentDownloadEndpoint = selectedVariables['DocumentDownloadEndpoint']
            ElasticsearchEndpoint = selectedVariables['ElasticsearchEndpoint']
            PortalMessageReadClientid = selectedVariables['PortalMessageReadClientid']
            PortalMessageReadClientsecret = selectedVariables['PortalMessageReadClientsecret']
            SendBulkNotificationEndpoint = selectedVariables['SendBulkNotificationEndpoint']
            SendNotificationLRS = selectedVariables['SendNotificationLRS']
            sendnottificationlrssingleclientid = selectedVariables['sendnottificationlrssingleclientid']
            sendnottificationlrssingleclientsecret = selectedVariables['sendnottificationlrssingleclientsecret']
            sendnotficationendpoint = selectedVariables['sendnotficationendpoint']
            
        } catch (Exception e) {
            TestCaseMain.logGlobalVariableError(e)
        }
    }
}
