<?xml version="1.0" encoding="UTF-8"?>
<TestSuiteEntity>
   <description></description>
   <name>Smoke Test Suite For Documentsearch Service</name>
   <tag></tag>
   <isRerun>false</isRerun>
   <mailRecipient></mailRecipient>
   <numberOfRerun>0</numberOfRerun>
   <pageLoadTimeout>30</pageLoadTimeout>
   <pageLoadTimeoutDefault>true</pageLoadTimeoutDefault>
   <rerunFailedTestCasesOnly>false</rerunFailedTestCasesOnly>
   <testSuiteGuid>04be26e5-b762-4d2e-a885-915d4215296f</testSuiteGuid>
   <testCaseLink>
      <guid>71563018-def5-47b6-a1f8-3a8d3b80a6c2</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/DocumentsearchIOSmobile</testCaseId>
      <variableLink>
         <testDataLinkId></testDataLinkId>
         <type>DEFAULT</type>
         <value></value>
         <variableId>aef0a479-6dbf-492b-8c50-248124c70161</variableId>
      </variableLink>
   </testCaseLink>
   <testCaseLink>
      <guid>9f146eb7-46b0-462c-9a40-40742c93ad94</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/DocumentSearchPortalservice</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>d3e97a90-b516-4139-baa3-89f4fde93e10</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/DocumentsearchAndriodmobile</testCaseId>
      <variableLink>
         <testDataLinkId></testDataLinkId>
         <type>DEFAULT</type>
         <value></value>
         <variableId>0cd7da91-b994-4ab0-9144-a8307ccfc189</variableId>
      </variableLink>
   </testCaseLink>
</TestSuiteEntity>
