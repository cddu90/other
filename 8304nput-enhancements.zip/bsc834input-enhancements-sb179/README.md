# 834InputFileValidation
## Environment Variables
Examples:
INPUT_834_PATH=\\ainf423s\QES_Automation\BSCPHP\VALIDATIONS\834_Validation 
CIN_COMPLETE_FILE_PATH_IDcards=\\ainf423s\QES_Automation\BSCPHP\VALIDATIONS\ID_card_CIN_capture\CINs.csv
CIN_COMPLETE_FILE_PATH_WKIT=\\ainf423s\QES_Automation\BSCPHP\VALIDATIONS\WelcomeKits_CIN_capture\CINs.csv
ARCHIVE_834_PATH=\\ainf423s\QES_Automation\BSCPHP\Archive\834_VALIDATION
