package pageobjects.registration

import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject

import com.kms.katalon.core.testobject.TestObject
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI

import internal.GlobalVariable

public class EmployerBillContactValidationPage {

	TestObject list_ListOfGroupSubgroup = findTestObject('Page_Employer Registration/SubPage_RegStep2_ValidateBillAndContactInformation/ListBox_ListOfGroupSubgroup')

	TestObject input_DateOfLastBill = findTestObject('Page_Employer Registration/SubPage_RegStep2_ValidateBillAndContactInformation/Input_DateOfLastBill')

	TestObject input_EmailAddress = findTestObject('Page_Employer Registration/SubPage_RegStep2_ValidateBillAndContactInformation/Input_EmailAddress')

	TestObject input_FirstName = findTestObject('Page_Employer Registration/SubPage_RegStep2_ValidateBillAndContactInformation/Input_FirstName')

	TestObject input_LastName = findTestObject('Page_Employer Registration/SubPage_RegStep2_ValidateBillAndContactInformation/Input_LastName')

	TestObject input_totalBillAmount = findTestObject('Page_Employer Registration/SubPage_RegStep2_ValidateBillAndContactInformation/Input_TotalBillAmount')

	TestObject button_next = findTestObject('Page_Employer Registration/SubPage_RegStep2_ValidateBillAndContactInformation/Button_Next')

	boolean isPageDisplayed(){

		boolean bool = false

		boolean isListGroupSubgroupPresent = WebUI.waitForElementPresent(list_ListOfGroupSubgroup, GlobalVariable.TIMEOUT)

		boolean isBillAmountNotDisplayed = WebUI.verifyElementNotClickable(input_totalBillAmount)

		boolean isDateOfLastBillDisplayed = WebUI.verifyElementNotClickable(input_DateOfLastBill)

		boolean isFirstNameDisplayed = WebUI.verifyElementPresent(input_FirstName, GlobalVariable.TIMEOUT)

		boolean isLastNameDisplayed = WebUI.verifyElementPresent(input_LastName, GlobalVariable.TIMEOUT)

		boolean isEmailAddressDisplayed = WebUI.verifyElementPresent(input_EmailAddress, GlobalVariable.TIMEOUT)

		boolean isNextButtonDisplayed = WebUI.verifyElementClickable(button_next)

		if(isListGroupSubgroupPresent && isBillAmountNotDisplayed && isDateOfLastBillDisplayed && isFirstNameDisplayed && isLastNameDisplayed && isEmailAddressDisplayed && isNextButtonDisplayed){

			bool = true
		}

		return bool
	}
}
