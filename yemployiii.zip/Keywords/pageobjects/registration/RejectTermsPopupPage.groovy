package pageobjects.registration
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject

import com.kms.katalon.core.testobject.TestObject
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI

import internal.GlobalVariable


/**
 * Page Class to capture elements, actions and helper methods on RegistrationCancellationPage
 * @author pkonda01
 *
 */
class RejectTermsPopupPage {

	//Define TestObjects
	TestObject oRejectTermsButton = findTestObject('Page_Employer Registration/SubPage_RegStep3.2_SelectNo_AcceptTermsConditions/img_RejectTerms')
	//Action Methods on WebElements
	void clickRejectTermsButton(){

		WebUI.click(oRejectTermsButton)
	}

	//Helper Methods
	/**
	 * Navigate to Next Page
	 * @return True/False
	 */
	void navigateToRegistrationCancellationPage(){

		clickRejectTermsButton()
	}

	/**
	 * Verify if Page is up
	 * @return
	 */
	boolean isPageDisplayed(){
		return WebUI.verifyElementPresent(oRejectTermsButton,GlobalVariable.TIMEOUT)
	}
}