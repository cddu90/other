package pageobjects.registration

import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject

import com.kms.katalon.core.model.FailureHandling
import com.kms.katalon.core.testobject.TestObject
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI

/**
 * Page Class to capture elements, actions and helper methods on RegistrationCancellationPage
 * @author pkonda01
 *
 */
class RegistrationCancellationPage {

	//Define TestObjects
	TestObject cancellationCloseButton = findTestObject('Page_Employer Registration/SubPage_RegStep3.2_SelectNo_AcceptTermsConditions/img_CloseButton_CancellationPage')
	TestObject registrationCancellationFrame = findTestObject('Object Repository/Page_Employer Registration/SubPage_RegStep3.2_SelectNo_AcceptTermsConditions/iframe_IRejectTermsLink')

	//Action Methods on WebElements
	void clickCloseButton(){
		WebUI.click(cancellationCloseButton)
	}

	//HelperMethods
	/**
	 * Verify if page is up
	 * @return True/False
	 */
	boolean  isPageDisplayed(){
		WebUI.waitForElementPresent(registrationCancellationFrame, 5, FailureHandling.STOP_ON_FAILURE)
		return WebUI.verifyElementPresent(cancellationCloseButton, 5, FailureHandling.STOP_ON_FAILURE)
	}
}