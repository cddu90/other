package pageobjects.registration

import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject

import org.apache.commons.lang.RandomStringUtils

import com.kms.katalon.core.model.FailureHandling
import com.kms.katalon.core.testobject.TestObject
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI

import internal.GlobalVariable

public class RegistrationProfilePage {

	TestObject input_firstName = findTestObject('Page_Employer Registration/SubPage_RegStep4_EnterProfileInfo/Input_FirstName')

	TestObject input_LastName = findTestObject('Page_Employer Registration/SubPage_RegStep4_EnterProfileInfo/Input_LastName')

	TestObject input_email = findTestObject('Page_Employer Registration/SubPage_RegStep4_EnterProfileInfo/Input_Email')

	TestObject input_confirmationEmail = findTestObject('Page_Employer Registration/SubPage_RegStep4_EnterProfileInfo/Input_ConfirmEmail')

	TestObject input_userName = findTestObject('Page_Employer Registration/SubPage_RegStep4_EnterProfileInfo/Input_UserName')

	TestObject input_password = findTestObject('Page_Employer Registration/SubPage_RegStep4_EnterProfileInfo/Input_Password')

	TestObject input_confirmationPassword = findTestObject('Page_Employer Registration/SubPage_RegStep4_EnterProfileInfo/Input_ConfirmPassword')

	TestObject input_phoneOne = findTestObject('Page_Employer Registration/SubPage_RegStep4_EnterProfileInfo/Input_PhoneOne')

	TestObject input_phoneTwo = findTestObject('Page_Employer Registration/SubPage_RegStep4_EnterProfileInfo/Input_PhoneTwo')

	TestObject input_phoneThree = findTestObject('Page_Employer Registration/SubPage_RegStep4_EnterProfileInfo/Input_PhoneThree')

	TestObject input_secAnsOne = findTestObject('Page_Employer Registration/SubPage_RegStep4_EnterProfileInfo/Input_SecAnswer1')

	TestObject input_secAnsTwo = findTestObject('Page_Employer Registration/SubPage_RegStep4_EnterProfileInfo/Input_SecAnswer2')

	TestObject listbox_secOneQues = findTestObject('Page_Employer Registration/SubPage_RegStep4_EnterProfileInfo/LB_SecQuestion1')

	TestObject listbox_secTwoQues = findTestObject('Page_Employer Registration/SubPage_RegStep4_EnterProfileInfo/LB_SecQuestion2')

	TestObject button_next = findTestObject('Page_Employer Registration/SubPage_RegStep4_EnterProfileInfo/Button_Next')

	boolean isPageDisplayed(){

		boolean bool = false

		boolean isNextButtonDisplayed = WebUI.verifyElementPresent(button_next,GlobalVariable.TIMEOUT, FailureHandling.OPTIONAL)

		if(isNextButtonDisplayed){
			bool = true
		}

		return bool
	}

	void enterNamePhoneDetails(){

		WebUI.setText(input_firstName, randomString1)

		WebUI.setText(input_LastName, randomString2)

		WebUI.setText(input_phoneOne, '650')

		WebUI.setText(input_phoneTwo, '539')

		WebUI.setText(input_phoneThree, '9226')
	}

	void enterEmail(){

		WebUI.click(input_email)

		WebUI.setText(input_email, ((randomString1 + '_') + randomString2) + '@test.com')

		WebUI.click(input_confirmationEmail)

		WebUI.setText(input_confirmationEmail, ((randomString1 + '_') + randomString2) + '@test.com')
	}

	void enterLoginInfo(String groupSubgroupID){

		def userId = 'auto_' + groupSubgroupID

		WebUI.setText(input_userName, userId)

		WebUI.setText(input_password, 'Blue$hield1')

		WebUI.setText(input_confirmationPassword, 'Blue$hield1')
	}

	void enterSecurityQuesAns(){

		WebUI.selectOptionByIndex(listbox_secOneQues, 1, FailureHandling.OPTIONAL)

		WebUI.setText(input_secAnsOne, 'It may work')

		WebUI.selectOptionByIndex(listbox_secTwoQues, 1, FailureHandling.OPTIONAL)

		WebUI.setText(input_secAnsTwo, 'or it may not work')
	}

	void enterProfileInfo(String groupSubgroupID){

		enterNamePhoneDetails()
		enterEmail()
		enterLoginInfo(groupSubgroupID)
		enterSecurityQuesAns()
		WebUI.click(button_next, FailureHandling.OPTIONAL)
	}

	String randomString1 = RandomStringUtils.randomAlphabetic(9)

	String randomString2 = RandomStringUtils.randomAlphabetic(9)
}
