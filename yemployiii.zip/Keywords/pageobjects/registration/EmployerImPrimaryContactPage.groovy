package pageobjects.registration
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject

import com.kms.katalon.core.model.FailureHandling
import com.kms.katalon.core.testobject.TestObject
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI

import internal.GlobalVariable


/**
 * Page Class to capture elements, actions and helper methods on EmployerImPrimaryContactPage
 * @author pkonda01
 *
 */
class EmployerImPrimaryContactPage {

	//Define TestObjects
	TestObject oImPrimaryContactButton = findTestObject('Page_EmployerUnAuthHome/img_ImPrimaryContact')
	TestObject oIFrameImPrimaryContact = findTestObject('Page_EmployerUnAuthHome/iFrame_ImPrimaryContact')

	/**
	 * Verify if Page is up
	 * @return
	 */
	boolean isPageDisplayed(){
		boolean bool = false
		boolean isIFramePresent = WebUI.verifyElementPresent(oIFrameImPrimaryContact, GlobalVariable.TIMEOUT, FailureHandling.OPTIONAL)
		boolean isPrimaryContactButtonDisplayed = WebUI.verifyElementPresent(oImPrimaryContactButton, GlobalVariable.TIMEOUT, FailureHandling.OPTIONAL)
		WebUI.waitForElementPresent(oImPrimaryContactButton, GlobalVariable.TIMEOUT, FailureHandling.STOP_ON_FAILURE)
		if(isIFramePresent && isPrimaryContactButtonDisplayed){
			bool = true
		}
		return bool
	}

}