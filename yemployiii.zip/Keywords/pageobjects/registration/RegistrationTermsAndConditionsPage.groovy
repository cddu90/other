package pageobjects.registration
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject

import com.kms.katalon.core.annotation.Keyword
import com.kms.katalon.core.testobject.TestObject
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI

import internal.GlobalVariable

/**
 * Page Class to capture elements, actions and helper methods on RegistrationCancellationPage
 * @author pkonda01
 *
 */
class RegistrationTermsAndConditionsPage {

	//Define Test Objects
	TestObject oRejectTermsLink = findTestObject('Page_Employer Registration/SubPage_RegStep3.2_SelectNo_AcceptTermsConditions/link_IRejectTermsAbove')
	TestObject oIAcceptTerms = findTestObject('Page_Employer Registration/SubPage_RegStep3.2_SelectNo_AcceptTermsConditions/Img_AcceptTerms')


	//Action Method on WebElements


	void clickRejectTermsLink(){
		WebUI.click(oRejectTermsLink)
	}

	//Helper Methods

	/**
	 * Navigate to Next page
	 * @return
	 */
	void navigateToRejectTermPopup () {
		clickRejectTermsLink()
	}

	/**
	 * Verify if page is up
	 * @return True/False
	 */

	boolean isPageDisplayed () {
		return WebUI.verifyElementPresent(oRejectTermsLink, GlobalVariable.TIMEOUT)
	}
}