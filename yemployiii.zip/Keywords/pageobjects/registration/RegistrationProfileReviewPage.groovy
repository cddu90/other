package pageobjects.registration

import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject

import com.kms.katalon.core.model.FailureHandling
import com.kms.katalon.core.testobject.TestObject
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI

import internal.GlobalVariable

public class RegistrationProfileReviewPage {

	TestObject text_PleaseConfirm = findTestObject('Page_Employer Registration/SubPage_RegStep5_ProfleReviewPage/Text_PleaseConfirm')

	TestObject text_ReturnToPreviousPage = findTestObject('Page_Employer Registration/SubPage_RegStep5_ProfleReviewPage/Text_ReturnToPreviousPage')

	TestObject button_finish = findTestObject('Page_Employer Registration/SubPage_RegStep5_ProfleReviewPage/Button_Finish')

	boolean isPageDisplayed(){

		boolean bool = false

		boolean isFinishButtonDisplayed = WebUI.verifyElementPresent(button_finish, GlobalVariable.TIMEOUT, FailureHandling.OPTIONAL)

		if(isFinishButtonDisplayed){

			bool = true
		}

		return bool
	}
}
