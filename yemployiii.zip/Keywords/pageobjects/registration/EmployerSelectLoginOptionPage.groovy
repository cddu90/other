package pageobjects.registration
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject

import com.kms.katalon.core.model.FailureHandling
import com.kms.katalon.core.testobject.TestObject
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI

import internal.GlobalVariable


/**
 * Page Class to capture elements, actions and helper methods on EmployerSelectLoginOptionPage
 * @author pkonda01
 *
 */
class EmployerSelectLoginOptionPage {

	//Define TestObjects
	TestObject oToRegisterRadioButton = findTestObject('Page_Employer Registration/SubPage_RegStep3_YesNo_MergeOrNoMerge/RButton_NoINeedToRegister')
	TestObject oSubmitButton = findTestObject('Page_Employer Registration/SubPage_RegStep3_YesNo_MergeOrNoMerge/Button_Submit')
	TestObject oYesRadioButton = findTestObject('Page_Employer Registration/SubPage_RegStep3_YesNo_MergeOrNoMerge/RButton_ExistingLogin')
	TestObject oUsername = findTestObject('Page_Employer Registration/SubPage_RegStep3_YesNo_MergeOrNoMerge/Input_Username')
	TestObject oPassword = findTestObject('Page_Employer Registration/SubPage_RegStep3_YesNo_MergeOrNoMerge/Input_Password')


	//Action Methods on WebElements
	void selectNoINeedToRegisterButton(){
		WebUI.click(oToRegisterRadioButton)
	}

	void clickSubmitButton(){
		WebUI.click(oSubmitButton)
	}

	//Helper Methods
	/**
	 * Navigate to next page
	 * @return
	 */
	void navigateToRegisterTCPageBySelectingINeedToRegister(){
		selectNoINeedToRegisterButton()
		clickSubmitButton()
	}

	/**
	 * Verify if page is up
	 * @return True/False
	 */
	boolean isPageDisplayed(){
		WebUI.waitForElementClickable(oToRegisterRadioButton, GlobalVariable.TIMEOUT,FailureHandling.OPTIONAL)
		return (WebUI.verifyElementPresent(oToRegisterRadioButton,0))
	}

	void login(String username, String password){
		WebUI.setText(oUsername, username, FailureHandling.OPTIONAL)
		WebUI.setText(oPassword, password,FailureHandling.OPTIONAL)
		WebUI.click(oSubmitButton)

	}
}