package pageobjects.registration

import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject

import com.kms.katalon.core.model.FailureHandling
import com.kms.katalon.core.testobject.TestObject
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI

import internal.GlobalVariable

public class EmployerNoMergeConfirmationPage {

	TestObject text_RegistrationConfirmation = findTestObject('Page_Employer Registration/SubPage_RegStep6_ConfirmationPage/Text_RegistrationConfirmation')

	TestObject text_CloseAndLogin = findTestObject('Page_Employer Registration/SubPage_RegStep6_ConfirmationPage/Text_SimplyLogin')

	TestObject text_ThankyouMsg = findTestObject('Page_Employer Registration/SubPage_RegStep6_ConfirmationPage/Text_Thank you for setting up your account')

	TestObject imgCloseLink = findTestObject('Object Repository/Page_Employer Registration/SubPage_RegStep6_ConfirmationPage/img_Registration_imgClose')

	boolean isPageDisplayed(){

		boolean bool = false

		boolean isRegistrationConfDisplayed = WebUI.verifyElementPresent(text_RegistrationConfirmation, GlobalVariable.TIMEOUT, FailureHandling.OPTIONAL)
		boolean isCloseLoginDisplayed = WebUI.verifyElementPresent(text_CloseAndLogin, GlobalVariable.TIMEOUT, FailureHandling.OPTIONAL)
		boolean isThankYouMsgDisplayed = WebUI.verifyElementPresent(text_ThankyouMsg, GlobalVariable.TIMEOUT, FailureHandling.OPTIONAL)

		if(isRegistrationConfDisplayed && isCloseLoginDisplayed && isThankYouMsgDisplayed){
			bool = true
		}

		return bool
	}
}
