package pageobjects.registration
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject

import com.kms.katalon.core.model.FailureHandling
import com.kms.katalon.core.testobject.TestObject
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI

import internal.GlobalVariable



/**
 * Page Class to capture elements, actions and helper methods on ValidateBillingAndContactPage
 * @author pkonda01
 *
 */
class ValidateBillingAndContactPage {

	//Define TestObjects
	private TestObject oDateOfLastBill = findTestObject('Page_Employer Registration/SubPage_RegStep2_ValidateBillAndContactInformation/Input_DateOfLastBill')
	private TestObject ototalAmountOfLastBill = findTestObject('Page_Employer Registration/SubPage_RegStep2_ValidateBillAndContactInformation/Input_TotalBillAmount')
	private TestObject oFirstName = findTestObject('Page_Employer Registration/SubPage_RegStep2_ValidateBillAndContactInformation/Input_FirstName')
	private TestObject oLastName = findTestObject('Page_Employer Registration/SubPage_RegStep2_ValidateBillAndContactInformation/Input_LastName')
	private TestObject oEmailAddress = findTestObject('Page_Employer Registration/SubPage_RegStep2_ValidateBillAndContactInformation/Input_EmailAddress')
	private TestObject oNextButton = findTestObject('Object Repository/Page_Employer Registration/SubPage_RegStep2_ValidateBillAndContactInformation/Button_Next')
	private TestObject oCalendarButton = findTestObject('Page_Employer Registration/SubPage_RegStep2_ValidateBillAndContactInformation/New_Button_Calendar')
	private TestObject oSubgroupListBox = findTestObject('Page_Employer Registration/SubPage_RegStep2_ValidateBillAndContactInformation/ListBox_ListOfGroupSubgroup')


	//ActionMethods

	void selectSubgroupID(String subGroupID){
		WebUI.verifyElementPresent(oSubgroupListBox, GlobalVariable.TIMEOUT)
		WebUI.selectOptionByValue(oSubgroupListBox, subGroupID, false, FailureHandling.STOP_ON_FAILURE)
	}



	void enterDateOfLastBill(String dateOfLastBill){
		WebUI.verifyElementPresent(oDateOfLastBill, GlobalVariable.TIMEOUT)
		WebUI.setText(oDateOfLastBill, dateOfLastBill,FailureHandling.STOP_ON_FAILURE)
	}


	void enterTotalAmountOfBill(String totalAmountOfBill){
		WebUI.waitForElementPresent(ototalAmountOfLastBill, GlobalVariable.TIMEOUT)
		WebUI.setText(ototalAmountOfLastBill, totalAmountOfBill,FailureHandling.STOP_ON_FAILURE)
	}


	void enterFirstName(String firstName){
		WebUI.verifyElementPresent(oFirstName, GlobalVariable.TIMEOUT)
		WebUI.setText(oFirstName, firstName,FailureHandling.STOP_ON_FAILURE)
	}


	void enterLastName(String lastName){
		WebUI.verifyElementPresent(oLastName, GlobalVariable.TIMEOUT)
		WebUI.setText(oLastName, lastName,FailureHandling.STOP_ON_FAILURE)
	}


	void enterEmailAddress(String emailAddress){
		WebUI.verifyElementPresent(oEmailAddress, GlobalVariable.TIMEOUT)
		WebUI.setText(oEmailAddress, emailAddress,FailureHandling.STOP_ON_FAILURE)
	}


	void closeCalendarButton(){
		WebUI.verifyElementClickable(oCalendarButton,FailureHandling.STOP_ON_FAILURE)
		WebUI.focus(oCalendarButton,FailureHandling.OPTIONAL)
		WebUI.click(oCalendarButton)
	}


	void clickNext(){
		WebUI.verifyElementClickable(oNextButton,FailureHandling.STOP_ON_FAILURE)
		WebUI.focus(oNextButton,FailureHandling.STOP_ON_FAILURE)
		WebUI.click(oNextButton,FailureHandling.STOP_ON_FAILURE)
	}


	boolean isPageDisplayed(){
		return WebUI.verifyElementPresent(oDateOfLastBill, GlobalVariable.TIMEOUT)
	}

	//Helper methods
	/**
	 * Add Billing and Contact Details
	 * @param subGroupID
	 * @param dateOfLastBill
	 * @param totalAmountOfBill
	 * @param firstName
	 * @param lastName
	 * @param emailAddress
	 */

	void addBillingContactDetails(subGroupID,dateOfLastBill,totalAmountOfBill,firstName,lastName,emailAddress){
		selectSubgroupID(subGroupID)
		enterDateOfLastBill(dateOfLastBill)
		closeCalendarButton()
		enterTotalAmountOfBill(totalAmountOfBill)
		enterFirstName(firstName)
		enterLastName(lastName)
		enterEmailAddress(emailAddress)
	}

	/**
	 * Navigate to next page by adding Billing and ContactDetails
	 * @param subGroupID
	 * @param dateOfLastBill
	 * @param totalAmountOfBill
	 * @param firstName
	 * @param lastName
	 * @param emailAddress
	 */

	void navigateToEmployerSelectLoginOptionPage(subGroupID,dateOfLastBill,totalAmountOfBill,firstName,lastName,emailAddress){
		addBillingContactDetails(subGroupID,dateOfLastBill,totalAmountOfBill,firstName,lastName,emailAddress)
		clickNext()

	}
}