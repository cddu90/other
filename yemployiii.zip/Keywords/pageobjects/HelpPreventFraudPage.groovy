package pageobjects
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject

import com.kms.katalon.core.model.FailureHandling
import com.kms.katalon.core.testobject.TestObject
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI

import internal.GlobalVariable


class HelpPreventFraudPage {

	TestObject aboutBSPreventingFraud = findTestObject('Object Repository/Page_Preventing Fraud/div_Home AboutBS PreventingFraud')
	TestObject headerTxt = findTestObject('Object Repository/Page_Preventing Fraud/h1_Preventing Fraud')

	boolean isPageDisplayed(){

		boolean bool = false

		boolean isAboutPreventingFraudDisplayed = WebUI.waitForElementPresent(aboutBSPreventingFraud, GlobalVariable.TIMEOUT, FailureHandling.CONTINUE_ON_FAILURE)

		boolean isHeaderTxtDisplayed = WebUI.waitForElementPresent(headerTxt, GlobalVariable.TIMEOUT, FailureHandling.CONTINUE_ON_FAILURE)

		if(isAboutPreventingFraudDisplayed && isHeaderTxtDisplayed){
			bool = true
		}

		return bool
	}
}