package pageobjects
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject

import com.kms.katalon.core.annotation.Keyword
import com.kms.katalon.core.model.FailureHandling
import com.kms.katalon.core.testobject.TestObject
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI

import internal.GlobalVariable


class EmployerSiteHelpPage {
	TestObject link_technicalSupport = findTestObject('Page_EmployerSiteHelp/a_Technical Support')
	TestObject link_compatibleBrowsers = findTestObject('Page_EmployerSiteHelp/a_Compatible Browsers')

	/**
	 * 
	 * @return
	 */
	boolean isPageDisplayed(){
		boolean bool = false
		boolean isLinkTechnicalSupportDisplayed = WebUI.waitForElementPresent(link_technicalSupport, GlobalVariable.TIMEOUT,FailureHandling.STOP_ON_FAILURE)
		boolean isLinkCompatibleBrowsersDisplayed= WebUI.verifyElementPresent(link_compatibleBrowsers,0)
		if(isLinkTechnicalSupportDisplayed && isLinkCompatibleBrowsersDisplayed ){
			bool = true
		}

		return bool
	}
}