package pageobjects.employerreports
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject

import com.kms.katalon.core.model.FailureHandling
import com.kms.katalon.core.testobject.TestObject
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI

import internal.GlobalVariable


class EmployerReportsPage {

	TestObject oCensusReportLink = findTestObject('Page_Employer Census Report/Census Report Link')
	TestObject oBillingReportLink = findTestObject('Object Repository/Page_EmployerBilling/Page_Welcome Billing Reports/a_Billing Report')



	/**
	 * 
	 * @return
	 */
	boolean isPageDisplayed(){

		boolean bool = false
		boolean isCensusReportLinkDisplayed = WebUI.verifyElementPresent(oCensusReportLink, GlobalVariable.TIMEOUT, FailureHandling.OPTIONAL)
		boolean isBillingReportLinkDisplayed = WebUI.verifyElementPresent(oBillingReportLink, GlobalVariable.TIMEOUT, FailureHandling.OPTIONAL)
		if(isCensusReportLinkDisplayed || isBillingReportLinkDisplayed){
			bool = true
		}

		return bool
	}
}