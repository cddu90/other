package pageobjects.employerreports
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject

import com.kms.katalon.core.annotation.Keyword
import com.kms.katalon.core.model.FailureHandling
import com.kms.katalon.core.testobject.TestObject
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI

import internal.GlobalVariable


class CreateBillingReportPage {

	TestObject oAllSubgroupsCheckBox = findTestObject('Page_EmployerBilling/Page_CreateBillingReport/input_Subgroups_selectAll')
	TestObject oSubmitButton =findTestObject('Page_EmployerBilling/Page_CreateBillingReport/input_Submit_submitButton')
	TestObject oBillingDateYear = findTestObject('Page_EmployerBilling/Page_CreateBillingReport/select_year201720182019')
	TestObject oBillingDateMonth = findTestObject('Object Repository/Page_EmployerBilling/Page_CreateBillingReport/select_month')
	TestObject oCancelButton = findTestObject('Page_EmployerBilling/Page_Welcome Billing Reports/Page_Create Billing Report/Cancel Button')
	TestObject oCloseCreateReportLink = findTestObject('Page_EmployerBilling/Page_Welcome Billing Reports/Page_Create Billing Report/Close Create Report Window')
	TestObject oEmailNotificationCheckBox = findTestObject('Page_EmployerBilling/Page_CreateBillingReport/input_Email Notification_emailNotify')
	TestObject oSingleSubgrpupCheckbox = findTestObject('Page_EmployerBilling/Page_Welcome Billing Reports/Page_Create Billing Report/Single Subgroup Check Box')
	TestObject oMsgSuccessfullySubmitted = findTestObject('Page_EmployerBilling/Page_CreateBillingReport/h4_Your report request has been submitted successfully')
	TestObject okButton = findTestObject('Page_EmployerBilling/Page_CreateBillingReport/okButton')
	@Keyword
	def boolean isPageDisplayed(){
		boolean isSubmitButtonDisplayed = WebUI.waitForElementPresent(oSubmitButton, GlobalVariable.TIMEOUT, FailureHandling.STOP_ON_FAILURE)
		if(isSubmitButtonDisplayed) return true
		else return false
	}
}