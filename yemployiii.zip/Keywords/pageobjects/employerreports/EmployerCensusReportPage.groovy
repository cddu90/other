package pageobjects.employerreports

import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject

import com.kms.katalon.core.model.FailureHandling
import com.kms.katalon.core.testobject.TestObject
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI

import internal.GlobalVariable

public class EmployerCensusReportPage {

	TestObject oCreateReport = findTestObject('Page_Employer Census Report/create report Button')
	TestObject oEmployeeAndDependent = findTestObject('Page_Employer Census Report/Employee and Dependent RadioButton')
	TestObject oEmployee = findTestObject('Object Repository/Page_Employer Census Report/Employee RadioBUtton')
	TestObject oSubgroups = findTestObject('Object Repository/Page_Employer Census Report/Subgroups Drop Down')
	TestObject oContinue = findTestObject('Object Repository/Page_Employer Census Report/Continue Link')
	TestObject oInactiveMembers = findTestObject('Object Repository/Page_Employer Census Report/Census Report Selection PopUp/Inactive Members CheckBox')
	TestObject oSubmit = findTestObject('Object Repository/Page_Employer Census Report/Census Report Selection PopUp/Submit Census Report Button')
	TestObject oRequestId = findTestObject('Object Repository/Page_Employer Census Report/Page_Census Generated Report/Request Id')
	TestObject oSubgroupsTwo = findTestObject('Object Repository/Page_Employer Census Report/Page_Census Generated Report/Subgroups')
	TestObject oReportType = findTestObject('Object Repository/Page_Employer Census Report/Page_Census Generated Report/Report Type')
	TestObject oRequestedDate = findTestObject('Object Repository/Page_Employer Census Report/Page_Census Generated Report/Requested Date')
	TestObject oSortBy = findTestObject('Object Repository/Page_Employer Census Report/Page_Census Generated Report/Sort By')
	TestObject oFormat = findTestObject('Object Repository/Page_Employer Census Report/Page_Census Generated Report/Format')
	TestObject oStatus = findTestObject('Object Repository/Page_Employer Census Report/Status')
	TestObject oDeleteButton = findTestObject('Object Repository/Page_Employer Census Report/Page_Census Generated Report/Delete BUtton')
	TestObject o2HourMessage = findTestObject('Object Repository/Page_Employer Census Report/Page_Census Generated Report/Typically report take 2 hours Message')
	TestObject oSubmittedMsg = findTestObject('Object Repository/Page_Employer Census Report/Page_Census Generated Report/Your report request submitted message')
	TestObject oOkButton = findTestObject('Object Repository/Page_Employer Census Report/Page_Census Generated Report/OK Button')
	TestObject oReportLessThan100Msg = findTestObject('Object Repository/Page_Employer Census Report/Your report has less than 100 Message')
	TestObject oDownloadRoster = findTestObject('Object Repository/Page_Employer Census Report/a_Download from Roster page')
	TestObject oCancelLink = findTestObject('Object Repository/Page_Employer Census Report/Cancel Link')

	boolean isPageDisplayed(){

		boolean bool = false
		boolean isCreateReportDisplayed = WebUI.verifyElementPresent(oCreateReport, GlobalVariable.TIMEOUT, FailureHandling.OPTIONAL)
		if(isCreateReportDisplayed){
			bool = true
		}

		return bool
	}

	boolean isElementsInPageDisplayed(){

		boolean bool = false
		boolean isEmployeeDependentDisplayed = WebUI.verifyElementPresent(oEmployeeAndDependent, GlobalVariable.TIMEOUT, FailureHandling.STOP_ON_FAILURE)
		boolean isSubgroupDownDisplayed = WebUI.verifyElementPresent(oSubgroups, GlobalVariable.TIMEOUT, FailureHandling.STOP_ON_FAILURE)
		boolean isSubmitButtonDisplayed = WebUI.verifyElementPresent(oSubmit, GlobalVariable.TIMEOUT, FailureHandling.STOP_ON_FAILURE)
		boolean isCancelButtonDisplayed = WebUI.verifyElementPresent(oCancelLink, GlobalVariable.TIMEOUT, FailureHandling.STOP_ON_FAILURE)

		if(isEmployeeDependentDisplayed && isSubgroupDownDisplayed && isSubmitButtonDisplayed && isCancelButtonDisplayed){
			bool = true
		}

		return bool
	}
}
