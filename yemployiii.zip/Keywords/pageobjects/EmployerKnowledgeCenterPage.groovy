package pageobjects
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject

import com.kms.katalon.core.annotation.Keyword
import com.kms.katalon.core.model.FailureHandling
import com.kms.katalon.core.testobject.TestObject
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI

import internal.GlobalVariable


class EmployerKnowledgeCenterPage {

	TestObject breadCrumb_home_knowledgeCenter = findTestObject('Object Repository/Page_Knowledge Center/ul_HomeKnowledge Center')
	TestObject title_knowledgeCenter = findTestObject('Object Repository/Page_Knowledge Center/h1_Knowledge Center')

	boolean isPageDisplayed(){
		WebUI.waitForElementPresent(title_knowledgeCenter, GlobalVariable.TIMEOUT,FailureHandling.STOP_ON_FAILURE)
		boolean isBreadCrumbKnowledgeCenterDisplayed = WebUI.verifyElementPresent(breadCrumb_home_knowledgeCenter, 0)
		if(isBreadCrumbKnowledgeCenterDisplayed){
			return true
		} else return false
	}
}