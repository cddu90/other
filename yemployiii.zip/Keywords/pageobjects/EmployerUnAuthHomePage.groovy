package pageobjects
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject

import com.kms.katalon.core.testobject.TestObject
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI

import internal.GlobalVariable


/**
 * Page Class to capture elements, actions and helper methods on EmployerUnAuthHomePage
 * @author pkonda01
 *
 */
class EmployerUnAuthHomePage{

	//Define TestObjects
	TestObject oRegisterNowButton =  findTestObject('Page_EmployerUnAuthHome/Link_RegisterNow')


	/**
	 * Verify if page is up
	 * @return
	 */
	boolean isPageDisplayed(){
		return WebUI.verifyElementPresent(oRegisterNowButton, GlobalVariable.TIMEOUT)
	}


	void login(String username, String password){

	}



}