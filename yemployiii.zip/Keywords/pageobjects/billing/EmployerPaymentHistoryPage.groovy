package pageobjects.billing
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject

import com.kms.katalon.core.annotation.Keyword
import com.kms.katalon.core.model.FailureHandling
import com.kms.katalon.core.testobject.TestObject
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI

import internal.GlobalVariable


class EmployerPaymentHistoryPage {

	TestObject oCancelConfirmationButton = findTestObject('Page_EmployerBilling/SubPage_PaymentHistory/input_Cancel One-Time Payment Confirmation_yes')
	TestObject oCancelButton = findTestObject('Page_EmployerBilling/SubPage_PaymentHistory/CancelButton')
	TestObject oBillingLink = findTestObject('Page_EmployerAuthLandingPage/link_billing')
	TestObject oBillingCenterLink = findTestObject('Page_EmployerBilling/link_billingCenter')
	TestObject oActionTitle = findTestObject('Page_EmployerBilling/SubPage_PaymentHistory/Action Title')
	TestObject oAmountPaidTitle = findTestObject('Page_EmployerBilling/SubPage_PaymentHistory/Amount Paid Title')
	TestObject oCheckTitle = findTestObject('Page_EmployerBilling/SubPage_PaymentHistory/Check Title')
	TestObject oMethodTitle = findTestObject('Page_EmployerBilling/SubPage_PaymentHistory/Method Title')
	TestObject oPaidDateTitle = findTestObject('Page_EmployerBilling/SubPage_PaymentHistory/Paid Date Title')
	TestObject oRecieptTitle = findTestObject('Page_EmployerBilling/SubPage_PaymentHistory/Receipt Title')
	TestObject oStatusTitle = findTestObject('Page_EmployerBilling/SubPage_PaymentHistory/Status Title')
	TestObject oSubgroupTitle = findTestObject('Page_EmployerBilling/SubPage_PaymentHistory/Subgroup Title')
	TestObject oCloseCancelDialogBox = findTestObject('Page_EmployerBilling/SubPage_PaymentHistory/img')
	TestObject oSearchButton = findTestObject('Page_EmployerBilling/SubPage_PaymentHistory/button_search')
	TestObject dynamicDeleteButton = new TestObject("DynamicDeleteButton")
	TestObject oFromDateInput = findTestObject('Page_EmployerBilling/Page_Billing History/From Date Input')
	//TestObject oSearchButton_new = findTestObject('Page_EmployerBilling/Page_Billing History/Search Button')

	@Keyword
	def boolean isPageDisplayed(){
		boolean isSearchButtonDisplayed = WebUI.verifyElementPresent(oSearchButton, GlobalVariable.TIMEOUT, FailureHandling.STOP_ON_FAILURE)
		if(isSearchButtonDisplayed){
			return true
		} else return false
	}

	@Keyword
	def boolean isPaymentHistoryTableDisplayed(){
		boolean isActionTitleDisplayed = WebUI.verifyElementPresent(oActionTitle, GlobalVariable.TIMEOUT, FailureHandling.STOP_ON_FAILURE)
		boolean isoRecieptTitleDisplayed = WebUI.verifyElementPresent(oRecieptTitle, GlobalVariable.TIMEOUT, FailureHandling.STOP_ON_FAILURE)
		boolean isoPaidDateTitleDisplayed = WebUI.verifyElementPresent(oPaidDateTitle, GlobalVariable.TIMEOUT, FailureHandling.STOP_ON_FAILURE)
		boolean isoSubgroupTitleDisplayed = WebUI.verifyElementPresent(oSubgroupTitle, GlobalVariable.TIMEOUT, FailureHandling.STOP_ON_FAILURE)
		boolean isoStatusTitleDisplayed = WebUI.verifyElementPresent(oStatusTitle, GlobalVariable.TIMEOUT, FailureHandling.STOP_ON_FAILURE)
		boolean isoCheckTitleDisplayed = WebUI.verifyElementPresent(oCheckTitle, GlobalVariable.TIMEOUT, FailureHandling.STOP_ON_FAILURE)
		boolean isoAmountPaidTitleDisplayed = WebUI.verifyElementPresent(oAmountPaidTitle, GlobalVariable.TIMEOUT, FailureHandling.STOP_ON_FAILURE)
		boolean isoMethodTitleDisplayed = WebUI.verifyElementPresent(oMethodTitle, GlobalVariable.TIMEOUT, FailureHandling.STOP_ON_FAILURE)
		if(isActionTitleDisplayed && isoRecieptTitleDisplayed && isoMethodTitleDisplayed && isoStatusTitleDisplayed && isoSubgroupTitleDisplayed && isoPaidDateTitleDisplayed && isoCheckTitleDisplayed && isoAmountPaidTitleDisplayed) {
			return true
		} else return false
	}

	void cancelPayments(){

		if(isPageDisplayed()){


			WebUI.click(oCancelButton, FailureHandling.OPTIONAL)

			WebUI.click(oCancelConfirmationButton,FailureHandling.OPTIONAL)

			WebUI.click(oCloseCancelDialogBox,FailureHandling.OPTIONAL)

		}



	}
}