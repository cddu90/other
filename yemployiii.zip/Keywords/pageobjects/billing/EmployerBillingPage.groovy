package pageobjects.billing
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject

import com.kms.katalon.core.model.FailureHandling
import com.kms.katalon.core.testobject.TestObject
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI

import internal.GlobalVariable


class EmployerBillingPage {

	TestObject link_billingCenter = findTestObject('Page_EmployerBilling/link_billingCenter')

	TestObject link_autoPayments = findTestObject('Page_EmployerBilling/link_autoPayments')

	TestObject link_billingOptions = findTestObject('Page_EmployerBilling/link_billingOptions')

	TestObject link_makePayment = findTestObject('Object Repository/Page_EmployerBilling/a_Make a Payment')

	TestObject link_paymentHistory = findTestObject('Page_EmployerBilling/SubPage_BillingCenter/link_paymentHistory')

	TestObject link_searchInvoices = findTestObject('Page_EmployerBilling/link_searchInvoices')

	TestObject homeLink = findTestObject('Object Repository/Page_EmployerBilling/homeLink')


	/**
	 * 
	 * @return
	 */
	boolean isPageDisplayed(){
		boolean bool = false
		boolean isBillingCenterDisplayed = WebUI.verifyElementPresent(link_billingCenter, GlobalVariable.TIMEOUT,FailureHandling.STOP_ON_FAILURE)
		boolean isBillingOptionsDisplayed = WebUI.verifyElementPresent(link_billingOptions, GlobalVariable.TIMEOUT)
		boolean isAutoPaymentDisplayed = WebUI.verifyElementPresent(link_autoPayments, GlobalVariable.TIMEOUT)
		boolean isMakePaymentDisplayed = WebUI.verifyElementPresent(link_makePayment, GlobalVariable.TIMEOUT)
		boolean isPaymentHistoryDisplayed = WebUI.verifyElementPresent(link_paymentHistory, GlobalVariable.TIMEOUT)
		boolean isSearchInvoicesDisplayed = WebUI.verifyElementPresent(link_searchInvoices, GlobalVariable.TIMEOUT)
		if(isBillingCenterDisplayed && isBillingOptionsDisplayed && isAutoPaymentDisplayed && isSearchInvoicesDisplayed && isMakePaymentDisplayed && isPaymentHistoryDisplayed){
			bool = true
		}

		return bool
	}
}