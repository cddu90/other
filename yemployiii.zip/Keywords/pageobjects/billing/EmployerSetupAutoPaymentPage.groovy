package pageobjects.billing
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject

import com.kms.katalon.core.annotation.Keyword
import com.kms.katalon.core.model.FailureHandling
import com.kms.katalon.core.testobject.TestObject
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI

import internal.GlobalVariable


class EmployerSetupAutoPaymentPage {

	TestObject oCancelExistingAutoPayButton = findTestObject('Page_EmployerBilling/SubPage_SetupAutoPayments/button_cancelExistingAutoPay')
	TestObject oSpanAddNewAutoPayment = findTestObject('Page_EmployerBilling/SubPage_SetupAutoPayments/span_Adda new Auto Payment')
	TestObject oSubgroupDropDown = findTestObject('Page_EmployerBilling/SubPage_SetupAutoPayments/select_Subgroup')
	TestObject oBankAccountDropDown = findTestObject('Page_EmployerBilling/SubPage_SetupAutoPayments/select_listOfBankAccount')
	TestObject oAddBankAccount = findTestObject('Page_EmployerBilling/SubPage_SetupAutoPayments/a_AddBank Account')
	TestObject oSaveButton = findTestObject('Page_EmployerBilling/SubPage_SetupAutoPayments/input_AddBank Account_btnAPSubmit')
	@Keyword
	def boolean isPageDisplayed(){
		boolean isSpanAddNewAutoPaymentDisplayed = WebUI.verifyElementPresent(oSpanAddNewAutoPayment, GlobalVariable.TIMEOUT, FailureHandling.STOP_ON_FAILURE)
		if(isSpanAddNewAutoPaymentDisplayed){
			return true
		} else return false
	}

	@Keyword
	def boolean setUpAutoPay(String subGroupID){

		WebUI.click(oSpanAddNewAutoPayment)

		WebUI.delay(GlobalVariable.TIMEOUT)

		WebUI.selectOptionByValue(oSubgroupDropDown, subGroupID, false)

		WebUI.selectOptionByIndex(oBankAccountDropDown, 1)

		WebUI.delay(GlobalVariable.TIMEOUT)

		WebUI.waitForElementClickable(oSaveButton, GlobalVariable.TIMEOUT)

		WebUI.verifyElementClickable(oSaveButton, FailureHandling.STOP_ON_FAILURE)

		//WebUI.focus(oSaveButton)

		WebUI.click(oSaveButton)
	}
}