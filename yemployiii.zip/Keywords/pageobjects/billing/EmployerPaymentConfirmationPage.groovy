package pageobjects.billing
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject

import com.kms.katalon.core.annotation.Keyword
import com.kms.katalon.core.model.FailureHandling
import com.kms.katalon.core.testobject.TestObject
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI

import internal.GlobalVariable


class EmployerPaymentConfirmationPage {

	TestObject oPaymentHistoryLink = findTestObject('Page_EmployerBilling/SubPage_BillingOptions/a_Payment History')
	TestObject oSetUpAutoPaymentLink = findTestObject('Page_EmployerBilling/SubPage_PaymentConfirmation/Setup auto payment link')
	TestObject oMakeAnotherPaymentLink = findTestObject('Page_EmployerBilling/SubPage_PaymentConfirmation/Make another payment link')
	TestObject oPaymentSubmittedText = findTestObject('Page_EmployerBilling/SubPage_PaymentConfirmation/Your Payment has been submi')
	TestObject oBillingOptionsLink = findTestObject('Page_EmployerBilling/SubPage_PaymentConfirmation/link_menuBillingOptions')
	TestObject oYesButtonConfirmationBoxAfter6 = findTestObject('Page_EmployerBilling/SubPage_PaymentConfirmation/YesButton')

	@Keyword
	def boolean isPageDisplayed(){
		boolean isPaymentHistoryLinkDisplayed = WebUI.verifyElementPresent(oPaymentHistoryLink, GlobalVariable.TIMEOUT, FailureHandling.STOP_ON_FAILURE)
		boolean isSetUpAutoPaymentLink = WebUI.verifyElementPresent(oSetUpAutoPaymentLink, GlobalVariable.TIMEOUT)
		boolean isMakeAnotherPaymentLink = WebUI.verifyElementPresent(oMakeAnotherPaymentLink, GlobalVariable.TIMEOUT)
		boolean isPaymentSubmittedText = WebUI.verifyElementPresent(oPaymentSubmittedText, GlobalVariable.TIMEOUT)
		if(isPaymentHistoryLinkDisplayed && isPaymentSubmittedText && isSetUpAutoPaymentLink && isMakeAnotherPaymentLink){
			return true
		} else return false
	}
	
	/**
	 * 
	 * @return
	 */
	boolean isYesButtonDisplayed(){
		boolean bool = false
		boolean isYesButtonDisplayed = WebUI.verifyElementPresent(oYesButtonConfirmationBoxAfter6, 5, FailureHandling.OPTIONAL)
		if(isYesButtonDisplayed){
			bool = true
		}
		return bool
	}
}