package pageobjects.billing
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject

import com.kms.katalon.core.annotation.Keyword
import com.kms.katalon.core.model.FailureHandling
import com.kms.katalon.core.testobject.TestObject
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI
import internal.GlobalVariable


class EmployerMakePaymentPage {

	TestObject oSubgroupDropdown = findTestObject('Page_EmployerBilling/SubPage_MakePayment/Subgroup DropDown')
	TestObject oCurrentBillAmount = findTestObject('Page_EmployerBilling/SubPage_MakePayment/Current Bill Amnt')
	TestObject oPreviousBalance
	TestObject oAmountDue = findTestObject('Page_EmployerBilling/SubPage_MakePayment/Amount Due Lable')
	TestObject oPaymentAmount = findTestObject('Page_EmployerBilling/SubPage_MakePayment/Payment Amount')
	TestObject oBankAccount = findTestObject('Page_EmployerBilling/SubPage_MakePayment/Bank Account Selection')
	TestObject oNameOnAccount = findTestObject('Page_EmployerBilling/SubPage_MakePayment/Name on Account')
	TestObject oAccountType = findTestObject('Page_EmployerBilling/SubPage_MakePayment/Account Type DropDown')
	TestObject oAccountNumber = findTestObject('Page_EmployerBilling/SubPage_MakePayment/Account Number')
	TestObject oABARoutingNumber = findTestObject('Page_EmployerBilling/SubPage_MakePayment/ABA Routing Number')
	TestObject oAccountNickName = findTestObject('Page_EmployerBilling/SubPage_MakePayment/Account Nickname')
	TestObject oNextButton =  findTestObject('Page_EmployerBilling/SubPage_MakePayment/button_next')
	TestObject oAddBankAccountLink = findTestObject('Page_EmployerBilling/SubPage_MakePayment/Add Bank Account Link')

	/**
	 * 
	 * @return
	 */
	@Keyword
	def boolean isPageDisplayed(){
		boolean isSubgroupDopDownDisplayed = WebUI.waitForElementPresent(oSubgroupDropdown, GlobalVariable.TIMEOUT, FailureHandling.STOP_ON_FAILURE)
		boolean isCurrentBillAmountDisplayed = WebUI.waitForElementPresent(oCurrentBillAmount, GlobalVariable.TIMEOUT)
		boolean isAmountDueDisplayed = WebUI.waitForElementPresent(oAmountDue, GlobalVariable.TIMEOUT)
		boolean isPaymentAmountDisplayed = WebUI.waitForElementPresent(oPaymentAmount, GlobalVariable.TIMEOUT)
		boolean isBankAccountDisplayed = WebUI.waitForElementPresent(oBankAccount, GlobalVariable.TIMEOUT)
		
		if(isSubgroupDopDownDisplayed && isCurrentBillAmountDisplayed && isAmountDueDisplayed && isPaymentAmountDisplayed && isBankAccountDisplayed){
			return true
		} else return false
	}

	/**
	 * 
	 * @param accountName
	 * @param accountNumber
	 * @param routingNumber
	 * @param nickName
	 * @return
	 */
	@Keyword
	def addBankDetails(String accountName, String accountNumber, String routingNumber, String nickName){
		if(isPageDisplayed()){
			WebUI.verifyElementPresent(oAddBankAccountLink, GlobalVariable.TIMEOUT, FailureHandling.STOP_ON_FAILURE)
			WebUI.click(oAddBankAccountLink)
			WebUI.verifyElementPresent(oNameOnAccount, GlobalVariable.TIMEOUT)
			WebUI.sendKeys(oNameOnAccount, accountName)
			WebUI.selectOptionByIndex(oAccountType, '1')
			WebUI.sendKeys(oAccountNumber, accountNumber)
			WebUI.sendKeys(oABARoutingNumber,routingNumber)
			WebUI.sendKeys(oAccountNickName, nickName)
			WebUI.verifyElementPresent(oNextButton, GlobalVariable.TIMEOUT)
			WebUI.click(oNextButton)
		}
	}
	
	/**
	 * 
	 * @param paymentAmount
	 * @return
	 */
	@Keyword
	def addPaymentDetails(String paymentAmount, String groupSubgroupNumber){
		if(isPageDisplayed()){
			WebUI.delay(10)
			println("groupnumber is " +groupSubgroupNumber)
			//WebUI.selectOptionByIndex(oSubgroupDropdown, 1)
			WebUI.selectOptionByValue(oSubgroupDropdown, groupSubgroupNumber, false)
			//WebUI.waitForElementPresent(oAmountDue, GlobalVariable.TIMEOUT)
			WebUI.delay(10)
			WebUI.setText(oPaymentAmount, paymentAmount)
		}
	}
}