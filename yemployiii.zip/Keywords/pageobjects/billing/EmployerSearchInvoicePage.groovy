package pageobjects.billing
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject

import com.kms.katalon.core.annotation.Keyword
import com.kms.katalon.core.model.FailureHandling
import com.kms.katalon.core.testobject.TestObject
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI

import internal.GlobalVariable


class EmployerSearchInvoicePage {

	TestObject oSearchButton = findTestObject('Page_EmployerBilling/SubPage_SearchInvoices/Search Invoces Button')
	TestObject oInvoiceID = findTestObject('Page_EmployerBilling/SubPage_SearchInvoices/div_Invoice ID')
	TestObject oSubgroup = findTestObject('Page_EmployerBilling/SubPage_SearchInvoices/div_Subgroup')
	TestObject oExportResults = findTestObject('Page_EmployerBilling/SubPage_SearchInvoices/a_Export results')
	TestObject oInvoiceDate = findTestObject('Page_EmployerBilling/SubPage_SearchInvoices/div_Invoice Date')
	TestObject oBillingPeriod = findTestObject('Page_EmployerBilling/SubPage_SearchInvoices/div_Billing Period')
	TestObject oDueDate = findTestObject('Page_EmployerBilling/SubPage_SearchInvoices/div_Due Date')
	TestObject oAmountDue = findTestObject('Page_EmployerBilling/SubPage_SearchInvoices/div_Amount Due')
	TestObject oPreviousAmounDue = findTestObject('Page_EmployerBilling/SubPage_SearchInvoices/td_Previous Amount Due')
	TestObject oPayment = findTestObject('Page_EmployerBilling/SubPage_SearchInvoices/td_Payments - thank you')
	TestObject oRetroActiveAdjustments = findTestObject('Page_EmployerBilling/SubPage_SearchInvoices/td_Retroactive Adjustments')
	TestObject oNetCreditDebit = findTestObject('Page_EmployerBilling/SubPage_SearchInvoices/td_Net CreditsDebits')
	TestObject oBalance = findTestObject('Page_EmployerBilling/SubPage_SearchInvoices/td_Balance')
	TestObject oCurrentCharges = findTestObject('Page_EmployerBilling/SubPage_SearchInvoices/td_Current Charges')
	TestObject oNoInvoicesMsg = findTestObject('Page_EmployerBilling/SubPage_SearchInvoices/span_There are no invoices tha')
	//String strOnclickValue = "toggle(\$(this), 'record_1')"
	TestObject oExpandForInvoiceDetails = new TestObject("objectName")



	/**
	 * Verify if Search Invoice page is up
	 * @return
	 */
	@Keyword
	def boolean isPageDisplayed(){
		boolean isSearchButtonDisplayed = WebUI.verifyElementPresent(oSearchButton, GlobalVariable.TIMEOUT, FailureHandling.STOP_ON_FAILURE)
		if(isSearchButtonDisplayed){
			return true
		} else return false
	}

	/**
	 * Verify content of Search results page are displayed
	 * @return
	 */
	@Keyword
	def boolean verifyContentOfSearchResults(){
		boolean isExportLinkDisplayed = WebUI.verifyElementPresent(oExportResults, GlobalVariable.TIMEOUT)
		boolean isAmountDueDisplayed = WebUI.verifyElementPresent(oAmountDue, GlobalVariable.TIMEOUT)
		boolean isInvoiceIDDisplayed = WebUI.verifyElementPresent(oInvoiceID, GlobalVariable.TIMEOUT)
		boolean isSubgroupDisplayed = WebUI.verifyElementPresent(oSubgroup, GlobalVariable.TIMEOUT)
		boolean isBillingPeriodDisplayed = WebUI.verifyElementPresent(oBillingPeriod, GlobalVariable.TIMEOUT)
		boolean isDueDateDisplayed = WebUI.verifyElementPresent(oDueDate, GlobalVariable.TIMEOUT)
		boolean isInvoiceDateDisplayed = WebUI.verifyElementPresent(oInvoiceDate, GlobalVariable.TIMEOUT)
		if(isExportLinkDisplayed && isAmountDueDisplayed && isInvoiceIDDisplayed && isSubgroupDisplayed && isBillingPeriodDisplayed && isDueDateDisplayed && isInvoiceDateDisplayed){
			return true
		} else return false
	}

	/**
	 * Verify Invoice Content is displayed
	 * @return
	 */
	@Keyword
	def boolean verifyContentInInvoiceDetails(){
		boolean isPreviousAmountDueDisplayed = WebUI.verifyElementPresent(oPreviousAmounDue, GlobalVariable.TIMEOUT)
		boolean isPaymentDisplayed = WebUI.verifyElementPresent(oPayment, GlobalVariable.TIMEOUT)
		boolean isRetroAdjustmentsDisplayed = WebUI.verifyElementPresent(oRetroActiveAdjustments, GlobalVariable.TIMEOUT)
		boolean isNetCreditDebitDisplayed = WebUI.verifyElementPresent(oNetCreditDebit, GlobalVariable.TIMEOUT)
		boolean isBalanceDisplayed = WebUI.verifyElementPresent(oBalance, GlobalVariable.TIMEOUT)
		boolean isCurrentChargesDisplayed = WebUI.verifyElementPresent(oCurrentCharges, GlobalVariable.TIMEOUT)
		if(isPreviousAmountDueDisplayed && isPaymentDisplayed && isRetroAdjustmentsDisplayed && isNetCreditDebitDisplayed && isBalanceDisplayed && isCurrentChargesDisplayed){

			return true
		} else {

			return false
		}
	}
}