 package pageobjects.billing
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject

import com.kms.katalon.core.annotation.Keyword
import com.kms.katalon.core.model.FailureHandling
import com.kms.katalon.core.testobject.TestObject
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI

import internal.GlobalVariable


class EmployerBillingCenterPage {

	TestObject text_billingCenterTitle = findTestObject('Page_EmployerBilling/SubPage_BillingCenter/span_billingCenterTitle')
	TestObject text_billingCenterBreadcrumb = findTestObject('Page_EmployerBilling/SubPage_BillingCenter/span_billingCenterBreadCrumb')
	TestObject text_helpfulLinks = findTestObject('Page_EmployerBilling/SubPage_BillingCenter/h2_helpfulLinks')
	TestObject link_employerHome = findTestObject('Page_EmployerBilling/SubPage_BillingCenter/link_home')

	TestObject oDivBillingPeriod = findTestObject('Page_EmployerBilling/SubPage_BillingCenter/div_billingPeriod')
	TestObject oDivDueDate = findTestObject('Page_EmployerBilling/SubPage_BillingCenter/div_dueDate')
	TestObject oAmountDue = findTestObject('Page_EmployerBilling/SubPage_BillingCenter/div_amountDue')
	TestObject oDivInvoiceDate = findTestObject('Page_EmployerBilling/SubPage_BillingCenter/div_invoiceDate')
	TestObject oInvoiceID = findTestObject('Page_EmployerBilling/SubPage_BillingCenter/div_invoice ID')

	TestObject oViewPastInvoices = findTestObject('Page_EmployerBilling/SubPage_BillingCenter/View Past Invoices')
	TestObject oViewBillingAddress = findTestObject('Page_EmployerBilling/SubPage_BillingCenter/View your Billing Address Page')
	TestObject oDivSubgroup = findTestObject('Page_EmployerBilling/SubPage_BillingCenter/div_Subgroup')
	TestObject oPaymentPolicies = findTestObject('Page_EmployerBilling/SubPage_BillingCenter/Payment Policies')
	TestObject oPaymentHistoryLink = findTestObject('Page_EmployerBilling/SubPage_BillingCenter/link_paymentHistory')

	TestObject oViewOrUpdateRoster = findTestObject('Object Repository/Page_EmployerBilling/SubPage_BillingCenter/a_Verify rosters')


	@Keyword
	def boolean isPageDisplayed(){
		boolean isDivBillingPeriodDisplayed = WebUI.verifyElementPresent(oDivBillingPeriod, GlobalVariable.TIMEOUT, FailureHandling.STOP_ON_FAILURE)
		boolean isDivDueDateDisplayed = WebUI.verifyElementPresent(oDivDueDate, GlobalVariable.TIMEOUT)
		boolean isDivAmountDueDisplayed = WebUI.verifyElementPresent(oAmountDue, GlobalVariable.TIMEOUT)
		boolean isDivInvoiceIDDisplayed = WebUI.verifyElementPresent(oInvoiceID,GlobalVariable.TIMEOUT)
		boolean isDivInvoiceDateDisplayed = WebUI.verifyElementPresent(oDivInvoiceDate, GlobalVariable.TIMEOUT)

		if(isDivAmountDueDisplayed && isDivBillingPeriodDisplayed && isDivInvoiceDateDisplayed && isDivInvoiceIDDisplayed && isDivDueDateDisplayed){
			return true
		} else return false
	}
}