package pageobjects.billing
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject

import com.kms.katalon.core.annotation.Keyword
import com.kms.katalon.core.model.FailureHandling
import com.kms.katalon.core.testobject.TestObject
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI

import internal.GlobalVariable


class EmployerBillingOptionsPage {

	TestObject oAccountName = findTestObject('Page_EmployerBilling/SubPage_BillingOptions/input_ Name on Account_bankDet')
	TestObject oAccountType= findTestObject('Page_EmployerBilling/SubPage_BillingOptions/select_Choose account typeCHEC')
	TestObject oAccountNumber = findTestObject('Page_EmployerBilling/SubPage_BillingOptions/input_ Account Number_bankDeta')
	TestObject oABARoutingNumber = findTestObject('Page_EmployerBilling/SubPage_BillingOptions/input_ ABA Routing Number_bank')
	TestObject oAccountNickName = findTestObject('Page_EmployerBilling/SubPage_BillingOptions/input_ Account Nickname_bankDe')
	TestObject oBillingOptionsHeader = findTestObject('Page_EmployerBilling/SubPage_BillingOptions/header_billingOptions')
	TestObject oAddNewAccount = findTestObject('Page_EmployerBilling/SubPage_BillingOptions/toggle_addBankAccount')
	TestObject oAddAccountButton = findTestObject('Page_EmployerBilling/SubPage_BillingOptions/input_ Account Nickname_submit')
	TestObject oMenuAutoPaymentLink = findTestObject('Page_EmployerBilling/SubPage_BillingOptions/link_autoPaymentMenu')
	TestObject oPaymentHistoryLink = findTestObject('Page_EmployerBilling/SubPage_BillingOptions/a_Payment History')
	TestObject oCannotDeleteMsg = findTestObject('Page_EmployerBilling/SubPage_BillingOptions/You cannot delete this bank Account')
	TestObject divDeleteBankConfirmation = findTestObject('Object Repository/Page_EmployerBilling/SubPage_BillingOptions/div_Delete Bank Account Confirmation')
	TestObject imgClose = findTestObject('Object Repository/Page_EmployerBilling/SubPage_BillingOptions/img')

	/**
	 * Verify if Billing Options page is up
	 * @return
	 */
	@Keyword
	def boolean isPageDisplayed(){
		boolean isBillingOptionsDisplayed = WebUI.verifyElementPresent(oBillingOptionsHeader, GlobalVariable.TIMEOUT, FailureHandling.STOP_ON_FAILURE)
		boolean isAddNewAccount = WebUI.verifyElementPresent(oAddNewAccount, GlobalVariable.TIMEOUT, FailureHandling.STOP_ON_FAILURE)
		if(isBillingOptionsDisplayed && isAddNewAccount){
			return true
		} else return false
	}

	/**
	 * Add bank account with accountName, accountNum, Routing Num as parameters
	 * @param accountName
	 * @param accountNum
	 * @param routingNum
	 * @return
	 */
	@Keyword
	def addBankAccount(String accountName, String accountNum, String routingNum){
		WebUI.click(oAddNewAccount)

		WebUI.setText(oAccountName, accountName)

		WebUI.selectOptionByIndex(oAccountType, 1)

		WebUI.setText(oAccountNumber, accountNum)

		WebUI.setText(oABARoutingNumber, routingNum)

		WebUI.setText(oAccountNickName, accountName)

		WebUI.click(oAddAccountButton)
	}

	void deleteBankAccount(){
	}
}