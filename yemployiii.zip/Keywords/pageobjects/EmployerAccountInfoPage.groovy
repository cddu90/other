package pageobjects
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject

import com.kms.katalon.core.model.FailureHandling
import com.kms.katalon.core.testobject.TestObject
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI

import internal.GlobalVariable


class EmployerAccountInfoPage {
	TestObject buttonSave =  findTestObject('Page_Employer Forgot User-Password/AccountInfo/input')
	TestObject inputPassword = findTestObject('Page_Employer Forgot User-Password/AccountInfo/input_ Password_userAccountInf')
	TestObject inputConfirmPassword = findTestObject('Page_Employer Forgot User-Password/AccountInfo/input_ Confirm Password_userAc')
	

	/**
	 * 
	 * @return
	 */
	void updatePassword(String strNewPassword){
		WebUI.setEncryptedText(inputPassword,strNewPassword)
		WebUI.setEncryptedText(inputConfirmPassword,strNewPassword)
		WebUI.click(buttonSave)
	}
	
	
	
}