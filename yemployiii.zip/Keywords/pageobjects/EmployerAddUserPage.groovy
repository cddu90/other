package pageobjects

import static com.kms.katalon.core.checkpoint.CheckpointFactory.findCheckpoint
import static com.kms.katalon.core.testcase.TestCaseFactory.findTestCase
import static com.kms.katalon.core.testdata.TestDataFactory.findTestData
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject
import static com.kms.katalon.core.testobject.ObjectRepository.findWindowsObject

import com.github.javafaker.Faker
import org.apache.commons.lang.RandomStringUtils
import org.apache.commons.lang3.RandomUtils
import org.apache.commons.lang3.StringUtils

import com.kms.katalon.core.annotation.Keyword
import com.kms.katalon.core.checkpoint.Checkpoint
import com.kms.katalon.core.cucumber.keyword.CucumberBuiltinKeywords as CucumberKW
import com.kms.katalon.core.mobile.keyword.MobileBuiltInKeywords as Mobile
import com.kms.katalon.core.model.FailureHandling
import com.kms.katalon.core.testcase.TestCase
import com.kms.katalon.core.testdata.TestData
import com.kms.katalon.core.testobject.TestObject
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WS
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI
import com.kms.katalon.core.windows.keyword.WindowsBuiltinKeywords as Windows

import internal.GlobalVariable

public class EmployerAddUserPage {

	TestObject inputFName = findTestObject('Page_ManageUsers/SubPage_AddUser/input_ First Name')
	TestObject inputLName = findTestObject('Page_ManageUsers/SubPage_AddUser/input_ Last Name')
	TestObject inputEmail = findTestObject('Page_ManageUsers/SubPage_AddUser/input_ Email_emailAddress')
	TestObject inputConfirmEmail = findTestObject('Page_ManageUsers/SubPage_AddUser/input_ Confirm Email')
	TestObject inputPhoneNum1 = findTestObject('Page_ManageUsers/SubPage_AddUser/input_phoneNumber1')
	TestObject inputPhoneNum2 = findTestObject('Page_ManageUsers/SubPage_AddUser/input_phoneNumber2')
	TestObject inputPhoneNum3 = findTestObject('Page_ManageUsers/SubPage_AddUser/input_phoneNumber3')
	TestObject inputView = findTestObject('Page_ManageUsers/SubPage_AddUser/input_View')
	TestObject inputMaitainenance = findTestObject('Page_ManageUsers/SubPage_AddUser/input_Maintainenance')
	TestObject inputBillingView = findTestObject('Page_ManageUsers/SubPage_AddUser/input_BillingView')
	TestObject inputBillingMaintainenance = findTestObject('Page_ManageUsers/SubPage_AddUser/input_BillingMain')
	TestObject buttonSave = findTestObject('Page_ManageUsers/SubPage_AddUser/span_save_button')
	TestObject buttonCancel= findTestObject('Page_ManageUsers/SubPage_AddUser/span_cancel_button')
	TestObject inputManageUsers = findTestObject('Page_ManageUsers/SubPage_AddUser/input_ManageUsers')

	boolean isPageDisplayed(){
		boolean bool = false
		boolean isInputFnameDisplayed = WebUI.verifyElementPresent(inputFName, GlobalVariable.TIMEOUT, FailureHandling.CONTINUE_ON_FAILURE)
		boolean isInputLnameDisplayed= WebUI.verifyElementPresent(inputLName, GlobalVariable.TIMEOUT, FailureHandling.CONTINUE_ON_FAILURE)
		boolean isSaveButtonDisplayed= WebUI.verifyElementPresent(buttonSave, GlobalVariable.TIMEOUT, FailureHandling.CONTINUE_ON_FAILURE)

		if(isInputFnameDisplayed && isInputLnameDisplayed && isSaveButtonDisplayed){
			bool = true
		}

		return bool
	}

	String addUser(String email){
		Faker faker = new Faker()
		String firstname = faker.name().firstName();
		String lastname = faker.name().lastName();
		WebUI.setText(inputFName,firstname, FailureHandling.CONTINUE_ON_FAILURE)
		WebUI.setText(inputLName,lastname, FailureHandling.CONTINUE_ON_FAILURE)
		WebUI.setText(inputEmail,email, FailureHandling.CONTINUE_ON_FAILURE)
		WebUI.setText(inputConfirmEmail,email, FailureHandling.CONTINUE_ON_FAILURE)
		WebUI.setText(inputPhoneNum1,'123', FailureHandling.CONTINUE_ON_FAILURE)
		WebUI.setText(inputPhoneNum2,'456', FailureHandling.CONTINUE_ON_FAILURE)
		WebUI.setText(inputPhoneNum3,'7890', FailureHandling.CONTINUE_ON_FAILURE)
		WebUI.click(inputView)
		WebUI.click(inputMaitainenance)
		WebUI.click(inputBillingView)
		WebUI.click(inputBillingMaintainenance)
		WebUI.click(inputManageUsers)
		WebUI.click(buttonSave)
		return firstname+' '+lastname
	}
}
