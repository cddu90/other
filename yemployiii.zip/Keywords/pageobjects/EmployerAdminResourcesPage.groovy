package pageobjects
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject

import com.kms.katalon.core.model.FailureHandling
import com.kms.katalon.core.testobject.TestObject
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI

import internal.GlobalVariable


class EmployerAdminResourcesPage {

	TestObject div_homeAdminResources = findTestObject('Object Repository/Page_Administrator Resources/div_HomeAdministratorResources')
	TestObject li_adminResources = findTestObject('Object Repository/Page_Administrator Resources/li_Administrator Resources')
	TestObject h1_adminResources = findTestObject('Object Repository/Page_Administrator Resources/h1_Administrator Resources')

	boolean isPageDisplayed(){
		WebUI.waitForElementPresent(div_homeAdminResources,GlobalVariable.TIMEOUT,FailureHandling.STOP_ON_FAILURE)
		boolean isH1AdminResourcesTextDisplayed = WebUI.verifyElementPresent(h1_adminResources, 0)
		boolean isLiAdminResourcesTextDisplayed = WebUI.verifyElementPresent(li_adminResources, 0)
		if(isH1AdminResourcesTextDisplayed && isLiAdminResourcesTextDisplayed){
			return true
		} else false
	}
}