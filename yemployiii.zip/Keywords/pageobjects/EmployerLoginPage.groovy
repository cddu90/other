package pageobjects
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject

import com.kms.katalon.core.model.FailureHandling
import com.kms.katalon.core.testobject.TestObject
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI

import internal.GlobalVariable
import pageobjects.authenticatedlandingpage.EmployerAuthenticatedLandingRightRail


class EmployerLoginPage {

	TestObject oUsername = findTestObject('Object Repository/Page_Employer Login/Page_Employer Connection - Log In/Username Input')
	TestObject oPassword = findTestObject('Object Repository/Page_Employer Login/Page_Employer Connection - Log In/Password Input')
	TestObject oLoginButton = findTestObject('Object Repository/Page_Employer Login/Page_Employer Connection - Log In/Employer Log In Button')
	TestObject oInvalidUsernamePassword = findTestObject('Object Repository/Employer - Password Recovery/Please enter a valid usernam')
	TestObject oChangePassword = findTestObject('Object Repository/Employer - Password Recovery/Employer Expired Password/Your Password Has Expired')
	TestObject oLoginFailure = findTestObject('Object Repository/Page_Employer Login/loginFailure')
	TestObject oChangePasswordLater = findTestObject('Object Repository/Page_Employer Login/ChangePwdLater')
	TestObject oCurrentPassword = findTestObject('Employer - Password Recovery/Employer Expired Password/Current Password')
	TestObject oNewPassword = findTestObject('Employer - Password Recovery/Employer Expired Password/New Password')
	TestObject oConfirmPassword = findTestObject('Employer - Password Recovery/Employer Expired Password/Confirm Password')
	TestObject oSubmitButtion = findTestObject('Object Repository/Employer - Password Recovery/Employer Expired Password/Submit Button')
	TestObject oLoginButton_ErrMsg = findTestObject('Object Repository/Page_Employer Login/loginButton_errMsg')
	TestObject oEmployerUnavailable = findTestObject('Object Repository/Page_Employer Login/EmployerUnavailable')
	TestObject oTermsConditions = findTestObject('Object Repository/Page_Employer Login/TermsAndConditions')
	TestObject oAgreeTermsConditions = findTestObject('Object Repository/Page_Employer Login/AgreeTermsButton')
	EmployerAuthenticatedLandingRightRail employerAuthLandingRightRailPage = new EmployerAuthenticatedLandingRightRail()

	/**
	 * Verify if Change password Page is displayed
	 * @return TRUE or FALSE
	 */
	boolean isChangePwdPresent(){
		boolean bool = false
		if(WebUI.verifyElementPresent(oChangePassword, 5,FailureHandling.OPTIONAL)){
			bool = true
		}
		return bool
	}

	/**
	 * Verify if Invalid Login Page is displayed
	 * @return TRUE or FALSE
	 */
	boolean isInvalidLoginMsgPresent(){
		boolean bool = false
		if(WebUI.verifyElementPresent(oInvalidUsernamePassword, 15, FailureHandling.OPTIONAL)){
			bool = true
		}

		return bool
	}


	/**
	 * Verify if Change Password Later Page displayed
	 * @return TRUE or FALSE
	 */
	boolean isChangePwdLaterPresent(){
		boolean bool = false
		if(WebUI.verifyElementPresent(oChangePasswordLater, 5, FailureHandling.OPTIONAL)){
			bool = true
		}
		return bool
	}


	/**
	 *  Verify if TERMS CONDITIONS page is displayed
	 * @return TRUE OR FALSE
	 */
	boolean isTermsConditionsDisplayed(){
		boolean bool = false
		boolean isTermsConditionsDisplayed = WebUI.verifyElementPresent(oTermsConditions,5, FailureHandling.OPTIONAL)
		if(isTermsConditionsDisplayed){
			bool = true
		}
		return bool
	}

	/**
	 * Verify if Employer Unavailable page is Displayed
	 * @return TRUE or FALSE
	 */
	boolean isLoginFailure(){
		boolean bool= false
		boolean isNoGroupsDisplayed = WebUI.verifyElementPresent(oLoginFailure, 1,FailureHandling.OPTIONAL)
		boolean isEmployerUnavailable = WebUI.verifyElementPresent(oEmployerUnavailable, 1,FailureHandling.OPTIONAL)
		if(isEmployerUnavailable || isNoGroupsDisplayed){
			bool = true
		}

		return bool
	}

	/**
	 * Navigate to Employer UnAuth Page
	 */
	void navigateToEmployerUnAuthPage(){
		WebUI.disableSmartWait()
		WebUI.openBrowser(GlobalVariable.PORTAL_URL)
		WebUI.waitForElementPresent(oLoginButton, GlobalVariable.TIMEOUT)
	}
}