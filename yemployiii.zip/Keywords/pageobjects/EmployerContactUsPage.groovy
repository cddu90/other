package pageobjects
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject

import com.kms.katalon.core.model.FailureHandling
import com.kms.katalon.core.testobject.TestObject
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI

import internal.GlobalVariable


class EmployerContactUsPage {

	TestObject text_h1_contactUs = findTestObject('Object Repository/Page_Contact Us/h1_Contact Us')

	/**
	 * 
	 * @return
	 */
	boolean isPageDisplayed(){
		boolean bool = false
		boolean isTextH1ContactusDisplayed = WebUI.waitForElementPresent(text_h1_contactUs, GlobalVariable.TIMEOUT,FailureHandling.CONTINUE_ON_FAILURE)
		if(isTextH1ContactusDisplayed){
			bool = true
		}

		return bool
	}
}