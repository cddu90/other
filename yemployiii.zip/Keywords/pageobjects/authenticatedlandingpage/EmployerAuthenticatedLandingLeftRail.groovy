package pageobjects.authenticatedlandingpage
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject

import com.kms.katalon.core.annotation.Keyword
import com.kms.katalon.core.model.FailureHandling
import com.kms.katalon.core.testobject.TestObject
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI

import internal.GlobalVariable


class EmployerAuthenticatedLandingLeftRail {

	//Left Rail
	TestObject link_logout = findTestObject('Object Repository/Page_Employer Connection/a_Log out')
	TestObject link_updateYourProfile = findTestObject('Object Repository/Page_Employer Connection/a_Update your profile')
	TestObject link_findAProvider = findTestObject('Object Repository/Page_Employer Connection/a_Find a Provider')
	TestObject link_helpPreventFraud = findTestObject('Object Repository/Page_Employer Connection/a_Help prevent fraud')
	TestObject link_blueShieldPledge = findTestObject('Object Repository/Page_Employer Connection/a_Learn more_LR')
	TestObject textUnderHelpPreventFraud = findTestObject('Object Repository/Page_Employer Connection/div_Healthcare fraud is costly')
	TestObject textUnderBSCPledge = findTestObject('Object Repository/Page_Employer Connection/div_As a not-for-profit health')
	/**
	 * 
	 * @return
	 */
	boolean isLinksInLeftRailSectionDisplayed(){
		boolean bool
		WebUI.waitForElementPresent(link_logout, GlobalVariable.TIMEOUT,FailureHandling.STOP_ON_FAILURE)
		def isLinkLogoutPresentDisplayed = WebUI.verifyElementPresent(link_logout, GlobalVariable.TIMEOUT)
		def isLinkUpdateYourProfileDisplayed = WebUI.verifyElementPresent(link_updateYourProfile, GlobalVariable.TIMEOUT)
		def isLinkFindProviderDisplayed = WebUI.verifyElementPresent(link_findAProvider, GlobalVariable.TIMEOUT)
		def isLinkHelpPreventFraudDisplayed = WebUI.verifyElementPresent(link_helpPreventFraud, GlobalVariable.TIMEOUT)
		def isLinkBlueShieldPledgeDisplayed = WebUI.verifyElementPresent(link_blueShieldPledge, GlobalVariable.TIMEOUT)
		if(isLinkLogoutPresentDisplayed && isLinkUpdateYourProfileDisplayed && isLinkFindProviderDisplayed && isLinkFindProviderDisplayed && isLinkHelpPreventFraudDisplayed && isLinkBlueShieldPledgeDisplayed ){
			bool = true
		}

		return bool


	}

	/**
	 * 
	 * @return
	 */
	boolean isLinkinMidLeftRailSectionDisplayed(){
		boolean bool
		boolean isTextUnderHelpPreventFraud = WebUI.verifyElementPresent(textUnderHelpPreventFraud, GlobalVariable.TIMEOUT)
		boolean isTextUnderBSCPledge = WebUI.verifyElementPresent(textUnderBSCPledge, GlobalVariable.TIMEOUT)
		boolean isLinkFindProviderDisplayed = WebUI.verifyElementPresent(link_findAProvider, GlobalVariable.TIMEOUT)
		boolean isLinkHelpPreventFraudDisplayed = WebUI.verifyElementPresent(link_helpPreventFraud, GlobalVariable.TIMEOUT)
		boolean isLinkBlueShieldPledgeDisplayed = WebUI.verifyElementPresent(link_blueShieldPledge, GlobalVariable.TIMEOUT)
		if(isTextUnderHelpPreventFraud && isTextUnderBSCPledge && isLinkFindProviderDisplayed && isLinkFindProviderDisplayed && isLinkHelpPreventFraudDisplayed && isLinkBlueShieldPledgeDisplayed ){
			bool = true
		}

		return bool

	}



}