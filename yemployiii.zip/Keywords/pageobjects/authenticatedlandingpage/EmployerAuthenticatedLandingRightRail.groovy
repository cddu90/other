package pageobjects.authenticatedlandingpage
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject

import com.kms.katalon.core.model.FailureHandling
import com.kms.katalon.core.testobject.TestObject
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI

import internal.GlobalVariable


class EmployerAuthenticatedLandingRightRail {

	//Right Rail
	TestObject link_updateEmailAddress = findTestObject('Page_Employer Connection/a_update email address_RR')
	TestObject link_manageMyUsers = findTestObject('Object Repository/Page_Employer Connection/a_manage my users_RR')
	TestObject link_viewAndReconcileYourBills = findTestObject('Page_Employer Connection/a_view and reconcile your bill_RR')
	TestObject link_searchPastInvoices = findTestObject('Page_Employer Connection/a_search past invoices_RR')
	TestObject link_viewPaymentHistory = findTestObject('Page_Employer Connection/a_view payment history_RR')
	TestObject link_makeAPayment = findTestObject('Object Repository/Page_Employer Connection/a_make a payment_RR')
	TestObject link_knowledgeCenter=findTestObject('Object Repository/Page_Employer Connection/a_Learn more')
	TestObject link_administratorResources = findTestObject('Object Repository/Page_Employer Connection/a_Access resources')
	TestObject link_signOut = findTestObject('Object Repository/Page_Employer Connection/a_Sign Out')
	TestObject link_contactUs = findTestObject('Object Repository/Page_Employer Connection/a_Contact Us')
	TestObject link_siteHelp = findTestObject('Object Repository/Page_Employer Connection/a_Site Help')
	TestObject link_feedback = findTestObject('Object Repository/Page_Employer Connection/a_Feedback')


	/**
	 * 
	 * @return
	 */
	boolean isWebElementsInRightTopRailDisplayed(){
		boolean bool = false
		boolean isLinkUpdateEmailAddressDisplayed = WebUI.verifyElementPresent(link_updateEmailAddress, GlobalVariable.TIMEOUT)
		boolean isLinkViewPaymentHistoryDisplayed = WebUI.verifyElementPresent(link_viewPaymentHistory, GlobalVariable.TIMEOUT)
		boolean isLinkMakePaymentDisplayed = WebUI.verifyElementPresent(link_makeAPayment, GlobalVariable.TIMEOUT)
		boolean isLinkSearchPasTInvDisplayed = WebUI.verifyElementPresent(link_searchPastInvoices, GlobalVariable.TIMEOUT)
		boolean isLinkManageMyUsersDisplayed = WebUI.verifyElementPresent(link_manageMyUsers, GlobalVariable.TIMEOUT)
		boolean isLinkViewReconcileBillsDisplayed = WebUI.verifyElementPresent(link_viewAndReconcileYourBills,GlobalVariable.TIMEOUT)


		if(isLinkSearchPasTInvDisplayed && isLinkManageMyUsersDisplayed && isLinkSearchPasTInvDisplayed && isLinkViewPaymentHistoryDisplayed && isLinkViewReconcileBillsDisplayed && isLinkMakePaymentDisplayed){
			bool = true
		}

		return bool

	}


	boolean isWebElementsInRightBottomRailDisplayed(){
		boolean isLinkKnowledgCenterDisplayed = WebUI.verifyElementPresent(link_knowledgeCenter,0)
		boolean isLinkAdminResourcesDisplayed = WebUI.verifyElementPresent(link_administratorResources, 0)

		if(isLinkAdminResourcesDisplayed && isLinkKnowledgCenterDisplayed){
			return true
		} else return false

	}


	void navigateToAdminResourcesPage(){
		WebUI.click(link_administratorResources)
	}

	void navigateToKnowledgeCenterPage(){
		WebUI.click(link_knowledgeCenter)
	}

	boolean isWebElementsInRightTopRailTopDisplayed(){
		WebUI.waitForElementPresent(link_signOut,GlobalVariable.TIMEOUT, FailureHandling.STOP_ON_FAILURE)
		boolean isLinkContactUsDisplayed = WebUI.verifyElementPresent(link_contactUs, 0)
		boolean isLinkSiteHelpDisplayed = WebUI.verifyElementPresent(link_siteHelp, 0)
		boolean isLinkFeedbackDisplayed = WebUI.verifyElementPresent(link_feedback, 0)
		if(isLinkContactUsDisplayed && isLinkSiteHelpDisplayed && isLinkFeedbackDisplayed){
			return true
		} else false
	}

	boolean isSignOutLinkDisplayed(){
		if(WebUI.verifyElementPresent(link_signOut, GlobalVariable.TIMEOUT, FailureHandling.OPTIONAL)){
			return true
		} else return false
	}

}