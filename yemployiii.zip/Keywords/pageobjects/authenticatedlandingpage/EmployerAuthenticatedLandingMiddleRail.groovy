package pageobjects.authenticatedlandingpage
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject

import com.kms.katalon.core.model.FailureHandling
import com.kms.katalon.core.testobject.TestObject
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI
import internal.GlobalVariable


class EmployerAuthenticatedLandingMiddleRail {


	//Middle Rail
	TestObject button_rosterGo = findTestObject('Object Repository/auth_to/Page_Welcome to Blue Shield of California Employer Connection - Home/img_roster_home')
	TestObject link_popup_closeButton = findTestObject('Object Repository/auth_to/Page_Welcome to Blue Shield of California Employer Connection - Home/a_Close')
	TestObject button_billingGo = findTestObject('Object Repository/auth_to/Page_Welcome to Blue Shield of California Employer Connection - Home/img_billing_home')
	TestObject startUsingOnlineBilling = findTestObject('Object Repository/Page_Employer Connection/img_start_using_online_billing')
	TestObject onlineBillingFAQPdf = findTestObject('Object Repository/Page_Employer Connection/a_Online Billing FAQ (PDF)')
	TestObject benefitManagementTxt = findTestObject('Object Repository/Page_Employer Connection/div_benefits management')
	TestObject benefitManagementGoButton = findTestObject('Object Repository/Page_Employer Connection/img_benefits management_home')
	TestObject billingTxt = findTestObject('Object Repository/Page_Employer Connection/div_billing')
	TestObject resources = findTestObject('Object Repository/Page_Employer Connection/p_Resources')
	TestObject billingGetStartedButton = findTestObject('Object Repository/Page_Employer Connection/get started')
	TestObject yourMembersAndPlansText = findTestObject('Page_Employer Connection/your members and plans')
	TestObject link_viewMemberRoster = findTestObject('Page_Employer Connection/a_viewMemberRoster')

	boolean isWebElementsInMiddleRailDisplayed(){

		boolean isResourcesLinkDisplayed = WebUI.verifyElementPresent(resources, GlobalVariable.TIMEOUT, FailureHandling.OPTIONAL)
		boolean isBillingTxtDisplayed = WebUI.verifyElementPresent(billingTxt, GlobalVariable.TIMEOUT)
		boolean isBenefitGoButtonDisplayed = WebUI.verifyElementPresent(benefitManagementGoButton, GlobalVariable.TIMEOUT)
		boolean isBenefitTxtDisplayed = WebUI.verifyElementPresent(benefitManagementTxt, GlobalVariable.TIMEOUT)
		boolean isStartOnlineBillingDisplayed = WebUI.verifyElementPresent(startUsingOnlineBilling, GlobalVariable.TIMEOUT)
		boolean isOnlineBillingFAQDisplayed = WebUI.verifyElementPresent(onlineBillingFAQPdf, GlobalVariable.TIMEOUT)
		boolean isGetStartedButtonDisplayed = WebUI.verifyElementPresent(billingGetStartedButton, GlobalVariable.TIMEOUT)
		boolean bool = false

		if(isGetStartedButtonDisplayed && isStartOnlineBillingDisplayed && isBillingTxtDisplayed&&isResourcesLinkDisplayed && isBenefitGoButtonDisplayed && isBenefitTxtDisplayed &&  isOnlineBillingFAQDisplayed){
			bool = true
		}

		return bool

	}

}