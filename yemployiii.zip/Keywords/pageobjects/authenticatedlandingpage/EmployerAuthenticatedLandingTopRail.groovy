package pageobjects.authenticatedlandingpage
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject

import com.kms.katalon.core.annotation.Keyword
import com.kms.katalon.core.model.FailureHandling
import com.kms.katalon.core.testobject.TestObject
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI

import internal.GlobalVariable


class EmployerAuthenticatedLandingTopRail{


	//Declare Test Object

	//Top Rail Billing
	TestObject link_billing_billingCenter = findTestObject('Page_EmployerAuthLandingPage/SubPage_TopRail_Billing/a_Billing Center')
	TestObject link_billing_billingOptions = findTestObject('Page_EmployerAuthLandingPage/SubPage_TopRail_Billing/a_Billing Options')
	TestObject link_billing_searchInvoices = findTestObject('Page_EmployerAuthLandingPage/SubPage_TopRail_Billing/a_Search Invoices')
	TestObject link_billing_paymentHistory = findTestObject('Page_EmployerAuthLandingPage/SubPage_TopRail_Billing/a_Payment History')
	TestObject link_billing_autoPayments = findTestObject('Page_EmployerAuthLandingPage/SubPage_TopRail_Billing/a_Auto Payments')
	TestObject link_billing_makePayment = findTestObject('Page_EmployerAuthLandingPage/SubPage_TopRail_Billing/a_Make a Payment')
	TestObject link_billing = findTestObject('Page_EmployerAuthLandingPage/SubPage_TopRail_Billing/em_billing')

	//Top Rail PlanAdministration
	TestObject link_planAdministration = findTestObject('Page_EmployerAuthLandingPage/SubPage_TopRail_PlanAdministration/em_plan administration')
	TestObject link_planAdmin_benefitMgmt = findTestObject('Page_EmployerAuthLandingPage/SubPage_TopRail_PlanAdministration/a_Benefits Management')
	TestObject link_planAdmin_Roster = findTestObject('Page_EmployerAuthLandingPage/SubPage_TopRail_PlanAdministration/a_Member Roster  Search')
	TestObject link_planAdmin_yourPlans = findTestObject('Page_EmployerAuthLandingPage/SubPage_TopRail_PlanAdministration/a_Your Plans')
	TestObject link_planAdmin_addSubscriber = findTestObject('Page_EmployerAuthLandingPage/SubPage_TopRail_PlanAdministration/a_Add a Subscriber')
	TestObject link_planAdmin_workQueue = findTestObject('Page_EmployerAuthLandingPage/SubPage_TopRail_PlanAdministration/a_Work Queue')
	TestObject link_planAdmin_transactionHistory = findTestObject('Page_EmployerAuthLandingPage/SubPage_TopRail_PlanAdministration/a_Transaction History')

	//Top Reports
	TestObject link_reports = findTestObject('Page_EmployerAuthLandingPage/SubPage_TopRail_Reports/em_reports')
	TestObject link_reports_censusReport = findTestObject('Page_EmployerAuthLandingPage/SubPage_TopRail_Reports/a_Census Report')
	TestObject link_reports_billingReport = findTestObject('Page_EmployerAuthLandingPage/SubPage_TopRail_Reports/a_Billing Report')

	//Top HealthWellness
	TestObject link_healthWellness = findTestObject('Page_EmployerAuthLandingPage/SubPage_TopRail_HW/em_health wellness')

	//Top Settings
	TestObject link_settings = findTestObject('Page_EmployerAuthLandingPage/SubPage_TopRail_Settings/em_settings')
	TestObject link_settings_manageUsers = findTestObject('Page_EmployerAuthLandingPage/SubPage_TopRail_Settings/a_Manage Users')
	TestObject link_settings_myProfilePreferences = findTestObject('Page_EmployerAuthLandingPage/SubPage_TopRail_Settings/a_My Profile  Preferences')

	void clickTestObject(TestObject to){
		WebUI.click(to)
	}

	void navigateToBenefitFocusPage(){
		WebUI.mouseOver(link_planAdministration)
		WebUI.click(link_planAdmin_benefitMgmt)
	}


	boolean isBillingLinksDisplayed(){
		WebUI.waitForElementPresent(link_billing, GlobalVariable.TIMEOUT,FailureHandling.STOP_ON_FAILURE)
		WebUI.mouseOver(link_billing)
		boolean isBillingCenterLinkDisplayed = WebUI.verifyElementPresent(link_billing_billingCenter, GlobalVariable.TIMEOUT)
		boolean isMakePaymentLinkDisplayed = WebUI.verifyElementPresent(link_billing_makePayment, GlobalVariable.TIMEOUT)
		boolean isAutoPaymentLinkDisplayed = WebUI.verifyElementPresent(link_billing_autoPayments, GlobalVariable.TIMEOUT)
		boolean isPaymentHistoryLinkDisplayed = WebUI.verifyElementPresent(link_billing_paymentHistory, GlobalVariable.TIMEOUT)
		boolean isSearchInvoiceLinkDisplayed = WebUI.verifyElementPresent(link_billing_searchInvoices, GlobalVariable.TIMEOUT)
		boolean isBillingOptionsLinkDisplayed = WebUI.verifyElementPresent(link_billing_billingOptions, GlobalVariable.TIMEOUT)

		if (isBillingCenterLinkDisplayed && isBillingOptionsLinkDisplayed && isMakePaymentLinkDisplayed && isAutoPaymentLinkDisplayed && isPaymentHistoryLinkDisplayed && isSearchInvoiceLinkDisplayed){
			return true
		} else {
			return false
		}
	}


	boolean isReportLinksDisplayed(){
		WebUI.waitForElementPresent(link_reports, GlobalVariable.TIMEOUT,FailureHandling.STOP_ON_FAILURE)
		WebUI.mouseOver(link_reports)
		boolean isCensusReportLinkDisplayed = WebUI.verifyElementPresent(link_reports_censusReport, 0)
		boolean isBillingReportLinkDisplayed = WebUI.verifyElementPresent(link_reports_billingReport, 0)

		if(isCensusReportLinkDisplayed && isBillingReportLinkDisplayed){
			return true
		} else false

	}

	boolean isSettingsLinksDisplayed(){
		WebUI.waitForElementPresent(link_settings, GlobalVariable.TIMEOUT,FailureHandling.STOP_ON_FAILURE)
		WebUI.mouseOver(link_settings)

		boolean isLinkManageUsersDisplayed = WebUI.verifyElementPresent(link_settings_manageUsers, 0)
		boolean isMyProfilePrefDisplayed = WebUI.verifyElementPresent(link_settings_myProfilePreferences, 0)

		if(isLinkManageUsersDisplayed && isMyProfilePrefDisplayed){
			return true
		} else false


	}

	boolean isHealthWellnessLinksDisplayed(){
		boolean isLinkHealthWellnessDisplayed = WebUI.verifyElementPresent(link_healthWellness, GlobalVariable.TIMEOUT,FailureHandling.STOP_ON_FAILURE)
		if(isLinkHealthWellnessDisplayed){
			return true
		} else false


	}

	boolean isPlanAdminstrationLinksDisplayed(){
		WebUI.waitForElementPresent(link_planAdministration, GlobalVariable.TIMEOUT,FailureHandling.STOP_ON_FAILURE)
		WebUI.mouseOver(link_planAdministration)
		boolean isBenefitManagementLinkDisplayed = WebUI.verifyElementPresent(link_planAdmin_benefitMgmt, 0)
		if(isBenefitManagementLinkDisplayed){
			return true
		} else false


	}

	boolean isPlanAdminstrationNonEnrollLinksDisplayed(){
		WebUI.waitForElementPresent(link_planAdministration, GlobalVariable.TIMEOUT,FailureHandling.STOP_ON_FAILURE)
		WebUI.mouseOver(link_planAdministration)
		boolean isLinkPlanAdminRoster = WebUI.verifyElementPresent(link_planAdmin_Roster, 0)
		boolean isLinkYourPlansDisplayed = WebUI.verifyElementPresent(link_planAdmin_yourPlans, 0)
		boolean isLinkAddSubDisplayed = WebUI.verifyElementPresent(link_planAdmin_addSubscriber, 0)
		boolean isLinkWorkQueueDisplayed = WebUI.verifyElementPresent(link_planAdmin_workQueue, 0)
		boolean isLinkTransactionHistoryDisplayed = WebUI.verifyElementPresent(link_planAdmin_transactionHistory, 0)
		if(isLinkPlanAdminRoster && isLinkAddSubDisplayed && isLinkWorkQueueDisplayed && isLinkTransactionHistoryDisplayed && isLinkYourPlansDisplayed){
			return true
		} else false


	}

	boolean isWebElementsInTopRailDisplayed(){
		if(isPlanAdminstrationLinksDisplayed() && isSettingsLinksDisplayed() && isBillingLinksDisplayed() && isHealthWellnessLinksDisplayed()){
			return true
		} else false
	}



}