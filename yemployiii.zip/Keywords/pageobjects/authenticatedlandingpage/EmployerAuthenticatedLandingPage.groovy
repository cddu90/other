package pageobjects.authenticatedlandingpage

import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject

import com.kms.katalon.core.model.FailureHandling
import com.kms.katalon.core.testobject.TestObject
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI

import internal.GlobalVariable

class EmployerAuthenticatedLandingPage {

	//boolean isLeftRailDisplayed = new EmployerAuthenticatedLandingLeftRail().isLinksInLeftRailSectionDisplayed()
	TestObject link_home = findTestObject('Object Repository/Page_Employer Connection/em_home')
	TestObject oGroupDropDownMenu = findTestObject('Object Repository/Page_Employer Login/Page_Employer Connection - Log In/Company or Group Selection/Group Drop Down Menu')
	TestObject oSelectButton = findTestObject('Object Repository/Page_Employer Login/Page_Employer Connection - Log In/Company or Group Selection/Select Button')
	TestObject oAssignGroupsDontShowMe = findTestObject('Object Repository/Page_Employer Connection/Page_AssignGroups_Alert/input_Assign Groups_dontShowMe')
	TestObject oAssignGroupsLater = findTestObject('Object Repository/Page_Employer Connection/Page_AssignGroups_Alert/img_Later')
	TestObject oAssignGroupAlert = findTestObject('Object Repository/Page_Employer Connection/Page_AssignGroups_Alert/div_Assign Groups')
	TestObject oOpenEnrollmentPopup = findTestObject('Object Repository/Page_Employer Open Erollment/ill do this later button')
	TestObject oPopup = findTestObject('Object Repository/Employer - Password Recovery/Ill Do this Later')
	TestObject oDontShowMeAgain = findTestObject('Object Repository/Employer - Password Recovery/dontShowMeAgain')
	TestObject oSignOut = findTestObject('Object Repository/Page_Employer Connection/a_Sign Out')
	TestObject oMyProfileAndPreferencesLink = findTestObject('Page_Employer Forgot User-Password/a_Update your profile')
	TestObject oDivChangeAssignments = findTestObject('Object Repository/Page_Employer Login/div_Changed Assignments')
	TestObject oImgClose = findTestObject('Object Repository/Page_Employer Login/img')
	TestObject oPYourAssignmentsChanged = findTestObject('Object Repository/Page_Employer Login/p_Your assignments have changed')




	/**
	 * Select Group
	 * @param groupID
	 * @return
	 */
	void selectGroup(String groupID){
		WebUI.waitForElementPresent(oGroupDropDownMenu, GlobalVariable.TIMEOUT,FailureHandling.STOP_ON_FAILURE)
		WebUI.selectOptionByValue(oGroupDropDownMenu, groupID, false)
		WebUI.click(oSelectButton)
	}



	/**
	 * 
	 */
	void closeAlertPopUps() {

		boolean isAssignGroupPopUpDisplayed = WebUI.verifyElementPresent(oAssignGroupAlert, 1, FailureHandling.OPTIONAL)
		boolean isPopupDisplayed =  WebUI.verifyElementPresent(oPopup, 1, FailureHandling.OPTIONAL)
		boolean isChangedAssignmentsPopUpDisplayed = WebUI.verifyElementPresent(oDivChangeAssignments, 1, FailureHandling.OPTIONAL)

		if(isAssignGroupPopUpDisplayed){

			WebUI.check(oAssignGroupsDontShowMe,FailureHandling.OPTIONAL)

			WebUI.click(oAssignGroupsLater, FailureHandling.OPTIONAL)
		} else if (isPopupDisplayed){

			WebUI.click(oDontShowMeAgain, FailureHandling.OPTIONAL)

			WebUI.click(oPopup, FailureHandling.OPTIONAL)
		} else if (isChangedAssignmentsPopUpDisplayed) {
			WebUI.click(oImgClose, FailureHandling.OPTIONAL)

		}

	}


	/**
	 * 
	 * @return
	 */
	boolean isOpenEnrollmentPopUpDisplayed(){
		boolean bool
		if(WebUI.verifyElementPresent(oOpenEnrollmentPopup, GlobalVariable.TIMEOUT, FailureHandling.OPTIONAL)){
			bool = true
		}

		return bool
	}

	boolean isProfileAndPreferencesLinkDisplayed(){
		boolean bool
		if(WebUI.verifyElementPresent(oMyProfileAndPreferencesLink, GlobalVariable.TIMEOUT, FailureHandling.OPTIONAL)){
			bool = true
		}

		return bool
	}

	/**
	 * 
	 * @return
	 */
	boolean isSignOutLinkDisplayed(){
		boolean bool
		if(WebUI.verifyElementPresent(oSignOut, GlobalVariable.TIMEOUT, FailureHandling.OPTIONAL)){
			bool = true
		}

		return bool

	}

	void clickSignOutLink(){
		WebUI.click(oSignOut);
	}

	void clickProfileAndPreferencesLink(){
		WebUI.click(oMyProfileAndPreferencesLink);
	}




}