package pageobjects.authenticatedlandingpage
import com.kms.katalon.core.annotation.Keyword
import com.kms.katalon.core.testobject.TestObject


class EmployerAuthenticatedLandingBottomRail {

	//Bottom Rail
	TestObject link_onlineBillingFAQ


	@Keyword
	def isWebElementsInBottomRailDisplayed(){
		return true
	}


}