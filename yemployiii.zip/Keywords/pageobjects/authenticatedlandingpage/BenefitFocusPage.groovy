package pageobjects.authenticatedlandingpage
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject

import com.kms.katalon.core.model.FailureHandling
import com.kms.katalon.core.testobject.TestObject
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI

import internal.GlobalVariable


class BenefitFocusPage {

	TestObject oBenFocusHome = findTestObject('Page_BenefitFocusPage/a_Home')
	TestObject oBenFocusPopup = findTestObject('Page_BenefitFocusPage/span_Welcome to the Benefit Administration')
	TestObject oDontShowmeAgain = findTestObject('Page_BenefitFocusPage/button_Dont show me this again')
	TestObject bttnGo = findTestObject('Object Repository/Page_BenefitFocusPage/button_Go')
	TestObject inputSearchCriteria = findTestObject('Page_BenefitFocusPage/input_Search_searchCriteria')
	TestObject spanHome = findTestObject('Object Repository/BF/Page_Welcome to online benefits enrollment/span_Home')

	/**
	 * 
	 * @return
	 */
	boolean isPageDisplayed(){

		boolean bool = false
		boolean isButtonGoDisplayed = WebUI.verifyElementPresent(bttnGo, GlobalVariable.TIMEOUT, FailureHandling.STOP_ON_FAILURE)
		boolean isInputSearchDisplayed= WebUI.verifyElementPresent(inputSearchCriteria, GlobalVariable.TIMEOUT, FailureHandling.CONTINUE_ON_FAILURE)
		boolean isSpanHomeDisplayed= WebUI.verifyElementPresent(spanHome, GlobalVariable.TIMEOUT, FailureHandling.CONTINUE_ON_FAILURE)

		if(isButtonGoDisplayed && isInputSearchDisplayed && isSpanHomeDisplayed) {

			bool = true
		}

		return bool
	}
}