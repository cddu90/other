package pageobjects


import org.assertj.core.api.SoftAssertions

import com.kms.katalon.core.model.FailureHandling
import com.kms.katalon.core.testobject.ResponseObject
import com.kms.katalon.core.testobject.TestObject
import com.kms.katalon.core.util.KeywordUtil
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI

import Keywords.dbUtility.DataUtilsAdvanced
import groovy.json.JsonSlurper
import internal.GlobalVariable
import keyword.helper.JsonUtilsAdv
import keyword.helper.ServiceUtils
import pageobjects.authenticatedlandingpage.EmployerAuthenticatedLandingRightRail

public class EmployerLoginPageMethods extends EmployerLoginPage {

	SoftAssertions softAssertions = new SoftAssertions()
	DataUtilsAdvanced dataUtils = new DataUtilsAdvanced('wpr')
	JsonSlurper jsonSlurper = new JsonSlurper()

	/**
	 * Call LDAP Create User Service
	 * @param data
	 * @return ResponseObject
	 */
	ResponseObject callCreateLDAPUserService(Map<String,String> data){
		String json = JsonUtilsAdv.getJsonRequestAsString('ldapCreateUserRequest.json', data)
		KeywordUtil.logInfo("LDAP create user json" +json)
		ServiceUtils serviceUtils = new ServiceUtils()
		ResponseObject response = serviceUtils.getServiceResponse(GlobalVariable.WS_CREATE_USER_URI, json)
		String responseAsString = response.getResponseBodyContent()
		KeywordUtil.logInfo("LDAP create user Response" +responseAsString)
		def responseObject = jsonSlurper.parseText(responseAsString)
		String statusCode = responseObject.responseHeader.transactionNotification.remarks.messages[0].code
		softAssertions.assertThat(statusCode).isIn('200','602')
		softAssertions.assertAll()
		return response
	}



	/**
	 * Call LDAP Change Password Service
	 * @param data
	 * @return ResponseObject
	 */
	ResponseObject callChangePasswordService(Map<String,String> data){
		String json = JsonUtilsAdv.getJsonRequestAsString('ldapChangePasswordRequest.json', data)
		KeywordUtil.logInfo("change password JSON" +json)
		ServiceUtils serviceUtils = new ServiceUtils()
		ResponseObject response = serviceUtils.getServiceResponse(GlobalVariable.WS_CHANGE_PWD_URI, json)
		String responseAsString = response.getResponseBodyContent()
		KeywordUtil.logInfo("change password response" +responseAsString)
		def responseObject = jsonSlurper.parseText(responseAsString)
		String statusCode = responseObject.responseHeader.transactionNotification.remarks.messages[0].code
		softAssertions.assertThat(statusCode).isIn('200','604')
		softAssertions.assertAll()
		return response
	}

	/**
	 * Login by calling Create LDAP Services
	 * @param loginData
	 * 
	 */


	void loginWithChangedPassword(Map<String,String>loginData){

		'Call Create User service to insert record in LDAP'
		ResponseObject response = callCreateLDAPUserService(loginData)
		'Check if user exists, if yes call Change password'
		if (response.getResponseBodyContent().contains("602")) {
			callChangePasswordService(loginData)
		}
		login(loginData,oLoginButton_ErrMsg)
	}


	/**
	 * Login in to Employer Application
	 * @param loginData
	 * @param ologinButton
	 * @return TRUE If Successful otherwise FALSE 
	 */
	boolean login(Map<String,String>loginData, TestObject ologinButton){
		String username = loginData.get("USR_NM")
		String password = 'Blue$hield1'
		boolean bool = false
		WebUI.setText(oUsername, username, FailureHandling.OPTIONAL)
		WebUI.setText(oPassword, password, FailureHandling.OPTIONAL)
		WebUI.click(ologinButton)
		if(new EmployerAuthenticatedLandingRightRail().isSignOutLinkDisplayed()){
			bool = true
		} else if(isTermsConditionsDisplayed()){
			WebUI.click(oAgreeTermsConditions)
		}
		return bool
	}

	/**
	 * Login to Employer with Username and Password
	 * @param username
	 * @param password
	 */
	void loginWithUsernamePasswod(String username,String password){
		WebUI.setText(oUsername, username, FailureHandling.OPTIONAL)
		WebUI.setText(oPassword, password, FailureHandling.OPTIONAL)
		WebUI.click(getoLoginButton())
	}

	/**
	 * Retry Login for 5 times in case of Employer Login Failure
	 * @param loginData
	 * @return Map of New Login Data
	 */
	Map<String,String> retryLogin(Map<String,String>loginData){
		int failedLoginCounter = 4
		boolean isLoginFailed = true
		String newUsername
		while (isLoginFailed && (failedLoginCounter <= 4 && failedLoginCounter >=0)) {
			println ('in while loop')
			String sql = loginData.get('transformedSql')
			println('retry with sql: '+sql )
			loginData = dataUtils.getDataFromQuery(sql)
			loginData.put('transformedSql',sql)
			newUsername = loginData.get('USR_NM')
			println 'New Username:-->' + loginData.get('USR_NM')
			navigateToEmployerUnAuthPage()
			login(loginData, oLoginButton)
			isLoginFailed = isLoginFailure()
			println 'Login failed T/F-->' + isLoginFailed
			failedLoginCounter = (failedLoginCounter - 1)
			println 'Failed Counter-->' +failedLoginCounter
			if(failedLoginCounter == -1) {
				KeywordUtil.markFailedAndStop("Login Failure. Tried Max(5) Login Attempts")
			}
		}
		boolean isSignOutLinkDisplayed = new EmployerAuthenticatedLandingRightRail().isSignOutLinkDisplayed()
		if(!(isSignOutLinkDisplayed)){
			loginData = fixEmployerLoginWithNoRetry(loginData)
		}
		//println 'New Login data Map: '+loginData
		return loginData
	}

	/**
	 * Fix Employer login for Invalid Login, Login Failures, Change password scenarios
	 * @param loginData
	 * @return Map of Login Data
	 */
	Map<String,String> fixEmployerLogin(Map<String,String>loginData){
		Map<String,String> newLoginData = loginData
		if(isInvalidLoginMsgPresent()){
			KeywordUtil.logInfo("Invalid Login Msg Dispayed: Changing Password or Creating User in LDAP")
			loginWithChangedPassword(loginData)
			if(isChangePwdPresent() || isChangePwdLaterPresent()){
				KeywordUtil.logInfo("Password Expired Msg is Displayed")
				loginWithNewPassword(loginData)
				navigateToEmployerUnAuthPage()
				login(loginData,oLoginButton)
				if(isLoginFailure()){
					println 'Retry Login after password expired'
					newLoginData= retryLogin(loginData)
				}
			} else if(isLoginFailure()){
				KeywordUtil.logInfo("Employer Connection UnAvailable or No Groups Msg Displayed")
				newLoginData= retryLogin(loginData)
			}
		}else if(isChangePwdPresent() || isChangePwdLaterPresent()){
			println 'password expired'
			loginWithNewPassword(loginData)
			navigateToEmployerUnAuthPage()
			login(loginData,oLoginButton)
			if(isLoginFailure()){
				println 'Retry Login after password expired'
				newLoginData= retryLogin(loginData)
			}
		}else if (isLoginFailure()){
			println 'login error'
			newLoginData = retryLogin(loginData)
		}
		return newLoginData
	}

	Map<String,String> fixEmployerLoginWithNoRetry(Map<String,String>loginData){
		Map<String,String> newLoginData = loginData
		if(isInvalidLoginMsgPresent()){
			KeywordUtil.logInfo("Invalid Login Msg Dispayed: Changing Password or Creating User in LDAP")
			loginWithChangedPassword(loginData)
			if(isChangePwdPresent() || isChangePwdLaterPresent()){
				KeywordUtil.logInfo("Password Expired Msg is Displayed")
				loginWithNewPassword(loginData)
				navigateToEmployerUnAuthPage()
				login(loginData,oLoginButton)
			}
		}else if(isChangePwdPresent() || isChangePwdLaterPresent()){
			println 'password expired'
			loginWithNewPassword(loginData)
			navigateToEmployerUnAuthPage()
			login(loginData,oLoginButton)
			return newLoginData
		}
	}
	/**
	 * 
	 * @param loginData
	 */
	void  changePwdDuringLogin(Map<String,String>loginData){
		Map<String,String> newLoginData = loginData
		if(isChangePwdPresent() || isChangePwdLaterPresent()){
			KeywordUtil.logInfo("Password Expired Msg is Displayed")
			loginWithNewPassword(loginData)
			navigateToEmployerUnAuthPage()
			login(loginData,oLoginButton)
		} else {
			KeywordUtil.logInfo("Login Failure Occured for : " +loginData.get('USR_NM'))
		}
	}


	/**
	 * Login with Change Password in Password Expired Flow
	 * @param loginData
	 */
	void loginWithNewPassword(Map<String,String>loginData){
		WebUI.setText(oCurrentPassword, 'Blue$hield1')
		WebUI.setText(oNewPassword, 'Blue$hield99')
		WebUI.setText(oConfirmPassword, 'Blue$hield99')
		WebUI.click(oSubmitButtion)
		callChangePasswordService(loginData)
		WebUI.closeBrowser(FailureHandling.OPTIONAL)
	}


	/**
	 * Call LDAP Create User and LDAP Change Password Service
	 * @param loginData
	 */
	void callLdapServices(Map<String,String>loginData){
		//'Call Create User service to insert record in LDAP'
		ResponseObject response = callCreateLDAPUserService(loginData)
		//'Check if user exists, if yes call Change password'
		if (response.getResponseBodyContent().contains('602')) {
			// call web service to reset password
			callChangePasswordService(loginData)
		}
	}



}
