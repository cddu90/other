package pageobjects
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject

import com.kms.katalon.core.model.FailureHandling
import com.kms.katalon.core.testobject.TestObject
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI

import internal.GlobalVariable


class EmployerRosterPage {

	//TestObject link_employerHome = findTestObject('Page_Employer_MemberRoster/a_Home')
	TestObject inputFirstname = findTestObject('Object Repository/Page_Employer_MemberRoster/input_Find a Member_firstName')
	TestObject inputLastname = findTestObject('Object Repository/Page_Employer_MemberRoster/input_Find a Member_lastName')
	TestObject inputMemberSSN = findTestObject('Object Repository/Page_Employer_MemberRoster/input_Find a Member_ssnDisplay')
	TestObject bttnSearch = findTestObject('Object Repository/Page_Employer_MemberRoster/bttn_search')
	TestObject homeBreadCrumbLink = findTestObject('Object Repository/Page_Employer_MemberRoster/a_Home')

	boolean isPageDisplayed(){
		boolean bool = false
		//boolean isEmployerHomeDisplayed = WebUI.waitForElementClickable(link_employerHome,GlobalVariable.TIMEOUT,FailureHandling.OPTIONAL)
		boolean isInputFirstnameDisplayed = WebUI.verifyElementPresent(inputFirstname, GlobalVariable.TIMEOUT, FailureHandling.CONTINUE_ON_FAILURE)
		boolean isInputLastnameDisplayed= WebUI.verifyElementPresent(inputLastname, GlobalVariable.TIMEOUT, FailureHandling.CONTINUE_ON_FAILURE)
		boolean isInputMemberSSNDisplayed= WebUI.verifyElementPresent(inputMemberSSN, GlobalVariable.TIMEOUT, FailureHandling.CONTINUE_ON_FAILURE)
		boolean isBttnSearchDisplayed= WebUI.verifyElementPresent(bttnSearch, GlobalVariable.TIMEOUT, FailureHandling.CONTINUE_ON_FAILURE)

		//boolean isbuttonAddSubscriberDisplayed = WebUI.verifyElementPresent(button_addSubscriber, 0)
		if(isInputFirstnameDisplayed && isInputLastnameDisplayed && isInputMemberSSNDisplayed && isBttnSearchDisplayed){
			bool = true
		}

		return bool
	}
}