package pageobjects

import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject

import com.kms.katalon.core.model.FailureHandling
import com.kms.katalon.core.testobject.TestObject
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI

import internal.GlobalVariable

public class EmployerManageUsersTermsConditionsPage {

	TestObject buttonAgreeTerms = findTestObject('Object Repository/Page_ManageUsers/SubPage_TermsConditions/span_agree')
	TestObject buttonDoNotAgreeTerms = findTestObject('Object Repository/Page_ManageUsers/SubPage_TermsConditions/span_donotagree')
	TestObject txtAgreement = findTestObject('Object Repository/Page_User Activation/strong_Please read and accept')

	boolean isPageDisplayed(){
		boolean bool = false
		boolean isButtonAgreeDisplayed = WebUI.verifyElementPresent(buttonAgreeTerms, GlobalVariable.TIMEOUT, FailureHandling.CONTINUE_ON_FAILURE)
		boolean isButtonDoNotAgreedDisplayed= WebUI.verifyElementPresent(buttonDoNotAgreeTerms, GlobalVariable.TIMEOUT, FailureHandling.CONTINUE_ON_FAILURE)
		boolean isTxtAgreementDisplayed= WebUI.verifyElementPresent(txtAgreement, GlobalVariable.TIMEOUT, FailureHandling.CONTINUE_ON_FAILURE)
	}
}
