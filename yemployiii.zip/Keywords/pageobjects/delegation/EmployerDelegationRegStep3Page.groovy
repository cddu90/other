package pageobjects.delegation

import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject

import com.kms.katalon.core.model.FailureHandling
import com.kms.katalon.core.testobject.TestObject
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI

import internal.GlobalVariable

public class EmployerDelegationRegStep3Page {
	TestObject divDelegationDetail = findTestObject('Object Repository/Page_DelRegistration/SubPage_RegStep3/div_regstep3detail')
	TestObject btnPrevious = findTestObject('Object Repository/Page_DelRegistration/SubPage_RegStep3/a_A_previousButton')
	TestObject btnFinish = findTestObject('Object Repository/Page_DelRegistration/SubPage_RegStep3/input_A_finishWithArrowBtn')
	TestObject lableRegStep3 = findTestObject('Object Repository/Page_DelRegistration/SubPage_RegStep3/label_Register Step 3 of 3')

	boolean isPageDisplayed(){
		boolean bool = false
		boolean isBtnFinishDisplayed = WebUI.verifyElementPresent(getLableRegStep3(), GlobalVariable.TIMEOUT, FailureHandling.CONTINUE_ON_FAILURE)
		if(isBtnFinishDisplayed)
			bool = true
		return bool
	}
}
