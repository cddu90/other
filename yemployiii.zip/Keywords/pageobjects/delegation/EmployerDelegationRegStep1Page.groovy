package pageobjects.delegation

import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject

import com.kms.katalon.core.model.FailureHandling
import com.kms.katalon.core.testobject.TestObject
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI

import internal.GlobalVariable

/**
 * This class holds all page elements and methods for delegation reg step1 page during Delegation Registration flow
 * Url: https://www.webh70.bsc.bscal.com/bsca/bsc/public/employer/employerPage/registration/activationRegistration
 * @author pkonda01
 *
 */
public class EmployerDelegationRegStep1Page {

	TestObject h1RegStep1 = findTestObject('Object Repository/Page_DelRegistration/SubPage_RegStep1/h1_Register Step 1 of 3')
	TestObject imgAcceptTerms = findTestObject('Object Repository/Page_DelRegistration/SubPage_RegStep1/img_acceptterms')
	TestObject imgRejectTerms = findTestObject('Object Repository/Page_DelRegistration/SubPage_RegStep1/img_rejectterms')

	/**
	 * Verify if page is displayed
	 * @return
	 */
	boolean isPageDisplayed(){
		boolean bool = false
		boolean isH1RegStep1Displayed = WebUI.verifyElementPresent(getH1RegStep1(), GlobalVariable.TIMEOUT, FailureHandling.CONTINUE_ON_FAILURE)
		boolean isImgAcceptTermsDisplayed = WebUI.verifyElementPresent(getImgAcceptTerms(), GlobalVariable.TIMEOUT, FailureHandling.CONTINUE_ON_FAILURE)
		boolean isImgRejectTermsDisplayed = WebUI.verifyElementPresent(getImgRejectTerms(), GlobalVariable.TIMEOUT, FailureHandling.CONTINUE_ON_FAILURE)
		if(isH1RegStep1Displayed && isImgAcceptTermsDisplayed && isImgRejectTermsDisplayed){
			bool = true
		}

		return bool
	}
}
