package pageobjects.delegation

import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject

import com.kms.katalon.core.model.FailureHandling
import com.kms.katalon.core.testobject.TestObject
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI

import internal.GlobalVariable

/**
 * This class holds all the elements and methods in Employer Delegation Group validation page in Delegation Registration flow
 * Url: https://www.webh70.bsc.bscal.com/bsca/bsc/public/employer/employerPage/registration/activationRegistration
 * @author pkonda01
 *
 */
public class EmployerDelegationGrpValidationPage {

	TestObject inputGrpSubgrp = findTestObject('Object Repository/Page_DelRegistration/SubPage_GroupValidation/inpu_grpSubGrpNum')

	/**
	 * Verify if page is displayed
	 * @return
	 */
	boolean isPageDisplayed(){
		boolean bool = false
		boolean isInputGrpSubgrpDisplayed = WebUI.verifyElementPresent(getInputGrpSubgrp(), GlobalVariable.TIMEOUT, FailureHandling.CONTINUE_ON_FAILURE)
		if(isInputGrpSubgrpDisplayed)
			bool = true
		return bool
	}
}
