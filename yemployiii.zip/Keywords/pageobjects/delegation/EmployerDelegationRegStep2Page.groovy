package pageobjects.delegation

import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject

import com.github.javafaker.Faker
import com.kms.katalon.core.model.FailureHandling
import com.kms.katalon.core.testobject.TestObject
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI

import internal.GlobalVariable

/**
 * This class holds elements and actions on Delegation Reg Step2 page.
 * Url: https://www.webh70.bsc.bscal.com/bsca/bsc/public/employer/employerPage/registration/activationRegistration
 * @author pkonda01
 *
 */
public class EmployerDelegationRegStep2Page {

	TestObject inputFirstname = findTestObject('Object Repository/Page_DelRegistration/SubPage_RegStep2/input__selfRegistrationBeanuserProfileBeanfirstName')
	TestObject inputLastname = findTestObject('Object Repository/Page_DelRegistration/SubPage_RegStep2/input__selfRegistrationBeanuserProfileBeanlastName')
	TestObject inputEmail = findTestObject('Object Repository/Page_DelRegistration/SubPage_RegStep2/input__selfRegistrationBeanuserProfileBeanemailAddress')
	TestObject inputConfirmEmail = findTestObject('Object Repository/Page_DelRegistration/SubPage_RegStep2/input__selfRegistrationBeanuserProfileBeanconfirmEmailId')
	TestObject inputPassword = findTestObject('Object Repository/Page_DelRegistration/SubPage_RegStep2/input__selfRegistrationBeanuserProfileBeanpassword')
	TestObject inputConfirmPassword = findTestObject('Object Repository/Page_DelRegistration/SubPage_RegStep2/input__selfRegistrationBeanuserProfileBeanconfirmPassword')
	TestObject inputSecAnswerOne = findTestObject('Object Repository/Page_DelRegistration/SubPage_RegStep2/input__selfRegistrationBeanuserProfileBeansecurityAnswerOne')
	TestObject inputSecAnswerTwo = findTestObject('Object Repository/Page_DelRegistration/SubPage_RegStep2/input__selfRegistrationBeanuserProfileBeansecurityAnswerTwo')
	TestObject inputPhoneOne = findTestObject('Object Repository/Page_DelRegistration/SubPage_RegStep2/input__selfRegistrationBeanuserProfileBeanphoneOne')
	TestObject inputPhoneTwo = findTestObject('Object Repository/Page_DelRegistration/SubPage_RegStep2/input__selfRegistrationBeanuserProfileBeanphoneTwo')
	TestObject inputPhoneThree = findTestObject('Object Repository/Page_DelRegistration/SubPage_RegStep2/input__selfRegistrationBeanuserProfileBeanphoneThree')
	TestObject inputUsername = findTestObject('Object Repository/Page_DelRegistration/SubPage_RegStep2/input__selfRegistrationBeanuserProfileBeanuserName')
	TestObject btnPrevious = findTestObject('Object Repository/Page_DelRegistration/SubPage_RegStep2/a__previousButton')
	TestObject btnNext = findTestObject('Object Repository/Page_DelRegistration/SubPage_RegStep2/input__nextWithArrowBtn')
	TestObject h1RegStep2 = findTestObject('Object Repository/Page_DelRegistration/SubPage_RegStep2/h1_Register Step 2 of 3')
	DelegateUser delegateUser
	Faker faker = new Faker()

	/**
	 * 
	 * @return
	 */
	boolean isPageDisplayed(){
		boolean bool = false
		boolean isButtonNextDisplayed = WebUI.verifyElementPresent(getBtnNext(), GlobalVariable.TIMEOUT, FailureHandling.CONTINUE_ON_FAILURE)
		if(isButtonNextDisplayed)
			bool = true
		return bool
	}

	/**
	 * 
	 * @return
	 */
	boolean isPageElementsDisplayed(){
		boolean bool = false
		boolean isButtonNextDisplayed = WebUI.verifyElementPresent(getBtnNext(), GlobalVariable.TIMEOUT, FailureHandling.CONTINUE_ON_FAILURE)
		boolean isUsernameDisplayed = WebUI.verifyElementPresent(getInputUsername(), GlobalVariable.TIMEOUT, FailureHandling.CONTINUE_ON_FAILURE)
		boolean isPasswordDisplayed = WebUI.verifyElementPresent(getInputPassword(), GlobalVariable.TIMEOUT, FailureHandling.CONTINUE_ON_FAILURE)
		boolean isConfirmPwdDisplayed = WebUI.verifyElementPresent(getInputConfirmPassword(), GlobalVariable.TIMEOUT, FailureHandling.CONTINUE_ON_FAILURE)
		boolean isFirstnameDisplayed = WebUI.verifyElementPresent(getInputFirstname(), GlobalVariable.TIMEOUT, FailureHandling.CONTINUE_ON_FAILURE)
		boolean isLastNameDisplayed = WebUI.verifyElementPresent(getInputLastname(), GlobalVariable.TIMEOUT, FailureHandling.CONTINUE_ON_FAILURE)
		boolean isEmailDisplayed = WebUI.verifyElementPresent(getInputEmail(), GlobalVariable.TIMEOUT, FailureHandling.CONTINUE_ON_FAILURE)
		boolean isConfirmEmailDisplayed = WebUI.verifyElementPresent(getInputConfirmEmail(), GlobalVariable.TIMEOUT, FailureHandling.CONTINUE_ON_FAILURE)
		boolean isPhoneOneDisplayed = WebUI.verifyElementPresent(getInputPhoneOne(), GlobalVariable.TIMEOUT, FailureHandling.CONTINUE_ON_FAILURE)
		boolean isPhoneTwoDisplayed = WebUI.verifyElementPresent(getInputPhoneTwo(), GlobalVariable.TIMEOUT, FailureHandling.CONTINUE_ON_FAILURE)
		boolean isPhoneThreeDisplayed = WebUI.verifyElementPresent(getInputPhoneThree(), GlobalVariable.TIMEOUT, FailureHandling.CONTINUE_ON_FAILURE)
		boolean isSecAnswerOneDisplayed = WebUI.verifyElementPresent(getInputSecAnswerOne(), GlobalVariable.TIMEOUT, FailureHandling.CONTINUE_ON_FAILURE)
		boolean isSecAnswerTwoDisplayed = WebUI.verifyElementPresent(getInputSecAnswerTwo(), GlobalVariable.TIMEOUT, FailureHandling.CONTINUE_ON_FAILURE)
		boolean isBtnPreviousLinkDisplayed = WebUI.verifyElementPresent(getBtnPrevious(), GlobalVariable.TIMEOUT, FailureHandling.CONTINUE_ON_FAILURE)
		if(isBtnPreviousLinkDisplayed && isUsernameDisplayed && isPasswordDisplayed && isConfirmPwdDisplayed && isFirstnameDisplayed && isLastNameDisplayed && isEmailDisplayed && isConfirmEmailDisplayed && isPhoneOneDisplayed && isPhoneTwoDisplayed && isPhoneThreeDisplayed && isSecAnswerOneDisplayed && isSecAnswerTwoDisplayed && isButtonNextDisplayed){
			bool = true
		}

		return bool
	}

	/**
	 * 
	 * @param userId
	 * @return
	 */
	DelegateUser addUserProfileDetails(String userId){
		if(isPageDisplayed()){
			String firstname = faker.name().firstName()
			String lastname = faker.name().lastName()
			String email = firstname + 'auto@test.com'
			String username = 'auto_hr' + userId
			String password = 'Blue$hield1'
			String secAns = 'A'
			WebUI.setText(getInputFirstname(),firstname, FailureHandling.CONTINUE_ON_FAILURE)
			WebUI.setText(getInputLastname(),lastname, FailureHandling.CONTINUE_ON_FAILURE)
			WebUI.setText(getInputPhoneOne(),'111', FailureHandling.CONTINUE_ON_FAILURE)
			WebUI.setText(getInputPhoneTwo(),'222', FailureHandling.CONTINUE_ON_FAILURE)
			WebUI.setText(getInputPhoneThree(),'3333', FailureHandling.CONTINUE_ON_FAILURE)
			WebUI.setText(getInputEmail(),email, FailureHandling.CONTINUE_ON_FAILURE)
			WebUI.setText(getInputConfirmEmail(),email, FailureHandling.CONTINUE_ON_FAILURE)
			WebUI.setText(getInputUsername(),username, FailureHandling.CONTINUE_ON_FAILURE)
			WebUI.setText(getInputPassword(),password, FailureHandling.CONTINUE_ON_FAILURE)
			WebUI.setText(getInputConfirmPassword(),password, FailureHandling.CONTINUE_ON_FAILURE)
			WebUI.setText(getInputSecAnswerOne(),secAns, FailureHandling.CONTINUE_ON_FAILURE)
			WebUI.setText(getInputSecAnswerTwo(),secAns, FailureHandling.CONTINUE_ON_FAILURE)
			WebUI.click(getBtnNext(), FailureHandling.CONTINUE_ON_FAILURE)
			delegateUser = new DelegateUser(firstname, lastname, email, username, userId)
		}

		return delegateUser
	}
}
