package pageobjects.delegation

import static com.kms.katalon.core.checkpoint.CheckpointFactory.findCheckpoint
import static com.kms.katalon.core.testcase.TestCaseFactory.findTestCase
import static com.kms.katalon.core.testdata.TestDataFactory.findTestData
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject
import static com.kms.katalon.core.testobject.ObjectRepository.findWindowsObject

import com.kms.katalon.core.annotation.Keyword
import com.kms.katalon.core.checkpoint.Checkpoint
import com.kms.katalon.core.cucumber.keyword.CucumberBuiltinKeywords as CucumberKW
import com.kms.katalon.core.mobile.keyword.MobileBuiltInKeywords as Mobile
import com.kms.katalon.core.model.FailureHandling
import com.kms.katalon.core.testcase.TestCase
import com.kms.katalon.core.testdata.TestData
import com.kms.katalon.core.testobject.TestObject
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WS
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI
import com.kms.katalon.core.windows.keyword.WindowsBuiltinKeywords as Windows

import internal.GlobalVariable

/**
 * This class captures all the elements in welcome page of Delegation Registration flow.
 * Url: https://www.webh70.bsc.bscal.com/bsca/bsc/public/employer/employerPage/registration/activationRegistration
 * @author pkonda01
 *
 */
public class EmployerDelegationWelcomePage {

	TestObject inputNo = findTestObject('Object Repository/Page_DelRegistration/SubPage_Welcome/input_no')
	TestObject inputYes = findTestObject('Object Repository/Page_DelRegistration/SubPage_Welcome/input_yes')
	TestObject buttonSubmit = findTestObject('Object Repository/Page_DelRegistration/SubPage_Welcome/button_submit')
	TestObject h1Welcome = findTestObject('Object Repository/Page_DelRegistration/SubPage_Welcome/h1_Welcome to Employer Connection')
	TestObject divDoYouHaveAccount = findTestObject('Object Repository/Page_DelRegistration/SubPage_Welcome/div_doyouhaveaccount')

	/**
	 * Verify if Page is Displayed
	 * @return
	 */
	boolean isPageDisplayed(){
		boolean bool = false
		boolean isButtonSubmitDisplayed=WebUI.verifyElementPresent(getButtonSubmit(), GlobalVariable.TIMEOUT, FailureHandling.CONTINUE_ON_FAILURE)
		if(isButtonSubmitDisplayed)
			bool = true
		return bool
	}

	/**
	 * Verify if Page elements are displayed
	 * @return
	 */
	boolean isPageElementsDisplayed(){
		boolean bool = false
		boolean isInputNoDisplayed = WebUI.verifyElementPresent(getInputNo(), GlobalVariable.TIMEOUT, FailureHandling.CONTINUE_ON_FAILURE)
		boolean isInputYesDisplayed= WebUI.verifyElementPresent(getInputYes(), GlobalVariable.TIMEOUT, FailureHandling.CONTINUE_ON_FAILURE)
		boolean isH1WelcomeDisplayed= WebUI.verifyElementPresent(getH1Welcome(), GlobalVariable.TIMEOUT, FailureHandling.CONTINUE_ON_FAILURE)
		boolean isDivYouHaveccountDisplayed= WebUI.verifyElementPresent(getDivDoYouHaveAccount(), GlobalVariable.TIMEOUT, FailureHandling.CONTINUE_ON_FAILURE)
		boolean isButtonSubmitDisplayed= WebUI.verifyElementPresent(getButtonSubmit(), GlobalVariable.TIMEOUT, FailureHandling.CONTINUE_ON_FAILURE)
		if(isInputNoDisplayed && isInputYesDisplayed && isH1WelcomeDisplayed && isDivYouHaveccountDisplayed && isButtonSubmitDisplayed){
			bool = true
		}

		return bool
	}
}
