package pageobjects
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject

import com.kms.katalon.core.model.FailureHandling
import com.kms.katalon.core.testobject.TestObject
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI

import internal.GlobalVariable


class BlueshieldPledgePage {

	TestObject navigationTitle = findTestObject('Object Repository/auth_to/Page_Our pledge to keep healthcare affordable - Employer Connection - Blue Shield of California/li_Our pledge to keep healthcare affordable')

	TestObject pageTitle = findTestObject('Object Repository/auth_to/Page_Our pledge to keep healthcare affordable - Employer Connection - Blue Shield of California/h1_Our pledge to keep healthcare affordable')

	TestObject imgOurPledgeBanner = findTestObject('Object Repository/auth_to/Page_Our pledge to keep healthcare affordable - Employer Connection - Blue Shield of California/img')


	boolean isPageDisplayed(){

		boolean bool = false

		boolean isNavigationTitleDisplayed = WebUI.waitForElementPresent(navigationTitle, GlobalVariable.TIMEOUT, FailureHandling.CONTINUE_ON_FAILURE)

		boolean isPageTitleDisplayed = WebUI.waitForElementPresent(pageTitle, GlobalVariable.TIMEOUT, FailureHandling.CONTINUE_ON_FAILURE)

		boolean isImgOurPledgeBannerDisplayed  = WebUI.waitForElementPresent(imgOurPledgeBanner, GlobalVariable.TIMEOUT, FailureHandling.CONTINUE_ON_FAILURE)

		if(isNavigationTitleDisplayed && isPageTitleDisplayed && isImgOurPledgeBannerDisplayed){
			bool = true
		}

		return bool
	}
}