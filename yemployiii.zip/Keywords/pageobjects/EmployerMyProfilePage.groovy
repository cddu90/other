package pageobjects
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject

import com.kms.katalon.core.model.FailureHandling
import com.kms.katalon.core.testobject.TestObject
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI

import internal.GlobalVariable


class EmployerMyProfilePage {
	TestObject link_changeAccountInfo =  findTestObject('Object Repository/Page_Employer My Profile/a_Change Account Info')
	TestObject link_manageEmailSubscriptions = findTestObject('Object Repository/Page_Employer My Profile/a_Manage Email Subscriptions')
	TestObject link_employerHome = findTestObject('Object Repository/Page_Employer My Profile/a_Home')
	def isLinkChangeAccountInfoDisplayed, isLinkManageEmailSubscriptionsDisplayed


	/**
	 * 
	 * @return
	 */
	boolean isPageDisplayed(){
		isLinkChangeAccountInfoDisplayed = WebUI.waitForElementPresent(link_changeAccountInfo, GlobalVariable.TIMEOUT, FailureHandling.STOP_ON_FAILURE)
		isLinkManageEmailSubscriptionsDisplayed = WebUI.verifyElementPresent(link_manageEmailSubscriptions, 0)
		if(isLinkChangeAccountInfoDisplayed && isLinkManageEmailSubscriptionsDisplayed  ){
			return true
		} else {
			return false
		}
	}

	/**
	 * 
	 * @return
	 */
	boolean navigateToHomePage(){
		clickOnTestObject(link_employerHome)
	}

	/**
	 * 
	 * @param to
	 * @return
	 */
	boolean clickOnTestObject(TestObject to){
		WebUI.click(to)
	}
	
	/**
	 *
	 * @param to
	 * @return
	 */
	void clickOnChangeAccountInfoLink(){
		WebUI.click(link_changeAccountInfo)
	}
	
}