package pageobjects


import org.openqa.selenium.By
import org.openqa.selenium.WebDriver
import org.openqa.selenium.WebElement

import com.kms.katalon.core.webui.driver.DriverFactory

public class WebUtils {


	/**
	 *
	 * @return
	 */
	WebElement getFirstRowFromWebTable(){

		List<WebElement> rows = getTableRows()

		List<WebElement> listCols = rows.get(0).findElements(By.tagName('td'))

		return  listCols.get(0)
	}

	/**
	 *
	 * @return
	 */
	String getContentsAsStringFromTable(){

		List<WebElement> rows = getTableRows()

		println('No. of rows: ' + rows.size())

		StringBuilder partnerData = new StringBuilder()

		for (int i = 0; i < rows.size(); i++) {
			'To locate columns(cells) of that specific row'
			List<WebElement> Cols = rows.get(i).findElements(By.tagName('td'))

			for (int j = 0; j < Cols.size(); j++) {
				partnerData.append(Cols.get(j).getText())
			}
		}

		println(partnerData.toString())

		return partnerData.toString()
	}

	/**
	 *
	 * @return
	 */
	static List<WebElement>getTableRows(){

		WebDriver driver = DriverFactory.getWebDriver()

		WebElement Table = driver.findElement(By.xpath("//table[@id='tblGroup0']/tbody"))

		List<WebElement> rows = Table.findElements(By.tagName('tr'))

		println('No. of rows: ' + rows.size())

		return rows
	}
}
