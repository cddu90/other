package Keywords.dbUtility

import java.sql.Connection
import java.sql.DriverManager
import java.sql.PreparedStatement
import java.sql.ResultSet
import java.sql.ResultSetMetaData
import java.sql.SQLException
import java.sql.Statement

import org.apache.commons.dbutils.QueryRunner
import org.apache.commons.dbutils.handlers.KeyedHandler
import org.apache.commons.dbutils.handlers.MapListHandler
import org.json.JSONArray

import com.bqsa.qe.utils.AutomationEncryptionUtility
import com.bsc.qa.framework.utility.JSONUtils

import internal.GlobalVariable

/**
 * DBUtils encapsulates methods required to get data from an Oracle database
 *
 * @author gholla01
 */
public class DBUtils {

	private Connection facetsConnection = null
	private Connection wprConnection = null
	private Connection connection = null


	/**
	 * Setup the database connection using the oracle JDBC driver.
	 *
	 */
	public void setUp() {
		String facetsDB = System.getenv("FACETS_DB")
		String wprDB = System.getenv("WPR_DB")

		if (facetsConnection == null && facetsDB != null && !"".equals(facetsDB)) {
			String facetsUser = System.getenv("FACETS_USER")
			String facetsPassword = System.getenv("FACETS_PWD")
			String facetsServer = System.getenv("FACETS_SERVER")
			String facetsPort = System.getenv("FACETS_PORT")
			String facetsConnectionString = "jdbc:oracle:thin:"+ facetsUser.trim() + "/" + facetsPassword.trim() + "@"+ facetsServer.trim() + ":" + facetsPort.trim() + "/"+ facetsDB.trim()
			try {
				facetsConnection = DriverManager
						.getConnection(facetsConnectionString)
			} catch (SQLException ex) {
				System.out
						.println("ERROR: SQL Exception when connecting to the database: "
						+ facetsDB)
				ex.printStackTrace()
			}
		}

		if (wprConnection == null && wprDB != null && !"".equals(wprDB)) {
			String wprUser = System.getenv("WPR_USER")
			String wprPassword = System.getenv("WPR_PWD")
			String wprServer = System.getenv("WPR_SERVER")
			String wprPort = System.getenv("WPR_PORT")
			String wprConnectionString = "jdbc:oracle:thin:" + wprUser.trim()+ "/" + wprPassword.trim() + "@" + wprServer.trim() + ":"+ wprPort.trim() + ":" + wprDB.trim()
			try {
				wprConnection = DriverManager
						.getConnection(wprConnectionString)
			} catch (SQLException ex) {
				System.out
						.println("ERROR: SQL Exception when connecting to the database: "
						+ wprDB + ": " + ex.getMessage())
				ex.printStackTrace()
			}
		}
	}



	/**
	 * Close the database connection
	 *
	 */
	public void tearDown() {
		if (facetsConnection != null) {
			try {
				// System.out.println("Closing Facets Database Connection...")
				facetsConnection.close()
				facetsConnection = null
			} catch (SQLException ex) {
				ex.printStackTrace()
			}
		}
		if (wprConnection != null) {
			try {
				// System.out.println("Closing WPR Database Connection...")
				wprConnection.close()
				wprConnection = null
			} catch (SQLException ex) {
				ex.printStackTrace()
			}
		}
		if (connection != null) {
			try {
				// System.out.println("Closing WPR Database Connection...")
				connection.close()
				connection = null
			} catch (SQLException ex) {
				ex.printStackTrace()
			}
		}
	}




	/**
	 * Get resultset as a map
	 *
	 * @param dbSource Data source
	 * @param query SQL Query
	 * @return Map
	 */
	public Map<String, String> getOneRowResultSetAsMap(String dbSource,
			String query) {
		ResultSetMetaData resultSetMetaData = null
		ResultSet resultSet = getResultSet(dbSource, query)
		Map<String, String> table = null

		try {
			resultSetMetaData = resultSet.getMetaData()
			if (resultSet.next()) {
				table = new HashMap<String, String>()
				for (int i = 1;i <= resultSetMetaData.getColumnCount(); i++) {
					String key = resultSetMetaData.getColumnName(i)
					String value = resultSet.getString(i)
					if (value == null) {
						value = ""
					}
					table.put(key, value)
				}
			} else {
				throw new Exception("No query results returned")
			}
			System.out.println("Keyset size: " + table.keySet().size())
			// System.out.println("Row count: " + rowCounter)
			// System.out.println("Column count: " +
			// resultSetMetaData.getColumnCount())
			// System.out.println("Cell count: " + cellCounter)
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace()
		} catch (Exception e) {
			e.printStackTrace()
		}
		tearDown()
		return table
	}

	/**
	 * Execute a query and get a ResultSet
	 *
	 * @param dbSource
	 *            Database source
	 * @param query
	 *            SQL Query
	 * @return resultSet
	 */
	public ResultSet getResultSet(String dbSource, String query) {
		Statement statement = null
		ResultSet resultSet = null
		setUp()
		try {
			if ("facets".equals(dbSource)) {
				statement = facetsConnection.createStatement(
						ResultSet.TYPE_SCROLL_INSENSITIVE,
						ResultSet.CONCUR_READ_ONLY)
			} else if ("wpr".equals(dbSource)) {
				statement = wprConnection.createStatement(
						ResultSet.TYPE_SCROLL_INSENSITIVE,
						ResultSet.CONCUR_READ_ONLY)
			} else if ("mssql".equals(dbSource)) {
				statement = msSqlConnection.createStatement(
						ResultSet.TYPE_SCROLL_INSENSITIVE,
						ResultSet.CONCUR_READ_ONLY)
			} else if ("other".equals(dbSource)){
				statement = connection.createStatement(
						ResultSet.TYPE_SCROLL_INSENSITIVE,
						ResultSet.CONCUR_READ_ONLY)
			}

			resultSet = statement.executeQuery(query)
		} catch (SQLException ex) {
			ex.printStackTrace()
		}
		return resultSet
	}



	/**
	 * Get a resultSet from an SQL query as a JSONArray
	 *
	 * @param dbSource
	 *            Database source
	 * @param sqlQuery
	 *            SQL Query
	 * @param jsonArrayFromResultSet
	 *            Json array
	 * @return Resultset as JSONArray
	 */
	public JSONArray getResultSetAsJson(String dbSource, String sqlQuery,
			JSONArray jsonArrayFromResultSet) {
		ResultSet resultSet = getResultSet(dbSource, sqlQuery)
		try {
			jsonArrayFromResultSet = JSONUtils.convertToJSONArray(resultSet)
		} catch (Exception e) {
			System.out
					.println("Error: converting resultset to JSONArray failed: ")
			e.printStackTrace()
		}
		tearDown()
		return jsonArrayFromResultSet
	}

	/**
	 * Get resultset as a map of maps where key = primary key
	 *
	 * @param dbSource Data source
	 * @param query SQL Query
	 * @param key Primay key
	 * @return Map of maps
	 */
	public Map<Object, Map<String, Object>> getKeyedResultSetAsMap(String dbSource, String query, String key) {
		connection = setUpDbType(dbSource)
		Map<Object, Map<String, Object>> row = null
		QueryRunner queryRunner = new QueryRunner()
		try {
			row = queryRunner.query(connection, query, new KeyedHandler<>(key))
		} catch (SQLException e) {
			System.out.println("Execution of query: " + query + " in " + dbSource + " failed:")
			// TODO Auto-generated catch block
			e.printStackTrace()
		}

		return row
	}

	/**
	 * Get resultset as a list of maps
	 *
	 * @param dbSource Data source
	 * @param query SQL Query
	 * @return List of maps
	 */
	public List<Map<String, Object>> getResultSetAsMapList(String dbSource, String query){
		connection = setUpDbType(dbSource)
		List<Map<String, Object>> result = null
		QueryRunner queryRunner = new QueryRunner()
		try {
			result = queryRunner.query(connection, query, new MapListHandler())
		} catch (SQLException e) {
			System.out.println("Execution of query: " + query + " in " + dbSource + " failed:")
			// TODO Auto-generated catch block
			e.printStackTrace()
		}
		tearDown()

		return result
	}





	/**
	 *
	 * @param connectionType
	 *            Connection type
	 * @return Connection object
	 */
	public Connection setUp(String connectionType) {
		Connection connection = null
		String db = null
		String user = null
		String password = null
		String server = null
		String port = null
		String connectionString = null

		if (("facets").equals(connectionType)) {
			db = GlobalVariable.FACETS_DB
			user = AutomationEncryptionUtility.decryptValue(GlobalVariable.FACETS_USER)
			password = AutomationEncryptionUtility.decryptValue(GlobalVariable.FACETS_PWD)
			server = GlobalVariable.FACETS_SERVER
			port = GlobalVariable.FACETS_PORT
			connectionString = "jdbc:oracle:thin:" + user.trim()+ "/" + password.trim() + "@" + server.trim() + ":"+ port.trim() + "/" + db.trim()
		} else if ("wpr".equals(connectionType)) {
			db = GlobalVariable.WPR_DB
			user = AutomationEncryptionUtility.decryptValue(GlobalVariable.WPR_USER)
			password = AutomationEncryptionUtility.decryptValue(GlobalVariable.WPR_PWD)
			server = GlobalVariable.WPR_SERVER
			port = GlobalVariable.WPR_PORT
			connectionString = "jdbc:oracle:thin:" + user.trim() + "/"+ password.trim() + "@" + server.trim() + ":"+ port.trim() + "/" + db.trim()
		}

		try {
			connection = DriverManager
					.getConnection(connectionString)
		} catch (SQLException ex) {
			System.out
					.println("ERROR: SQL Exception when connecting to the database: "
					+ db)
			ex.printStackTrace()
		}

		return connection
	}



	/**
	 * Get multi row resultset as a sorted map of sorted map
	 *
	 * @param dbSource Database source
	 * @param sql	Prepared Query
	 * @param values	Values for prepared query
	 * @return SortedMap
	 */
	public SortedMap<String, SortedMap<String, String>> getMultiRowsFromPreparedQuery(String dbSource, String sql, Object... values) {
		connection = setUp(dbSource)
		@SuppressWarnings("unused")
				int rowCounter = 0
		@SuppressWarnings("unused")
				int cellCounter = 0
		SortedMap<String, String> row = null
		StringBuilder keyBuilder = null

		SortedMap<String, SortedMap<String, String>> table = new TreeMap<String, SortedMap<String, String>>()
		PreparedStatement preparedStatement
		ResultSet resultSet
		ResultSetMetaData resultSetMetaData
		try {
			preparedStatement = preparePreparedStatement(sql, values)
			resultSet = preparedStatement.executeQuery()
			resultSetMetaData = resultSet.getMetaData()
			while (resultSet.next()) {
				keyBuilder = new StringBuilder()
				row = new TreeMap<String, String>()
				for (int i = 1;i <= resultSetMetaData.getColumnCount();i++) {
					String key = resultSetMetaData.getColumnName(i)
					String value = resultSet.getString(i)
					if (value == null) {
						value = ""
					}
					keyBuilder.append(value)
					row.put(key, value)
					cellCounter++
				}
				table.put(keyBuilder.toString(), row)
				rowCounter++
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace()
		}
		tearDown()
		return table
	}

	/**
	 * Get multi row resultset as a SortedMap of SortedMap with a specified primaryKey
	 *
	 * @param dbSource Database source
	 * @param sql Prepared Query
	 * @param primaryKey Primary key
	 * @param values Values for prepared query
	 * @return SortedMap
	 */
	public SortedMap<String, SortedMap<String, String>> getMultiRowsFromPreparedQuery(String dbSource, String sql, String primaryKey, Object... values) {
		connection = setUp(dbSource)
		SortedMap<String, SortedMap<String, String>> data = new TreeMap<>()
		SortedMap<String, String> innerMap = null

		String value = null
		String columnName = null
		PreparedStatement preparedStatement
		ResultSet resultSet

		try {
			preparedStatement = preparePreparedStatement(sql, values)
			resultSet = preparedStatement.executeQuery()
			ResultSetMetaData rsmd = resultSet.getMetaData()
			while(resultSet.next()) {
				innerMap = new TreeMap<>()
				String key = resultSet.getString(primaryKey)
				for (int i = 0 ;i < rsmd.getColumnCount(); i++) {
					columnName = rsmd.getColumnName(i+1)
					value = resultSet.getString(columnName)
					innerMap.put(columnName, value)
				}
				data.put(key, innerMap)
			}
		} catch (SQLException ex) {
			ex.printStackTrace()
		}
		tearDown()
		return data
	}

	/**
	 *
	 * @param dbSource Data source
	 * @param sql SQL query
	 * @param values Values to find and replace
	 * @return Map
	 */
	public Map<String, String> getDataFromPreparedQuery(String dbSource, String sql, Object... values) {
		connection = setUp(dbSource)
		HashMap<String, String> data = new HashMap<>()
		String value = null
		String columnName = null
		PreparedStatement preparedStatement
		ResultSet resultSet

		try {
			preparedStatement = preparePreparedStatement(sql, values)
			resultSet = preparedStatement.executeQuery()
			ResultSetMetaData rsmd = resultSet.getMetaData()
			if (resultSet.next()) {
				for (int i = 0;i < rsmd.getColumnCount();i++) {
					columnName = rsmd.getColumnName(i+1)
					value = resultSet.getString(columnName)
					data.put(columnName, value)
				}
			}
		} catch (SQLException ex) {
			ex.printStackTrace()
		}
		tearDown()
		return data
	}

	/**
	 * Prepared prepared statement
	 *
	 * @param sql Prepared query
	 * @param values Values for the prepared query
	 * @return PreparedStatement
	 * @throws SQLException
	 */
	private PreparedStatement preparePreparedStatement(String sql,
			Object... values) throws SQLException {
		PreparedStatement preparedStatement = connection.prepareStatement(sql,
				ResultSet.TYPE_SCROLL_INSENSITIVE,
				ResultSet.CONCUR_READ_ONLY)
		for (int i=0;i < values.length;i++) {
			preparedStatement.setObject(i+1, values[i])
		}
		return preparedStatement
	}
}
