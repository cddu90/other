package Keywords.dbUtility

import java.sql.SQLException
import java.util.stream.Collectors

import com.bqsa.qe.utils.AutomationEncryptionUtility
import com.bsc.qa.framework.utility.DBUtils

import groovy.sql.GroovyResultSet
import groovy.sql.GroovyRowResult
import groovy.sql.Sql
import internal.GlobalVariable

public class DataUtilsAdvanced extends DBUtils {

	String dbSource
	String facetsDB =  GlobalVariable.FACETS_DB
	String facetsUser = AutomationEncryptionUtility.decryptValue(GlobalVariable.FACETS_USER)
	String facetsPassword =  AutomationEncryptionUtility.decryptValue(GlobalVariable.FACETS_PWD)
	String facetsServer =  GlobalVariable.FACETS_SERVER
	String facetsPort =  GlobalVariable.FACETS_PORT

	String facetsConnectionString = "jdbc:oracle:thin:" + facetsUser.trim() + "/" + facetsPassword.trim() + "@" + facetsServer.trim() + ":" + facetsPort.trim() + "/" + facetsDB.trim()
	String wprDB = GlobalVariable.WPR_DB
	String wprUser = AutomationEncryptionUtility.decryptValue(GlobalVariable.WPR_USER)
	String wprPassword = AutomationEncryptionUtility.decryptValue(GlobalVariable.WPR_PWD)
	String wprServer = GlobalVariable.WPR_SERVER
	String wprPort = GlobalVariable.WPR_PORT
	String wprConnectionString = "jdbc:oracle:thin:" + wprUser.trim() + "/" + wprPassword.trim() + "@" + wprServer.trim() + ":" + wprPort.trim() + "/" + wprDB.trim()

	Map wprDbConnParams = [url : wprConnectionString, user: wprUser, password: wprPassword]
	Map facetsDbConnParams = [url : facetsConnectionString, user: facetsUser, password: facetsPassword]

	static Sql sql

	public DataUtilsAdvanced(String dbSource){
		sql = getConnection(dbSource)
		this.sql = sql
	}


	/**
	 * 
	 * @param dbSource
	 * @return
	 */
	Sql getConnection(String dbSource){

		if (dbSource.equals("facets")) {

			try {
				println facetsPort
				sql = Sql.newInstance(facetsDbConnParams)
			} catch (SQLException var16) {
				System.out.println("ERROR: SQL Exception when connecting to the database: " + facetsDB)
				var16.printStackTrace();
			}
		}

		if (dbSource.equals("wpr")) {

			try{
				sql = Sql.newInstance(wprDbConnParams)
				println "wpr connection"
			}catch (SQLException var16) {
				System.out.println("ERROR: SQL Exception when connecting to the database: " + facetsDB)
				var16.printStackTrace();
			}
		}
		return sql
	}

	//getDataFromQuery(SQl sql, String Query)
	/**
	 * 
	 * @param sql
	 * @param query
	 * @return
	 */
	Map getDataFromQuery(String query){
		def firstRow = sql.firstRow(query)
		return firstRow
	}

	/**
	 * 
	 * @param sql
	 * @param params
	 * @param query
	 * @return
	 */
	Map getDataFromPreparedQuery(List<Object> params, String query){
		//sql.createPreparedQueryCommand(query, params)
		Map data = [:]
		def firstRow = sql.firstRow(query, params)
		firstRow.each{ entry ->
			println "key: $entry.key value: $entry.value"
			String key = entry.key
			String value = entry?.value
			data[key] = value.toString()
			return data
		}

	}

	/**
	 * 
	 * @param sql
	 * @param query
	 * @return
	 */
	def getColumnValuesAsInputString(String query){
		List cols = []
		sql.eachRow(query) { row->
			cols.add(row.getAt(0).toString())
		}
		println cols
		String columnValuesAsInputString = cols.stream().collect(Collectors.joining('\',\'', '\'', '\''))
		return columnValuesAsInputString
	}

	/**
	 *
	 * @param sql
	 * @param query
	 * @return
	 */
	def getValuesOfColumnAsList(query,columnNumber){
		List cols = []
		sql.eachRow(query) { row->
			cols.add(row[columnNumber].toString())
		}
		println cols
		return cols
	}

	/**
	 * 
	 * @param sql
	 * @param query
	 * @return
	 */
	List<GroovyResultSet> getResultSet(String query){
		List<GroovyRowResult> rows = sql.rows(query)
		println 'Number of Records: ' +rows.size()
		println rows
		return rows
	}


	/**
	 * 
	 * @param sql
	 */
	void closeConnection(){
		sql.close()
	}
}
