package Keywords.dbUtility

import groovy.sql.Sql

public class DataUtilsTests {

	DataUtilsAdvanced ds = new DataUtilsAdvanced()

	def testDbConnection(){
		Sql sql = ds.getConnection()
		ds.getDataFromQuery(sql, "Select * from employer_admin_user where rownum < 2")
	}
}
