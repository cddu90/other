package Keywords.dbUtility
import com.bqsa.qe.utils.AutomationEncryptionUtility;
import com.kms.katalon.core.annotation.Keyword

import groovy.sql.GroovyRowResult
import groovy.sql.Sql
import internal.GlobalVariable
public class MyOra {


	// Method returns instance of {ORACLE} DB connection to WPR
	// Credential are fed from user system variables
	//Connection String from global vars (Profile- environemntname)
	def getWPRDBInstance(){

		//get url value' from profile
		String dbUrl = GlobalVariable.WPR_DB

		//get user id from global profile
		//		String dbUser = System.getenv("WPR_USER")
		//
		//		//call to external jar to decrypt value
		//		String dbPwd = System.getenv("WPR_PASSWORD")

		String dbUser = AutomationEncryptionUtility.decryptValue(GlobalVariable.WPR_USER)

		String dbPwd = AutomationEncryptionUtility.decryptValue(GlobalVariable.WPR_PWD)

		// create instance of connection
		def wprOracleInstance = Sql.newInstance("jdbc:oracle:thin:@" + dbUrl, dbUser, dbPwd,"oracle.jdbc.pool.OracleDataSource")

		//return instance of connection
		return wprOracleInstance

	}

	// Method returns instance of {ORACLE} DB connection to FACETS
	// Credential are fed from user system variables
	//Connection String from global vars (Profile- environemntname)
	def getFacetsDBInstance(){

		//get url value' from profile
		String dbUrl = GlobalVariable.FACETS_DB

		//		//get user id from global profile
		//		String dbUser = System.getenv("FACETS_USER")
		//
		//		//call to external jar to decrypt value
		//		String dbPwd = System.getenv("FACETS_PASSWORD")

		String dbUser = AutomationEncryptionUtility.decryptValue(GlobalVariable.FACETS_USER)

		String dbPwd = AutomationEncryptionUtility.decryptValue(GlobalVariable.FACETS_PWD)

		// create instance of connection
		def wprOracleInstance = Sql.newInstance("jdbc:oracle:thin:@" + dbUrl, dbUser, dbPwd,"oracle.jdbc.pool.OracleDataSource")

		//return instance of connection
		return wprOracleInstance

	}


	@Keyword
	def getDBColumnDataToWhereClause(String sqlSingleColumnFormatedQuery, String strWPRorFACETS){
		//return string
		def returnValues = null

		def sql

		def dbSource = strWPRorFACETS.toUpperCase()


		def blnWPRDB = dbSource.contains('WPR')

		print blnWPRDB

		if (blnWPRDB == true)  {

			//get instance of connection
			sql = getWPRDBInstance()

		}else{

			//get instance of connection
			sql = getFacetsDBInstance()

		}

		// list of DB values
		def DBlist = sql.rows(sqlSingleColumnFormatedQuery)

		def list = []

		// for each row in the result list
		def rowResults = DBlist.collect{ row ->

			// get only the column values
			list << row.keySet().collect { row[it] }

		}


		// trim string to follow where clause format

		if (list.size() > 0){

			returnValues = list.toString()

			returnValues = returnValues.replace('[','\'')

			returnValues = returnValues.replace(']', '\'')

			returnValues = returnValues.substring(1, returnValues.length()-1);

		}

		print '@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@'
		print returnValues
		print '@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@'

		return returnValues

	}

	@Keyword
	def getDBRowValue(String sqlSingleColumnFormatedQuery, String strWPRorFACETS){

		println '@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@'
		println sqlSingleColumnFormatedQuery


		//return string
		def returnValues = null

		def sql

		def dbSource = strWPRorFACETS.toUpperCase()

		def blnWPRDB = dbSource.contains('WPR')

		if (blnWPRDB == true)  {
			//get instance of connection
			sql = getWPRDBInstance()
		}else{
			//get instance of connection
			sql = getFacetsDBInstance()
		}

		// list of DB values
		def DBlist = sql.rows(sqlSingleColumnFormatedQuery)

		def list = []

		// for each row in the result list
		def rowResults = DBlist.collect{ row ->

			// get only the column values
			list << row.keySet().collect { row[it] }

		}


		// trim string
		if (list.size() > 0){

			returnValues = list.toString()

			returnValues = returnValues.replace('[','')

			returnValues = returnValues.replace(']', '')

		}

		println ''
		println 'QRY Value: '
		println returnValues
		println '@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@'

		return returnValues

	}


	@Keyword
	def getDBRowasListValue(String sqlSingleColumnFormatedQuery, String strWPRorFACETS){

		println '@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@'
		println sqlSingleColumnFormatedQuery


		//return string
		def returnValues = null

		def sql

		def dbSource = strWPRorFACETS.toUpperCase()

		def blnWPRDB = dbSource.contains('WPR')

		if (blnWPRDB == true)  {
			//get instance of connection
			sql = getWPRDBInstance()
		}else{
			//get instance of connection
			sql = getFacetsDBInstance()
		}

		// list of DB values
		def DBlist = sql.rows(sqlSingleColumnFormatedQuery)

		def list = []

		// for each row in the result list
		def rowResults = DBlist.collect{ row ->

			// get only the column values
			list << row.keySet().collect { row[it] }

		}



		println ''
		println 'QRY Value: '
		println returnValues
		println '@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@'

		return list

	}


	/**
	 * This Method will connect to DB based on DbSourceName, Execute Query and Copy the result in resultSet.
	 * @param sqlSingleColumnFormatedQuery
	 * @param strWPRorFACETS
	 * @return resultSet
	 */
	@Keyword
	def getResultSetFromDBQUery(String sqlSingleColumnFormatedQuery, String strWPRorFACETS){

		println '@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@'
		println sqlSingleColumnFormatedQuery


		//return string
		def returnValues = null

		Sql sql

		def dbSource = strWPRorFACETS.toUpperCase()

		def blnWPRDB = dbSource.contains('WPR')

		if (blnWPRDB == true)  {
			//get instance of connection
			sql = getWPRDBInstance()
		}else{
			//get instance of connection
			sql = getFacetsDBInstance()
		}

		// list of DB values
		GroovyRowResult resultSet = sql.firstRow(sqlSingleColumnFormatedQuery)

		println ''
		println 'QRY Value: '
		println returnValues
		println '@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@'

		sql.close()

		return resultSet

	}

	//Purpose: update execute SQL query by injecting a collection of values from first query in a where clause
	//ARGES: first query as string - must be formated in a single column, string db could be facets or wpr, second query with templatazed where caluse, sting database could be wpr or facets
	//Example : def groups2 = CustomKeywords.'Keywords.dbUtility.MyOra.getSQLTestDataWithDynamicWhereClasuse'(strSQLOne, 'wpr', strSQLTwo, 'wpr')

	def getSQLTestDataWithDynamicWhereClasuse(String sqlSingleColumnFormatedQuery, String strWPRorFACETS_One, String DataQueryWithVarWhereClase, String strWPRorFACETS_Two){

		def sql //instance of db connection

		def returnValues = null // return value

		def strWhereClaseValues = getDBColumnDataToWhereClause(sqlSingleColumnFormatedQuery, strWPRorFACETS_One ) // call to get output of forst sql query

		def dbSource = strWPRorFACETS_Two.toUpperCase() // check db env

		def blnWPRDB = dbSource.contains('WPR') // is it WPR ?

		// query update to inject values to where clause
		def strUpdatedQuery =  DataQueryWithVarWhereClase.replace('STR_VAR', strWhereClaseValues)

		print strUpdatedQuery

		// if db connection is not wpr then facets
		if (blnWPRDB == true)  {

			//get instance of connection
			sql = getWPRDBInstance()

		}else{

			//get instance of connection
			sql = getFacetsDBInstance()

		}


		// list of DB values
		def DBlist = sql.rows(strUpdatedQuery)
		// array
		def list = []

		// for each row in the result list
		def rowResults = DBlist.collect{ row ->

			// get only the column values
			list << row.keySet().collect { row[it] }

		} // def rowResults = DBlist.collect{ row ->

		// see if any data was returned
		if (list.size() > 0){

			//array to sting conversion
			returnValues = list.toString()

		}

		//return value
		return returnValues

	}





}



