package Keywords.dbUtility

import java.sql.Connection
import java.util.stream.Collectors

import org.apache.commons.dbutils.QueryRunner
import org.apache.commons.dbutils.handlers.ColumnListHandler
import org.apache.commons.dbutils.handlers.MapListHandler

public class DataUtils extends DBUtils{

	//Declare Variables
	String username, groupID, groupSubgroupID
	QueryRunner runner = new QueryRunner()
	Connection wprConnection
	Connection facetsConnection




	/**
	 * 
	 * @param dbSource
	 * @param sql
	 * @return
	 */
	List<Map<String,String>>getData(String dbSource, String sql){

		'Get Login Details from DB'
		List<Map<String, String>> resultList = runner.query(setUp(dbSource),sql, new MapListHandler())

		return resultList
	}

	/**
	 * 
	 * @param dbSource
	 * @param sql
	 * @return
	 */
	Map<String,String> getDataFromFirstRow(String dbSource, String sql){
		Map<String,String>dataMap = getData(dbSource,sql).get(0)
	}


	/**
	 * Get List of Groups from facets in inQuery Format
	 * @param sql
	 * @return String of Groups
	 */
	String getSingleColumnValuesAsInputString(String dbSource, String sql){

		List<String> groups = runner.query(setUp(dbSource), sql, new ColumnListHandler<String>(1))

		'Create a string for in condition in WPR Query'
		String listOfGroups = groups.stream().collect(Collectors.joining('\',\'', '\'', '\''))
		//

		runner.close(setUp(dbSource))

		return listOfGroups
	}


	/**
	 * Get Login details from WPRDB based on groups list
	 * @param inputParameter
	 * @param sql
	 * @return Map of Login Details
	 */
	List<Map<String,String>> getDataFromPreparedStatement(String dbSource, String ...params, String sql){


		'Get Login Details from DB'
		List<Map<String, String>> resultList = runner.

				//runner.query(wprConnection,newSQl, new MapListHandler())
				//runner.query(setUp(dbSource),sql,new MapListHandler(),inputParameter)

				return resultList
	}

	/**
	 * Get Facets Data based on SQL and column name
	 * @param inputParameter
	 * @param sql
	 * @return query result
	 */
	String getDataBasedOnColumnName(String dbSource, String sql,String columnName){

		'Get Login Details from DB'
		List<Map<String, String>> list = runner.query(setUp(dbSource),sql, new MapListHandler());

		String columnValue = list.get(0).get(columnName)

		runner.close(setUp(dbSource))

		return columnValue
	}


}
