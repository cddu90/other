package Keywords.fileUtility

import org.apache.poi.xssf.usermodel.XSSFCell
import org.apache.poi.xssf.usermodel.XSSFRow
import org.apache.poi.xssf.usermodel.XSSFSheet
import org.apache.poi.xssf.usermodel.XSSFWorkbook

import com.kms.katalon.core.annotation.Keyword
import com.kms.katalon.core.util.KeywordUtil

public class ExcelHelper {

	// Create Work book

	private XSSFWorkbook getWorkBook(){
		return new XSSFWorkbook();
	}

	//Create the Sheet

	private XSSFSheet getSheet(XSSFWorkbook workBook,String sheetName){
		return workBook.createSheet(sheetName);
	}

	//Keyword , which write the data to excel

	@Keyword
	public void writeTOExcelFile(String excelPath,String sheetName,String value,int rowNo,int colNo){
		XSSFWorkbook book = getWorkBook() // created the book
		XSSFSheet sheet = getSheet(book, sheetName) //created the sheet
		XSSFRow aRow = sheet.createRow(rowNo) // created the row-> index
		XSSFCell bCell = aRow.createCell(colNo) // created the col -> index
		bCell.setCellValue(value)
		writeToFileSystem(book,excelPath)
	}


	//Write the excel to the FS

	private void writeToFileSystem(XSSFWorkbook book,String excelPath){
		try {
			FileOutputStream aOut = new FileOutputStream(excelPath)
			book.write(aOut)
			aOut.close()
		} catch (Exception e) {
			KeywordUtil.markError(e.toString())
		}
	}

}