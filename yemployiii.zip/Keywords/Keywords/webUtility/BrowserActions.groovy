package Keywords.webUtility
import static com.kms.katalon.core.checkpoint.CheckpointFactory.findCheckpoint
import static com.kms.katalon.core.testcase.TestCaseFactory.findTestCase
import static com.kms.katalon.core.testdata.TestDataFactory.findTestData
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject

import com.kms.katalon.core.annotation.Keyword
import com.kms.katalon.core.checkpoint.Checkpoint
import com.kms.katalon.core.checkpoint.CheckpointFactory
import com.kms.katalon.core.mobile.keyword.MobileBuiltInKeywords
import com.kms.katalon.core.model.FailureHandling
import com.kms.katalon.core.testcase.TestCase
import com.kms.katalon.core.testcase.TestCaseFactory
import com.kms.katalon.core.testdata.TestData
import com.kms.katalon.core.testdata.TestDataFactory
import com.kms.katalon.core.testobject.ObjectRepository
import com.kms.katalon.core.testobject.TestObject
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords

import internal.GlobalVariable

import MobileBuiltInKeywords as Mobile
import WSBuiltInKeywords as WS
import WebUiBuiltInKeywords as WebUI

//import org.openqa.selenium.Dimension
import org.openqa.selenium.WebElement
import org.openqa.selenium.WebDriver
import org.openqa.selenium.By

import com.kms.katalon.core.mobile.keyword.internal.MobileDriverFactory
import com.kms.katalon.core.webui.driver.DriverFactory

import com.kms.katalon.core.testobject.RequestObject
import com.kms.katalon.core.testobject.ResponseObject
import com.kms.katalon.core.testobject.ConditionType
import com.kms.katalon.core.testobject.TestObjectProperty

import com.kms.katalon.core.mobile.helper.MobileElementCommonHelper
import com.kms.katalon.core.util.KeywordUtil

import com.kms.katalon.core.webui.exception.WebElementNotFoundException
import java.awt.GraphicsDevice
import java.awt.Toolkit
//import java.awt.Dimension

class BrowserActions {
	/**
	 * Refresh browser
	 */
	@Keyword
	def refreshBrowser() {
		KeywordUtil.logInfo("Refreshing")
		WebDriver webDriver = DriverFactory.getWebDriver()
		webDriver.navigate().refresh()
		KeywordUtil.markPassed("Refresh successfully")
	}


	/**
	 * To Maximize Browser Window in headless mode . Jenkins fix 
	 * @Author: Serhiy M.
	 * @ Reason default call to MaximizeBrowse causing Jenkins to fail test
	 * @return void
	 */
	@Keyword
	def maxBrowserWindow() {

		//		//		// JAVA - get screen size
		//		java.awt.Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
		//		//
		//		// get height and with
		//		double width = screenSize.getWidth();
		//		double height = screenSize.getHeight();
		//
		//		// convert height and with to int
		//		Integer valWith = Integer.valueOf(width.intValue());
		//		Integer valHeigh = Integer.valueOf(height.intValue());
		//
		//
		//		// Groovy Katalon call to set browser size to screen size
		//		//	WebUI.setViewPortSize(valWith, valHeigh)
		//
		//		// Java selenium driver call to resize the screen
		//		WebDriver webDriver = DriverFactory.getWebDriver();
		//		org.openqa.selenium.Dimension d = new org.openqa.selenium.Dimension(valWith,valHeigh);


	}
}