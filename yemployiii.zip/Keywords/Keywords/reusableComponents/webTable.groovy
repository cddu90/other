package Keywords.reusableComponents

//import static com.kms.katalon.core.checkpoint.CheckpointFactory.findCheckpoint
//import static com.kms.katalon.core.testcase.TestCaseFactory.findTestCase
//import static com.kms.katalon.core.testdata.TestDataFactory.findTestData
//import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject

import com.kms.katalon.core.annotation.Keyword
import com.kms.katalon.core.checkpoint.Checkpoint
import com.kms.katalon.core.checkpoint.CheckpointFactory
import com.kms.katalon.core.mobile.keyword.MobileBuiltInKeywords
import com.kms.katalon.core.model.FailureHandling
import com.kms.katalon.core.testcase.TestCase
import com.kms.katalon.core.testcase.TestCaseFactory
import com.kms.katalon.core.testdata.TestData
import com.kms.katalon.core.testdata.TestDataFactory
import com.kms.katalon.core.testobject.ObjectRepository
import com.kms.katalon.core.testobject.TestObject
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords

import internal.GlobalVariable

import MobileBuiltInKeywords as Mobile
import WSBuiltInKeywords as WS
import WebUiBuiltInKeywords as WebUI

import org.openqa.selenium.WebElement
import org.openqa.selenium.WebDriver
import org.openqa.selenium.By

import com.kms.katalon.core.mobile.keyword.internal.MobileDriverFactory
import com.kms.katalon.core.webui.driver.DriverFactory

import com.kms.katalon.core.testobject.RequestObject
import com.kms.katalon.core.testobject.ResponseObject
import com.kms.katalon.core.testobject.ConditionType
import com.kms.katalon.core.testobject.TestObjectProperty

import com.kms.katalon.core.mobile.helper.MobileElementCommonHelper
import com.kms.katalon.core.util.KeywordUtil

import com.kms.katalon.core.webui.exception.WebElementNotFoundException
import org.openqa.selenium.JavascriptExecutor;

import org.testng.Assert


public class webTable{

	@Keyword
	public int FindAndClickTableValue(String ExpectedRowName, int Column, TestObject objFrame) throws InterruptedException {

		WebDriver driver = DriverFactory.getWebDriver();
		int Row;
		String ActualRowName = null;
		boolean page = true;
		int TestData=1;
		String celtext=null;

		table: while (page) {
			WebElement mainFrame = WebUiBuiltInKeywords.findWebElement(objFrame);
			driver.switchTo().frame(mainFrame);

			WebElement UsersTable = driver.findElement(By.xpath("//table/tbody"));

			List<WebElement> rows_UsersTable = UsersTable.findElements(By
					.tagName("tr"));

			int rows_count = rows_UsersTable.size();
			println ("Total rows is  " +rows_count)

			for (int row = 0; row < rows_count; row++) {

				List<WebElement> Columns_row = rows_UsersTable.get(row)
						.findElements(By.tagName("td"));
				Row = row+1 ;

				int columns_count = Columns_row.size();
				System.out.println("Number of cells in Row " + row + " is "
						+ columns_count);
				boolean a = true;

				for (int column = 0; column < columns_count; column++) {

					celtext = Columns_row.get(column).getText();
					System.out.println("Cell Value Of row number " + row
							+ " and column number " + column + " is "
							+ celtext);

					if (celtext.matches(ExpectedRowName)) {
						ActualRowName = celtext;

						//driver.switchTo().frame(driver.findElement(By.xpath("/html/frameset/frame[2]")));
						WebElement common = driver.findElement(By
								.xpath("//table/tbody/tr["+Row+"]/td["+Column+"]/a"));

						JavascriptExecutor js = (JavascriptExecutor)driver;
						js.executeScript("arguments[0].click();", common);

						//Thread.sleep(5000);
						a = false;
						page = false;
						TestData=1;
						break table;
					}
				}
				if (a == false) {
					break;
				}
				if(row==rows_count-1){
					System.out.println("Test Data is incorrect or Value is Missing");
					TestData=0;
					break table;
				}
				/*
				 if (celtext != ExpectedRowName) {
				 if (driver.findElements(By.xpath("//li[@class='next']/a")).size() != 0) {
				 driver.findElement(By.xpath("//li[@class='next']/a")).click();
				 Thread.sleep(1500);
				 } else {
				 Assert.fail(
				 "The searching Element is ::" + ExpectedRowName + ":: not present in table");
				 }
				 }*/
			}
		}
		return TestData;
	}

	@Keyword
	public int OCVFindAndClickTableValue(String ExpectedRowName, int Column, TestObject SearchResTable) throws InterruptedException {

		WebDriver driver = DriverFactory.getWebDriver();
		int Row;
		String ActualRowName = null;
		boolean page = true;
		int TestData=1;
		String celtext=null;

		table: while (page) {
			//WebElement mainFrame = WebUiBuiltInKeywords.findWebElement(objFrame);
			//driver.switchTo().frame(mainFrame);

			//WebElement UsersTable = driver.findElement(By.xpath("//*[@id='MainContent_SearchGV']"));
			WebElement UsersTable = WebUiBuiltInKeywords.findWebElement(SearchResTable);

			List<WebElement> rows_UsersTable = UsersTable.findElements(By.tagName("tr"));

			int rows_count = rows_UsersTable.size();
			println ("Total rows is  " +rows_count)

			for (int row = 0; row < rows_count; row++) {

				List<WebElement> Columns_row = rows_UsersTable.get(row)
						.findElements(By.tagName("td"));
				Row = row+1 ;

				int columns_count = Columns_row.size();
				System.out.println("Number of cells in Row " + row + " is "
						+ columns_count);
				boolean a = true;

				for (int column = 0; column < columns_count; column++) {

					celtext = Columns_row.get(column).getText();
					System.out.println("Cell Value Of row number " + row
							+ " and column number " + column + " is "
							+ celtext);

					if (celtext.matches(ExpectedRowName)) {
						ActualRowName = celtext;

						//driver.switchTo().frame(driver.findElement(By.xpath("/html/frameset/frame[2]")));
						WebElement common = driver.findElement(By
								.xpath("//*[@id='MainContent_SearchGV_rbtnOption_0']"));

						//		.xpath("//table/tbody/tr["+Row+"]/td["+Column+"]"));

						JavascriptExecutor js = (JavascriptExecutor)driver;
						js.executeScript("arguments[0].click();", common);

						//common.click();

						//Thread.sleep(5000);
						a = false;
						page = false;
						TestData=1;
						break table;
					}
				}
				if (a == false) {
					break;
				}
				if(row==rows_count-1){
					System.out.println("Test Data is incorrect or Value is Missing");
					TestData=0;
					break table;
				}
				/*
				 if (celtext != ExpectedRowName) {
				 if (driver.findElements(By.xpath("//li[@class='next']/a")).size() != 0) {
				 driver.findElement(By.xpath("//li[@class='next']/a")).click();
				 Thread.sleep(1500);
				 } else {
				 Assert.fail(
				 "The searching Element is ::" + ExpectedRowName + ":: not present in table");
				 }
				 }*/
			}
		}
		return TestData;
	}

	@Keyword
	public String GetText_From_WebTable(String ExpectedRowName, int Column) throws InterruptedException {

		WebDriver driver = DriverFactory.getWebDriver();
		int Row;
		String ActualRowName = null;
		boolean page = true;
		int TestData=1;
		String Str;

		table: while (page) {
			WebElement UsersTable = driver.findElement(By.xpath("//table/tbody"));

			List<WebElement> rows_UsersTable = UsersTable.findElements(By
					.tagName("tr"));

			int rows_count = rows_UsersTable.size();
			println ("Toatl rows is  " +rows_count)

			for (int row = 0; row < rows_count; row++) {

				List<WebElement> Columns_row = rows_UsersTable.get(row)
						.findElements(By.tagName("td"));
				Row = row+1 ;

				int columns_count = Columns_row.size();
				System.out.println("Number of cells In Row " + row + " are "
						+ columns_count);
				boolean a = true;

				for (int column = 0; column < columns_count; column++) {

					String celtext = Columns_row.get(column).getText();
					System.out.println("Cell Value Of row number " + row
							+ " and column number " + column + " Is "
							+ celtext);

					if (celtext.matches(ExpectedRowName)) {
						ActualRowName = celtext;

						WebElement common = driver.findElement(By
								.xpath("//table/tbody/tr["+Row+"]/td["+Column+"]/span"));

						Str=common.getText();

						Thread.sleep(5000);
						a = false;
						page = false;
						TestData=1;
						break table;
					}
				}
				if (a == false) {
					break;
				}
				if(row==rows_count-1){
					System.out.println("Test Data is incorrect or Value is Missing");
					TestData=0;
					break table;
				}
			}
		}
		return Str;
	}



	@Keyword
	public String GetText_From_WebTable_Organisation(String ExpectedRowName, int Column) throws InterruptedException {

		WebDriver driver = DriverFactory.getWebDriver();
		int Row;
		String ActualRowName = null;
		boolean page = true;
		int TestData=1;
		String Str;

		table: while (page) {
			WebElement UsersTable = driver.findElement(By.xpath("//table/tbody"));

			List<WebElement> rows_UsersTable = UsersTable.findElements(By
					.tagName("tr"));

			int rows_count = rows_UsersTable.size();
			println ("Toatl rows is  " +rows_count)

			for (int row = 0; row < rows_count; row++) {

				List<WebElement> Columns_row = rows_UsersTable.get(row)
						.findElements(By.tagName("td"));
				Row = row+1 ;

				int columns_count = Columns_row.size();
				System.out.println("Number of cells In Row " + row + " are "
						+ columns_count);
				boolean a = true;

				for (int column = 0; column < columns_count; column++) {

					String celtext = Columns_row.get(column).getText();
					System.out.println("Cell Value Of row number " + row
							+ " and column number " + column + " Is "
							+ celtext);

					if (celtext.matches(ExpectedRowName)) {
						ActualRowName = celtext;

						WebElement common = driver.findElement(By
								.xpath("//table/tbody/tr["+Row+"]/td["+Column+"]"));

						Str=common.getText();

						Thread.sleep(5000);
						a = false;
						page = false;
						TestData=1;
						break table;
					}
				}
				if (a == false) {
					break;
				}
				if(row==rows_count-1){
					System.out.println("Test Data is incorrect or Value is Missing");
					TestData=0;
					break table;
				}
			}
		}
		return Str;
	}


	@Keyword
	public String Selecting_CheckBox_From_WebTable(String ExpectedRowName, int Column) throws InterruptedException {

		WebDriver driver = DriverFactory.getWebDriver();
		int Row;
		String ActualRowName = null;
		boolean page = true;
		int TestData=1;
		String Str;

		table: while (page) {
			WebElement UsersTable = driver.findElement(By.xpath("//table/tbody"));

			List<WebElement> rows_UsersTable = UsersTable.findElements(By
					.tagName("tr"));

			int rows_count = rows_UsersTable.size();
			println ("Toatl rows is  " +rows_count)

			for (int row = 0; row < rows_count; row++) {

				List<WebElement> Columns_row = rows_UsersTable.get(row)
						.findElements(By.tagName("td"));
				Row = row+1 ;

				int columns_count = Columns_row.size();
				System.out.println("Number of cells In Row " + row + " are "
						+ columns_count);
				boolean a = true;

				for (int column = 0; column < columns_count; column++) {

					String celtext = Columns_row.get(column).getText();
					System.out.println("Cell Value Of row number " + row
							+ " and column number " + column + " Is "
							+ celtext);

					if (celtext.matches(ExpectedRowName)) {
						ActualRowName = celtext;

						WebElement common = driver.findElement(By
								.xpath("//table/tbody/tr["+Row+"]/td["+Column+"]/input"));

						common.click();

						Str=common.getText();

						Thread.sleep(5000);
						a = false;
						page = false;
						TestData=1;
						break table;
					}
				}
				if (a == false) {
					break;
				}
				if(row==rows_count-1){
					System.out.println("Test Data is incorrect or Value is Missing");
					TestData=0;
					break table;
				}
			}
		}
		return Str;
	}




	//// Custom Keyword Julia . Will click link in web table cell
	////Example: CustomKeywords.'Keywords.reusableComponents.webTable.ClickOnLinkInWebTableByRowAndColValues'('datatable', 'YEIP, MELISSA', 'Claim Number')
	//@Keyword
	//public void ClickOnLinkInWebTableByRowAndColValues(String tableCalssName, String RowTextIdentifier, String ColumnName){
	//
	//	int columnIndex = 0;
	//
	//	WebUI.verifyTextPresent(RowTextIdentifier, false, FailureHandling.OPTIONAL)
	//
	//	// driver obj.
	//	WebDriver driver = DriverFactory.getWebDriver()
	//
	//	//locate table'
	//	WebElement Table = driver.findElement(By.className(tableCalssName.trim()))
	//
	//
	//	//To locate rows of table it will Capture all the rows available in the table '
	//	List<WebElement> Rows = Table.findElements(By.tagName('tr'))
	//
	//	//print row counts
	//	println('No. of rows: ' + Rows.size())
	//
	//	////Loop will execute for all the rows of the table'
	//	table: for (int i = 0; i < Rows.size(); i++) {
	//
	//		//To locate columns(cells) of that specific row'
	//		List<WebElement> Cols = Rows.get(i).findElements(By.tagName('td'))
	//
	//		// for each column in a row
	//		for (int j = 0; j < Cols.size(); j++) {
	//
	//			println (Cols.get(j).getText())
	//
	//			if (Cols.get(j).getText().equalsIgnoreCase(ColumnName)) {
	//
	//				columnIndex = j;
	//			}
	//
	//			//Verifying the expected text in the each cell'
	//
	//			if (Cols.get(j).getText().equalsIgnoreCase(RowTextIdentifier)) {
	//
	//				// click on link in a row if row name matches
	//				Cols.get(columnIndex).findElement(By.tagName('a')).click()
	//
	//				break table
	//			}
	//		}
	//	}
	//}
	//
	//
	//


	// Custom Keyword by Julia. Will click link in web table cell found by table class, column name and row index
	//Example: CustomKeywords.'Keywords.reusableComponents.webTable.ClickOnLinkInWebTableByColNameAndRowIndex'('datatable', 'Claim Number', 1)
	@Keyword
	public void ClickLinkInWebTableByColNameAndRowIndex(String tableClassName, String ColumnName, int RowIndex){

		// driver obj.
		WebDriver driver = DriverFactory.getWebDriver()

		//locate table'
		WebElement Table = driver.findElement(By.className(tableClassName.trim()))

		//To locate rows of table it will Capture all the rows available in the table '
		List<WebElement> Rows = Table.findElements(By.tagName('tr'))

		//To locate columns(cells) of that specific row'
		List<WebElement> Cols = Rows.get(0).findElements(By.tagName('td'))

		// for each column in a row
		for (int j = 0; j < Cols.size(); j++) {

			println (Cols.get(j).getText())

			if (Cols.get(j).getText().equalsIgnoreCase(ColumnName)) {

				// reassign row index to
				Cols = Rows.get(RowIndex).findElements(By.tagName('td'))

				// click on link in a row if row name matches
				Cols.get(j).findElement(By.tagName('a')).click()

				break

			}

		}
	}


	// Custom Keyword Julia // DO NOT REMOVE, used in Delegation Test Cases
	//Will click link in web table cell
	//Example: CustomKeywords.'Keywords.reusableComponents.webTable.ReturnTextFromWebTableCell_ByRowIdentifierAndColTitle'('datatable', 'YEIP, MELISSA', 'Claim Number')
	@Keyword
	public String ReturnTextFromWebTableCell_ByRowIdentifierAndColTitle(String tableClassName, String RowTextIdentifier, String ColumnName){

		int columnIndex = 0;
		String strCellText;

		//WebUI.verifyTextPresent(RowTextIdentifier, false, FailureHandling.STOP_ON_FAILURE)

		// driver obj.
		WebDriver driver = DriverFactory.getWebDriver()

		//locate table'
		WebElement Table = driver.findElement(By.className(tableClassName.trim()))

		// Capture all the table rows ('tr')
		List<WebElement> Rows = Table.findElements(By.tagName('tr'))

		//print row counts
		//println('No. of rows: ' + Rows.size())

		//Loop will execute for each row of the table
		table: for (int i = 0; i < Rows.size(); i++) {

			// Locate columns(cells) of that specific row
			List<WebElement> Cols = Rows.get(i).findElements(By.tagName('td'))

			// for each column in a row
			for (int j = 0; j < Cols.size(); j++) {

				println (Cols.get(j).getText())
				// If table cell data = expected column name, record column number
				if (Cols.get(j).getText().equalsIgnoreCase(ColumnName)) {

					columnIndex = j;
					print ('Column SUBID number:    ' + columnIndex)
				}

				//Verifying the expected text in the each row cell, looking for text identifier

				if (Cols.get(j).getText().equalsIgnoreCase(RowTextIdentifier)) {

					// click on link in a row if row name matches
					strCellText = Cols.get(columnIndex).getText()
					//Cols.get(columnIndex).findElement(By.tagName('a')).click()
					print ('zzzzzzzzzzzzzzz   ' + strCellText)
					break table
				}
			}
		}
		return strCellText;
	}

	// Custom Keyword Julia // DO NOT REMOVE, used in Delegation Test Cases
	// Will return a text from a web table cell, found by table ID, text identifier and column index (startign from 0)
	// Example: CustomKeywords.'Keywords.reusableComponents.webTable.ReturnTextFromWebTableCell_ByRowIdentifierAndColIndex'('datatable', 'YEIP, MELISSA', 1)
	@Keyword
	public String ReturnTextFromWebTableCell_ByRowIdentifierAndColIndex(String tableClassName, String RowTextIdentifier, int ColumnIndex)
	{
		String strCellText;

		// driver obj.
		WebDriver driver = DriverFactory.getWebDriver()

		//locate table'
		WebElement Table = driver.findElement(By.className(tableClassName.trim()))

		// Capture all the table rows ('tr')
		List<WebElement> Rows = Table.findElements(By.tagName('tr'))

		//print row counts
		//println('No. of rows: ' + Rows.size())

		// Loop will execute for each row of the table
		table: for (int i = 0; i < Rows.size(); i++)
		{

			// Locate and record all columns(cells) of that specific row
			List<WebElement> Cols = Rows.get(i).findElements(By.tagName('td'))

			// for each cell in a row
			for (int j = 0; j < Cols.size(); j++)
			{
				//println (Cols.get(j).getText())

				// Verifying text in the each row cell, looking for text identifier
				if (Cols.get(j).getText().equalsIgnoreCase(RowTextIdentifier))
				{

					// return text from a specified cell ind
					strCellText = Cols.get(ColumnIndex).getText().trim()
					//Cols.get(columnIndex).findElement(By.tagName('a')).click()
					print ('Cell Text:   ' + strCellText)
					break table
				}
			}
		}
		return strCellText;
	}

	//
	//	// Custom Keyword Julia . Will return element property, such as text or inner HTML, found by row text identifier and column name
	//	//Example: CustomKeywords.'Keywords.reusableComponents.webTable.ClickOnLinkInWebTableByRowAndColValues'('datatable', 'YEIP, MELISSA', 'Claim Number')
	//	@Keyword
	//	public String ClickOnLinkInWebTableByRowTextIdentifierAndColName(String tableCalssName, String RowTextIdentifier, String ColumnName){
	//
	//		int columnIndex = 0;
	//
	//		WebUI.verifyTextPresent(RowTextIdentifier, false, FailureHandling.OPTIONAL)
	//
	//		// driver obj.
	//		WebDriver driver = DriverFactory.getWebDriver()
	//
	//		//locate table'
	//		WebElement Table = driver.findElement(By.className(tableCalssName.trim()))
	//
	//
	//		//To locate rows of table it will Capture all the rows available in the table '
	//		List<WebElement> Rows = Table.findElements(By.tagName('tr'))
	//
	//		//print row counts
	//		println('No. of rows: ' + Rows.size())
	//
	//		////Loop will execute for all the rows of the table'
	//		table: for (int i = 0; i < Rows.size(); i++) {
	//
	//			//To locate columns(cells) of that specific row'
	//			List<WebElement> Cols = Rows.get(i).findElements(By.tagName('td'))
	//
	//			// for each column in a row
	//			for (int j = 0; j < Cols.size(); j++) {
	//
	//				println (Cols.get(j).getText())
	//
	//				if (Cols.get(j).getText().equalsIgnoreCase(ColumnName)) {
	//
	//					columnIndex = j;
	//				}
	//
	//				//Verifying the expected text in the each cell'
	//
	//				if (Cols.get(j).getText().equalsIgnoreCase(RowTextIdentifier)) {
	//
	//					// click on link in a row if row name matches
	//					Cols.get(columnIndex).findElement(By.tagName('a')).click()
	//
	//					break table
	//				}
	//			}
	//		}return something
	//	}

	// Custom Keyword Julia . Will click link in web table cell
	//Example: CustomKeywords.'Keywords.reusableComponents.webTable.ClickOnLinkInWebTableByRowAndColValues'('datatable', 'YEIP, MELISSA', 'Claim Number')
	@Keyword
	public void ReturnElementPropertyByTextIdentifierAndColName(String tableCalssName, String RowTextIdentifier, String ColumnName){

		int columnIndex = 0;

		WebUI.verifyTextPresent(RowTextIdentifier, false, FailureHandling.OPTIONAL)

		// driver obj.
		WebDriver driver = DriverFactory.getWebDriver()

		//locate table'
		WebElement Table = driver.findElement(By.className(tableCalssName.trim()))


		//To locate rows of table it will Capture all the rows available in the table '
		List<WebElement> Rows = Table.findElements(By.tagName('tr'))

		//print row counts
		println('No. of rows: ' + Rows.size())

		////Loop will execute for all the rows of the table'
		table: for (int i = 0; i < Rows.size(); i++) {

			//To locate columns(cells) of that specific row'
			List<WebElement> Cols = Rows.get(i).findElements(By.tagName('td'))

			// for each column in a row
			for (int j = 0; j < Cols.size(); j++) {

				println (Cols.get(j).getText())

				if (Cols.get(j).getText().equalsIgnoreCase(ColumnName)) {

					columnIndex = j;
				}

				//Verifying the expected text in the each cell'

				if (Cols.get(j).getText().equalsIgnoreCase(RowTextIdentifier)) {

					// click on link in a row if row name matches
					Cols.get(columnIndex).findElement(By.tagName('a')).click()

					break table
				}
			}
		}
	}



	/////////////////////////////////////////////////////////////// end bracket
}

