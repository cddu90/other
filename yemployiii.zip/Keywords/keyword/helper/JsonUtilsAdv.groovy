package keyword.helper

import java.nio.file.Files
import java.nio.file.Paths

import com.bsc.qa.framework.utility.JSONUtils

public class JsonUtilsAdv extends JSONUtils{

	/**
	 * Get JSON request object as String using a json template. The key-value pairs in the dataMap will be used to find the key as a keyword in the template and replace it with the value in the map for that key.
	 *
	 * @param templateJsonFilePath Template file path
	 * @param dataMap HashMap with key-value pairs where key = keyword in the template that needs to be replaced and value = the actual value that the keyword needs to be replaced with.
	 * @param testClassName Test class name
	 * @param testCaseName Test case name
	 * @param appendToFile Save response string to file? true/false
	 * @return Json as a string
	 * @throws IOException IOException
	 */
	public static synchronized String getJsonRequestAsString(String templateJsonFilePath,Map<String, String> dataMap
	) throws IOException {
		String json = new String(Files.readAllBytes(Paths
				.get(templateJsonFilePath)))

		if(dataMap){
			for (String key : dataMap.keySet()) {
				json = json.replace(key, dataMap.get(key).toString())
				println(json)
			}
		}
		return json;
	}
}
