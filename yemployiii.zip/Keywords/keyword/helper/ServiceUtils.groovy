package keyword.helper

import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject

import com.kms.katalon.core.testobject.ConditionType
import com.kms.katalon.core.testobject.RequestObject
import com.kms.katalon.core.testobject.ResponseObject
import com.kms.katalon.core.testobject.RestRequestObjectBuilder
import com.kms.katalon.core.testobject.TestObjectProperty
import com.kms.katalon.core.testobject.UrlEncodedBodyParameter
import com.kms.katalon.core.util.KeywordUtil
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WS

import groovy.json.JsonOutput
import groovy.json.JsonSlurper
import internal.GlobalVariable

public class ServiceUtils  {

	/**
	 * 
	 * @param endpointUrl
	 * @param jsonBody
	 * @return
	 */
	ResponseObject getServiceResponse(String endpointUrl, String jsonBody){

		KeywordUtil.logInfo("JsonBody" +jsonBody)

		RestRequestObjectBuilder rs = new RestRequestObjectBuilder()

		TestObjectProperty contentType = new TestObjectProperty('Content-Type', ConditionType.EQUALS, 'application/json')

		TestObjectProperty clientId = new TestObjectProperty('x-ibm-client-id', ConditionType.EQUALS, GlobalVariable.Client_ID)

		TestObjectProperty clientSecret = new TestObjectProperty('x-ibm-client-secret', ConditionType.EQUALS, GlobalVariable.Client_Secret)

		TestObjectProperty authorization = new TestObjectProperty('Authorization', ConditionType.EQUALS, 'Bearer '+GlobalVariable.OAuth_Token)

		TestObjectProperty apiAuth = new TestObjectProperty('x-bsc-api-auth', ConditionType.EQUALS, 'Bearer '+GlobalVariable.OAuth_Token)

		ArrayList defaultHeaders = Arrays.asList(contentType, clientId, clientSecret, authorization, apiAuth)

		RequestObject rso = rs.withTextBodyContent(jsonBody).withHttpHeaders(defaultHeaders).withRestRequestMethod('POST').withRestUrl(
				endpointUrl).build()

		ResponseObject response = WS.sendRequest(rso)

		KeywordUtil.logInfo("response" +	JsonOutput.prettyPrint(response.getResponseBodyContent()))

		return response
	}



	/**
	 * 
	 * @param url
	 * @return
	 */
	String runAuthService(String url){

		RestRequestObjectBuilder rs = new RestRequestObjectBuilder()

		TestObjectProperty contentType = new TestObjectProperty('Content-Type', ConditionType.EQUALS, 'application/x-www-form-urlencoded')

		ArrayList defaultHeaders = Arrays.asList(contentType)

		RequestObject rso = 	rs.withUrlEncodedBodyContent([
			new UrlEncodedBodyParameter("Content-Type", 'application/json'),
			new UrlEncodedBodyParameter("scope", "employers_authorize"),
			new UrlEncodedBodyParameter("client_id", GlobalVariable.Client_ID),
			new UrlEncodedBodyParameter("client_secret", GlobalVariable.Client_Secret),
			new UrlEncodedBodyParameter("grant_type", "client_credentials"),
		]).withRestUrl(GlobalVariable.OAuthUrl).withRestRequestMethod('POST').withHttpHeaders(defaultHeaders).build()

		ResponseObject response = WS.sendRequest(rso)

		KeywordUtil.logInfo("response" +	JsonOutput.prettyPrint(response.getResponseBodyContent()))

		String responseString = response.responseBodyContent

		def dataValue = new JsonSlurper().parseText(responseString)

		def Access_Token = dataValue.access_token

		println ('Access_Token from OAuth Service >>' + Access_Token)

		GlobalVariable.OAuth_Token = Access_Token
	}
}
