
/**
 * This class is generated automatically by Katalon Studio and should not be modified or deleted.
 */

import com.kms.katalon.core.testobject.TestObject

import java.lang.String

import com.kms.katalon.core.model.FailureHandling

import java.lang.Object

import java.util.List

import org.openqa.selenium.WebElement

import kms.turing.katalon.plugins.helper.table.WebTableHelper.CellTextOptions

import kms.turing.katalon.plugins.helper.XPathHelper.CompareOptions

import java.util.Map

import com.applitools.eyes.selenium.Eyes

import com.applitools.eyes.RectangleSize



def static "Keywords.reusableComponents.DatepickerHandler.handleDatepicker"(
    	TestObject calender	
     , 	String exp_Date	
     , 	String exp_Month	
     , 	String exp_Year	) {
    (new Keywords.reusableComponents.DatepickerHandler()).handleDatepicker(
        	calender
         , 	exp_Date
         , 	exp_Month
         , 	exp_Year)
}


def static "pageobjects.employerreports.CreateBillingReportPage.isPageDisplayed"() {
    (new pageobjects.employerreports.CreateBillingReportPage()).isPageDisplayed()
}


def static "kms.turing.katalon.plugins.assertj.DateTimeAssert.equals"(
    	String verifiedDate	
     , 	String compare2Date	
     , 	String description	) {
    (new kms.turing.katalon.plugins.assertj.DateTimeAssert()).equals(
        	verifiedDate
         , 	compare2Date
         , 	description)
}


def static "kms.turing.katalon.plugins.assertj.DateTimeAssert.equals"(
    	String verifiedDate	
     , 	String compare2Date	
     , 	String format	
     , 	String description	) {
    (new kms.turing.katalon.plugins.assertj.DateTimeAssert()).equals(
        	verifiedDate
         , 	compare2Date
         , 	format
         , 	description)
}


def static "kms.turing.katalon.plugins.assertj.DateTimeAssert.equals"(
    	String verifiedDate	
     , 	String compare2Date	
     , 	String format	
     , 	String description	
     , 	FailureHandling flowControl	) {
    (new kms.turing.katalon.plugins.assertj.DateTimeAssert()).equals(
        	verifiedDate
         , 	compare2Date
         , 	format
         , 	description
         , 	flowControl)
}


def static "kms.turing.katalon.plugins.assertj.DateTimeAssert.isAfter"(
    	String verifiedDate	
     , 	String compare2Date	
     , 	String format	
     , 	String description	) {
    (new kms.turing.katalon.plugins.assertj.DateTimeAssert()).isAfter(
        	verifiedDate
         , 	compare2Date
         , 	format
         , 	description)
}


def static "kms.turing.katalon.plugins.assertj.DateTimeAssert.isAfter"(
    	String verifiedDate	
     , 	String compare2Date	
     , 	String description	) {
    (new kms.turing.katalon.plugins.assertj.DateTimeAssert()).isAfter(
        	verifiedDate
         , 	compare2Date
         , 	description)
}


def static "kms.turing.katalon.plugins.assertj.DateTimeAssert.isAfter"(
    	String verifiedDate	
     , 	String compare2Date	
     , 	String format	
     , 	String description	
     , 	FailureHandling flowControl	) {
    (new kms.turing.katalon.plugins.assertj.DateTimeAssert()).isAfter(
        	verifiedDate
         , 	compare2Date
         , 	format
         , 	description
         , 	flowControl)
}


def static "kms.turing.katalon.plugins.assertj.DateTimeAssert.isBefore"(
    	String verifiedDate	
     , 	String compare2Date	
     , 	String description	) {
    (new kms.turing.katalon.plugins.assertj.DateTimeAssert()).isBefore(
        	verifiedDate
         , 	compare2Date
         , 	description)
}


def static "kms.turing.katalon.plugins.assertj.DateTimeAssert.isBefore"(
    	String verifiedDate	
     , 	String compare2Date	
     , 	String format	
     , 	String description	
     , 	FailureHandling flowControl	) {
    (new kms.turing.katalon.plugins.assertj.DateTimeAssert()).isBefore(
        	verifiedDate
         , 	compare2Date
         , 	format
         , 	description
         , 	flowControl)
}


def static "kms.turing.katalon.plugins.assertj.DateTimeAssert.isBefore"(
    	String verifiedDate	
     , 	String compare2Date	
     , 	String format	
     , 	String description	) {
    (new kms.turing.katalon.plugins.assertj.DateTimeAssert()).isBefore(
        	verifiedDate
         , 	compare2Date
         , 	format
         , 	description)
}


def static "kms.turing.katalon.plugins.assertj.DateTimeAssert.matchesDateTimeFormat"(
    	String dateInString	
     , 	String datetimeFormat	
     , 	String description	
     , 	FailureHandling flowControl	) {
    (new kms.turing.katalon.plugins.assertj.DateTimeAssert()).matchesDateTimeFormat(
        	dateInString
         , 	datetimeFormat
         , 	description
         , 	flowControl)
}


def static "kms.turing.katalon.plugins.assertj.DateTimeAssert.matchesDateTimeFormat"(
    	String dateInString	
     , 	String datetimeFormat	
     , 	String description	) {
    (new kms.turing.katalon.plugins.assertj.DateTimeAssert()).matchesDateTimeFormat(
        	dateInString
         , 	datetimeFormat
         , 	description)
}

/**
	 * Refresh browser
	 */
def static "Keywords.webUtility.Grid.refreshBrowser"() {
    (new Keywords.webUtility.Grid()).refreshBrowser()
}

/**
	 * Click element
	 * @param to Katalon test object
	 */
def static "Keywords.webUtility.Grid.clickElement"(
    	TestObject to	) {
    (new Keywords.webUtility.Grid()).clickElement(
        	to)
}

/**
	 * Get all rows of HTML table
	 * @param table Katalon test object represent for HTML table
	 * @param outerTagName outer tag name of TR tag, usually is TBODY
	 * @return All rows inside HTML table
	 */
def static "Keywords.webUtility.Grid.getHtmlTableRows"(
    	TestObject table	
     , 	String outerTagName	) {
    (new Keywords.webUtility.Grid()).getHtmlTableRows(
        	table
         , 	outerTagName)
}


def static "Keywords.reusableComponents.webTable.FindAndClickTableValue"(
    	String ExpectedRowName	
     , 	int Column	
     , 	TestObject objFrame	) {
    (new Keywords.reusableComponents.webTable()).FindAndClickTableValue(
        	ExpectedRowName
         , 	Column
         , 	objFrame)
}


def static "Keywords.reusableComponents.webTable.OCVFindAndClickTableValue"(
    	String ExpectedRowName	
     , 	int Column	
     , 	TestObject SearchResTable	) {
    (new Keywords.reusableComponents.webTable()).OCVFindAndClickTableValue(
        	ExpectedRowName
         , 	Column
         , 	SearchResTable)
}


def static "Keywords.reusableComponents.webTable.GetText_From_WebTable"(
    	String ExpectedRowName	
     , 	int Column	) {
    (new Keywords.reusableComponents.webTable()).GetText_From_WebTable(
        	ExpectedRowName
         , 	Column)
}


def static "Keywords.reusableComponents.webTable.GetText_From_WebTable_Organisation"(
    	String ExpectedRowName	
     , 	int Column	) {
    (new Keywords.reusableComponents.webTable()).GetText_From_WebTable_Organisation(
        	ExpectedRowName
         , 	Column)
}


def static "Keywords.reusableComponents.webTable.Selecting_CheckBox_From_WebTable"(
    	String ExpectedRowName	
     , 	int Column	) {
    (new Keywords.reusableComponents.webTable()).Selecting_CheckBox_From_WebTable(
        	ExpectedRowName
         , 	Column)
}


def static "Keywords.reusableComponents.webTable.ClickLinkInWebTableByColNameAndRowIndex"(
    	String tableClassName	
     , 	String ColumnName	
     , 	int RowIndex	) {
    (new Keywords.reusableComponents.webTable()).ClickLinkInWebTableByColNameAndRowIndex(
        	tableClassName
         , 	ColumnName
         , 	RowIndex)
}


def static "Keywords.reusableComponents.webTable.ReturnTextFromWebTableCell_ByRowIdentifierAndColTitle"(
    	String tableClassName	
     , 	String RowTextIdentifier	
     , 	String ColumnName	) {
    (new Keywords.reusableComponents.webTable()).ReturnTextFromWebTableCell_ByRowIdentifierAndColTitle(
        	tableClassName
         , 	RowTextIdentifier
         , 	ColumnName)
}


def static "Keywords.reusableComponents.webTable.ReturnTextFromWebTableCell_ByRowIdentifierAndColIndex"(
    	String tableClassName	
     , 	String RowTextIdentifier	
     , 	int ColumnIndex	) {
    (new Keywords.reusableComponents.webTable()).ReturnTextFromWebTableCell_ByRowIdentifierAndColIndex(
        	tableClassName
         , 	RowTextIdentifier
         , 	ColumnIndex)
}


def static "Keywords.reusableComponents.webTable.ReturnElementPropertyByTextIdentifierAndColName"(
    	String tableCalssName	
     , 	String RowTextIdentifier	
     , 	String ColumnName	) {
    (new Keywords.reusableComponents.webTable()).ReturnElementPropertyByTextIdentifierAndColName(
        	tableCalssName
         , 	RowTextIdentifier
         , 	ColumnName)
}


def static "pageobjects.authenticatedlandingpage.EmployerAuthenticatedLandingBottomRail.isWebElementsInBottomRailDisplayed"() {
    (new pageobjects.authenticatedlandingpage.EmployerAuthenticatedLandingBottomRail()).isWebElementsInBottomRailDisplayed()
}


def static "kms.turing.katalon.plugins.assertj.BooleanAssert.isTrue"(
    	boolean expression	
     , 	String description	) {
    (new kms.turing.katalon.plugins.assertj.BooleanAssert()).isTrue(
        	expression
         , 	description)
}


def static "kms.turing.katalon.plugins.assertj.BooleanAssert.isTrue"(
    	boolean expression	
     , 	String description	
     , 	FailureHandling flowControl	) {
    (new kms.turing.katalon.plugins.assertj.BooleanAssert()).isTrue(
        	expression
         , 	description
         , 	flowControl)
}


def static "kms.turing.katalon.plugins.assertj.BooleanAssert.isFalse"(
    	boolean expression	
     , 	String description	) {
    (new kms.turing.katalon.plugins.assertj.BooleanAssert()).isFalse(
        	expression
         , 	description)
}


def static "kms.turing.katalon.plugins.assertj.BooleanAssert.isFalse"(
    	boolean expression	
     , 	String description	
     , 	FailureHandling flowControl	) {
    (new kms.turing.katalon.plugins.assertj.BooleanAssert()).isFalse(
        	expression
         , 	description
         , 	flowControl)
}


def static "pageobjects.billing.EmployerBillingCenterPage.isPageDisplayed"() {
    (new pageobjects.billing.EmployerBillingCenterPage()).isPageDisplayed()
}


def static "Keywords.reusableComponents.GenerateRandomString_Alpha_Num_MixedCase.randomString"(
    	int length	) {
    (new Keywords.reusableComponents.GenerateRandomString_Alpha_Num_MixedCase()).randomString(
        	length)
}


def static "kms.turing.katalon.plugins.assertj.GenericAssert.isNull"(
    	Object object	
     , 	String description	
     , 	FailureHandling flowControl	) {
    (new kms.turing.katalon.plugins.assertj.GenericAssert()).isNull(
        	object
         , 	description
         , 	flowControl)
}


def static "kms.turing.katalon.plugins.assertj.GenericAssert.isNull"(
    	Object object	
     , 	String description	) {
    (new kms.turing.katalon.plugins.assertj.GenericAssert()).isNull(
        	object
         , 	description)
}


def static "kms.turing.katalon.plugins.assertj.GenericAssert.isNotNull"(
    	Object object	
     , 	String description	
     , 	FailureHandling flowControl	) {
    (new kms.turing.katalon.plugins.assertj.GenericAssert()).isNotNull(
        	object
         , 	description
         , 	flowControl)
}


def static "kms.turing.katalon.plugins.assertj.GenericAssert.isNotNull"(
    	Object object	
     , 	String description	) {
    (new kms.turing.katalon.plugins.assertj.GenericAssert()).isNotNull(
        	object
         , 	description)
}


def static "Keywords.reusableComponents.VerifyDrodownValues_AlphabeticalOrder.verifyOptionsInDropdownInAphabeticalOrder"(
    	TestObject objectto	) {
    (new Keywords.reusableComponents.VerifyDrodownValues_AlphabeticalOrder()).verifyOptionsInDropdownInAphabeticalOrder(
        	objectto)
}

/**
	 * 
	 * @return
	 */
def static "pageobjects.billing.EmployerMakePaymentPage.isPageDisplayed"() {
    (new pageobjects.billing.EmployerMakePaymentPage()).isPageDisplayed()
}

/**
	 * 
	 * @param accountName
	 * @param accountNumber
	 * @param routingNumber
	 * @param nickName
	 * @return
	 */
def static "pageobjects.billing.EmployerMakePaymentPage.addBankDetails"(
    	String accountName	
     , 	String accountNumber	
     , 	String routingNumber	
     , 	String nickName	) {
    (new pageobjects.billing.EmployerMakePaymentPage()).addBankDetails(
        	accountName
         , 	accountNumber
         , 	routingNumber
         , 	nickName)
}

/**
	 * 
	 * @param paymentAmount
	 * @return
	 */
def static "pageobjects.billing.EmployerMakePaymentPage.addPaymentDetails"(
    	String paymentAmount	
     , 	String groupSubgroupNumber	) {
    (new pageobjects.billing.EmployerMakePaymentPage()).addPaymentDetails(
        	paymentAmount
         , 	groupSubgroupNumber)
}

/**
	 * Refresh browser
	 */
def static "Keywords.webUtility.WebUICustom.refreshBrowser"() {
    (new Keywords.webUtility.WebUICustom()).refreshBrowser()
}

/**
	 * Click element
	 * @param to Katalon test object
	 */
def static "Keywords.webUtility.WebUICustom.clickElement"(
    	TestObject to	) {
    (new Keywords.webUtility.WebUICustom()).clickElement(
        	to)
}

/**
	 * Get all rows of HTML table
	 * @param table Katalon test object represent for HTML table
	 * @param outerTagName outer tag name of TR tag, usually is TBODY
	 * @return All rows inside HTML table
	 */
def static "Keywords.webUtility.WebUICustom.getHtmlTableRows"(
    	TestObject table	
     , 	String outerTagName	) {
    (new Keywords.webUtility.WebUICustom()).getHtmlTableRows(
        	table
         , 	outerTagName)
}

/**
	 * Log result for searching and terminating user
	 * @param filename
	 * @param username
	 * @param result
	 * @param webapp
	 */
def static "Keywords.fileUtility.WriteToCSV.logResult"(
    	String username	
     , 	String result	
     , 	String webapp	) {
    (new Keywords.fileUtility.WriteToCSV()).logResult(
        	username
         , 	result
         , 	webapp)
}

/**
	 * Send request and verify status code
	 * @param request request object, must be an instance of RequestObject
	 * @param expectedStatusCode
	 * @return a boolean to indicate whether the response status code equals the expected one
	 */
def static "Keywords.fileUtility.WriteToCSV.verifyStatusCode"(
    	TestObject request	
     , 	int expectedStatusCode	) {
    (new Keywords.fileUtility.WriteToCSV()).verifyStatusCode(
        	request
         , 	expectedStatusCode)
}

/**
	 * Add Header basic authorization field,
	 * this field value is Base64 encoded token from user name and password
	 * @param request object, must be an instance of RequestObject
	 * @param username username
	 * @param password password
	 * @return the original request object with basic authorization header field added
	 */
def static "Keywords.fileUtility.WriteToCSV.addBasicAuthorizationProperty"(
    	TestObject request	
     , 	String username	
     , 	String password	) {
    (new Keywords.fileUtility.WriteToCSV()).addBasicAuthorizationProperty(
        	request
         , 	username
         , 	password)
}

/**
	 * Stops Chrome Driver 
	 */
def static "Keywords.testUtility.killDriver.killChrome"() {
    (new Keywords.testUtility.killDriver()).killChrome()
}

/**
	 * Stops Chrome Driver
	 */
def static "Keywords.testUtility.killDriver.killAllWebDrivers"() {
    (new Keywords.testUtility.killDriver()).killAllWebDrivers()
}

/**
	 * Stops Chrome Driver
	 */
def static "Keywords.testUtility.killDriver.killAllWebDriversAndBrowsers"() {
    (new Keywords.testUtility.killDriver()).killAllWebDriversAndBrowsers()
}

/**
	 * Refresh browser
	 */
def static "Keywords.testUtility.killDriver.refreshBrowser"() {
    (new Keywords.testUtility.killDriver()).refreshBrowser()
}

/**
	 * Click element
	 * @param to Katalon test object
	 */
def static "Keywords.testUtility.killDriver.clickElement"(
    	TestObject to	) {
    (new Keywords.testUtility.killDriver()).clickElement(
        	to)
}

/**
	 * Get all rows of HTML table
	 * @param table Katalon test object represent for HTML table
	 * @param outerTagName outer tag name of TR tag, usually is TBODY
	 * @return All rows inside HTML table
	 */
def static "Keywords.testUtility.killDriver.getHtmlTableRows"(
    	TestObject table	
     , 	String outerTagName	) {
    (new Keywords.testUtility.killDriver()).getHtmlTableRows(
        	table
         , 	outerTagName)
}


def static "pageobjects.billing.EmployerPaymentConfirmationPage.isPageDisplayed"() {
    (new pageobjects.billing.EmployerPaymentConfirmationPage()).isPageDisplayed()
}

/**
	 * Refresh browser
	 */
def static "Keywords.webUtility.BrowserActions.refreshBrowser"() {
    (new Keywords.webUtility.BrowserActions()).refreshBrowser()
}

/**
	 * To Maximize Browser Window in headless mode . Jenkins fix 
	 * @Author: Serhiy M.
	 * @ Reason default call to MaximizeBrowse causing Jenkins to fail test
	 * @return void
	 */
def static "Keywords.webUtility.BrowserActions.maxBrowserWindow"() {
    (new Keywords.webUtility.BrowserActions()).maxBrowserWindow()
}


def static "pageobjects.billing.EmployerSetupAutoPaymentPage.isPageDisplayed"() {
    (new pageobjects.billing.EmployerSetupAutoPaymentPage()).isPageDisplayed()
}


def static "pageobjects.billing.EmployerSetupAutoPaymentPage.setUpAutoPay"(
    	String subGroupID	) {
    (new pageobjects.billing.EmployerSetupAutoPaymentPage()).setUpAutoPay(
        	subGroupID)
}


def static "Keywords.reusableComponents.GenerateRandomString_Numeric.randomString"(
    	int length	) {
    (new Keywords.reusableComponents.GenerateRandomString_Numeric()).randomString(
        	length)
}


def static "Keywords.reusableComponents.HighlightElement.run"(
    	TestObject objectto	) {
    (new Keywords.reusableComponents.HighlightElement()).run(
        	objectto)
}

/**
	 * Verify if Search Invoice page is up
	 * @return
	 */
def static "pageobjects.billing.EmployerSearchInvoicePage.isPageDisplayed"() {
    (new pageobjects.billing.EmployerSearchInvoicePage()).isPageDisplayed()
}

/**
	 * Verify content of Search results page are displayed
	 * @return
	 */
def static "pageobjects.billing.EmployerSearchInvoicePage.verifyContentOfSearchResults"() {
    (new pageobjects.billing.EmployerSearchInvoicePage()).verifyContentOfSearchResults()
}

/**
	 * Verify Invoice Content is displayed
	 * @return
	 */
def static "pageobjects.billing.EmployerSearchInvoicePage.verifyContentInInvoiceDetails"() {
    (new pageobjects.billing.EmployerSearchInvoicePage()).verifyContentInInvoiceDetails()
}

/**
	 * Verify if Billing Options page is up
	 * @return
	 */
def static "pageobjects.billing.EmployerBillingOptionsPage.isPageDisplayed"() {
    (new pageobjects.billing.EmployerBillingOptionsPage()).isPageDisplayed()
}

/**
	 * Add bank account with accountName, accountNum, Routing Num as parameters
	 * @param accountName
	 * @param accountNum
	 * @param routingNum
	 * @return
	 */
def static "pageobjects.billing.EmployerBillingOptionsPage.addBankAccount"(
    	String accountName	
     , 	String accountNum	
     , 	String routingNum	) {
    (new pageobjects.billing.EmployerBillingOptionsPage()).addBankAccount(
        	accountName
         , 	accountNum
         , 	routingNum)
}


def static "kms.turing.katalon.plugins.assertj.ListAssert.contains"(
    	java.util.List<Object> list	
     , 	java.util.List<Object> subList	
     , 	String description	) {
    (new kms.turing.katalon.plugins.assertj.ListAssert()).contains(
        	list
         , 	subList
         , 	description)
}


def static "kms.turing.katalon.plugins.assertj.ListAssert.contains"(
    	java.util.List<Object> list	
     , 	java.util.List<Object> subList	
     , 	String description	
     , 	FailureHandling flowControl	) {
    (new kms.turing.katalon.plugins.assertj.ListAssert()).contains(
        	list
         , 	subList
         , 	description
         , 	flowControl)
}


def static "kms.turing.katalon.plugins.assertj.ListAssert.equalsIgnoreOrder"(
    	java.util.List<Object> actual	
     , 	java.util.List<Object> expected	
     , 	String description	
     , 	FailureHandling flowControl	) {
    (new kms.turing.katalon.plugins.assertj.ListAssert()).equalsIgnoreOrder(
        	actual
         , 	expected
         , 	description
         , 	flowControl)
}


def static "kms.turing.katalon.plugins.assertj.ListAssert.equalsIgnoreOrder"(
    	java.util.List<Object> actual	
     , 	java.util.List<Object> expected	
     , 	String description	) {
    (new kms.turing.katalon.plugins.assertj.ListAssert()).equalsIgnoreOrder(
        	actual
         , 	expected
         , 	description)
}


def static "kms.turing.katalon.plugins.assertj.ListAssert.equalsWithOrder"(
    	java.util.List<Object> actual	
     , 	java.util.List<Object> expected	
     , 	String description	) {
    (new kms.turing.katalon.plugins.assertj.ListAssert()).equalsWithOrder(
        	actual
         , 	expected
         , 	description)
}


def static "kms.turing.katalon.plugins.assertj.ListAssert.equalsWithOrder"(
    	java.util.List<Object> actual	
     , 	java.util.List<Object> expected	
     , 	String description	
     , 	FailureHandling flowControl	) {
    (new kms.turing.katalon.plugins.assertj.ListAssert()).equalsWithOrder(
        	actual
         , 	expected
         , 	description
         , 	flowControl)
}


def static "Keywords.fileUtility.ExcelHelper.writeTOExcelFile"(
    	String excelPath	
     , 	String sheetName	
     , 	String value	
     , 	int rowNo	
     , 	int colNo	) {
    (new Keywords.fileUtility.ExcelHelper()).writeTOExcelFile(
        	excelPath
         , 	sheetName
         , 	value
         , 	rowNo
         , 	colNo)
}


def static "Keywords.dbUtility.MyOra.getDBColumnDataToWhereClause"(
    	String sqlSingleColumnFormatedQuery	
     , 	String strWPRorFACETS	) {
    (new Keywords.dbUtility.MyOra()).getDBColumnDataToWhereClause(
        	sqlSingleColumnFormatedQuery
         , 	strWPRorFACETS)
}


def static "Keywords.dbUtility.MyOra.getDBRowValue"(
    	String sqlSingleColumnFormatedQuery	
     , 	String strWPRorFACETS	) {
    (new Keywords.dbUtility.MyOra()).getDBRowValue(
        	sqlSingleColumnFormatedQuery
         , 	strWPRorFACETS)
}


def static "Keywords.dbUtility.MyOra.getDBRowasListValue"(
    	String sqlSingleColumnFormatedQuery	
     , 	String strWPRorFACETS	) {
    (new Keywords.dbUtility.MyOra()).getDBRowasListValue(
        	sqlSingleColumnFormatedQuery
         , 	strWPRorFACETS)
}

/**
	 * This Method will connect to DB based on DbSourceName, Execute Query and Copy the result in resultSet.
	 * @param sqlSingleColumnFormatedQuery
	 * @param strWPRorFACETS
	 * @return resultSet
	 */
def static "Keywords.dbUtility.MyOra.getResultSetFromDBQUery"(
    	String sqlSingleColumnFormatedQuery	
     , 	String strWPRorFACETS	) {
    (new Keywords.dbUtility.MyOra()).getResultSetFromDBQUery(
        	sqlSingleColumnFormatedQuery
         , 	strWPRorFACETS)
}

/**
	 * 
	 * @return
	 */
def static "pageobjects.billing.EmployerPaymentReviewPage.isPageDisplayed"() {
    (new pageobjects.billing.EmployerPaymentReviewPage()).isPageDisplayed()
}


def static "kms.turing.katalon.plugins.helper.table.HTMLTableHelper.clickOnColumn"(
    	WebElement table	
     , 	String columnHeader	
     , 	FailureHandling flowControl	) {
    (new kms.turing.katalon.plugins.helper.table.HTMLTableHelper()).clickOnColumn(
        	table
         , 	columnHeader
         , 	flowControl)
}


def static "kms.turing.katalon.plugins.helper.table.HTMLTableHelper.clickOnColumn"(
    	WebElement table	
     , 	String columnHeader	) {
    (new kms.turing.katalon.plugins.helper.table.HTMLTableHelper()).clickOnColumn(
        	table
         , 	columnHeader)
}


def static "kms.turing.katalon.plugins.helper.table.HTMLTableHelper.verifyCellPresentWithText"(
    	WebElement table	
     , 	String columnHeader	
     , 	String text	
     , 	CellTextOptions textOption	) {
    (new kms.turing.katalon.plugins.helper.table.HTMLTableHelper()).verifyCellPresentWithText(
        	table
         , 	columnHeader
         , 	text
         , 	textOption)
}


def static "kms.turing.katalon.plugins.helper.table.HTMLTableHelper.verifyCellPresentWithText"(
    	WebElement table	
     , 	String columnHeader	
     , 	String text	) {
    (new kms.turing.katalon.plugins.helper.table.HTMLTableHelper()).verifyCellPresentWithText(
        	table
         , 	columnHeader
         , 	text)
}


def static "kms.turing.katalon.plugins.helper.table.HTMLTableHelper.verifyCellPresentWithText"(
    	WebElement table	
     , 	String columnHeader	
     , 	String text	
     , 	CellTextOptions textOption	
     , 	CompareOptions compareOption	) {
    (new kms.turing.katalon.plugins.helper.table.HTMLTableHelper()).verifyCellPresentWithText(
        	table
         , 	columnHeader
         , 	text
         , 	textOption
         , 	compareOption)
}


def static "kms.turing.katalon.plugins.helper.table.HTMLTableHelper.verifyCellPresentWithText"(
    	WebElement table	
     , 	String columnHeader	
     , 	String text	
     , 	CellTextOptions textOption	
     , 	CompareOptions compareOption	
     , 	FailureHandling flowControl	) {
    (new kms.turing.katalon.plugins.helper.table.HTMLTableHelper()).verifyCellPresentWithText(
        	table
         , 	columnHeader
         , 	text
         , 	textOption
         , 	compareOption
         , 	flowControl)
}


def static "kms.turing.katalon.plugins.helper.table.HTMLTableHelper.getColumnIndexByHeader"(
    	WebElement table	
     , 	String columnHeader	
     , 	FailureHandling flowControl	) {
    (new kms.turing.katalon.plugins.helper.table.HTMLTableHelper()).getColumnIndexByHeader(
        	table
         , 	columnHeader
         , 	flowControl)
}


def static "kms.turing.katalon.plugins.helper.table.HTMLTableHelper.getColumnIndexByHeader"(
    	WebElement table	
     , 	String columnHeader	) {
    (new kms.turing.katalon.plugins.helper.table.HTMLTableHelper()).getColumnIndexByHeader(
        	table
         , 	columnHeader)
}


def static "kms.turing.katalon.plugins.helper.table.HTMLTableHelper.identifyCellByValueAndColHeader"(
    	WebElement table	
     , 	String columnHeader	
     , 	String cellValue	) {
    (new kms.turing.katalon.plugins.helper.table.HTMLTableHelper()).identifyCellByValueAndColHeader(
        	table
         , 	columnHeader
         , 	cellValue)
}


def static "kms.turing.katalon.plugins.helper.table.HTMLTableHelper.identifyCellByValueAndColHeader"(
    	WebElement table	
     , 	String columnHeader	
     , 	String cellValue	
     , 	FailureHandling flowControl	) {
    (new kms.turing.katalon.plugins.helper.table.HTMLTableHelper()).identifyCellByValueAndColHeader(
        	table
         , 	columnHeader
         , 	cellValue
         , 	flowControl)
}


def static "kms.turing.katalon.plugins.helper.table.HTMLTableHelper.identifyCellByIndexes"(
    	WebElement table	
     , 	int columnIndex	
     , 	int rowIndex	) {
    (new kms.turing.katalon.plugins.helper.table.HTMLTableHelper()).identifyCellByIndexes(
        	table
         , 	columnIndex
         , 	rowIndex)
}


def static "kms.turing.katalon.plugins.helper.table.HTMLTableHelper.identifyCellByIndexes"(
    	WebElement table	
     , 	int columnIndex	
     , 	int rowIndex	
     , 	FailureHandling flowControl	) {
    (new kms.turing.katalon.plugins.helper.table.HTMLTableHelper()).identifyCellByIndexes(
        	table
         , 	columnIndex
         , 	rowIndex
         , 	flowControl)
}


def static "kms.turing.katalon.plugins.helper.table.HTMLTableHelper.getRowIndexByCellsInfo"(
    	WebElement table	
     , 	java.util.Map<String, Object> cellsInfo	
     , 	FailureHandling flowControl	) {
    (new kms.turing.katalon.plugins.helper.table.HTMLTableHelper()).getRowIndexByCellsInfo(
        	table
         , 	cellsInfo
         , 	flowControl)
}


def static "kms.turing.katalon.plugins.helper.table.HTMLTableHelper.getRowIndexByCellsInfo"(
    	WebElement table	
     , 	java.util.Map<String, Object> cellsInfo	) {
    (new kms.turing.katalon.plugins.helper.table.HTMLTableHelper()).getRowIndexByCellsInfo(
        	table
         , 	cellsInfo)
}


def static "kms.turing.katalon.plugins.helper.table.HTMLTableHelper.verifyRowDisplayed"(
    	WebElement table	
     , 	java.util.Map<String, Object> cellsInfo	
     , 	FailureHandling flowControl	) {
    (new kms.turing.katalon.plugins.helper.table.HTMLTableHelper()).verifyRowDisplayed(
        	table
         , 	cellsInfo
         , 	flowControl)
}


def static "kms.turing.katalon.plugins.helper.table.HTMLTableHelper.verifyRowDisplayed"(
    	WebElement table	
     , 	java.util.Map<String, Object> cellsInfo	) {
    (new kms.turing.katalon.plugins.helper.table.HTMLTableHelper()).verifyRowDisplayed(
        	table
         , 	cellsInfo)
}


def static "kms.turing.katalon.plugins.helper.table.HTMLTableHelper.identifyTableByColumnHeaders"(
    	java.util.List<String> columnHeaders	
     , 	int timeout	
     , 	FailureHandling flowControl	) {
    (new kms.turing.katalon.plugins.helper.table.HTMLTableHelper()).identifyTableByColumnHeaders(
        	columnHeaders
         , 	timeout
         , 	flowControl)
}


def static "kms.turing.katalon.plugins.helper.table.HTMLTableHelper.identifyTableByColumnHeaders"(
    	java.util.List<String> columnHeaders	) {
    (new kms.turing.katalon.plugins.helper.table.HTMLTableHelper()).identifyTableByColumnHeaders(
        	columnHeaders)
}


def static "kms.turing.katalon.plugins.helper.table.HTMLTableHelper.identifyTableByColumnHeaders"(
    	java.util.List<String> columnHeaders	
     , 	int timeout	) {
    (new kms.turing.katalon.plugins.helper.table.HTMLTableHelper()).identifyTableByColumnHeaders(
        	columnHeaders
         , 	timeout)
}


def static "kms.turing.katalon.plugins.helper.table.HTMLTableHelper.identifyCellByHeaderAndCellsInfo"(
    	WebElement table	
     , 	String columnHeader	
     , 	java.util.Map<String, Object> cellsInfo	
     , 	FailureHandling flowControl	) {
    (new kms.turing.katalon.plugins.helper.table.HTMLTableHelper()).identifyCellByHeaderAndCellsInfo(
        	table
         , 	columnHeader
         , 	cellsInfo
         , 	flowControl)
}


def static "kms.turing.katalon.plugins.helper.table.HTMLTableHelper.identifyCellByHeaderAndCellsInfo"(
    	WebElement table	
     , 	String columnHeader	
     , 	java.util.Map<String, Object> cellsInfo	) {
    (new kms.turing.katalon.plugins.helper.table.HTMLTableHelper()).identifyCellByHeaderAndCellsInfo(
        	table
         , 	columnHeader
         , 	cellsInfo)
}


def static "kms.turing.katalon.plugins.helper.table.HTMLTableHelper.getCellsValueByColumnHeader"(
    	WebElement table	
     , 	String columnHeader	) {
    (new kms.turing.katalon.plugins.helper.table.HTMLTableHelper()).getCellsValueByColumnHeader(
        	table
         , 	columnHeader)
}


def static "kms.turing.katalon.plugins.helper.table.HTMLTableHelper.getCellsValueByColumnHeader"(
    	WebElement table	
     , 	String columnHeader	
     , 	FailureHandling flowControl	) {
    (new kms.turing.katalon.plugins.helper.table.HTMLTableHelper()).getCellsValueByColumnHeader(
        	table
         , 	columnHeader
         , 	flowControl)
}


def static "kms.turing.katalon.plugins.helper.table.HTMLTableHelper.getColumnIndexByAttribute"(
    	WebElement table	
     , 	String attribute	
     , 	String value	) {
    (new kms.turing.katalon.plugins.helper.table.HTMLTableHelper()).getColumnIndexByAttribute(
        	table
         , 	attribute
         , 	value)
}


def static "kms.turing.katalon.plugins.helper.table.HTMLTableHelper.getColumnIndexByAttribute"(
    	WebElement table	
     , 	String attribute	
     , 	String value	
     , 	FailureHandling flowControl	) {
    (new kms.turing.katalon.plugins.helper.table.HTMLTableHelper()).getColumnIndexByAttribute(
        	table
         , 	attribute
         , 	value
         , 	flowControl)
}


def static "Keywords.reusableComponents.GenerateRandomString_Alpha_Upper.randomString"(
    	int length	) {
    (new Keywords.reusableComponents.GenerateRandomString_Alpha_Upper()).randomString(
        	length)
}


def static "Keywords.reusableComponents.VerifyExpectedAndActualOptionsInDropdown.VerifyExpectedAndActual"(
    	TestObject objectto	
     , 	java.util.List<String> listOfOptions	) {
    (new Keywords.reusableComponents.VerifyExpectedAndActualOptionsInDropdown()).VerifyExpectedAndActual(
        	objectto
         , 	listOfOptions)
}


def static "com.kms.katalon.keyword.applitools.BasicKeywords.checkElement"(
    	Eyes eyes	
     , 	WebElement element	) {
    (new com.kms.katalon.keyword.applitools.BasicKeywords()).checkElement(
        	eyes
         , 	element)
}


def static "com.kms.katalon.keyword.applitools.BasicKeywords.checkWindow"(
    	String testName	) {
    (new com.kms.katalon.keyword.applitools.BasicKeywords()).checkWindow(
        	testName)
}


def static "com.kms.katalon.keyword.applitools.BasicKeywords.checkTestObject"(
    	TestObject testObject	
     , 	String testName	) {
    (new com.kms.katalon.keyword.applitools.BasicKeywords()).checkTestObject(
        	testObject
         , 	testName)
}


def static "kms.turing.katalon.plugins.assertj.StringAssert.equals"(
    	String actual	
     , 	String expected	
     , 	boolean caseSensitive	
     , 	String description	
     , 	FailureHandling flowControl	) {
    (new kms.turing.katalon.plugins.assertj.StringAssert()).equals(
        	actual
         , 	expected
         , 	caseSensitive
         , 	description
         , 	flowControl)
}


def static "kms.turing.katalon.plugins.assertj.StringAssert.equals"(
    	String actual	
     , 	String expected	
     , 	boolean caseSensitive	
     , 	String description	) {
    (new kms.turing.katalon.plugins.assertj.StringAssert()).equals(
        	actual
         , 	expected
         , 	caseSensitive
         , 	description)
}


def static "kms.turing.katalon.plugins.assertj.StringAssert.equals"(
    	String actual	
     , 	String expected	
     , 	String description	) {
    (new kms.turing.katalon.plugins.assertj.StringAssert()).equals(
        	actual
         , 	expected
         , 	description)
}


def static "kms.turing.katalon.plugins.assertj.StringAssert.startsWith"(
    	String text	
     , 	String prefix	
     , 	String description	) {
    (new kms.turing.katalon.plugins.assertj.StringAssert()).startsWith(
        	text
         , 	prefix
         , 	description)
}


def static "kms.turing.katalon.plugins.assertj.StringAssert.startsWith"(
    	String text	
     , 	String prefix	
     , 	boolean caseSensitive	
     , 	String description	
     , 	FailureHandling flowControl	) {
    (new kms.turing.katalon.plugins.assertj.StringAssert()).startsWith(
        	text
         , 	prefix
         , 	caseSensitive
         , 	description
         , 	flowControl)
}


def static "kms.turing.katalon.plugins.assertj.StringAssert.startsWith"(
    	String text	
     , 	String prefix	
     , 	boolean caseSensitive	
     , 	String description	) {
    (new kms.turing.katalon.plugins.assertj.StringAssert()).startsWith(
        	text
         , 	prefix
         , 	caseSensitive
         , 	description)
}


def static "kms.turing.katalon.plugins.assertj.StringAssert.endsWith"(
    	String text	
     , 	String suffix	
     , 	String description	) {
    (new kms.turing.katalon.plugins.assertj.StringAssert()).endsWith(
        	text
         , 	suffix
         , 	description)
}


def static "kms.turing.katalon.plugins.assertj.StringAssert.endsWith"(
    	String text	
     , 	String suffix	
     , 	boolean caseSensitive	
     , 	String description	) {
    (new kms.turing.katalon.plugins.assertj.StringAssert()).endsWith(
        	text
         , 	suffix
         , 	caseSensitive
         , 	description)
}


def static "kms.turing.katalon.plugins.assertj.StringAssert.endsWith"(
    	String text	
     , 	String suffix	
     , 	boolean caseSensitive	
     , 	String description	
     , 	FailureHandling flowControl	) {
    (new kms.turing.katalon.plugins.assertj.StringAssert()).endsWith(
        	text
         , 	suffix
         , 	caseSensitive
         , 	description
         , 	flowControl)
}


def static "kms.turing.katalon.plugins.assertj.StringAssert.matches"(
    	String text	
     , 	String pattern	
     , 	String description	
     , 	FailureHandling flowControl	) {
    (new kms.turing.katalon.plugins.assertj.StringAssert()).matches(
        	text
         , 	pattern
         , 	description
         , 	flowControl)
}


def static "kms.turing.katalon.plugins.assertj.StringAssert.matches"(
    	String text	
     , 	String pattern	
     , 	String description	) {
    (new kms.turing.katalon.plugins.assertj.StringAssert()).matches(
        	text
         , 	pattern
         , 	description)
}


def static "kms.turing.katalon.plugins.assertj.StringAssert.contains"(
    	String text	
     , 	String subText	
     , 	String description	) {
    (new kms.turing.katalon.plugins.assertj.StringAssert()).contains(
        	text
         , 	subText
         , 	description)
}


def static "kms.turing.katalon.plugins.assertj.StringAssert.contains"(
    	String text	
     , 	String subText	
     , 	boolean caseSensitive	
     , 	String description	
     , 	FailureHandling flowControl	) {
    (new kms.turing.katalon.plugins.assertj.StringAssert()).contains(
        	text
         , 	subText
         , 	caseSensitive
         , 	description
         , 	flowControl)
}


def static "kms.turing.katalon.plugins.assertj.StringAssert.contains"(
    	String text	
     , 	String subText	
     , 	boolean caseSensitive	
     , 	String description	) {
    (new kms.turing.katalon.plugins.assertj.StringAssert()).contains(
        	text
         , 	subText
         , 	caseSensitive
         , 	description)
}


def static "kms.turing.katalon.plugins.assertj.StringAssert.notContain"(
    	String text	
     , 	String subText	
     , 	boolean caseSensitive	
     , 	String description	
     , 	FailureHandling flowControl	) {
    (new kms.turing.katalon.plugins.assertj.StringAssert()).notContain(
        	text
         , 	subText
         , 	caseSensitive
         , 	description
         , 	flowControl)
}


def static "kms.turing.katalon.plugins.assertj.StringAssert.notContain"(
    	String text	
     , 	String subText	
     , 	boolean caseSensitive	
     , 	String description	) {
    (new kms.turing.katalon.plugins.assertj.StringAssert()).notContain(
        	text
         , 	subText
         , 	caseSensitive
         , 	description)
}


def static "kms.turing.katalon.plugins.assertj.StringAssert.notContain"(
    	String text	
     , 	String subText	
     , 	String description	) {
    (new kms.turing.katalon.plugins.assertj.StringAssert()).notContain(
        	text
         , 	subText
         , 	description)
}


def static "kms.turing.katalon.plugins.assertj.StringAssert.notEqual"(
    	String actual	
     , 	String expected	
     , 	boolean caseSensitive	
     , 	String description	
     , 	FailureHandling flowControl	) {
    (new kms.turing.katalon.plugins.assertj.StringAssert()).notEqual(
        	actual
         , 	expected
         , 	caseSensitive
         , 	description
         , 	flowControl)
}


def static "kms.turing.katalon.plugins.assertj.StringAssert.notEqual"(
    	String actual	
     , 	String expected	
     , 	String description	) {
    (new kms.turing.katalon.plugins.assertj.StringAssert()).notEqual(
        	actual
         , 	expected
         , 	description)
}


def static "kms.turing.katalon.plugins.assertj.StringAssert.notEqual"(
    	String actual	
     , 	String expected	
     , 	boolean caseSensitive	
     , 	String description	) {
    (new kms.turing.katalon.plugins.assertj.StringAssert()).notEqual(
        	actual
         , 	expected
         , 	caseSensitive
         , 	description)
}


def static "com.kms.katalon.keyword.applitools.EyesKeywords.eyesOpenWithBaseline"(
    	String baselineName	
     , 	String testName	
     , 	RectangleSize viewportSize	) {
    (new com.kms.katalon.keyword.applitools.EyesKeywords()).eyesOpenWithBaseline(
        	baselineName
         , 	testName
         , 	viewportSize)
}


def static "com.kms.katalon.keyword.applitools.EyesKeywords.eyesClose"(
    	Eyes eyes	) {
    (new com.kms.katalon.keyword.applitools.EyesKeywords()).eyesClose(
        	eyes)
}


def static "com.kms.katalon.keyword.applitools.EyesKeywords.eyesOpen"(
    	String testName	
     , 	RectangleSize viewportSize	) {
    (new com.kms.katalon.keyword.applitools.EyesKeywords()).eyesOpen(
        	testName
         , 	viewportSize)
}


def static "com.kms.katalon.keyword.applitools.EyesKeywords.eyesInit"() {
    (new com.kms.katalon.keyword.applitools.EyesKeywords()).eyesInit()
}


def static "Keywords.reusableComponents.VerifyDataInWebTable.verify_expText_In_Colum_Table"(
    	TestObject tableObject	
     , 	String expText	
     , 	int expTextColNum	) {
    (new Keywords.reusableComponents.VerifyDataInWebTable()).verify_expText_In_Colum_Table(
        	tableObject
         , 	expText
         , 	expTextColNum)
}


def static "Keywords.reusableComponents.VerifyDataInWebTable.verify_Deleted_ExpText_In_Colum_Table"(
    	TestObject tableObject	
     , 	String expText	
     , 	int expTextColNum	) {
    (new Keywords.reusableComponents.VerifyDataInWebTable()).verify_Deleted_ExpText_In_Colum_Table(
        	tableObject
         , 	expText
         , 	expTextColNum)
}


def static "Keywords.reusableComponents.VerifyDataInWebTable.verify_MultipleTexts_In_Colum_Table"(
    	TestObject tableObject	
     , 	String expText1	
     , 	int expText1ColNum	
     , 	String expText2	
     , 	int expText2ColNum	) {
    (new Keywords.reusableComponents.VerifyDataInWebTable()).verify_MultipleTexts_In_Colum_Table(
        	tableObject
         , 	expText1
         , 	expText1ColNum
         , 	expText2
         , 	expText2ColNum)
}


def static "Keywords.reusableComponents.VerifyDataInWebTable.EditDelete_Click_Operation_In_WebTable"(
    	TestObject tableObject	
     , 	String expText	
     , 	int expTextColNum	
     , 	String clickOperation	
     , 	int clickOperationColNum	
     , 	String clickAttribute	) {
    (new Keywords.reusableComponents.VerifyDataInWebTable()).EditDelete_Click_Operation_In_WebTable(
        	tableObject
         , 	expText
         , 	expTextColNum
         , 	clickOperation
         , 	clickOperationColNum
         , 	clickAttribute)
}


def static "Keywords.reusableComponents.VerifyDataInWebTable.Peform_AnchorClick_Operation_In_Table"(
    	TestObject tableObject	
     , 	String expText	
     , 	int expTextColNum	
     , 	int clickOperationColNum	) {
    (new Keywords.reusableComponents.VerifyDataInWebTable()).Peform_AnchorClick_Operation_In_Table(
        	tableObject
         , 	expText
         , 	expTextColNum
         , 	clickOperationColNum)
}


def static "kms.turing.katalon.plugins.assertj.NumberAssert.equals"(
    	Object actual	
     , 	Object expected	
     , 	String description	
     , 	FailureHandling flowControl	) {
    (new kms.turing.katalon.plugins.assertj.NumberAssert()).equals(
        	actual
         , 	expected
         , 	description
         , 	flowControl)
}


def static "kms.turing.katalon.plugins.assertj.NumberAssert.equals"(
    	Object actual	
     , 	Object expected	
     , 	String description	) {
    (new kms.turing.katalon.plugins.assertj.NumberAssert()).equals(
        	actual
         , 	expected
         , 	description)
}


def static "kms.turing.katalon.plugins.assertj.NumberAssert.isNegative"(
    	Object value	
     , 	String description	
     , 	FailureHandling flowControl	) {
    (new kms.turing.katalon.plugins.assertj.NumberAssert()).isNegative(
        	value
         , 	description
         , 	flowControl)
}


def static "kms.turing.katalon.plugins.assertj.NumberAssert.isNegative"(
    	Object value	
     , 	String description	) {
    (new kms.turing.katalon.plugins.assertj.NumberAssert()).isNegative(
        	value
         , 	description)
}


def static "kms.turing.katalon.plugins.assertj.NumberAssert.isZero"(
    	Object value	
     , 	String description	
     , 	FailureHandling flowControl	) {
    (new kms.turing.katalon.plugins.assertj.NumberAssert()).isZero(
        	value
         , 	description
         , 	flowControl)
}


def static "kms.turing.katalon.plugins.assertj.NumberAssert.isZero"(
    	Object value	
     , 	String description	) {
    (new kms.turing.katalon.plugins.assertj.NumberAssert()).isZero(
        	value
         , 	description)
}


def static "kms.turing.katalon.plugins.assertj.NumberAssert.isPositive"(
    	Object value	
     , 	String description	
     , 	FailureHandling flowControl	) {
    (new kms.turing.katalon.plugins.assertj.NumberAssert()).isPositive(
        	value
         , 	description
         , 	flowControl)
}


def static "kms.turing.katalon.plugins.assertj.NumberAssert.isPositive"(
    	Object value	
     , 	String description	) {
    (new kms.turing.katalon.plugins.assertj.NumberAssert()).isPositive(
        	value
         , 	description)
}


def static "kms.turing.katalon.plugins.assertj.NumberAssert.greaterThanOrEqual"(
    	Object x	
     , 	Object y	
     , 	String description	
     , 	FailureHandling flowControl	) {
    (new kms.turing.katalon.plugins.assertj.NumberAssert()).greaterThanOrEqual(
        	x
         , 	y
         , 	description
         , 	flowControl)
}


def static "kms.turing.katalon.plugins.assertj.NumberAssert.greaterThanOrEqual"(
    	Object x	
     , 	Object y	
     , 	String description	) {
    (new kms.turing.katalon.plugins.assertj.NumberAssert()).greaterThanOrEqual(
        	x
         , 	y
         , 	description)
}


def static "kms.turing.katalon.plugins.assertj.NumberAssert.greaterThan"(
    	Object x	
     , 	Object y	
     , 	String description	) {
    (new kms.turing.katalon.plugins.assertj.NumberAssert()).greaterThan(
        	x
         , 	y
         , 	description)
}


def static "kms.turing.katalon.plugins.assertj.NumberAssert.greaterThan"(
    	Object x	
     , 	Object y	
     , 	String description	
     , 	FailureHandling flowControl	) {
    (new kms.turing.katalon.plugins.assertj.NumberAssert()).greaterThan(
        	x
         , 	y
         , 	description
         , 	flowControl)
}


def static "kms.turing.katalon.plugins.assertj.NumberAssert.lessThan"(
    	Object x	
     , 	Object y	
     , 	String description	) {
    (new kms.turing.katalon.plugins.assertj.NumberAssert()).lessThan(
        	x
         , 	y
         , 	description)
}


def static "kms.turing.katalon.plugins.assertj.NumberAssert.lessThan"(
    	Object x	
     , 	Object y	
     , 	String description	
     , 	FailureHandling flowControl	) {
    (new kms.turing.katalon.plugins.assertj.NumberAssert()).lessThan(
        	x
         , 	y
         , 	description
         , 	flowControl)
}


def static "kms.turing.katalon.plugins.assertj.NumberAssert.notEqual"(
    	Object actual	
     , 	Object expected	
     , 	String description	
     , 	FailureHandling flowControl	) {
    (new kms.turing.katalon.plugins.assertj.NumberAssert()).notEqual(
        	actual
         , 	expected
         , 	description
         , 	flowControl)
}


def static "kms.turing.katalon.plugins.assertj.NumberAssert.notEqual"(
    	Object actual	
     , 	Object expected	
     , 	String description	) {
    (new kms.turing.katalon.plugins.assertj.NumberAssert()).notEqual(
        	actual
         , 	expected
         , 	description)
}


def static "kms.turing.katalon.plugins.assertj.NumberAssert.lessThanOrEqual"(
    	Object x	
     , 	Object y	
     , 	String description	) {
    (new kms.turing.katalon.plugins.assertj.NumberAssert()).lessThanOrEqual(
        	x
         , 	y
         , 	description)
}


def static "kms.turing.katalon.plugins.assertj.NumberAssert.lessThanOrEqual"(
    	Object x	
     , 	Object y	
     , 	String description	
     , 	FailureHandling flowControl	) {
    (new kms.turing.katalon.plugins.assertj.NumberAssert()).lessThanOrEqual(
        	x
         , 	y
         , 	description
         , 	flowControl)
}


def static "Keywords.reusableComponents.GenerateRandomString_Alpha_Lower.randomString"(
    	int length	) {
    (new Keywords.reusableComponents.GenerateRandomString_Alpha_Lower()).randomString(
        	length)
}


def static "pageobjects.billing.EmployerPaymentHistoryPage.isPageDisplayed"() {
    (new pageobjects.billing.EmployerPaymentHistoryPage()).isPageDisplayed()
}


def static "pageobjects.billing.EmployerPaymentHistoryPage.isPaymentHistoryTableDisplayed"() {
    (new pageobjects.billing.EmployerPaymentHistoryPage()).isPaymentHistoryTableDisplayed()
}


def static "Keywords.dbUtility.MySql.getGlobalVar"() {
    (new Keywords.dbUtility.MySql()).getGlobalVar()
}


def static "Keywords.dbUtility.MySql.connectDB"(
    	String url	
     , 	String dbname	
     , 	String port	
     , 	String username	
     , 	String password	) {
    (new Keywords.dbUtility.MySql()).connectDB(
        	url
         , 	dbname
         , 	port
         , 	username
         , 	password)
}


def static "Keywords.dbUtility.MySql.executeQuery"(
    	String queryString	) {
    (new Keywords.dbUtility.MySql()).executeQuery(
        	queryString)
}


def static "Keywords.dbUtility.MySql.closeDatabaseConnection"() {
    (new Keywords.dbUtility.MySql()).closeDatabaseConnection()
}

/**
	 * Execute non-query (usually INSERT/UPDATE/DELETE/COUNT/SUM...) on database
	 * @param queryString a SQL statement
	 * @return single value result of SQL statement
	 */
def static "Keywords.dbUtility.MySql.execute"(
    	String queryString	) {
    (new Keywords.dbUtility.MySql()).execute(
        	queryString)
}


def static "Keywords.reusableComponents.Verify_Text_In_WebElement.verifyTextInWebelement"(
    	TestObject objectto	
     , 	String expText	) {
    (new Keywords.reusableComponents.Verify_Text_In_WebElement()).verifyTextInWebelement(
        	objectto
         , 	expText)
}
