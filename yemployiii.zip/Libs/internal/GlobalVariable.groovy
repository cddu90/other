package internal

import com.kms.katalon.core.configuration.RunConfiguration
import com.kms.katalon.core.main.TestCaseMain


/**
 * This class is generated automatically by Katalon Studio and should not be modified or deleted.
 */
public class GlobalVariable {
     
    /**
     * <p></p>
     */
    public static Object PORTAL_URL
     
    /**
     * <p></p>
     */
    public static Object FACETS_DB
     
    /**
     * <p></p>
     */
    public static Object FACETS_SERVER
     
    /**
     * <p></p>
     */
    public static Object FACETS_PORT
     
    /**
     * <p></p>
     */
    public static Object FACETS_USER
     
    /**
     * <p></p>
     */
    public static Object FACETS_PWD
     
    /**
     * <p></p>
     */
    public static Object WPR_DB
     
    /**
     * <p></p>
     */
    public static Object WPR_SERVER
     
    /**
     * <p></p>
     */
    public static Object WPR_PORT
     
    /**
     * <p></p>
     */
    public static Object WPR_USER
     
    /**
     * <p></p>
     */
    public static Object WPR_PWD
     
    /**
     * <p></p>
     */
    public static Object ENV_NAME
     
    /**
     * <p></p>
     */
    public static Object WS_CHANGE_PWD_URI
     
    /**
     * <p></p>
     */
    public static Object TIMEOUT
     
    /**
     * <p></p>
     */
    public static Object WS_CREATE_USER_URI
     
    /**
     * <p></p>
     */
    public static Object empLoginData
     
    /**
     * <p></p>
     */
    public static Object brokerLoginData
     
    /**
     * <p></p>
     */
    public static Object billingReportData
     
    /**
     * <p></p>
     */
    public static Object billingRptBrokerData
     
    /**
     * <p></p>
     */
    public static Object NoPaymentsSetUpData
     
    /**
     * <p></p>
     */
    public static Object EDILogin
     
    /**
     * <p></p>
     */
    public static Object EEnrollLogin
     
    /**
     * <p></p>
     */
    public static Object SelfAccountLogin
     
    /**
     * <p></p>
     */
    public static Object UserWithReciepts
     
    /**
     * <p></p>
     */
    public static Object UnRegGroupData
     
    /**
     * <p></p>
     */
    public static Object empLoginLargeGrp
     
    /**
     * <p></p>
     */
    public static Object empLoginSmallGrp
     
    /**
     * <p></p>
     */
    public static Object hrLoginData
     
    /**
     * <p></p>
     */
    public static Object hrpcLoginData
     
    /**
     * <p></p>
     */
    public static Object pendingDelegatesData
     
    /**
     * <p></p>
     */
    public static Object Client_ID
     
    /**
     * <p></p>
     */
    public static Object Client_Secret
     
    /**
     * <p></p>
     */
    public static Object OAuth_Token
     
    /**
     * <p></p>
     */
    public static Object OAuthUrl
     
    /**
     * <p></p>
     */
    public static Object AddUserUrl
     
    /**
     * <p></p>
     */
    public static Object hrNewRegData
     
    /**
     * <p></p>
     */
    public static Object PCWithAddUser
     
    /**
     * <p></p>
     */
    public static Object groupModificationURL
     
    /**
     * <p></p>
     */
    public static Object DEL_RGST_URL
     
    /**
     * <p></p>
     */
    public static Object WS_URL
     

    static {
        try {
            def selectedVariables = TestCaseMain.getGlobalVariables("default")
			selectedVariables += TestCaseMain.getGlobalVariables(RunConfiguration.getExecutionProfile())
            selectedVariables += RunConfiguration.getOverridingParameters()
    
            PORTAL_URL = selectedVariables['PORTAL_URL']
            FACETS_DB = selectedVariables['FACETS_DB']
            FACETS_SERVER = selectedVariables['FACETS_SERVER']
            FACETS_PORT = selectedVariables['FACETS_PORT']
            FACETS_USER = selectedVariables['FACETS_USER']
            FACETS_PWD = selectedVariables['FACETS_PWD']
            WPR_DB = selectedVariables['WPR_DB']
            WPR_SERVER = selectedVariables['WPR_SERVER']
            WPR_PORT = selectedVariables['WPR_PORT']
            WPR_USER = selectedVariables['WPR_USER']
            WPR_PWD = selectedVariables['WPR_PWD']
            ENV_NAME = selectedVariables['ENV_NAME']
            WS_CHANGE_PWD_URI = selectedVariables['WS_CHANGE_PWD_URI']
            TIMEOUT = selectedVariables['TIMEOUT']
            WS_CREATE_USER_URI = selectedVariables['WS_CREATE_USER_URI']
            empLoginData = selectedVariables['empLoginData']
            brokerLoginData = selectedVariables['brokerLoginData']
            billingReportData = selectedVariables['billingReportData']
            billingRptBrokerData = selectedVariables['billingRptBrokerData']
            NoPaymentsSetUpData = selectedVariables['NoPaymentsSetUpData']
            EDILogin = selectedVariables['EDILogin']
            EEnrollLogin = selectedVariables['EEnrollLogin']
            SelfAccountLogin = selectedVariables['SelfAccountLogin']
            UserWithReciepts = selectedVariables['UserWithReciepts']
            UnRegGroupData = selectedVariables['UnRegGroupData']
            empLoginLargeGrp = selectedVariables['empLoginLargeGrp']
            empLoginSmallGrp = selectedVariables['empLoginSmallGrp']
            hrLoginData = selectedVariables['hrLoginData']
            hrpcLoginData = selectedVariables['hrpcLoginData']
            pendingDelegatesData = selectedVariables['pendingDelegatesData']
            Client_ID = selectedVariables['Client_ID']
            Client_Secret = selectedVariables['Client_Secret']
            OAuth_Token = selectedVariables['OAuth_Token']
            OAuthUrl = selectedVariables['OAuthUrl']
            AddUserUrl = selectedVariables['AddUserUrl']
            hrNewRegData = selectedVariables['hrNewRegData']
            PCWithAddUser = selectedVariables['PCWithAddUser']
            groupModificationURL = selectedVariables['groupModificationURL']
            DEL_RGST_URL = selectedVariables['DEL_RGST_URL']
            WS_URL = selectedVariables['WS_URL']
            
        } catch (Exception e) {
            TestCaseMain.logGlobalVariableError(e)
        }
    }
}
