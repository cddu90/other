<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>p_The registration was cancelled as per user request</name>
   <tag></tag>
   <elementGuidId>8af6e38e-8617-4ebd-ba9a-44356f8ddc2c</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='layoutContainers']/div/div[2]/div/div/section/div[2]/p</value>
      </entry>
      <entry>
         <key>BASIC</key>
         <value>//*[(text() = '
        The registration was cancelled as per user request.
    ' or . = '
        The registration was cancelled as per user request.
    ') and @ref_element = 'Object Repository/Page_Employer Connection - Blue Shield of California/iframe_concat(id(  TB_iframeContent  ))_TB_iframeContent165']</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>p</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>mainContent NormalTexts</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>role</name>
      <type>Main</type>
      <value>main</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
        The registration was cancelled as per user request.
    </value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;layoutContainers&quot;)/div[@class=&quot;wpthemeInner&quot;]/div[@class=&quot;wptheme2Col&quot;]/div[@class=&quot;component-container wpthemeCol wpthemeLeft ibmDndColumn wpthemePrimaryContainer id-Z7_4G4GH241K0FL40AQEUMPN020B7&quot;]/div[@class=&quot;component-control selected asa.portlet.selected id-Z7_4G4GH241K0FL40AQEUMPN020N7&quot;]/section[@class=&quot;ibmPortalControl wpthemeNoSkin a11yRegionTarget&quot;]/div[@class=&quot;wpthemeOverflowAuto&quot;]/p[@class=&quot;mainContent NormalTexts&quot;]</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>ref_element</name>
      <type>Main</type>
      <value>Object Repository/Page_Employer Registration/SubPage_RegStep2_ValidateBillAndContactInformation/iframe_Feedback</value>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='layoutContainers']/div/div[2]/div/div/section/div[2]/p</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Registration'])[1]/following::p[1]</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//p</value>
   </webElementXpaths>
</WebElementEntity>
