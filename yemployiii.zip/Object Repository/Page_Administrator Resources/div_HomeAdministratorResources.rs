<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>div_HomeAdministratorResources</name>
   <tag></tag>
   <elementGuidId>69d795be-0db5-4cb0-b6d8-bd3e4acf4d4f</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='layoutContainers']/div/div[2]/div/div/section/div[2]/div/div/div</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>div</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>breadcrumb_area clearfix</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
       
Home>

if(&quot;Administrator Resources&quot; != &quot;Administrator Resources&quot;){
document.write('&lt;li>&lt;a href=&quot;?1dmy&amp;amp;urile=wcm%3apath%3a/employer_contents_en/administrator-resources?current=true&quot;>Administrator Resources&lt;/a>&lt;/li>');
document.write('&lt;li>&amp;gt;&lt;/li>');}
 Administrator Resources

     </value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;layoutContainers&quot;)/div[1]/div[@class=&quot;wptheme2Col&quot;]/div[@class=&quot;component-container wpthemeCol wpthemeLeft ibmDndColumn wpthemePrimaryContainer id-Z7_59D80A82KO42E0A6QVR15N00U4&quot;]/div[@class=&quot;component-control id-Z7_59D80A82KO42E0A6QVR15N00H4&quot;]/section[@class=&quot;ibmPortalControl wpthemeNoSkin a11yRegionTarget&quot;]/div[@class=&quot;wpthemeOverflowAuto&quot;]/div[@class=&quot;wrapper&quot;]/div[@class=&quot;content_wrapper clearfix&quot;]/div[@class=&quot;breadcrumb_area clearfix&quot;]</value>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <value>//div[@id='layoutContainers']/div/div[2]/div/div/section/div[2]/div/div/div</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Previous'])[2]/following::div[21]</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='New Session'])[2]/following::div[21]</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <value>//div[2]/div/div/div</value>
   </webElementXpaths>
</WebElementEntity>
