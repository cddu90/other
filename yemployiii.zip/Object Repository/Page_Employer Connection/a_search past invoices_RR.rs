<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>a_search past invoices_RR</name>
   <tag></tag>
   <elementGuidId>1afe97b3-213f-44fb-a6bd-ee7a3a2b4d5c</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='mainMediumRtHome']/div/div/div/div/div/div/p[5]/a</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>a</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>href</name>
      <type>Main</type>
      <value>/bsca/bsc/mysite/employer/auth/billing/searchinvoice/!ut/p/z1/04_Sj9CPykssy0xPLMnMz0vMAfIjo8zivfy9zQydTQz9_EODnA0C3YOCDD0C_Y0NLEz0wwkpiAJKG-AAjgZA_VFgJQgTPI1NQCaYmLo5Ghm6G5hCFeAxoyA3wiDTUVERAAWFJto!/dz/d5/L2dJQSEvUUt3QS80TmxFL1o2X0pPSzYxQzQxTk9JMzQwUUdSNDVGQTIxR1A0/</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>search past invoices </value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;mainMediumRtHome&quot;)/div[@class=&quot;mainHomeMediumRtMid clearfix&quot;]/div[@class=&quot;mainHomeMediumRtTop&quot;]/div[@class=&quot;mainHomeMediumRtBtm clearfix&quot;]/div[@class=&quot;mainHomeMediumRtContent&quot;]/div[@class=&quot;mainHomeMediumRtContentBody&quot;]/div[@class=&quot;homePageText&quot;]/p[5]/a[1]</value>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <value>//div[@id='mainMediumRtHome']/div/div/div/div/div/div/p[5]/a</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:link</name>
      <value>//a[contains(text(),'search past invoices')]</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='view and reconcile your bills'])[1]/following::a[1]</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='manage my users'])[1]/following::a[2]</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='view payment history'])[1]/preceding::a[1]</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='make a payment'])[1]/preceding::a[2]</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:href</name>
      <value>//a[contains(@href, '/bsca/bsc/mysite/employer/auth/billing/searchinvoice/!ut/p/z1/04_Sj9CPykssy0xPLMnMz0vMAfIjo8zivfy9zQydTQz9_EODnA0C3YOCDD0C_Y0NLEz0wwkpiAJKG-AAjgZA_VFgJQgTPI1NQCaYmLo5Ghm6G5hCFeAxoyA3wiDTUVERAAWFJto!/dz/d5/L2dJQSEvUUt3QS80TmxFL1o2X0pPSzYxQzQxTk9JMzQwUUdSNDVGQTIxR1A0/')]</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <value>//p[5]/a</value>
   </webElementXpaths>
</WebElementEntity>
