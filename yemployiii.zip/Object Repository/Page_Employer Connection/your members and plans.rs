<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>your members and plans</name>
   <tag></tag>
   <elementGuidId>b3f0c8f6-5745-4b19-8a8a-44fa39bce85d</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//h1[contains(text(),'Your Members and Plans')]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>div</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Administrator Resources </value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;mainMediumRtHome&quot;)/div[@class=&quot;mainHomeMediumRtMid clearfix&quot;]/div[@class=&quot;mainHomeMediumRtTop&quot;]/div[@class=&quot;mainHomeMediumRtBtm clearfix&quot;]/div[@class=&quot;mainHomeMediumRtContent&quot;]/div[@class=&quot;mainHomeMediumRtContentBody&quot;]/div[@class=&quot;homePageText&quot;]/div[4]</value>
   </webElementProperties>
</WebElementEntity>
