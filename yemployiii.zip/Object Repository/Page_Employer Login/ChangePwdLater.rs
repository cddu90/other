<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>ChangePwdLater</name>
   <tag></tag>
   <elementGuidId>82baf5ec-0861-43e0-9c03-d1685712cf51</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>div a.blueLink.paddingTop5</value>
      </entry>
      <entry>
         <key>BASIC</key>
         <value></value>
      </entry>
   </selectorCollection>
   <selectorMethod>CSS</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>
