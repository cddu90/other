<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>AgreeTermsButton</name>
   <tag></tag>
   <elementGuidId>8335c80d-d159-4711-bde5-0fd0ffb81fa1</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>a > img[alt='i agree to the terms above button']</value>
      </entry>
      <entry>
         <key>BASIC</key>
         <value></value>
      </entry>
   </selectorCollection>
   <selectorMethod>CSS</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>
