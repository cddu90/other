<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>loginFailure</name>
   <tag></tag>
   <elementGuidId>da4f3fad-3289-49ef-bd0a-8dcf4a14f97e</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='skippedContent'][contains(text(),'You currently do not have any associated groups')]</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>div#skippedContent.mainHomeContentPageHeader</value>
      </entry>
      <entry>
         <key>BASIC</key>
         <value></value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>
