<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>Bad User Password Message</name>
   <tag></tag>
   <elementGuidId>d35cc229-faa3-4b7e-8873-e0c16e68c7b5</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='mainHome']/div/div/div/div/div[2]/div/div/p</value>
      </entry>
      <entry>
         <key>BASIC</key>
         <value>//p[(text() = 'Please enter a valid username or password. For help, please visit  Username and Password Help.Note: your account will be locked after five failed login attempts. To regain access, please  contact the Employer Group Service and Support for assistance.' or . = 'Please enter a valid username or password. For help, please visit  Username and Password Help.Note: your account will be locked after five failed login attempts. To regain access, please  contact the Employer Group Service and Support for assistance.')]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>p</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Please enter a valid username or password. For help, please visit  Username and Password Help.Note: your account will be locked after five failed login attempts. To regain access, please  contact the Employer Group Service and Support for assistance.</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;mainHome&quot;)/div[@class=&quot;mainHomeMid clearfix&quot;]/div[@class=&quot;mainHomeTop&quot;]/div[@class=&quot;mainHomeBtm clearfix&quot;]/div[@class=&quot;mainHomeContent&quot;]/div[@class=&quot;mainHomeContentBody&quot;]/div[1]/div[@class=&quot;errorMessage_Bold&quot;]/p[1]</value>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <value>//div[@id='mainHome']/div/div/div/div/div[2]/div/div/p</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='employer connection login'])[1]/following::p[1]</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='why blue shield?'])[1]/following::p[1]</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <value>//p</value>
   </webElementXpaths>
</WebElementEntity>
