<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>Text_ErrMsg_InvalidContactLargeGrp</name>
   <tag></tag>
   <elementGuidId>af1cd552-1d00-4399-9eb6-5966b77324de</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//html</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>html</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>lang</name>
      <type>Main</type>
      <value>en</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>


#katalon{font-family:monospace;font-size:13px;background-color:rgba(0,0,0,.7);position:fixed;top:0;left:0;right:0;display:block;z-index:999999999;line-height: normal} #katalon div{padding:0;margin:0;color:#fff;} #katalon kbd{display:inline-block;padding:3px 5px;font:13px Consolas,&quot;Liberation Mono&quot;,Menlo,Courier,monospace;line-height:10px;color:#555;vertical-align:middle;background-color:#fcfcfc;border:1px solid #ccc;border-bottom-color:#bbb;border-radius:3px;box-shadow:inset 0 -1px 0 #bbb;font-weight: bold} div#katalon-spy_elementInfoDiv {color: lightblue; padding: 0px 5px 5px} div#katalon-spy_instructionDiv {padding: 5px 5px 2.5px}#katalon{font-family:monospace;font-size:13px;background-color:rgba(0,0,0,.7);position:fixed;top:0;left:0;right:0;display:block;z-index:999999999;line-height: normal} #katalon div{padding:0;margin:0;color:#fff;} #katalon kbd{display:inline-block;padding:3px 5px;font:13px Consolas,&quot;Liberation Mono&quot;,Menlo,Courier,monospace;line-height:10px;color:#555;vertical-align:middle;background-color:#fcfcfc;border:1px solid #ccc;border-bottom-color:#bbb;border-radius:3px;box-shadow:inset 0 -1px 0 #bbb;font-weight: bold} div#katalon-spy_elementInfoDiv {color: lightblue; padding: 0px 5px 5px} div#katalon-spy_instructionDiv {padding: 5px 5px 2.5px}#katalon{font-family:monospace;font-size:13px;background-color:rgba(0,0,0,.7);position:fixed;top:0;left:0;right:0;display:block;z-index:999999999;line-height: normal} #katalon div{padding:0;margin:0;color:#fff;} #katalon kbd{display:inline-block;padding:3px 5px;font:13px Consolas,&quot;Liberation Mono&quot;,Menlo,Courier,monospace;line-height:10px;color:#555;vertical-align:middle;background-color:#fcfcfc;border:1px solid #ccc;border-bottom-color:#bbb;border-radius:3px;box-shadow:inset 0 -1px 0 #bbb;font-weight: bold} div#katalon-spy_elementInfoDiv {color: lightblue; padding: 0px 5px 5px} div#katalon-spy_instructionDiv {padding: 5px 5px 2.5px}
	

&lt;iframe src=&quot;//www.googletagmanager.com/ns.html?id=GTM-TQRLHL&quot;
height=&quot;0&quot; width=&quot;0&quot; style=&quot;display:none;visibility:hidden&quot;>&lt;/iframe>
(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':
new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],
j=d.createElement(s),dl=l!='dataLayer'?'&amp;l='+l:'';j.async=true;j.src=
'//www.googletagmanager.com/gtm.js?id='+i+dl;f.parentNode.insertBefore(j,f);
})(window,document,'script','dataLayer','GTM-TQRLHL');


	
		
			
			{&quot;Z7_4G4GH241K0FL40AQEUMPN020N7&quot;:{&quot;windowState&quot;:&quot;normal&quot;,&quot;portletMode&quot;:&quot;view&quot;}}	
									
					
	
	



	
	
	
	
	
		
	
    
    
 		
	
     
        





















	
		
			Registration
		
	

	

		
		


		
		

		

		

		


		
		
		
		
		
		
		

		

		

		


		

		
		
		
		



		

		
			The contact information
				does not match. Check the information you entered and try again, or
				contact (800) 837-4215.
		

		


		
		
		
			
		
		
	

	
		 
		
	








	

  function redirectURL(){
	 self.parent.tb_remove();
	 var contactUsURL='';
	window.top.location.href = contactUsURL; 
   }
 


 

				
			
		
		
	
		


!function(b,e,f,g,a,c,d){b.fbq||(a=b.fbq=function(){a.callMethod?a.callMethod.apply(a,arguments):a.queue.push(arguments)},b._fbq||(b._fbq=a),a.push=a,a.loaded=!0,a.version=&quot;2.0&quot;,a.queue=[],c=e.createElement(f),c.async=!0,c.src=g,d=e.getElementsByTagName(f)[0],d.parentNode.insertBefore(c,d))}(window,document,&quot;script&quot;,&quot;https://connect.facebook.net/en_US/fbevents.js&quot;);fbq(&quot;init&quot;,&quot;1864435530490581&quot;);fbq(&quot;track&quot;,&quot;PageView&quot;);
&lt;img height=&quot;1&quot; width=&quot;1&quot; style=&quot;display:none&quot; src=&quot;https://www.facebook.com/tr?id=1864435530490581&amp;amp;ev=PageView&amp;amp;noscript=1&quot;>
(function(){function b(){!1===c&amp;&amp;(c=!0,Munchkin.init(&quot;417-JXY-489&quot;))}var c=!1,a=document.createElement(&quot;script&quot;);a.type=&quot;text/javascript&quot;;a.async=!0;a.src=&quot;//munchkin.marketo.net/munchkin.js&quot;;a.onreadystatechange=function(){&quot;complete&quot;!=this.readyState&amp;&amp;&quot;loaded&quot;!=this.readyState||b()};a.onload=b;document.getElementsByTagName(&quot;head&quot;)[0].appendChild(a)})();
var domains_to_track=[&quot;blueshieldca.com&quot;],extDoc=&quot;.doc .docx .xls .xlsx .xlsm .ppt .pptx .exe .zip .pdf .js .txt .csv .dxf .dwgd .rfa .rvt .dwfx .mp4 .dwg .wmv .jpg .msi&quot;.split(&quot; &quot;),socSites=[&quot;facebook.com/blueshieldca&quot;,&quot;twitter.com/blueshieldca&quot;,&quot;linkedin.com/company/blue-shield-of-california&quot;,&quot;youtube.com/blueshieldca&quot;],mainDomain=document.location.hostname.match(/(([^.\/]+\.[^.\/]{2,3}\.[^.\/]{2})|(([^.\/]+\.)[^.\/]{2,4}))(\/.*)?$/)[1];mainDomain=mainDomain.toLowerCase();var arr=document.getElementsByTagName(&quot;a&quot;);
for(i=0;i&lt;arr.length;i++){var flag=0,flagExt=0,flagOut=0,tmp=arr[i].getAttribute(&quot;onmousedown&quot;),doname=&quot;&quot;,mailPattern=/[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,4}/,urlPattern=/(ftp|http|https):\/\/(\w+:{0,1}\w*@)?(\S+)(:[0-9]+)?(\/|\/([\w#!:.?+=&amp;%@!\-\/]))?/;if(mailPattern.test(arr[i].href)||urlPattern.test(arr[i].href)){try{doname=arr[i].hostname.match(/(([^.\/]+\.[^.\/]{2,3}\.[^.\/]{2})|(([^.\/]+\.)[^.\/]{2,4}))(\/.*)?$/)[1],doname=doname.toLowerCase()}catch(a){doname=arr[i].href,doname=doname.toLowerCase()}if(null!=
tmp&amp;&amp;(tmp=String(tmp),-1&lt;tmp.indexOf(&quot;dataLayer.push&quot;)))continue;if(doname==mainDomain||-1!=doname.indexOf(mainDomain))if(-1!=arr[i].href.toLowerCase().indexOf(&quot;mailto:&quot;)){var gaUri=arr[i].href.match(/[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,4}/);arr[i].setAttribute(&quot;onmousedown&quot;,(null!=tmp?tmp+&quot;; &quot;:&quot;&quot;)+&quot;dataLayer.push({'event': 'eventTracker', 'eventCat': 'Email Clicks', 'eventAct': 'Click', 'eventLbl': '&quot;+gaUri+&quot;', 'eventVal': 0, 'nonInteract': false});&quot;)}else{if(-1==arr[i].href.toLowerCase().indexOf(&quot;mailto:&quot;))for(var j=
0;j&lt;extDoc.length;j++){var arExt=arr[i].href.split(&quot;.&quot;),ext=arExt[arExt.length-1].split(/[#?&amp;?]/);if(&quot;.&quot;+ext[0].toLowerCase()==extDoc[j]){var intGaUri=arr[i].href.split(doname);gaUri=intGaUri[1].split(extDoc[j]);arr[i].setAttribute(&quot;onmousedown&quot;,(null!=tmp?tmp+&quot;; &quot;:&quot;&quot;)+&quot;dataLayer.push({'event': 'eventTracker', 'eventCat': 'Assets', 'eventAct': '&quot;+ext[0].toLowerCase()+&quot;', 'eventLbl': '&quot;+gaUri[0]+extDoc[j]+&quot;', 'eventVal': 0, 'nonInteract': false});&quot;);break}}}else if(doname!=mainDomain&amp;&amp;-1==doname.indexOf(mainDomain))for(var k=
0;k&lt;domains_to_track.length;k++)if(-1==doname.indexOf(domains_to_track[k])){if(flag++,flag==domains_to_track.length&amp;&amp;-1==arr[i].href.toLowerCase().indexOf(&quot;mailto:&quot;)){gaUri=arr[i].href.split(&quot;//&quot;);for(var socCount=0;socCount&lt;socSites.length;socCount++)if(-1!=arr[i].href.toLowerCase().indexOf(socSites[socCount].toLowerCase())){arr[i].setAttribute(&quot;onmousedown&quot;,(null!=tmp?tmp+&quot;; &quot;:&quot;&quot;)+&quot;dataLayer.push({'event': 'eventTracker', 'eventCat': 'Social Profiles', 'eventAct': '&quot;+socSites[socCount].split(&quot;.&quot;)[0]+
&quot; Profile', 'eventLbl': '&quot;+gaUri[1]+&quot;', 'eventVal': 0, 'nonInteract': false});&quot;);break}else-1==arr[i].href.toLowerCase().indexOf(socSites[socCount].toLowerCase())&amp;&amp;(flagOut++,flagOut==socSites.length&amp;&amp;arr[i].setAttribute(&quot;onmousedown&quot;,(null!=tmp?tmp+&quot;; &quot;:&quot;&quot;)+&quot;dataLayer.push({'event': 'eventTracker', 'eventCat': 'Outbound Links', 'eventAct': 'Click', 'eventLbl': '&quot;+gaUri[1]+&quot;', 'eventVal': 0, 'nonInteract': false});&quot;))}}else if(-1!=doname.indexOf(domains_to_track[k])&amp;&amp;-1==arr[i].href.toLowerCase().indexOf(&quot;mailto:&quot;))for(var l=
0;l&lt;extDoc.length;l++)if(arExt=arr[i].href.split(&quot;.&quot;),ext=arExt[arExt.length-1].split(/[#?&amp;?]/),&quot;.&quot;+ext[0].toLowerCase()==extDoc[l]){intGaUri=arr[i].href.split(doname);gaUri=intGaUri[1].split(extDoc[l]);arr[i].setAttribute(&quot;onmousedown&quot;,(null!=tmp?tmp+&quot;; &quot;:&quot;&quot;)+&quot;dataLayer.push({'event': 'eventTracker', 'eventCat': 'Assets', 'eventAct': '&quot;+ext[0].toLowerCase()+&quot;', 'eventLbl': '&quot;+gaUri[0]+extDoc[l]+&quot;', 'eventVal': 0, 'nonInteract': false});&quot;);break}else&quot;.&quot;+ext[0].toLowerCase()!=extDoc[l]&amp;&amp;flagExt++;
else-1!=doname.indexOf(domains_to_track[k])&amp;&amp;-1!=arr[i].href.toLowerCase().indexOf(&quot;mailto:&quot;)&amp;&amp;(gaUri=arr[i].href.match(/[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,4}/),arr[i].setAttribute(&quot;onmousedown&quot;,(null!=tmp?tmp+&quot;; &quot;:&quot;&quot;)+&quot;dataLayer.push({'event': 'eventTracker', 'eventCat': 'Email Clicks', 'eventAct': 'Click', 'eventLbl': '&quot;+gaUri+&quot;', 'eventVal': 0, 'nonInteract': false});&quot;))}};jQuery(document).on(&quot;click&quot;,'a[onclick*\x3d&quot;/bsca/bsc/mysite/employer/auth/planadmin/eEnroll&quot;]',function(){/dropmenu/.test(jQuery(this).parents(&quot;div&quot;).attr(&quot;class&quot;))?dataLayer.push({event:&quot;eventTracker&quot;,eventCat:&quot;Employer Navigation&quot;,eventAct:&quot;Plan Administration&quot;,eventLbl:&quot;Benefits Management&quot;}):dataLayer.push({event:&quot;eventTracker&quot;,eventCat:&quot;Employer Home&quot;,eventAct:&quot;Benefits Management Go Button&quot;,eventLbl:&quot;Benefits Management Go Button&quot;})});function removeURLParameter(a,e){var c=a.split(&quot;?&quot;);if(2&lt;=c.length){for(var f=encodeURIComponent(e)+&quot;\x3d&quot;,b=c[1].split(/[&amp;;]/g),d=b.length;0&lt;d--;)-1!==b[d].lastIndexOf(f,0)&amp;&amp;b.splice(d,1);a=c[0]+(0&lt;b.length?&quot;?&quot;+b.join(&quot;\x26&quot;):&quot;&quot;)}return a}
jQuery(&quot;a&quot;).each(function(){if(/blueshieldca|bscapply/.test(jQuery(this).attr(&quot;href&quot;))&amp;&amp;/utm_source/.test(jQuery(this).attr(&quot;href&quot;))){var a=removeURLParameter(jQuery(this).attr(&quot;href&quot;),&quot;utm_source&quot;);a=removeURLParameter(a,&quot;utm_medium&quot;);a=removeURLParameter(a,&quot;utm_campaign&quot;);jQuery(this).attr(&quot;href&quot;,a)}});jQuery(&quot;#logoutlink&quot;).on(&quot;mousedown&quot;,function(){null==OOo.readCookie(&quot;oo_entry&quot;)&amp;&amp;OOo.oo_onSingleClick(event,&quot;oo_click&quot;)});function delete_cookie1(a){document.cookie=a+&quot;\x3d; Path\x3d/; Domain\x3d.blueshieldca.com; Expires\x3dThu, 01 Jan 1970 00:00:01 GMT;&quot;}function delete_cookie2(a){document.cookie=a+&quot;\x3d; Path\x3d/; Domain\x3dwww.blueshieldca.com; Expires\x3dThu, 01 Jan 1970 00:00:01 GMT;&quot;}
void 0==google_tag_manager[&quot;GTM-TQRLHL&quot;].macro(4)?void 0!=google_tag_manager[&quot;GTM-TQRLHL&quot;].macro(5)&amp;&amp;(document.cookie=&quot;DynId\x3d&quot;+google_tag_manager[&quot;GTM-TQRLHL&quot;].macro(6)+&quot;; path\x3d/&quot;):void 0!=google_tag_manager[&quot;GTM-TQRLHL&quot;].macro(7)&amp;&amp;google_tag_manager[&quot;GTM-TQRLHL&quot;].macro(8)!=google_tag_manager[&quot;GTM-TQRLHL&quot;].macro(9)&amp;&amp;(delete_cookie1(&quot;DynId&quot;),delete_cookie2(&quot;DynId&quot;),document.cookie=&quot;DynId\x3d&quot;+google_tag_manager[&quot;GTM-TQRLHL&quot;].macro(10)+&quot;; path\x3d/&quot;);
window.dataLayer=window.dataLayer||[];function gtag(){dataLayer.push(arguments)}gtag(&quot;js&quot;,new Date);gtag(&quot;config&quot;,&quot;DC-1844680&quot;);
dataLayer.push({event:&quot;globalTagLoaded&quot;});gtag(&quot;event&quot;,&quot;conversion&quot;,{allow_custom_scripts:!0,send_to:&quot;DC-1844680/bsca2000/bscac0+standard&quot;});

&lt;img src=&quot;https://ad.doubleclick.net/ddm/activity/src=1844680;type=bsca2000;cat=bscac0;dc_lat=;dc_rdid=;tag_for_child_directed_treatment=;ord=1?&quot; width=&quot;1&quot; height=&quot;1&quot; alt=&quot;&quot;>
/html[1]</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html[1]</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>ref_element</name>
      <type>Main</type>
      <value>Object Repository/Page_Employer Registration/SubPage_RegStep2.1_ErrMsgsAfterStep2/iframe_Feedback_TB_iframeConte</value>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//html</value>
   </webElementXpaths>
</WebElementEntity>
