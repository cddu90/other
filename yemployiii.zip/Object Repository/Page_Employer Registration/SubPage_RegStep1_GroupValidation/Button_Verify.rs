<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>Button_Verify</name>
   <tag></tag>
   <elementGuidId>3c60a358-9e3e-43a9-8505-a420929f0a92</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//*[@id=&quot;verifybuttonId&quot;]</value>
      </entry>
      <entry>
         <key>BASIC</key>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>ref_element</name>
      <type>Main</type>
      <value>Object Repository/Page_Employer Registration/SubPage_RegStep1_GroupValidation/iframe_registration_verify_lightbox</value>
   </webElementProperties>
</WebElementEntity>
