<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>div_Thank you for your interes</name>
   <tag></tag>
   <elementGuidId>578d7b4b-ac31-4807-bc36-cb00c979fe6e</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//*[(contains(text(), '
				Thank you for your interest. Employer Connection is not available to
				your group at this time. If you have questions') or contains(., '
				Thank you for your interest. Employer Connection is not available to
				your group at this time. If you have questions')) and @ref_element = 'Object Repository/Page_Employer Registration/SubPage_RegStep1.1_ErrMsgsAfterGroupValidation/iframe_Feedback_TB_iframeConte']</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//form[@id='errorPageForm']/div</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>div</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>mainContent NormalTexts</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>contains</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
				Thank you for your interest. Employer Connection is not available to
				your group at this time. If you have questions</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;errorPageForm&quot;)/div[@class=&quot;mainContent NormalTexts&quot;]</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>ref_element</name>
      <type>Main</type>
      <value>Object Repository/Page_Employer Registration/SubPage_RegStep1.1_ErrMsgsAfterGroupValidation/iframe_Feedback_TB_iframeConte</value>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//form[@id='errorPageForm']/div</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)=concat('id(', '&quot;', 'errorPageForm', '&quot;', ')/div[@class=', '&quot;', 'mainContent NormalTexts', '&quot;', ']')])[1]/preceding::div[3]</value>
   </webElementXpaths>
</WebElementEntity>
