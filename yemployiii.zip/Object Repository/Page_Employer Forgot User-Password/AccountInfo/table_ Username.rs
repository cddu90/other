<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>table_ Username</name>
   <tag></tag>
   <elementGuidId>9115e139-26fc-433f-aef0-ce718d892efb</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//form[@id='authAccountInfo']/div/table[2]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>table</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>width</name>
      <type>Main</type>
      <value>600</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>border</name>
      <type>Main</type>
      <value>0</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>cellspacing</name>
      <type>Main</type>
      <value>5</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>cellpadding</name>
      <type>Main</type>
      <value>0</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
                                                
                                                    
                                                        * Username:
                                                        
                                                    
                                                    
                                                        * Password:
                                                        
                                                    
                                                    
                                                        * Confirm Password:
                                                        
                                                    
                                                    
                                                        * Security Question 1:
                                                        
                                                            What is your pet's name?In what city were you at the turn of the millennium?What is the name of your first employer?What elementary school did you go to?What is the street number of the house you grew up in?                                                                                                                        
                                                        
                                                                                                       
                                                    
                                                        * Security Answer 1:
                                                        
                                                    
                                                    
                                                        * Security Question 2:
                                                        
                                                            What was your high school mascot?What is the middle name of your youngest sibling?What is your favorite movie?In what city was your father born?In what city was your mother born?What was the manufacturer or model of the first vehicle you drove?                                                            
                                                        
                                                                                                       
                                                    
                                                        *Security Answer 2:
                                                        
                                                    
                                                
                                            </value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;authAccountInfo&quot;)/div[1]/table[2]</value>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <value>//form[@id='authAccountInfo']/div/table[2]</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='* Phone:'])[1]/following::table[1]</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <value>//table[2]</value>
   </webElementXpaths>
</WebElementEntity>
