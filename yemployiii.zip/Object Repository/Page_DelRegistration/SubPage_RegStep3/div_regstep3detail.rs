<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>div_regstep3detail</name>
   <tag></tag>
   <elementGuidId>3ef00517-982d-4446-9200-b4360714bfa6</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='divRegStepThree']</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>div</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>mainContent</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>id</name>
      <type>Main</type>
      <value>divRegStepThree</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
									
										
									
									
										
											 Please confirm that following information you provided is correct.
												 Return to the previous page to make any changes. Click &quot;Finish&quot; to complete registration. 
											
										
									
									Account information
									
									
									
										First Name
										:
									
									
									 hellotest
									
									
									
										Last Name
										:
									
									
									 tesjgjgjg
									
									
									
										Phone
										:
									
									
									
									
									 (786)868-7868
									
									
									
									
										Email
										:
									
									
									

									 utyuu@test.com
									
									
									
										Email Format
										:
									
									

									 
										HTML


									
									
										Alerts
										:
									
									
									
										 
										 Yes
										
									
									
									

									
										Log in Information
									


									
									
										Username
										:
									
									
									 autohr_test01
									

									
									
										Password:
									
									
									 ******
									

									
									
										Security Question 1
										:
									
									
									 What is your pet's name?
									

									
									
										Security Answer 1
										:
									
									
									 A
									

									
									
										Security Question 2
										:
									
									
									 What is the middle name of your youngest sibling?
									

									
									
										Security Answer 2
										:
									
									
									 A
									
									
										
									

									
										
											
										
										
											
										
									
								</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;divRegStepThree&quot;)</value>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:attributes</name>
      <type>Main</type>
      <value>//div[@id='divRegStepThree']</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='mainHome']/div/div/div/div/div</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Register: Step 3 of 3'])[1]/following::div[6]</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[3]/div/div/div/div/div</value>
   </webElementXpaths>
</WebElementEntity>
