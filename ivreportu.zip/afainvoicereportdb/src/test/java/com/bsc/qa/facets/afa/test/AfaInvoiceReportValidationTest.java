package com.bsc.qa.facets.afa.test;

import java.util.HashMap;
import java.util.Hashtable;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import org.assertj.core.api.SoftAssertions;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.IHookCallBack;
import org.testng.IHookable;
import org.testng.ITestResult;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.bsc.qa.facets.afa.dao.DatabaseUtil;
import com.bsc.qa.facets.afa.excel_reader.AfaInvoiceReportReader;
import com.bsc.qa.facets.afa.pojo.ClaimsActivitySummary;
import com.bsc.qa.facets.afa.pojo.FrontPage;
import com.bsc.qa.facets.afa.pojo.MemberDetails;
import com.bsc.qa.facets.afa.pojo.PlanDetails;
import com.bsc.qa.facets.afa.pojo.ShieldSaving;
import com.bsc.qa.framework.base.BaseTest;
import com.relevantcodes.extentreports.LogStatus;

/**
 * 
 * @author Suchith Kumar(skumar33)
 */
public class AfaInvoiceReportValidationTest extends BaseTest implements IHookable {

	private Logger logger1 = LoggerFactory.getLogger(AfaInvoiceReportValidationTest.class);

	/**
	 * Tidal job creates a report in an excel sheet. The test method converts
	 * that to a map and uses it as a 'actual'. Expected is from the DB.
	 * 
	 * @param invoiceNo
	 *            Invoice number as string
	 * @param frontPageExcelTable
	 *            Map of data from the frontPageExcel worksheet
	 * @param frontPageDBTable
	 *            Map of data from the DB
	 */
	@Test(dataProvider = "provideFrontPageData",enabled=true)
	public void testFrontPageData(String invoiceNo,
			Hashtable<String, FrontPage> frontPageExcelTable,
			Hashtable<String, FrontPage> frontPageDBTable) {
		//Custom override needed to get pin point information of the validating invoice data
		reportInit("testFrontPage", " invoice:"+invoiceNo);
		logger.log(LogStatus.INFO, "Testing front page data for invoice no:"+invoiceNo);
		softAssertions
				.assertThat(frontPageExcelTable.get(invoiceNo).getGroupName())
				.as("GroupName || Expected( DB Value ) ==> "
						+ frontPageDBTable.get(invoiceNo).getGroupName()
						+ " ||  Actual( Report Value ) ==> "
						+ frontPageExcelTable.get(invoiceNo).getGroupName())
				.isEqualTo(frontPageDBTable.get(invoiceNo).getGroupName());

		softAssertions
				.assertThat(
						frontPageExcelTable.get(invoiceNo).getGroupAddress())
				.as("GroupAddress || Expected( DB Value ) ==> "
						+ frontPageDBTable.get(invoiceNo).getGroupAddress()
						+ " ||  Actual( Report Value ) ==> "
						+ frontPageExcelTable.get(invoiceNo).getGroupAddress())
				.isEqualToIgnoringWhitespace(frontPageDBTable.get(invoiceNo).getGroupAddress());

		softAssertions
				.assertThat(frontPageExcelTable.get(invoiceNo).getAttention())
				.as("Attention || Expected( DB Value ) ==> "
						+ frontPageDBTable.get(invoiceNo).getAttention()
						+ " ||  Actual( Report Value ) ==> "
						+ frontPageExcelTable.get(invoiceNo).getAttention())
				.isEqualTo(frontPageDBTable.get(invoiceNo).getAttention());

		softAssertions
				.assertThat(
						frontPageExcelTable.get(invoiceNo).getGroupBillingId())
				.as("GroupBillingId || Expected( DB Value ) ==> "
						+ frontPageDBTable.get(invoiceNo).getGroupBillingId()
						+ " ||  Actual( Report Value ) ==> "
						+ frontPageExcelTable.get(invoiceNo)
								.getGroupBillingId())
				.isEqualTo(frontPageDBTable.get(invoiceNo).getGroupBillingId());

		softAssertions
				.assertThat(
						frontPageExcelTable.get(invoiceNo).getFundingPeriod())
				.as("FundingPeriod || Expected( DB Value ) ==> "
						+ frontPageDBTable.get(invoiceNo).getFundingPeriod()
						+ " ||  Actual( Report Value ) ==> "
						+ frontPageExcelTable.get(invoiceNo).getFundingPeriod())
				.isEqualTo(frontPageDBTable.get(invoiceNo).getFundingPeriod());

		softAssertions
				.assertThat(frontPageExcelTable.get(invoiceNo).getBillDueDate())
				.as("BillDueDate || Expected( DB Value ) ==> "
						+ frontPageDBTable.get(invoiceNo).getBillDueDate()
						+ " ||  Actual( Report Value ) ==> "
						+ frontPageExcelTable.get(invoiceNo).getBillDueDate())
				.isEqualTo(frontPageDBTable.get(invoiceNo).getBillDueDate());

		softAssertions
				.assertThat(frontPageExcelTable.get(invoiceNo).getInvoiceNo())
				.as("InvoiceNo || Expected( DB Value ) ==> "
						+ frontPageDBTable.get(invoiceNo).getInvoiceNo()
						+ " ||  Actual( Report Value ) ==> "
						+ frontPageExcelTable.get(invoiceNo).getInvoiceNo())
				.isEqualTo(frontPageDBTable.get(invoiceNo).getInvoiceNo());

		softAssertions
				.assertThat(frontPageExcelTable.get(invoiceNo).getInvoiceDate())
				.as("InvoiceDate || Expected( DB Value ) ==> "
						+ frontPageDBTable.get(invoiceNo).getInvoiceDate()
						+ " ||  Actual( Report Value ) ==> "
						+ frontPageExcelTable.get(invoiceNo).getInvoiceDate())
				.isEqualTo(frontPageDBTable.get(invoiceNo).getInvoiceDate());

		softAssertions
				.assertThat(
						frontPageExcelTable.get(invoiceNo)
								.getCurrentPeriodClaims())
				.as("CurrentPeriodClaims || Expected( DB Value ) ==> "
						+ frontPageDBTable.get(invoiceNo)
								.getCurrentPeriodClaims()
						+ " ||  Actual( Report Value ) ==> "
						+ frontPageExcelTable.get(invoiceNo)
								.getCurrentPeriodClaims())
				.isEqualTo(
						frontPageDBTable.get(invoiceNo)
								.getCurrentPeriodClaims());

		softAssertions
				.assertThat(
						frontPageExcelTable.get(invoiceNo).getBalanceForward())
				.as("BalanceForward || Expected( DB Value ) ==> "
						+ frontPageDBTable.get(invoiceNo).getBalanceForward()
						+ " ||  Actual( Report Value ) ==> "
						+ frontPageExcelTable.get(invoiceNo)
								.getBalanceForward())
				.isEqualTo(frontPageDBTable.get(invoiceNo).getBalanceForward());

		softAssertions
				.assertThat(
						frontPageExcelTable.get(invoiceNo)
								.getTotalDueForClaimsReimbursement())
				.as("ClaimsReimbursement || Expected( DB Value ) ==> "
						+ frontPageDBTable.get(invoiceNo)
								.getTotalDueForClaimsReimbursement()
						+ " ||  Actual( Report Value ) ==> "
						+ frontPageExcelTable.get(invoiceNo)
								.getTotalDueForClaimsReimbursement())
				.isEqualTo(
						frontPageDBTable.get(invoiceNo)
								.getTotalDueForClaimsReimbursement());

		softAssertions
				.assertThat(
						frontPageExcelTable.get(invoiceNo)
								.getBscAccountantName())
				.as("BscAccountantName || Expected( DB Value ) ==> "
						+ frontPageDBTable.get(invoiceNo)
								.getBscAccountantName()
						+ " ||  Actual( Report Value ) ==> "
						+ frontPageExcelTable.get(invoiceNo)
								.getBscAccountantName())
				.isEqualTo(
						frontPageDBTable.get(invoiceNo).getBscAccountantName());

		softAssertions
				.assertThat(frontPageExcelTable.get(invoiceNo).getPhone())
				.as("Phone || Expected( DB Value ) ==> "
						+ frontPageDBTable.get(invoiceNo).getPhone()
						+ " ||  Actual( Report Value ) ==> "
						+ frontPageExcelTable.get(invoiceNo).getPhone())
				.isEqualTo(frontPageDBTable.get(invoiceNo).getPhone());

		softAssertions
				.assertThat(frontPageExcelTable.get(invoiceNo).getFax())
				.as("Fax || Expected( DB Value ) ==> "
						+ frontPageDBTable.get(invoiceNo).getFax()
						+ " ||  Actual( Report Value ) ==> "
						+ frontPageExcelTable.get(invoiceNo).getFax())
				.isEqualTo(frontPageDBTable.get(invoiceNo).getFax());

		softAssertions
				.assertThat(frontPageExcelTable.get(invoiceNo).getEmail())
				.as("Email || Expected( DB Value ) ==> "
						+ frontPageDBTable.get(invoiceNo).getEmail()
						+ " ||  Actual( Report Value ) ==> "
						+ frontPageExcelTable.get(invoiceNo).getEmail())
				.isEqualTo(frontPageDBTable.get(invoiceNo).getEmail());

	}

	/**
	 * Tidal job creates a report in an excel sheet. The test method converts
	 * that to a map and uses it as a 'actual'. Expceted is from the DB.
	 * 
	 * @param invoiceNo
	 *            Invoice number as string
	 * @param claimsActivitySummaryExcelTable
	 *            Map of data from the ClaimsActivitySummaryExcel worksheet
	 * @param claimsActivitySummaryDBTable
	 *            Map of data from the DB
	 */
	@Test(dataProvider = "provideClaimsActivitySummaryData",enabled=true)
	public void testClaimsActivitySummaryData(
		String invoiceNo,
		Hashtable<String, List<ClaimsActivitySummary>> claimsActivitySummaryExcelTable,
		Hashtable<String, List<ClaimsActivitySummary>> claimsActivitySummaryDBTable,
		HashMap<String, List<ClaimsActivitySummary>> claimsActivitySummaryExcelMap,
		HashMap<String, List<ClaimsActivitySummary>> claimsActivitySummaryDBMap) {
		List<ClaimsActivitySummary> claimsActivitySummaryExcelList = claimsActivitySummaryExcelMap
				.get(invoiceNo);
		List<ClaimsActivitySummary> claimsActivitySummaryDBList = claimsActivitySummaryDBMap
				.get(invoiceNo);
		//Custom override needed to get pin point information of the validating invoice data
		reportInit("testClaimsActivitySummary", " invoice:"+invoiceNo);
		logger.log(LogStatus.INFO, "Testing claims activity summary page data for invoice no:"+invoiceNo);
		for (ClaimsActivitySummary excelClaim : claimsActivitySummaryExcelList) {
			for (int i = 0; i < claimsActivitySummaryDBList.size(); i++) {
				ClaimsActivitySummary dbClaim = claimsActivitySummaryDBList.get(i);
				if (excelClaim.getBillingCategory().equalsIgnoreCase(dbClaim.getBillingCategory())) {
					
					logger.log(LogStatus.INFO, "Validating Billing Category : "+ dbClaim.getBillingCategory());
					softAssertions.assertThat(dbClaim.getClaimPaymentPeriod())
					.as("claimPaymentPeriod  for Invoice NO:" + invoiceNo + " Billing category:"	+ dbClaim.getBillingCategory()+" || Expected( Report Value) ==> " + excelClaim.getClaimPaymentPeriod()
							   + " ||  Actual( DB Value ) ==> " + dbClaim.getClaimPaymentPeriod())
							.isEqualTo(excelClaim.getClaimPaymentPeriod());
					
					softAssertions.assertThat(dbClaim.getInvoiceDate())
					.as("invoiceDate for Invoice NO:" + invoiceNo + " Billing category:"	+ dbClaim.getBillingCategory()+"  || Expected( Report Value) ==> " + excelClaim.getInvoiceDate()
							   + " ||  Actual( DB Value ) ==> " + dbClaim.getInvoiceDate())
							.isEqualTo(excelClaim.getInvoiceDate());
				
					softAssertions.assertThat(dbClaim.getGroupName())
					.as("groupName for Invoice NO:" + invoiceNo + " Billing category:"	+ dbClaim.getBillingCategory()+"  || Expected( Report Value) ==> " + excelClaim.getGroupName()
							   + " ||  Actual( DB Value ) ==> " + dbClaim.getGroupName())
							.isEqualTo(excelClaim.getGroupName());
					
					softAssertions.assertThat(dbClaim.getGroupBillingId())
					.as("groupBillingId for Invoice NO:" + invoiceNo + " Billing category:"	+ dbClaim.getBillingCategory()+"  || Expected( Report Value) ==> " + excelClaim.getGroupBillingId()
							   + " ||  Actual( DB Value ) ==> " + dbClaim.getGroupBillingId())
							.isEqualTo(excelClaim.getGroupBillingId());
					
					softAssertions.assertThat(dbClaim.getClaimsCycle())
					.as("claimsCycle for Invoice NO:" + invoiceNo + " Billing category:"	+ dbClaim.getBillingCategory()+"  || Expected( Report Value) ==> " + excelClaim.getClaimsCycle()
							   + " ||  Actual( DB Value ) ==> " + dbClaim.getClaimsCycle())
							.isEqualTo(excelClaim.getClaimsCycle());
					
					softAssertions.assertThat(excelClaim.getBillDueDate())
					.as("billDueDate for Invoice NO:" + invoiceNo + " Billing category:"	+ excelClaim.getBillingCategory()+"  || Expected( Report Value) ==> " + excelClaim.getBillDueDate()
							   + " ||  Actual( DB Value ) ==> " + excelClaim.getBillDueDate())
							.contains(dbClaim.getBillDueDate());
					
					softAssertions.assertThat(dbClaim.getInvoiceNo())
					.as("invoiceNo for Invoice NO:" + invoiceNo + " Billing category:"	+ dbClaim.getBillingCategory()+"  || Expected( Report Value) ==> " + excelClaim.getInvoiceNo()
							   + " ||  Actual( DB Value ) ==> " + dbClaim.getInvoiceNo())
							.isEqualTo(excelClaim.getInvoiceNo());
					
					softAssertions.assertThat(dbClaim.getBillingCategory())
					.as("billingCategory for Invoice NO:" + invoiceNo + " Billing category:"	+ dbClaim.getBillingCategory()+"  || Expected( Report Value) ==> " + excelClaim.getBillingCategory()
							   + " ||  Actual( DB Value ) ==> " + dbClaim.getBillingCategory())
							.isEqualTo(excelClaim.getBillingCategory());
					
					softAssertions.assertThat(dbClaim.getMedical())
					.as("medical for Invoice NO:" + invoiceNo + " Billing category:"	+ dbClaim.getBillingCategory()+"  || Expected( Report Value) ==> " + excelClaim.getMedical()
							   + " ||  Actual( DB Value ) ==> " + dbClaim.getMedical())
							.isEqualTo(excelClaim.getMedical());
					
					softAssertions.assertThat(dbClaim.getCostContainment())
					.as("costContainment for Invoice NO:" + invoiceNo + " Billing category:"	+ dbClaim.getBillingCategory()+"  || Expected( Report Value) ==> " + excelClaim.getCostContainment()
							   + " ||  Actual( DB Value ) ==> " + dbClaim.getCostContainment())
							.isEqualTo(excelClaim.getCostContainment());
					
					softAssertions.assertThat(dbClaim.getInterest())
					.as("interest for Invoice NO:" + invoiceNo + " Billing category:"	+ dbClaim.getBillingCategory()+"  || Expected( Report Value) ==> " + excelClaim.getInterest()
							   + " ||  Actual( DB Value ) ==> " + dbClaim.getInterest())
							.isEqualTo(excelClaim.getInterest());
					
					softAssertions.assertThat(dbClaim.getDental())
					.as("dental for Invoice NO:" + invoiceNo + " Billing category:"	+ dbClaim.getBillingCategory()+"  || Expected( Report Value) ==> " + excelClaim.getDental()
							   + " ||  Actual( DB Value ) ==> " + dbClaim.getDental())
							.isEqualTo(excelClaim.getDental());
					
					softAssertions.assertThat(dbClaim.getPharmacy())
					.as("pharmacy for Invoice NO:" + invoiceNo + " Billing category:"	+ dbClaim.getBillingCategory()+"  || Expected( Report Value) ==> " + excelClaim.getPharmacy()
							   + " ||  Actual( DB Value ) ==> " + dbClaim.getPharmacy())
							.isEqualTo(excelClaim.getPharmacy());
					
					softAssertions.assertThat(dbClaim.getBlueCardAccessFees())
					.as("blueCardAccessFees for Invoice NO:" + invoiceNo + " Billing category:"	+ dbClaim.getBillingCategory()+"  || Expected( Report Value) ==> " + excelClaim.getBlueCardAccessFees()
							   + " ||  Actual( DB Value ) ==> " + dbClaim.getBlueCardAccessFees())
							.isEqualTo(excelClaim.getBlueCardAccessFees());
					
					softAssertions.assertThat(dbClaim.getStopLossAdvancedFunding())
					.as("stopLossAdvancedFunding for Invoice NO:" + invoiceNo + " Billing category:"	+ dbClaim.getBillingCategory()+"  || Expected( Report Value) ==> " + excelClaim.getStopLossAdvancedFunding()
							   + " ||  Actual( DB Value ) ==> " + dbClaim.getStopLossAdvancedFunding())
							.isEqualTo(excelClaim.getStopLossAdvancedFunding());
					
					softAssertions.assertThat(dbClaim.getHealthReimbursementAccount())
					.as("healthReimbursementAccount || Expected( Report Value) ==> " + excelClaim.getHealthReimbursementAccount()
							   + " ||  Actual( DB Value ) ==> " + dbClaim.getHealthReimbursementAccount())
							.isEqualTo(excelClaim.getHealthReimbursementAccount());
					
					softAssertions.assertThat(dbClaim.getSubTotalClaimsActivity())
					.as("SubTotalClaimsActivity || Expected( Report Value) ==> " + excelClaim.getSubTotalClaimsActivity()
							   + " ||  Actual( DB Value ) ==> " + dbClaim.getSubTotalClaimsActivity())
							.isEqualTo(excelClaim.getSubTotalClaimsActivity());
					
					softAssertions.assertThat(dbClaim.getTotal())
					.as("total for Invoice NO:" + invoiceNo + " Billing category:"	+ dbClaim.getBillingCategory()+"  || Expected( Report Value) ==> " + excelClaim.getTotal()
							   + " ||  Actual( DB Value ) ==> " + dbClaim.getTotal())
							.isEqualTo(excelClaim.getTotal());
					

				}
			}

		}
	}

	/**
	 * Tidal job creates a report in an excel sheet. The test method converts
	 * that to a map and uses it as a 'actual'. Expected is from the DB.
	 * 
	 * @param invoiceNo
	 *            Invoice number as string
	 * @param shieldSavingExcelTable
	 *            Map of data from the shieldSavingExcel worksheet
	 * @param shieldSavingDBTable
	 *            Map of data from the DB
	 */
	@Test(dataProvider = "provideShieldSavingData",enabled=true)
	public void testShieldSavingData(String invoiceNo,
			Hashtable<String, List<ShieldSaving>> shieldSavingExcelTable,
			Hashtable<String, List<ShieldSaving>> shieldSavingDBTable,
			HashMap<String, List<ShieldSaving>> shieldSavingExcelMap,
			HashMap<String, List<ShieldSaving>> shieldSavingDBMap) {
		List<ShieldSaving> shieldSavingExcelList = shieldSavingExcelMap
				.get(invoiceNo);
		List<ShieldSaving> shieldSavingDBList = shieldSavingDBMap
				.get(invoiceNo);
		//Custom override needed to get pin point information of the validating invoice data
		reportInit("testShieldSavings", " invoice:"+invoiceNo);
		logger.log(LogStatus.INFO, "Testing shield savings page data for invoice no:"+invoiceNo);
		for (ShieldSaving excelShieldSaving : shieldSavingExcelList) {
			for (int i = 0; i < shieldSavingDBList.size(); i++) {
				ShieldSaving dbShieldSaving = shieldSavingDBList.get(i);
				logger1.info("Excel Billing cat'"+excelShieldSaving.getBillingCategory()+"' DB Billing cat'"+dbShieldSaving.getBillingCategory());
				if (excelShieldSaving.getBillingCategory().equalsIgnoreCase(
						dbShieldSaving.getBillingCategory()) | excelShieldSaving.getBillingCategory().equalsIgnoreCase("Billing Category")) {
					logger.log(
							LogStatus.INFO,
							"Testing for Billing Category - "
									+ dbShieldSaving.getBillingCategory());
					
					
					softAssertions.assertThat(dbShieldSaving.getClaimPaymentPeriod())
					.as("ClaimPaymentPeriod  for Invoice NO:" + invoiceNo + " Billing category:"	+ dbShieldSaving.getBillingCategory()+" || Expected( Report Value ) ==> " + excelShieldSaving.getClaimPaymentPeriod()
							   + " ||  Actual( DB Value ) ==> " + dbShieldSaving.getClaimPaymentPeriod())
							.isEqualTo(excelShieldSaving.getClaimPaymentPeriod());

					softAssertions.assertThat(dbShieldSaving.getGroupName())
					.as("GroupName  for Invoice NO:" + invoiceNo + " Billing category:"	+ dbShieldSaving.getBillingCategory()+" || Expected( Report Value ) ==> " + excelShieldSaving.getGroupName()
							   + " ||  Actual( DB Value ) ==> " + dbShieldSaving.getGroupName())
							.isEqualTo(excelShieldSaving.getGroupName());
					
					softAssertions.assertThat(dbShieldSaving.getGroupBillingId())
					.as("GroupBillingId  for Invoice NO:" + invoiceNo + " Billing category:"	+ dbShieldSaving.getBillingCategory()+" || Expected( Report Value ) ==> " + excelShieldSaving.getGroupBillingId()
							   + " ||  Actual( DB Value ) ==> " + dbShieldSaving.getGroupBillingId())
							.isEqualTo(excelShieldSaving.getGroupBillingId());

					softAssertions.assertThat(dbShieldSaving.getClaimsCycle())
					.as("ClaimsCycle  for Invoice NO:" + invoiceNo + " Billing category:"	+ dbShieldSaving.getBillingCategory()+" || Expected( Report Value ) ==> " + excelShieldSaving.getClaimsCycle()
							   + " ||  Actual( DB Value ) ==> " + dbShieldSaving.getClaimsCycle())
							.isEqualTo(excelShieldSaving.getClaimsCycle());

					softAssertions.assertThat(dbShieldSaving.getBillDueDate())
					.as("BillDueDate  for Invoice NO:" + invoiceNo + " Billing category:"	+ dbShieldSaving.getBillingCategory()+" || Expected( Report Value ) ==> " + excelShieldSaving.getBillDueDate()
							   + " ||  Actual( DB Value ) ==> " + dbShieldSaving.getBillDueDate())
							.isEqualTo(excelShieldSaving.getBillDueDate());

					softAssertions.assertThat(dbShieldSaving.getInvoiceNo())
					.as("InvoiceNo  for Invoice NO:" + invoiceNo + " Billing category:"	+ dbShieldSaving.getBillingCategory()+" || Expected( Report Value ) ==> " + excelShieldSaving.getInvoiceNo()
							   + " ||  Actual( DB Value ) ==> " + dbShieldSaving.getInvoiceNo())
							.isEqualTo(excelShieldSaving.getInvoiceNo());

					softAssertions.assertThat(dbShieldSaving.getProviderChargedAmount())
					.as("ProviderChargedAmount  for Invoice NO:" + invoiceNo + " Billing category:"	+ dbShieldSaving.getBillingCategory()+" || Expected( Report Value ) ==> " + excelShieldSaving.getProviderChargedAmount()
							   + " ||  Actual( DB Value ) ==> " + dbShieldSaving.getProviderChargedAmount())
							.isEqualTo(excelShieldSaving.getProviderChargedAmount());

					softAssertions.assertThat(dbShieldSaving.getSavings())
					.as("Savings  for Invoice NO:" + invoiceNo + " Billing category:"	+ dbShieldSaving.getBillingCategory()+" || Expected( Report Value ) ==> " + excelShieldSaving.getSavings()
							   + " ||  Actual( DB Value ) ==> " + dbShieldSaving.getSavings())
							.isEqualTo(excelShieldSaving.getSavings());

					softAssertions.assertThat(dbShieldSaving.getDisallowed())
					.as("Disallowed  for Invoice NO:" + invoiceNo + " Billing category:"	+ dbShieldSaving.getBillingCategory()+" || Expected( Report Value ) ==> " + excelShieldSaving.getDisallowed()
							   + " ||  Actual( DB Value ) ==> " + dbShieldSaving.getDisallowed())
							.isEqualTo(excelShieldSaving.getDisallowed());

					softAssertions.assertThat(dbShieldSaving.getAllowedAmount())
					.as("AllowedAmount  for Invoice NO:" + invoiceNo + " Billing category:"	+ dbShieldSaving.getBillingCategory()+" || Expected( Report Value ) ==> " + excelShieldSaving.getAllowedAmount()
							   + " ||  Actual( DB Value ) ==> " + dbShieldSaving.getAllowedAmount())
							.isEqualTo(excelShieldSaving.getAllowedAmount());

					softAssertions.assertThat(dbShieldSaving.getCostContainment())
					.as("CostContainment  for Invoice NO:" + invoiceNo + " Billing category:"	+ dbShieldSaving.getBillingCategory()+" || Expected( Report Value ) ==> " + excelShieldSaving.getCostContainment()
							   + " ||  Actual( DB Value ) ==> " + dbShieldSaving.getCostContainment())
							.isEqualTo(excelShieldSaving.getCostContainment());

					softAssertions.assertThat(dbShieldSaving.getTotal())
					.as("Total for Invoice NO:" + invoiceNo + " Billing category:"	+ dbShieldSaving.getBillingCategory()+" || Expected( Report Value ) ==> " + excelShieldSaving.getClaimPaymentPeriod()
							   + " ||  Actual( DB Value ) ==> " + dbShieldSaving.getClaimPaymentPeriod())
							.isEqualTo(excelShieldSaving.getTotal());
				
				}
			}
		}
		
	}

	/**
	 * Tidal job creates a report in an excel sheet. The test method converts
	 * that to a map and uses it as a 'actual'. Expected is from the DB.
	 * 
	 * @param invoiceNo
	 *            Invoice number as string
	 * @param memberDetailsExcelTable
	 *            Map of data from the memberDetailsExcel worksheet
	 * @param memberDetailsDBTable
	 *            Map of data from the DB
	 */
	@Test(dataProvider = "provideMemberDetailsData",enabled=true)
	public void testMemberDetailsData(String invoiceNo,
			Hashtable<String, List<MemberDetails>> memberDetailsExcelTable,
			Hashtable<String, List<MemberDetails>> memberDetailsDBTable,
			HashMap<String, List<MemberDetails>> memberDetailsExcelMap,
			HashMap<String, List<MemberDetails>> memberDetailsDBMap) {
		List<MemberDetails> memberDetailsExcelList = memberDetailsExcelMap
				.get(invoiceNo);
		List<MemberDetails> memberDetailsDBList = memberDetailsDBMap
				.get(invoiceNo);
		//Custom override needed to get pin point information of the validating invoice data
		reportInit("testMemberDetails", " invoice:"+invoiceNo);
		logger.log(LogStatus.INFO, "Testing member details page data for invoice no:"+invoiceNo);
		for (MemberDetails excelMemberDetails : memberDetailsExcelList) {
			for (int i = 0; i < memberDetailsDBList.size(); i++) {
				MemberDetails dbMemberDetails = memberDetailsDBList.get(i);
				if (excelMemberDetails.getClaimId().equalsIgnoreCase(
						dbMemberDetails.getClaimId())) {
					logger.log(
							LogStatus.INFO,
							"Testing for claim id - "
									+ dbMemberDetails.getClaimId());
					
					softAssertions.assertThat(dbMemberDetails.getGroupName())
					.as("GroupName for claim ID:" + dbMemberDetails.getClaimId()	+ 
						  " || Expected( Report Value) ==> " + excelMemberDetails.getGroupName()
						  + " ||  Actual( DB Value ) ==> " + dbMemberDetails.getGroupName())
					.isEqualTo(excelMemberDetails.getGroupName());
					
					softAssertions.assertThat(dbMemberDetails.getGroupBillingId())
					.as("GroupBillingId for claim ID:" + dbMemberDetails.getClaimId()	+ 
						  " || Expected( Report Value) ==> " + excelMemberDetails.getGroupBillingId()
						  + " ||  Actual( DB Value ) ==> " + dbMemberDetails.getGroupBillingId())
					.isEqualTo(excelMemberDetails.getGroupBillingId());

					softAssertions.assertThat(dbMemberDetails.getGroupName())
					.as("GroupName for claim ID:" + dbMemberDetails.getClaimId()	+ 
						  " || Expected( Report Value) ==> " + excelMemberDetails.getGroupName()
						  + " ||  Actual( DB Value ) ==> " + dbMemberDetails.getGroupName())
					.isEqualTo(excelMemberDetails.getGroupName());

					softAssertions.assertThat(dbMemberDetails.getBillDueDate())
					.as("BillDueDate for claim ID:" + dbMemberDetails.getClaimId()	+ 
						  " || Expected( Report Value) ==> " + excelMemberDetails.getBillDueDate()
						  + " ||  Actual( DB Value ) ==> " + dbMemberDetails.getBillDueDate())
					.isEqualTo(excelMemberDetails.getBillDueDate());

					softAssertions.assertThat(dbMemberDetails.getInvoiceNo())
					.as("InvoiceNo for claim ID:" + dbMemberDetails.getClaimId()	+ 
						  " || Expected( Report Value) ==> " + excelMemberDetails.getInvoiceNo()
						  + " ||  Actual( DB Value ) ==> " + dbMemberDetails.getInvoiceNo())
					.isEqualTo(excelMemberDetails.getInvoiceNo());

					softAssertions.assertThat(dbMemberDetails.getGroupIdName())
					.as("GroupIdName for claim ID:" + dbMemberDetails.getClaimId()	+ 
						  " || Expected( Report Value) ==> " + excelMemberDetails.getGroupIdName()
						  + " ||  Actual( DB Value ) ==> " + dbMemberDetails.getGroupIdName())
					.isEqualTo(excelMemberDetails.getGroupIdName());
					
					softAssertions.assertThat(dbMemberDetails.getBillingCategory())
					.as("BillingCategory for claim ID:" + dbMemberDetails.getClaimId()	+ 
						  " || Expected( Report Value) ==> " + excelMemberDetails.getBillingCategory()
						  + " ||  Actual( DB Value ) ==> " + dbMemberDetails.getBillingCategory())
					.isEqualTo(excelMemberDetails.getBillingCategory());

					softAssertions.assertThat(dbMemberDetails.getPlanId())
					.as("PlanId for claim ID:" + dbMemberDetails.getClaimId()	+ 
						  " || Expected( Report Value) ==> " + excelMemberDetails.getPlanId()
						  + " ||  Actual( DB Value ) ==> " + dbMemberDetails.getPlanId())
					.isEqualTo(excelMemberDetails.getPlanId());

					softAssertions.assertThat(dbMemberDetails.getClassId())
					.as("ClassId for claim ID:" + dbMemberDetails.getClaimId()	+ 
						  " || Expected( Report Value) ==> " + excelMemberDetails.getClassId()
						  + " ||  Actual( DB Value ) ==> " + dbMemberDetails.getClassId())
					.isEqualTo(excelMemberDetails.getClassId());

					softAssertions.assertThat(dbMemberDetails.getSubscriberId())
					.as("SubscriberId for claim ID:" + dbMemberDetails.getClaimId()	+ 
						  " || Expected( Report Value) ==> " + excelMemberDetails.getSubscriberId()
						  + " ||  Actual( DB Value ) ==> " + dbMemberDetails.getSubscriberId())
					.isEqualTo(excelMemberDetails.getSubscriberId());
					
					softAssertions.assertThat(dbMemberDetails.getSsn())
					.as("Ssn for claim ID:" + dbMemberDetails.getClaimId()	+ 
						  " || Expected( Report Value) ==> " + excelMemberDetails.getSsn()
						  + " ||  Actual( DB Value ) ==> " + dbMemberDetails.getSsn())
					.isEqualTo(excelMemberDetails.getSsn());

					softAssertions.assertThat(dbMemberDetails.getSubscriberName())
					.as("SubscriberName for claim ID:" + dbMemberDetails.getClaimId()	+ 
						  " || Expected( Report Value) ==> " + excelMemberDetails.getSubscriberName()
						  + " ||  Actual( DB Value ) ==> " + dbMemberDetails.getSubscriberName())
					.isEqualTo(excelMemberDetails.getSubscriberName());
					
					softAssertions.assertThat(dbMemberDetails.getPatientName())
					.as("PatientName for claim ID:" + dbMemberDetails.getClaimId()	+ 
						  " || Expected( Report Value) ==> " + excelMemberDetails.getPatientName()
						  + " ||  Actual( DB Value ) ==> " + dbMemberDetails.getPatientName())
					.isEqualTo(excelMemberDetails.getPatientName());
					
					softAssertions.assertThat(dbMemberDetails.getRelationship())
					.as("Relationship for claim ID:" + dbMemberDetails.getClaimId()	+ 
						  " || Expected( Report Value) ==> " + excelMemberDetails.getRelationship()
						  + " ||  Actual( DB Value ) ==> " + dbMemberDetails.getRelationship())
					.isEqualTo(excelMemberDetails.getRelationship());

					softAssertions.assertThat(dbMemberDetails.getDept())
					.as("Dept for claim ID:" + dbMemberDetails.getClaimId()	+ 
						  " || Expected( Report Value) ==> " + excelMemberDetails.getDept()
						  + " ||  Actual( DB Value ) ==> " + dbMemberDetails.getDept())
					.isEqualTo(excelMemberDetails.getDept());
					
					softAssertions.assertThat(dbMemberDetails.getClaimId())
					.as("ClaimId for claim ID:" + dbMemberDetails.getClaimId()	+ 
						  " || Expected( Report Value) ==> " + excelMemberDetails.getClaimId()
						  + " ||  Actual( DB Value ) ==> " + dbMemberDetails.getClaimId())
					.isEqualTo(excelMemberDetails.getClaimId());

					softAssertions.assertThat(dbMemberDetails.getCheckNumber())
					.as("CheckNumber for claim ID:" + dbMemberDetails.getClaimId()	+ 
						  " || Expected( Report Value) ==> " + excelMemberDetails.getCheckNumber()
						  + " ||  Actual( DB Value ) ==> " + dbMemberDetails.getCheckNumber())
					.isEqualTo(excelMemberDetails.getCheckNumber());
					
//					softAssertions.assertThat(dbMemberDetails.getPaidDate())
//					.as("PaidDate for claim ID:" + dbMemberDetails.getClaimId()	+ 
//						  " || Expected( Report Value) ==> " + excelMemberDetails.getPaidDate()
//						  + " ||  Actual( DB Value ) ==> " + dbMemberDetails.getPaidDate())
//					.isEqualTo(excelMemberDetails.getPaidDate());
//					
//					softAssertions.assertThat(dbMemberDetails.getFromDate())
//					.as("FromDate for claim ID:" + dbMemberDetails.getClaimId()	+ 
//						  " || Expected( Report Value) ==> " + excelMemberDetails.getFromDate()
//						  + " ||  Actual( DB Value ) ==> " + dbMemberDetails.getFromDate())
//					.isEqualTo(excelMemberDetails.getFromDate());
//					
//					softAssertions.assertThat(dbMemberDetails.getToDate())
//					.as("ToDate for claim ID:" + dbMemberDetails.getClaimId()	+ 
//						  " || Expected( Report Value) ==> " + excelMemberDetails.getToDate()
//						  + " ||  Actual( DB Value ) ==> " + dbMemberDetails.getToDate())
//					.isEqualTo(excelMemberDetails.getToDate());

					softAssertions.assertThat(dbMemberDetails.getPayeeName())
					.as("PayeeName for claim ID:" + dbMemberDetails.getClaimId()	+ 
						  " || Expected( Report Value) ==> " + excelMemberDetails.getPayeeName()
						  + " ||  Actual( DB Value ) ==> " + dbMemberDetails.getPayeeName())
					.isEqualTo(excelMemberDetails.getPayeeName());

					softAssertions.assertThat(dbMemberDetails.getPayeeId())
					.as("PayeeId for claim ID:" + dbMemberDetails.getClaimId()	+ 
						  " || Expected( Report Value) ==> " + excelMemberDetails.getPayeeId()
						  + " ||  Actual( DB Value ) ==> " + dbMemberDetails.getPayeeId())
					.isEqualTo(excelMemberDetails.getPayeeId());
					
					softAssertions.assertThat(dbMemberDetails.getCoverage())
					.as("Coverage for claim ID:" + dbMemberDetails.getClaimId()	+ 
						  " || Expected( Report Value) ==> " + excelMemberDetails.getCoverage()
						  + " ||  Actual( DB Value ) ==> " + dbMemberDetails.getCoverage())
					.isEqualTo(excelMemberDetails.getCoverage());

					softAssertions.assertThat(dbMemberDetails.getDeductible())
					.as("Deductible for claim ID:" + dbMemberDetails.getClaimId()	+ 
						  " || Expected( Report Value) ==> " + excelMemberDetails.getDeductible()
						  + " ||  Actual( DB Value ) ==> " + dbMemberDetails.getDeductible())
					.isEqualTo(excelMemberDetails.getDeductible());

					softAssertions.assertThat(dbMemberDetails.getCoinsurance())
					.as("Coinsurance for claim ID:" + dbMemberDetails.getClaimId()	+ 
						  " || Expected( Report Value) ==> " + excelMemberDetails.getCoinsurance()
						  + " ||  Actual( DB Value ) ==> " + dbMemberDetails.getCoinsurance())
					.isEqualTo(excelMemberDetails.getCoinsurance());

					softAssertions.assertThat(dbMemberDetails.getCopay())
					.as("Copay for claim ID:" + dbMemberDetails.getClaimId()	+ 
						  " || Expected( Report Value) ==> " + excelMemberDetails.getCopay()
						  + " ||  Actual( DB Value ) ==> " + dbMemberDetails.getCopay())
					.isEqualTo(excelMemberDetails.getCopay());

					softAssertions.assertThat(dbMemberDetails.getMedical())
					.as("Medical for claim ID:" + dbMemberDetails.getClaimId()	+ 
						  " || Expected( Report Value) ==> " + excelMemberDetails.getMedical()
						  + " ||  Actual( DB Value ) ==> " + dbMemberDetails.getMedical())
					.isEqualTo(excelMemberDetails.getMedical());

					softAssertions.assertThat(dbMemberDetails.getCostContainment())
					.as("CostContainment for claim ID:" + dbMemberDetails.getClaimId()	+ 
						  " || Expected( Report Value) ==> " + excelMemberDetails.getCostContainment()
						  + " ||  Actual( DB Value ) ==> " + dbMemberDetails.getCostContainment())
					.isEqualTo(excelMemberDetails.getCostContainment());
					
					softAssertions.assertThat(dbMemberDetails.getInterest())
					.as("Interest for claim ID:" + dbMemberDetails.getClaimId()	+ 
						  " || Expected( Report Value) ==> " + excelMemberDetails.getInterest()
						  + " ||  Actual( DB Value ) ==> " + dbMemberDetails.getInterest())
					.isEqualTo(excelMemberDetails.getInterest());

					softAssertions.assertThat(dbMemberDetails.getDental())
					.as("Dental for claim ID:" + dbMemberDetails.getClaimId()	+ 
						  " || Expected( Report Value) ==> " + excelMemberDetails.getDental()
						  + " ||  Actual( DB Value ) ==> " + dbMemberDetails.getDental())
					.isEqualTo(excelMemberDetails.getDental());
					
					softAssertions.assertThat(dbMemberDetails.getPharmacy())
					.as("Pharmacy for claim ID:" + dbMemberDetails.getClaimId()	+ 
						  " || Expected( Report Value) ==> " + excelMemberDetails.getPharmacy()
						  + " ||  Actual( DB Value ) ==> " + dbMemberDetails.getPharmacy())
					.isEqualTo(excelMemberDetails.getPharmacy());

					softAssertions.assertThat(dbMemberDetails.getBluecard())
					.as("Bluecard for claim ID:" + dbMemberDetails.getClaimId()	+ 
						  " || Expected( Report Value) ==> " + excelMemberDetails.getBluecard()
						  + " ||  Actual( DB Value ) ==> " + dbMemberDetails.getBluecard())
					.isEqualTo(excelMemberDetails.getBluecard());
					
					softAssertions.assertThat(dbMemberDetails.getStoploss())
					.as("Stoploss for claim ID:" + dbMemberDetails.getClaimId()	+ 
						  " || Expected( Report Value) ==> " + excelMemberDetails.getStoploss()
						  + " ||  Actual( DB Value ) ==> " + dbMemberDetails.getStoploss())
					.isEqualTo(excelMemberDetails.getStoploss());
				
					softAssertions.assertThat(dbMemberDetails.getHra())
					.as("Hra for claim ID:" + dbMemberDetails.getClaimId()	+ 
						  " || Expected( Report Value) ==> " + excelMemberDetails.getHra()
						  + " ||  Actual( DB Value ) ==> " + dbMemberDetails.getHra())
					.isEqualTo(excelMemberDetails.getHra());

					softAssertions.assertThat(dbMemberDetails.getTotalPaid())
					.as("TotalPaid for claim ID:" + dbMemberDetails.getClaimId()	+ 
						  " || Expected( Report Value) ==> " + excelMemberDetails.getTotalPaid()
						  + " ||  Actual( DB Value ) ==> " + dbMemberDetails.getTotalPaid())
					.isEqualTo(excelMemberDetails.getTotalPaid());
					
				}
			}
		}
		
	}

	/**
	 * Tidal job creates a report in an excel sheet. The test method converts
	 * that to a map and uses it as a 'actual'. Expected is from the DB.
	 * 
	 * @param invoiceNo
	 *            Invoice number as string
	 * @param planDetailsExcelTable
	 *            Map of data from the planDetailsExcel worksheet
	 * @param planDetailsDBTable
	 *            Map of data from the DB
	 */
	@Test(dataProvider = "providePlanDetailsData",enabled=true)
	public void testPlanDetailsData(String invoiceNo,
			Hashtable<String, List<PlanDetails>> planDetailsExcelTable,
			Hashtable<String, List<PlanDetails>> planDetailsDBTable,
			HashMap<String, List<PlanDetails>> planDetailsExcelMap,
			HashMap<String, List<PlanDetails>> planDetailsDBMap
			) {
		
		List<PlanDetails> planDetailsExcelList = planDetailsExcelMap.get(invoiceNo);
		List<PlanDetails> planDetailsDBList = planDetailsDBMap.get(invoiceNo);
		//Custom override needed to get pin point information of the validating invoice data
		reportInit("testPlanDetails", " invoice:"+invoiceNo);
		logger.log(LogStatus.INFO, "Testing plan details page data for invoice no:"+invoiceNo);
		for (PlanDetails excelPlanDetails : planDetailsExcelList) {
			for (int i = 0; i < planDetailsDBList.size(); i++) {
				PlanDetails dbPlanDetails = planDetailsDBList.get(i);
				if (excelPlanDetails.getPlanDetailsTotals().equalsIgnoreCase(
						dbPlanDetails.getPlanDetailsTotals())) {

					softAssertions.assertThat(dbPlanDetails.getTotalPaid())
					.as("TotalPaid for Plan Details Total :" + dbPlanDetails.getPlanDetailsTotals()	+ 
						  " || Expected( Report Value ) ==> " + excelPlanDetails.getTotalPaid()
						  + " ||  Actual( DB Value ) ==> " + dbPlanDetails.getTotalPaid())
					.isEqualTo(excelPlanDetails.getTotalPaid());
					
					softAssertions.assertThat(dbPlanDetails.getAfaId())
					.as("AfaId for Plan Details Total :" + dbPlanDetails.getPlanDetailsTotals()	+ 
						  " || Expected( Report Value ) ==> " + excelPlanDetails.getAfaId()
						  + " ||  Actual( DB Value ) ==> " + dbPlanDetails.getAfaId())
					.isEqualTo(excelPlanDetails.getAfaId());

					softAssertions.assertThat(dbPlanDetails.getClaimsCycle())
					.as("ClaimsCycle for Plan Details Total :" + dbPlanDetails.getPlanDetailsTotals()	+ 
						  " || Expected( Report Value ) ==> " + excelPlanDetails.getClaimsCycle()
						  + " ||  Actual( DB Value ) ==> " + dbPlanDetails.getClaimsCycle())
					.isEqualTo(excelPlanDetails.getClaimsCycle());

					softAssertions.assertThat(dbPlanDetails.getBillDueDate())
					.as("BillDueDate for Plan Details Total :" + dbPlanDetails.getPlanDetailsTotals()	+ 
						  " || Expected( Report Value ) ==> " + excelPlanDetails.getBillDueDate()
						  + " ||  Actual( DB Value ) ==> " + dbPlanDetails.getBillDueDate())
					.isEqualTo(excelPlanDetails.getBillDueDate());

					softAssertions.assertThat(dbPlanDetails.getInvoiceNo())
					.as("InvoiceNo for Plan Details Total :" + dbPlanDetails.getPlanDetailsTotals()	+ 
						  " || Expected( Report Value ) ==> " + excelPlanDetails.getInvoiceNo()
						  + " ||  Actual( DB Value ) ==> " + dbPlanDetails.getInvoiceNo())
					.isEqualTo(excelPlanDetails.getInvoiceNo());

					softAssertions.assertThat(dbPlanDetails.getGroupIdName())
					.as("GroupIdName for Plan Details Total :" + dbPlanDetails.getPlanDetailsTotals()	+ 
						  " || Expected( Report Value ) ==> " + excelPlanDetails.getGroupIdName()
						  + " ||  Actual( DB Value ) ==> " + dbPlanDetails.getGroupIdName())
					.isEqualTo(excelPlanDetails.getGroupIdName());

					softAssertions.assertThat(dbPlanDetails.getPln())
					.as("Pln for Plan Details Total :" + dbPlanDetails.getPlanDetailsTotals()	+ 
						  " || Expected( Report Value ) ==> " + excelPlanDetails.getPln()
						  + " ||  Actual( DB Value ) ==> " + dbPlanDetails.getPln())
					.isEqualTo(excelPlanDetails.getPln());

					softAssertions.assertThat(dbPlanDetails.getCbc())
					.as("Cbc for Plan Details Total :" + dbPlanDetails.getPlanDetailsTotals()	+ 
						  " || Expected( Report Value ) ==> " + excelPlanDetails.getCbc()
						  + " ||  Actual( DB Value ) ==> " + dbPlanDetails.getCbc())
					.isEqualTo(excelPlanDetails.getCbc());

					softAssertions.assertThat(dbPlanDetails.getGrpId())
					.as("GrpId for Plan Details Total :" + dbPlanDetails.getPlanDetailsTotals()	+ 
						  " || Expected( Report Value ) ==> " + excelPlanDetails.getGrpId()
						  + " ||  Actual( DB Value ) ==> " + dbPlanDetails.getGrpId())
					.isEqualTo(excelPlanDetails.getGrpId());

//					softAssertions.assertThat(dbPlanDetails.getCoverage())
//					.as("Coverage for Plan Details Total :" + dbPlanDetails.getPlanDetailsTotals()	+ 
//						  " || Expected( Report Value ) ==> " + excelPlanDetails.getCoverage()
//						  + " ||  Actual( DB Value ) ==> " + dbPlanDetails.getCoverage())
//					.isEqualTo(excelPlanDetails.getCoverage());
					
					softAssertions.assertThat(dbPlanDetails.getPlanDetailsTotals())
					.as("PlanDetailsTotals for Plan Details Total :" + dbPlanDetails.getPlanDetailsTotals()	+ 
						  " || Expected( Report Value ) ==> " + excelPlanDetails.getPlanDetailsTotals()
						  + " ||  Actual( DB Value ) ==> " + dbPlanDetails.getPlanDetailsTotals())
					.isEqualTo(excelPlanDetails.getPlanDetailsTotals());

					softAssertions.assertThat(dbPlanDetails.getMedical())
					.as("Medical for Plan Details Total :" + dbPlanDetails.getPlanDetailsTotals()	+ 
						  " || Expected( Report Value ) ==> " + excelPlanDetails.getMedical()
						  + " ||  Actual( DB Value ) ==> " + dbPlanDetails.getMedical())
					.isEqualTo(excelPlanDetails.getMedical());

					softAssertions.assertThat(dbPlanDetails.getCostContainment())
					.as("CostContainment for Plan Details Total :" + dbPlanDetails.getPlanDetailsTotals()	+ 
						  " || Expected( Report Value ) ==> " + excelPlanDetails.getCostContainment()
						  + " ||  Actual( DB Value ) ==> " + dbPlanDetails.getCostContainment())
					.isEqualTo(excelPlanDetails.getCostContainment());

					softAssertions.assertThat(dbPlanDetails.getInterest())
					.as("Interest for Plan Details Total :" + dbPlanDetails.getPlanDetailsTotals()	+ 
						  " || Expected( Report Value ) ==> " + excelPlanDetails.getInterest()
						  + " ||  Actual( DB Value ) ==> " + dbPlanDetails.getInterest())
					.isEqualTo(excelPlanDetails.getInterest());

					softAssertions.assertThat(dbPlanDetails.getDental())
					.as("Dental for Plan Details Total :" + dbPlanDetails.getPlanDetailsTotals()	+ 
						  " || Expected( Report Value ) ==> " + excelPlanDetails.getDental()
						  + " ||  Actual( DB Value ) ==> " + dbPlanDetails.getDental())
					.isEqualTo(excelPlanDetails.getDental());
					
					softAssertions.assertThat(dbPlanDetails.getPharmacy())
					.as("Pharmacy for Plan Details Total :" + dbPlanDetails.getPlanDetailsTotals()	+ 
						  " || Expected( Report Value ) ==> " + excelPlanDetails.getPharmacy()
						  + " ||  Actual( DB Value ) ==> " + dbPlanDetails.getPharmacy())
					.isEqualTo(excelPlanDetails.getPharmacy());
					
					softAssertions.assertThat(dbPlanDetails.getStoploss())
					.as("Stoploss for Plan Details Total :" + dbPlanDetails.getPlanDetailsTotals()	+ 
						  " || Expected( Report Value ) ==> " + excelPlanDetails.getStoploss()
						  + " ||  Actual( DB Value ) ==> " + dbPlanDetails.getStoploss())
					.isEqualTo(excelPlanDetails.getStoploss());

					softAssertions.assertThat(dbPlanDetails.getBluecard())
					.as("Bluecard for Plan Details Total :" + dbPlanDetails.getPlanDetailsTotals()	+ 
						  " || Expected( Report Value ) ==> " + excelPlanDetails.getBluecard()
						  + " ||  Actual( DB Value ) ==> " + dbPlanDetails.getBluecard())
					.isEqualTo(excelPlanDetails.getBluecard());

					softAssertions.assertThat(dbPlanDetails.getHra())
					.as("Hra for Plan Details Total :" + dbPlanDetails.getPlanDetailsTotals()	+ 
						  " || Expected( Report Value ) ==> " + excelPlanDetails.getHra()
						  + " ||  Actual( DB Value ) ==> " + dbPlanDetails.getHra())
					.isEqualTo(excelPlanDetails.getHra());

					softAssertions.assertThat(dbPlanDetails.getTotalPaid())
					.as("TotalPaid for Plan Details Total :" + dbPlanDetails.getPlanDetailsTotals()	+ 
						  " || Expected( Report Value ) ==> " + excelPlanDetails.getTotalPaid()
						  + " ||  Actual( DB Value ) ==> " + dbPlanDetails.getTotalPaid())
					.isEqualTo(excelPlanDetails.getTotalPaid());

				}
			}
		}
		
	}

	@DataProvider
	public Object[][] provideFrontPageData() {
		DatabaseUtil util = new DatabaseUtil();
		AfaInvoiceReportReader reader = new AfaInvoiceReportReader();
		Map<String, FrontPage> frontPageDBMap = new HashMap<>();
		Map<String, FrontPage> frontPageExcelMap = new HashMap<>();
		
		try {
			frontPageDBMap = util.getFrontPageData();
//			for(Entry<String, FrontPage> entrySet : frontPageDBMap.entrySet()) {
//				System.out.println(entrySet.getValue());
//			}
//			System.out.println(frontPageDBMap.size());
			logger1.info("Fetched Front Page Data from DB");
		} catch (Exception e) {
			logger1.error("Something wrong while fetching DB data for Front Page");
			e.printStackTrace();
		}

		try {
			frontPageExcelMap = reader.getFrontPageData();
//			for(Entry<String, FrontPage> entrySet : frontPageExcelMap.entrySet()) {
//				System.out.println(entrySet.getValue());
//			}
//			System.out.println(frontPageExcelMap.size());
			logger1.info("Fetched Front Page Data from Excel");
		} catch (Exception e) {
			logger1.error("Something wrong while fetching Excel data for Front Page");
			e.printStackTrace();
		}
		
		Object[][] data = new Object[AfaInvoiceReportReader.frontPageInputSet.size()][3];
		Hashtable<String, FrontPage> frontPageExcelTable = null;
		Hashtable<String, FrontPage> frontPageDBTable = null;

		int i = 0;
		for (String invoiceNo : AfaInvoiceReportReader.frontPageInputSet) {
			frontPageExcelTable = new Hashtable<String, FrontPage>();
			frontPageExcelTable.put(invoiceNo, frontPageExcelMap.get(invoiceNo));
			frontPageDBTable = new Hashtable<String, FrontPage>();
			frontPageDBTable.put(invoiceNo, frontPageDBMap.get(invoiceNo));
			data[i][0] = invoiceNo;
			data[i][1] = frontPageExcelTable;
			data[i][2] = frontPageDBTable;
			i++;
		}
		return data;
	}

	@DataProvider
	public Object[][] provideClaimsActivitySummaryData() {
		DatabaseUtil util = new DatabaseUtil();
		AfaInvoiceReportReader reader = new AfaInvoiceReportReader();
		 Map<String, List<ClaimsActivitySummary>> claimsActivitySummaryDBMap= new HashMap<>();
		 Map<String, List<ClaimsActivitySummary>> claimsActivitySummaryExcelMap= new HashMap<>();
		
		try {
			claimsActivitySummaryDBMap = util.getClaimsActivitySummary();
			logger1.info("Fetched Claims Activity Summary Data from DB");
		} catch (Exception e) {
			logger1.error("Something wrong while fetching DB data for Claims Activity Summary Page");
			e.printStackTrace();
		}
		try {
			claimsActivitySummaryExcelMap = reader
					.getClaimsActivitySummaryData(claimsActivitySummaryDBMap);
			logger1.info("Fetched Claims Activity Summary Data from Excel");
		} catch (Exception e) {
			logger1.error("Something wrong while fetching Excel data for Claims Activity Summary Page");
			e.printStackTrace();
		}

		
		Object[][] data = new Object[claimsActivitySummaryExcelMap.size()][5];
		Hashtable<String, List<ClaimsActivitySummary>> claimsActivitySummaryExcelTable = null;
		Hashtable<String, List<ClaimsActivitySummary>> claimsActivitySummaryDBTable = null;

		int i = 0;
		for (String invoiceNo : AfaInvoiceReportReader.claimsActivitySummaryInputSet) {
			claimsActivitySummaryExcelTable = new Hashtable<String, List<ClaimsActivitySummary>>();
			claimsActivitySummaryExcelTable.put(invoiceNo,claimsActivitySummaryExcelMap.get(invoiceNo));
			claimsActivitySummaryDBTable = new Hashtable<String, List<ClaimsActivitySummary>>();
			claimsActivitySummaryDBTable.put(invoiceNo,claimsActivitySummaryDBMap.get(invoiceNo));
			data[i][0] = invoiceNo;
			data[i][1] = claimsActivitySummaryExcelTable;
			data[i][2] = claimsActivitySummaryDBTable;
			data[i][3] = claimsActivitySummaryExcelMap;
			data[i][4] = claimsActivitySummaryDBMap;
			i++;
		}
//		System.out.println("No of invoices present : "+i);
		return data;
	}


	@DataProvider
	public Object[][] provideShieldSavingData() {
		DatabaseUtil util = new DatabaseUtil();
		AfaInvoiceReportReader reader = new AfaInvoiceReportReader();
		 Map<String, List<ShieldSaving>> shieldSavingDBMap= new HashMap<>();
		 Map<String, List<ShieldSaving>> shieldSavingExcelMap= new HashMap<>();

		try {
			shieldSavingDBMap = util.getShieldSaving();
			logger1.info("Fetched Shield saving Data from DB");
		} catch (Exception e) {
			logger1.error("Something wrong while fetching DB data for Shield Savings Page");
			e.printStackTrace();
		}
		
		try {
			shieldSavingExcelMap = reader
					.getShieldSavingData(shieldSavingDBMap);
			logger1.info("Fetched Shield saving Data from Excel");
		} catch (Exception e) {
			logger1.error("Something wrong while fetching Excel data for Shield Savings Page");
			e.printStackTrace();
		}
		
		Object[][] data = new Object[AfaInvoiceReportReader.shieldSavingsInputSet.size()][5];
		Hashtable<String, List<ShieldSaving>> shieldSavingExcelTable = null;
		Hashtable<String, List<ShieldSaving>> shieldSavingDBTable = null;

		int i = 0;
		for (String invoiceNo : AfaInvoiceReportReader.shieldSavingsInputSet) {

			shieldSavingExcelTable = new Hashtable<String, List<ShieldSaving>>();
			shieldSavingExcelTable.put(invoiceNo,shieldSavingExcelMap.get(invoiceNo));
			shieldSavingDBTable = new Hashtable<String, List<ShieldSaving>>();
			shieldSavingDBTable.put(invoiceNo, shieldSavingDBMap.get(invoiceNo));
			data[i][0] = invoiceNo;
			data[i][1] = shieldSavingExcelTable;
			data[i][2] = shieldSavingDBTable;
			data[i][3] = shieldSavingExcelMap;
			data[i][4] = shieldSavingDBMap;
			i++;
		}
		return data;
	}

	@DataProvider
	public Object[][] provideMemberDetailsData() {
		
		DatabaseUtil util = new DatabaseUtil();
		AfaInvoiceReportReader reader = new AfaInvoiceReportReader();
		Map<String, List<MemberDetails>> memberDetailsDBMap= new HashMap<>();
		Map<String, List<MemberDetails>> memberDetailsExcelMap= new HashMap<>();

		try {
			memberDetailsDBMap = util.getMemberDetails();
			logger1.info("Fetched Member details Data from DB");
		} catch (Exception e) {
			logger1.error("Something wrong while fetching DB data for Member Details Page");
			e.printStackTrace();
		}
		try {
			memberDetailsExcelMap = reader
					.getMemberDetailsData(memberDetailsDBMap);
			logger1.info("Fetched Member details Data from Excel");
		} catch (Exception e) {
			logger1.error("Something wrong while fetching Excel data for Member Details Page");
			e.printStackTrace();
		}
		
		
		Object[][] data = new Object[AfaInvoiceReportReader.memberDetailsInputSet.size()][5];
		Hashtable<String, List<MemberDetails>> memberDetailsExcelTable = null;
		Hashtable<String, List<MemberDetails>> memberDetailsDBTable = null;

		int i = 0;
		for (String invoiceNo : AfaInvoiceReportReader.memberDetailsInputSet) {
			memberDetailsExcelTable = new Hashtable<String, List<MemberDetails>>();
			memberDetailsExcelTable.put(invoiceNo,memberDetailsExcelMap.get(invoiceNo));
			memberDetailsDBTable = new Hashtable<String, List<MemberDetails>>();
			memberDetailsDBTable.put(invoiceNo,memberDetailsDBMap.get(invoiceNo));
			data[i][0] = invoiceNo;
			data[i][1] = memberDetailsExcelTable;
			data[i][2] = memberDetailsDBTable;
			data[i][3] = memberDetailsExcelMap;
			data[i][4] = memberDetailsDBMap;
			i++;
		}
		return data;
	}

	@DataProvider
	public Object[][] providePlanDetailsData() {
		
		DatabaseUtil util = new DatabaseUtil();
		AfaInvoiceReportReader reader = new AfaInvoiceReportReader();
		Map<String, List<PlanDetails>> planDetailsDBMap = new HashMap<>();
		Map<String, List<PlanDetails>> planDetailsExcelMap = new HashMap<>();
		
		try {
			planDetailsDBMap = util.getPlanDetails();
			logger1.info("Fetched Plan Details Data from DB");
		} catch (Exception e) {
			logger1.error("Something wrong while fetching DB data for Plan Details Page");
			e.printStackTrace();
		}
		try {
			planDetailsExcelMap = reader.getPlanDetailsData(planDetailsDBMap);
			logger1.info("Fetched Plan Details Data from Excel");
		} catch (Exception e) {
			logger1.error("Something wrong while fetching Excel data for Plan Details Page");
			e.printStackTrace();
		}
		
		
		Object[][] data = new Object[AfaInvoiceReportReader.planDetailsInputSet.size()][5];
		Hashtable<String, List<PlanDetails>> planDetailsExcelTable = null;
		Hashtable<String, List<PlanDetails>> planDetailsDBTable = null;

		int i = 0;
		for (String invoiceNo : AfaInvoiceReportReader.planDetailsInputSet) {
			planDetailsExcelTable = new Hashtable<String, List<PlanDetails>>();
			planDetailsExcelTable.put(invoiceNo,planDetailsExcelMap.get(invoiceNo));
			planDetailsDBTable = new Hashtable<String, List<PlanDetails>>();
			planDetailsDBTable.put(invoiceNo, planDetailsDBMap.get(invoiceNo));
			data[i][0] = invoiceNo;
			data[i][1] = planDetailsExcelTable;
			data[i][2] = planDetailsDBTable;
			data[i][3] = planDetailsExcelMap;
			data[i][4] = planDetailsDBMap;
			i++;
		}
		return data;
	}

	
	/**
	 * run is a hook before Test method 
	 */
	@Override
	public void run(IHookCallBack callBack, ITestResult testResult) {
		softAssertions = new SoftAssertions();
		callBack.runTestMethod(testResult);
		softAssertions.assertAll();
	}

	
}
