package com.bsc.qa.facets.afa.dao;

import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import java.util.SortedMap;

import org.apache.commons.collections4.map.HashedMap;

import com.bsc.qa.facets.afa.pojo.ClaimsActivitySummary;
import com.bsc.qa.facets.afa.pojo.FrontPage;
import com.bsc.qa.facets.afa.pojo.MemberDetails;
import com.bsc.qa.facets.afa.pojo.PlanDetails;
import com.bsc.qa.facets.afa.pojo.ShieldSaving;
import com.bsc.qa.framework.utility.DBUtils;
import com.bsc.qa.framework.utility.ExcelUtils;

public class DatabaseUtil {
	
	public static Set<String> frontPageInputSet = new HashSet<String>();
	public static Set<String> claimsActivitySummaryInputSet = new HashSet<String>();
	public static Set<String> shieldSavingsInputSet = new HashSet<String>();
	public static Set<String> memberDetailsInputSet = new HashSet<String>();
	public static Set<String> planDetailsInputSet = new HashSet<String>();
	
	
	public Map<String,FrontPage> getFrontPageData() {
		DBUtils dbUtils = new DBUtils();
		String xlsPath = new File("").getAbsolutePath()+ "/src/test/resources/AfaInvoiceReportValidationTest.xlsx";
		HashedMap<String, FrontPage> frontPageDBMap = new HashedMap<String, FrontPage>();
		Map<String, String> dataMap = new HashMap<String, String>();
		dataMap = ExcelUtils.getTestMethodData(xlsPath, "testFrontPageDataInput");
		Object[] values = {};
		SortedMap<String, SortedMap<String, String>> invoiceNoDataMap = dbUtils.getMultiRowsFromPreparedQuery("facets", dataMap.get("PREPARED_STATEMENT_QUERY"),values);
		
		for(Entry<String, SortedMap<String, String>> entry1 : invoiceNoDataMap.entrySet()) {
			frontPageInputSet.add(entry1.getValue().get("BLIV_ID").trim());
		}
		
		for (String invoiceId : frontPageInputSet) {
			
			dataMap = ExcelUtils.getTestMethodData(xlsPath, "testFrontPageData");
			Object[] values1 = {invoiceId};
			SortedMap<String, SortedMap<String, String>> claimDataResultMap = dbUtils.getMultiRowsFromPreparedQuery("facets", dataMap.get("PREPARED_STATEMENT_QUERY"),values1);
			
			FrontPage frontPage = new FrontPage();
			for (Entry<String, SortedMap<String, String>> entry1 : claimDataResultMap.entrySet()) {
				SortedMap<String, String> frontPageData = entry1.getValue();
				frontPage.setGroupName(frontPageData.get("GROUPNAME").trim());
				frontPage.setGroupAddress(frontPageData.get("GROUPADDRESS").trim());
				frontPage.setAttention(frontPageData.get("ATTENTION").trim());
				frontPage.setGroupBillingId(frontPageData.get("GROUPBILLINGID").trim());
				frontPage.setFundingPeriod(frontPageData.get("FUNDINGPERIOD").trim());
				frontPage.setBillDueDate(frontPageData.get("BILDUEDATE").trim());
				frontPage.setInvoiceNo(frontPageData.get("INVOICENO").trim());
				frontPage.setInvoiceDate(frontPageData.get("INVOICEDATE").trim());
				frontPage.setCurrentPeriodClaims(frontPageData.get("CURRENTPERIODCLAIMS").trim());
				frontPage.setBalanceForward(frontPageData.get("BALANCEFORWARD").trim());
				frontPage.setTotalDueForClaimsReimbursement(frontPageData.get("TOTALDUEFORCLAIMSREIMBURSEMENT").trim());
				frontPage.setBscAccountantName(frontPageData.get("BSCACCOUNTANTNAME").trim());
				frontPage.setPhone(frontPageData.get("PHONE").trim());
				frontPage.setFax(frontPageData.get("FAX").trim());
				frontPage.setEmail(frontPageData.get("EMAIL").trim());
				
				if(frontPage.getBscAccountantName()==null || frontPage.getBscAccountantName().equalsIgnoreCase(" ")){
					frontPage.setBscAccountantName("");
				}
				if(frontPage.getAttention()==null || frontPage.getAttention().equalsIgnoreCase(" ")){
					frontPage.setAttention("");
				}
				if(frontPage.getFax()==null || frontPage.getFax().equalsIgnoreCase(" ")){
					frontPage.setFax("");
				}
				if(frontPage.getPhone()==null || frontPage.getPhone().equalsIgnoreCase(" ")){
					frontPage.setPhone("");
				}
				if(frontPage.getEmail()==null || frontPage.getEmail().equalsIgnoreCase(" ")){
					frontPage.setEmail("");
				}
				frontPageDBMap.put(invoiceId,frontPage);
				
			}
			
			
		}
		
		return frontPageDBMap;

	}

	public Map<String,List<ClaimsActivitySummary>> getClaimsActivitySummary() {
		DBUtils dbUtils = new DBUtils();
		String xlsPath = new File("").getAbsolutePath()+ "/src/test/resources/AfaInvoiceReportValidationTest.xlsx";
		HashMap<String, List<ClaimsActivitySummary>> claimsActivitySummaryDBMap = new HashMap<String, List<ClaimsActivitySummary>>();
		Map<String, String> dataMap = new HashMap<String, String>();
		dataMap = ExcelUtils.getTestMethodData(xlsPath, "testClaimsActivitySummaryDataInput");
		Object[] values = {};
		SortedMap<String, SortedMap<String, String>> invoiceNoDataMap = dbUtils.getMultiRowsFromPreparedQuery("facets", dataMap.get("PREPARED_STATEMENT_QUERY"),values);
		
		for(Entry<String, SortedMap<String, String>> entry1 : invoiceNoDataMap.entrySet()) {
			claimsActivitySummaryInputSet.add(entry1.getValue().get("BLIV_ID").trim());
		}
		
		
		for (String invoiceId : claimsActivitySummaryInputSet) {
			
			dataMap = ExcelUtils.getTestMethodData(xlsPath, "testClaimsActivitySummaryData");
			Object[] values1 = {invoiceId};
			SortedMap<String, SortedMap<String, String>> claimDataResultMap = dbUtils.getMultiRowsFromPreparedQuery("facets", dataMap.get("PREPARED_STATEMENT_QUERY"),values1);
			
			List<ClaimsActivitySummary> claimsActivityList = new ArrayList<ClaimsActivitySummary>();
			for (Entry<String, SortedMap<String, String>> entry1 : claimDataResultMap.entrySet()) {
				SortedMap<String, String> claimsActivitySummaryData = entry1.getValue();
				ClaimsActivitySummary claimsActivitySummary = new ClaimsActivitySummary();
				claimsActivitySummary.setClaimPaymentPeriod(claimsActivitySummaryData.get("CLAIMPAYMENTPERIOD").trim());
				claimsActivitySummary.setInvoiceDate(claimsActivitySummaryData.get("INVOICEDATE").trim());
				claimsActivitySummary.setGroupName(claimsActivitySummaryData.get("GROUPNAME").trim());
				claimsActivitySummary.setGroupBillingId(claimsActivitySummaryData.get("GROUPBILLINGID").trim());
				claimsActivitySummary.setClaimsCycle(claimsActivitySummaryData.get("CLAIMSCYCLE").trim());
				claimsActivitySummary.setBillDueDate(claimsActivitySummaryData.get("BILDUEDATE").trim());
				claimsActivitySummary.setInvoiceNo(claimsActivitySummaryData.get("INVOICENO").trim());
				claimsActivitySummary.setBillingCategory(claimsActivitySummaryData.get("BILLINGCATEGORY").trim());
				claimsActivitySummary.setMedical(claimsActivitySummaryData.get("MEDICAL").trim());
				claimsActivitySummary.setCostContainment(claimsActivitySummaryData.get("COSTCONTAINMENT").trim());
				claimsActivitySummary.setInterest(claimsActivitySummaryData.get("INTEREST").trim());
				claimsActivitySummary.setDental(claimsActivitySummaryData.get("DENTAL").trim());
				claimsActivitySummary.setPharmacy(claimsActivitySummaryData.get("PHARMACY").trim());
				claimsActivitySummary.setBlueCardAccessFees(claimsActivitySummaryData.get("BLUECARDACCESSFEES").trim());
				claimsActivitySummary.setStopLossAdvancedFunding(claimsActivitySummaryData.get("STOPLOSSADVANCEDFUNDING").trim());
				claimsActivitySummary.setHealthReimbursementAccount(claimsActivitySummaryData.get("HEALTHREIMBURSEMENTACCOUNT").trim());
				claimsActivitySummary.setSubTotalClaimsActivity(claimsActivitySummaryData.get("SUBTOTALCLAIMSACTIVITY").trim());
				claimsActivitySummary.setTotal(claimsActivitySummaryData.get("TOTAL").trim());
				claimsActivityList.add(claimsActivitySummary);
		}
			claimsActivitySummaryDBMap.put(invoiceId, claimsActivityList);
		}
		return claimsActivitySummaryDBMap;
	}

	public Map<String,List<MemberDetails>> getMemberDetails() {
		DBUtils dbUtils = new DBUtils();
		String xlsPath = new File("").getAbsolutePath()+ "/src/test/resources/AfaInvoiceReportValidationTest.xlsx";
		HashMap<String, List<MemberDetails>> memberDetailsDBMap = new HashMap<String, List<MemberDetails>>();
		Map<String, String> dataMap = new HashMap<String, String>();
		dataMap = ExcelUtils.getTestMethodData(xlsPath, "testMemberDetailsDataInput");
		Object[] values = {};
		SortedMap<String, SortedMap<String, String>> invoiceNoDataMap = dbUtils.getMultiRowsFromPreparedQuery("facets", dataMap.get("PREPARED_STATEMENT_QUERY"),values);
		
		for(Entry<String, SortedMap<String, String>> entry1 : invoiceNoDataMap.entrySet()) {
			memberDetailsInputSet.add(entry1.getValue().get("BLIV_ID").trim());
		}
		
		for (String invoiceId : memberDetailsInputSet) {
		
			dataMap = ExcelUtils.getTestMethodData(xlsPath, "testMemberDetailsData");
			Object[] values1 = {invoiceId,invoiceId,invoiceId};
			SortedMap<String, SortedMap<String, String>> claimDataResultMap = dbUtils.getMultiRowsFromPreparedQuery("facets", dataMap.get("PREPARED_STATEMENT_QUERY"),values1);
			ArrayList<MemberDetails> memberDetailsList = new ArrayList<MemberDetails>();
			for (Entry<String, SortedMap<String, String>> entry1 : claimDataResultMap.entrySet()) {
				SortedMap<String, String> memberDetailsData = entry1.getValue();
				MemberDetails memberDetails = new MemberDetails();
				memberDetails.setGroupName(memberDetailsData.get("GROUPNAME").trim());
				memberDetails.setGroupBillingId(memberDetailsData.get("GROUPBILLINGID").trim());
				memberDetails.setClaimsCycle(memberDetailsData.get("CLAIMSCYCLE").trim());
				memberDetails.setBillDueDate(memberDetailsData.get("BILDUEDATE").trim());
				memberDetails.setInvoiceNo(memberDetailsData.get("INVOICENO").trim());
				memberDetails.setGroupIdName(memberDetailsData.get("GROUPIDNAME").trim());
				memberDetails.setBillingCategory(memberDetailsData.get("BILLINGCATEGORY").trim());
				memberDetails.setPlanId(memberDetailsData.get("PLANID").trim());
				memberDetails.setClassId(memberDetailsData.get("CLASSID").trim());
				memberDetails.setSubscriberId(memberDetailsData.get("SUBSCRIBERID").trim());
				memberDetails.setSsn(memberDetailsData.get("SSN").trim());
				memberDetails.setSubscriberName(memberDetailsData.get("SUBSCRIBERNAME").trim());
				memberDetails.setPatientName(memberDetailsData.get("PATIENT_NAME").trim());
				memberDetails.setRelationship(memberDetailsData.get("RELATIONSHIP").trim());
				memberDetails.setDept(memberDetailsData.get("DEPT").trim());
				memberDetails.setClaimId(memberDetailsData.get("CLAIMID").trim());
				memberDetails.setCheckNumber(memberDetailsData.get("CHECKNUMBER").trim());
				memberDetails.setPaidDate(memberDetailsData.get("PAIDDATE").trim());
				memberDetails.setFromDate(memberDetailsData.get("FROMDATE").trim());
				memberDetails.setToDate(memberDetailsData.get("TODATE").trim());
				memberDetails.setPayeeName(memberDetailsData.get("PAYEENAME").trim());
				memberDetails.setPayeeId(memberDetailsData.get("PAYEEID").trim());
				memberDetails.setCoverage(memberDetailsData.get("COVERAGE").trim());
				memberDetails.setDeductible(memberDetailsData.get("DEDUCTIBLE").trim());
				memberDetails.setCoinsurance(memberDetailsData.get("COINSURANCE").trim());
				memberDetails.setCopay(memberDetailsData.get("COPAY").trim());
				memberDetails.setMedical(memberDetailsData.get("MEDICAL").trim());
				memberDetails.setCostContainment(memberDetailsData.get("COSTCONTAINMENT").trim());
				memberDetails.setInterest(memberDetailsData.get("INTEREST").trim());
				memberDetails.setDental(memberDetailsData.get("DENTAL").trim());
				memberDetails.setPharmacy(memberDetailsData.get("PHARMACY").trim());
				memberDetails.setBluecard(memberDetailsData.get("BLUECARD").trim());
				memberDetails.setStoploss(memberDetailsData.get("STOPLOSS").trim());
				memberDetails.setHra(memberDetailsData.get("HRA").trim());
				memberDetails.setTotalPaid(memberDetailsData.get("TOTALPAID").trim());
				memberDetailsList.add(memberDetails);
			}
			memberDetailsDBMap.put(invoiceId, memberDetailsList);
			
		}
//		for(Entry<String,List<MemberDetails>> memEntry : memberDetailsDBMap.entrySet()) {
//			System.out.println("Invoice ID:"+memEntry.getValue().get(0).getInvoiceNo());
//			for(MemberDetails mem : memEntry.getValue()) {
//				System.out.println("  Claim ID:"+mem.getClaimId()+" ->"+mem);
//			}
//		}
		return memberDetailsDBMap;
	}

	public Map<String,List<ShieldSaving>> getShieldSaving() {
		DBUtils dbUtils = new DBUtils();
		String xlsPath = new File("").getAbsolutePath()+ "/src/test/resources/AfaInvoiceReportValidationTest.xlsx";
		HashMap<String, List<ShieldSaving>> shieldSavingDBMap = new HashMap<String, List<ShieldSaving>>();
		Map<String, String> dataMap = new HashMap<String, String>();
		dataMap = ExcelUtils.getTestMethodData(xlsPath, "testShieldSavingDataInput");
		Object[] values = {};
		SortedMap<String, SortedMap<String, String>> invoiceNoDataMap = dbUtils.getMultiRowsFromPreparedQuery("facets", dataMap.get("PREPARED_STATEMENT_QUERY"),values);
		
		for(Entry<String, SortedMap<String, String>> entry1 : invoiceNoDataMap.entrySet()) {
			shieldSavingsInputSet.add(entry1.getValue().get("BLIV_ID").trim());
		}
		
		for (String invoiceId : shieldSavingsInputSet) {
			dataMap = ExcelUtils.getTestMethodData(xlsPath, "testShieldSavingData");
			Object[] values1 = {invoiceId};
			SortedMap<String, SortedMap<String, String>> claimDataResultMap = dbUtils.getMultiRowsFromPreparedQuery("facets", dataMap.get("PREPARED_STATEMENT_QUERY"),values1);
			List<ShieldSaving> shieldSavingsList = new ArrayList<ShieldSaving>();
			
			for (Entry<String, SortedMap<String, String>> entry1 : claimDataResultMap.entrySet()) {
				SortedMap<String, String> shieldSavingData = entry1.getValue();
				
				ShieldSaving shieldSaving = new ShieldSaving();
				shieldSaving.setClaimPaymentPeriod(shieldSavingData.get("CLAIMPAYMENTPERIOD").trim());
				shieldSaving.setGroupName(shieldSavingData.get("GROUPNAME").trim());
				shieldSaving.setGroupBillingId(shieldSavingData.get("GROUPBILLINGID").trim());
				shieldSaving.setClaimsCycle(shieldSavingData.get("CLAIMSCYCLE").trim());
				shieldSaving.setBillDueDate(shieldSavingData.get("BILDUEDATE").trim());
				shieldSaving.setInvoiceNo(shieldSavingData.get("INVOICENO").trim());
				shieldSaving.setBillingCategory(shieldSavingData.get("BILLINGCATEGORY").trim());
				shieldSaving.setProviderChargedAmount(shieldSavingData.get("PROVIDERCHARGEDAMOUNT").trim());
				shieldSaving.setSavings(shieldSavingData.get("SAVINGS").trim());
				shieldSaving.setDisallowed(shieldSavingData.get("DISALLOWED").trim());
				shieldSaving.setAllowedAmount(shieldSavingData.get("ALLOWEDAMOUNT").trim());
				shieldSaving.setCostContainment(shieldSavingData.get("COSTCONTAINMENT").trim());
				shieldSaving.setTotal(shieldSavingData.get("TOTAL").trim());
				shieldSavingsList.add(shieldSaving);
			
		}
		
		shieldSavingDBMap.put(invoiceId,shieldSavingsList);
		}
		
		return shieldSavingDBMap;
	}

	public Map<String, List<PlanDetails>> getPlanDetails() {
		DBUtils dbUtils = new DBUtils();
		String xlsPath = new File("").getAbsolutePath()+ "/src/test/resources/AfaInvoiceReportValidationTest.xlsx";
		HashMap<String, List<PlanDetails>> planDetailsDBMap = new HashMap<String, List<PlanDetails>>();
		Map<String, String> dataMap = new HashMap<String, String>();
		dataMap = ExcelUtils.getTestMethodData(xlsPath, "testPlanDetailsDataInput");
		Object[] values = {};
		SortedMap<String, SortedMap<String, String>> invoiceNoDataMap = dbUtils.getMultiRowsFromPreparedQuery("facets", dataMap.get("PREPARED_STATEMENT_QUERY"),values);
		
		for(Entry<String, SortedMap<String, String>> entry1 : invoiceNoDataMap.entrySet()) {
			planDetailsInputSet.add(entry1.getValue().get("BLIV_ID").trim());
		}
		
		for (String invoiceId : planDetailsInputSet) {
			List<PlanDetails> planDetailsDBList = new ArrayList<>();
			dataMap = ExcelUtils.getTestMethodData(xlsPath, "testPlanDetailsData");
			Object[] values1 = {invoiceId};
			SortedMap<String, SortedMap<String, String>> claimDataResultMap = dbUtils.getMultiRowsFromPreparedQuery("facets", dataMap.get("PREPARED_STATEMENT_QUERY"),values1);
			
			for (Entry<String, SortedMap<String, String>> entry1 : claimDataResultMap.entrySet()) {
				SortedMap<String, String> planDetailsData = entry1.getValue();
				PlanDetails planDetails = new PlanDetails();
				planDetails.setGroupName(planDetailsData.get("GROUPNAME").trim());
				planDetails.setAfaId(planDetailsData.get("AFAID").trim());
				planDetails.setClaimsCycle(planDetailsData.get("CLAIMSCYCLE").trim());
				planDetails.setBillDueDate(planDetailsData.get("BILDUEDATE").trim());
				planDetails.setInvoiceNo(planDetailsData.get("INVOICENO").trim());
				planDetails.setGroupIdName(planDetailsData.get("GROUPIDNAME").trim());
				planDetails.setPln(planDetailsData.get("PLN").trim());
				planDetails.setCbc(planDetailsData.get("CBC").trim());
				planDetails.setGrpId(planDetailsData.get("GRPID").trim());
				planDetails.setCoverage(planDetailsData.get("COVERAGE").trim());
				planDetails.setPlanDetailsTotals(planDetailsData.get("PLANDETAILSTOTALS").trim());
				planDetails.setMedical(planDetailsData.get("MEDICAL").trim());
				planDetails.setCostContainment(planDetailsData.get("COSTCONTAINMENT").trim());
				planDetails.setInterest(planDetailsData.get("INTEREST").trim());
				planDetails.setDental(planDetailsData.get("DENTAL").trim());
				planDetails.setPharmacy(planDetailsData.get("PHARMACY").trim());
				planDetails.setStoploss(planDetailsData.get("STOPLOSS").trim());
				planDetails.setBluecard(planDetailsData.get("BLUECARD").trim());
				planDetails.setHra(planDetailsData.get("HRA").trim());
				planDetails.setTotalPaid(planDetailsData.get("TOTALPAID").trim());
				planDetails.setSortOrder1(planDetailsData.get("SORTORDER1").trim());
				planDetails.setSortOrder2(planDetailsData.get("SORTORDER2").trim());
				planDetailsDBList.add(planDetails);
				
			}
		planDetailsDBMap.put(invoiceId, planDetailsDBList);
		}
		return planDetailsDBMap;
	}
}
