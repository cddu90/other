package com.bsc.qa.stt;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;

import com.bsc.qa.framework.utility.DBUtils;

/**
 * 
 * @author ngami01
 *
 */
public class HospitalFileParser {
	// inputFileName :contains full file path
	
	public String inputFileName = null;

	/** csvDataList is used while writing to filename */
	public List<String[]> csvDataList = new ArrayList<String[]>();
	//timestamp is used to add timestamp to filename
	public static String timestamp = new SimpleDateFormat("yyyy-MM-dd-HH-mm-ss").format(new Date());
	// suiteName to store the report location folder
	
	public static String suiteName = System.getProperty("user.dir")
			.substring(System.getProperty("user.dir").lastIndexOf("\\") + 1);
	// to store the complete report location with time stamp
	

	public static Map<String, String> diagProcSequencesMap = new HashMap<>();

	// @param jSONList
	
	public static void writeToJSON(List<String> jSONList, int cnt,String patientAccountNumber) {

		// iterating through each code
		try {
			FileWriter fileWriter = null;
			BufferedWriter bufferedWriter = null;
			String outputFile = System.getenv("JSON_FILE_OUTPUT")+File.separator + "Hospital" +"_"+patientAccountNumber+ "_" + timestamp + "_" + cnt + ".txt";
			fileWriter = new FileWriter(outputFile);
			bufferedWriter = new BufferedWriter(fileWriter);
			//looping through codeblocks
			for (String code : jSONList) {

				bufferedWriter.write(code + System.lineSeparator());

			}

			bufferedWriter.close();
			fileWriter.close();
		} catch (IOException e) {
			System.out.println("exception occured " + e);
		}
	}

	/**
	 * hospitalParsing - creates hospital claim json files
	 */
	public void hospitalFileParsing() {
		ExcelUtils excelUtils = new ExcelUtils();
		Map<String, String> dbMap = new TreeMap<String, String>();
		String xlsPath = System.getenv("CLAIMS_JSON_UTILITY_DATASHEET")+"\\"+"ClaimJsonFileCreationMain."+"xlsx";
		/**
		 * inputDataMap - contains input data from medical claim excel sheet
		 */
		Map<String, Map<String, String>> inputDataMap = new HashMap<String, Map<String, String>>();
		inputDataMap.putAll(excelUtils.cacheAllExcelData(System.getenv("JSON_FILE_INPUT")+"\\"+"HospitalInputJsonSheet."+"xlsx"));
		//tempCnt -used to loop over line items
		int tempCnt = 1;
		/**
		 * tempinputDataMap - final input map with all line numbers
		 */
		Map<String, Map<String, String>> tempinputDataMap = new HashMap<String, Map<String, String>>();
		Set<String> testCases = new HashSet<String>();
		inputDataMap.remove("");
		//storing claims in set
		for (String key : inputDataMap.keySet()) {
			if (!"".equals(inputDataMap.get(key).get("Test_Name"))) {
				testCases.add(inputDataMap.get(key).get("Test_Name"));
			}
		}
		/**
		 * jsonList - Stores all JSON blocks
		 */
		List<String> jsonList = new ArrayList<String>();
		// Looping all claims present in hospital input sheet
		for (String tcKey : testCases) {
			jsonList.clear();
	
			tempinputDataMap.putAll(inputDataMap);
			//to implement single claim with all line numbers
			for (String inputKey : inputDataMap.keySet()) {
				//condition to get all line items for single claim id
				if (!tcKey.equals(inputDataMap.get(inputKey).get("Test_Name"))) {
					tempinputDataMap.remove(inputKey);
				}
			}
			String patientAccountNumber="";
			// looping over all line items to fetch relevant details
			for (String tc : tempinputDataMap.keySet()) {
				System.out.println("DataSheet Workbook Path : "+xlsPath);
				Map<String, Map<String, String>> outerdataMap = excelUtils.cacheAllExcelData(xlsPath);
				Map<String, String> dataMap = outerdataMap.get("ClaimJsonFileCreationMain");
				String firstRowCnt = "";
				// fetching all provider details from input sheet
				for (String fistRowData : tempinputDataMap.keySet()) {
					//fetching provider id from the first row
					if (!tempinputDataMap.get(fistRowData).get("Provider_id").equals("")) {
						firstRowCnt = fistRowData;
					}
				}
				dbMap.putAll(getDataFromQuery(dataMap.get("Provider_Details"),
						tempinputDataMap.get(firstRowCnt).get("Provider_id")));
				String subscriberSuffix = tempinputDataMap.get(firstRowCnt).get("subscriber_suffix").replace(".0", "");
				dbMap.putAll(getDataFromQuery(dataMap.get("Subscriber_Details"),
						tempinputDataMap.get(firstRowCnt).get("subscriber_id"), subscriberSuffix));
				//defaulting NPI to specific value
				if("".equals(dbMap.get("PRPR_NPI")) || dbMap.get("PRPR_NPI")==null || " ".equals(dbMap.get("PRPR_NPI")) ) {
				//	System.out.println("here");
					dbMap.put("PRPR_NPI", "1841315736");
				}
				String introBlock = "{\n\t\"resourceType\": \"Claim\",\n\t\"id\": \"1\",\n\t\"contained\": [";
				System.out.println(introBlock);
				String practitionerBlock = "\t\t{\n\t\t\t\"resourceType\": \"Practitioner\",\n\t\t\t\"id\": \""
						+ dbMap.get("PRPR_ID") + "\",\n"
						+ "\t\t\t\"identifier\": [\n\t\t\t\t{\n\t\t\t\t\t\"system\": \"http://blueshieldca.com/?prpr_id\",\n\t\t\t\t\t\"value\": \""
						+ dbMap.get("PRPR_ID") + "\"\n\t\t\t\t},\n"
						+ "\t\t\t\t{\n\t\t\t\t\t\"system\": \"http://blueshieldca.com/?npi\",\n\t\t\t\t\t\"value\": \""
						+ dbMap.get("PRPR_NPI") + "\"\n\t\t\t\t}\n\t\t\t],\n"
						+ "\t\t\t\"name\": [\n\t\t\t\t{\n\t\t\t\t\t\"given\": [\n\t\t\t\t\t\t\""
						+ dbMap.get("PRPR_NAME") + "\"\n\t\t\t\t\t]\n\t\t\t\t}\n\t\t\t],\n"
						+ "\t\t\t\"address\": [\n\t\t\t\t{\n\t\t\t\t\t\"use\": \"billing\",\n\t\t\t\t\t\"line\": [\n\t\t\t\t\t\t\""
						+ dbMap.get("PRAD_ADDR1") + "\"\n\t\t\t\t\t],\n\t\t\t\t\t\"city\": \"" + dbMap.get("PRAD_CITY")
						+ "\",\n\t\t\t\t\t\"district\": \"" + dbMap.get("PRAD_STATE")
						+ "\",\n\t\t\t\t\t\"postalCode\": \"" + dbMap.get("PRAD_ZIP")
						+ "\",\n\t\t\t\t\t\"country\": \"USA\"\n\t\t\t\t}\n\t\t\t],\n"
						+ "\t\t\t\"qualification\": [\n\t\t\t\t{\n\t\t\t\t\t\"identifier\": [\n\t\t\t\t\t\t{\n\t\t\t\t\t\t\t\"system\": \"http://example.org/UniversityIdentifier\",\n\t\t\t\t\t\t\t\"value\": \"12345\"\n\t\t\t\t\t\t}\n\t\t\t\t\t],\n\t\t\t\t\t\"code\": {\n\t\t\t\t\t\t\"coding\": [\n\t\t\t\t\t\t\t{\n\t\t\t\t\t\t\t\t\"system\": \"http://terminology.hl7.org/CodeSystem/v2-0360/2.7\",\n\t\t\t\t\t\t\t\t\"code\": \"Specialty code\",\n\t\t\t\t\t\t\t\t\"display\": \"Bachelor of Science\"\n\t\t\t\t\t\t\t}\n\t\t\t\t\t\t]\n\t\t\t\t\t}\n\t\t\t\t}\n\t\t\t]\n\t\t},";
				 patientAccountNumber = tempinputDataMap.get(tc).get("Patient_Account_Number");
				//defaulting PAT
				if ("".equals(patientAccountNumber) || patientAccountNumber == null) {
					patientAccountNumber = "PAC" + tempinputDataMap.get(firstRowCnt).get("subscriber_id");
				}
				String gender = "male";
				// values to be displayed for gender
				if ("F".equals(dbMap.get("MEME_SEX"))) {
					gender = "female";
				}
			//	System.out.println("birth date "+dbMap);
				String providerBlock = "\t\t{\n\t\t\t\"resourceType\": \"Patient\",\n\t\t\t\"id\": \""
						+ dbMap.get("MEME_CK") + "\",\n\t\t\t\"name\": [\n\t\t\t\t{\n\t\t\t\t\t\"family\": \""
						+ dbMap.get("SBSB_LAST_NAME") + "\",\n\t\t\t\t\t\"given\": [\n\t\t\t\t\t\t\""
						+ dbMap.get("SBSB_FIRST_NAME") + "\"\n\t\t\t\t\t]\n\t\t\t\t}\n\t\t\t],\n"
						+ "\t\t\t\"address\": [\n\t\t\t\t{\n\t\t\t\t\t\"use\": \"home\",\n\t\t\t\t\t\"line\": [\n\t\t\t\t\t\t\""
						+ dbMap.get("SBAD_ADDR1") + "\"\n\t\t\t\t\t],\n\t\t\t\t\t\"city\": \"" + dbMap.get("SBAD_CITY")
						+ "\",\n\t\t\t\t\t\"postalCode\": \"" + dbMap.get("SBAD_ZIP")
						+ "\",\n\t\t\t\t\t\"country\": \"USA\"\n\t\t\t\t}\n\t\t\t],\n"
						+ "\t\t\t\"identifier\": [\n\t\t\t\t{\n\t\t\t\t\t\"system\": \"http://blueshieldca.com/?meme_ck\",\n\t\t\t\t\t\"value\": \""
						+ dbMap.get("MEME_CK")
						+ "\"\n\t\t\t\t},\n\t\t\t\t{\n\t\t\t\t\t\"system\": \"http://www.blueshieldca.com/?medical_record_number\",\n\t\t\t\t\t\"value\": \"FYNL9668\"\n\t\t\t\t},\n\t\t\t\t{\n\t\t\t\t\t\"system\": \"http://www.blueshieldca.com/?patient_account_number\",\n\t\t\t\t\t\"value\": \""
						+ patientAccountNumber + "\"\n\t\t\t\t}\n\t\t\t],\n" + "\t\t\t\"birthDate\": \""
						+ dbMap.get("MEME_BIRTH_DT").substring(0, 10) + "\"," + "\n\t\t\t\"gender\": \"" + gender
						+ "\","
						+ "\n\t\t\t\"extension\": [\n\t\t\t\t{\n\t\t\t\t\t\"url\": \"Facets\",\n\t\t\t\t\t\"valueString\": \"FUTURE USE\"\n\t\t\t\t}\n\t\t\t]\n\t\t},\n"
						+ "\t\t{\n\t\t\t\"resourceType\": \"Patient\",\n\t\t\t\"id\": \""
						+ tempinputDataMap.get(firstRowCnt).get("subscriber_id")
						+ "\",\n\t\t\t\"name\": [\n\t\t\t\t{\n\t\t\t\t\t\"family\": \"" + dbMap.get("SBSB_LAST_NAME")
						+ "\",\n\t\t\t\t\t\"given\": [\n\t\t\t\t\t\t\"" + dbMap.get("SBSB_FIRST_NAME")
						+ "\"\n\t\t\t\t\t]\n\t\t\t\t}\n\t\t\t],\n"
						+ "\t\t\t\"address\": [\n\t\t\t\t{\n\t\t\t\t\t\"use\": \"home\",\n\t\t\t\t\t\"line\": [\n\t\t\t\t\t\t\""
						+ dbMap.get("SBAD_ADDR1") + "\"\n\t\t\t\t\t],\n\t\t\t\t\t\"city\": \"" + dbMap.get("SBAD_CITY")
						+ "\",\n\t\t\t\t\t\"postalCode\": \"" + dbMap.get("SBAD_ZIP")
						+ "\",\n\t\t\t\t\t\"country\": \"USA\"\n\t\t\t\t}\n\t\t\t],\n"
						+ "\t\t\t\"identifier\": [\n\t\t\t\t{\n\t\t\t\t\t\"system\": \"http://www.blueshieldca.com/?sbsb_ck\",\n\t\t\t\t\t\"value\": \""
						+ dbMap.get("SBSB_CK") + "\"\n\t\t\t\t}\n\t\t\t]\n\t\t},";
				System.out.println(providerBlock);
				String coverageBlock = "\t\t{\n\t\t\t\"resourceType\": \"Coverage\",\n\t\t\t\"id\": \""
						+ tempinputDataMap.get(firstRowCnt).get("subscriber_id")
						+ "\",\n\t\t\t\"status\": \"active\",\n\t\t\t\"beneficiary\": {\n\t\t\t\t\"reference\": \"#"
						+ dbMap.get("MEME_CK")
						+ "\",\n\t\t\t\t\"type\": \"Patient\"\n\t\t\t},\n\t\t\t\"policyHolder\": {\n\t\t\t\t\"reference\": \"#"
						+ tempinputDataMap.get(firstRowCnt).get("subscriber_id")
						+ "\",\n\t\t\t\t\"display\": \"Subscriber's reference\",\n\t\t\t\t\"type\": \"Patient\"\n\t\t\t},\n"
						+ "\t\t\t\"payor\": [\n\t\t\t\t{\n\t\t\t\t\t\"reference\": \"#BSC1\",\n\t\t\t\t\t\"display\": \"Insurance company identifier\",\n\t\t\t\t\t\"type\": \"Organization\"\n\t\t\t\t}\n\t\t\t],\n\t\t\t\"subscriber\": {\n\t\t\t\t\"reference\": \"#"
						+ tempinputDataMap.get(firstRowCnt).get("subscriber_id")
						+ "\",\n\t\t\t\t\"display\": \"Subscriber's reference\",\n\t\t\t\t\"type\": \"Patient\"\n\t\t\t},\n\t\t\t\"relationship\": {\n\t\t\t\t\"coding\": [\n\t\t\t\t\t{\n\t\t\t\t\t\t\"code\": \"self\"\n\t\t\t\t\t}\n\t\t\t\t]\n\t\t\t},\n"
						+ "\t\t\t\"extension\": [\n\t\t\t\t{\n\t\t\t\t\t\"url\": \"groupName\",\n\t\t\t\t\t\"valueString\": \"grpid-XXXXX\"\n\t\t\t\t}\n\t\t\t]\n\t\t},";
				System.out.println(coverageBlock);
				String defaultOrganizationBlock = "\t\t{\n\t\t\t\"resourceType\": \"Organization\",\n\t\t\t\"id\": \"BSC1\",\n\t\t\t\"identifier\": [\n\t\t\t\t{\n\t\t\t\t\t\"system\": \"Facets\",\n\t\t\t\t\t\"value\": \"Blue Shield of California\"\n\t\t\t\t}\n\t\t\t],\n\t\t\t\"extension\": [\n\t\t\t\t{\n\t\t\t\t\t\"url\": \"Facets\",\n\t\t\t\t\t\"valueString\": \"FUTURE USE\"\n\t\t\t\t}\n\t\t\t]\n\t\t},\n\t\t{\n\t\t\t\"resourceType\": \"Organization\",\n\t\t\t\"id\": \"org-prpr-id\",\n\t\t\t\"identifier\": [\n\t\t\t\t{\n\t\t\t\t\t\"system\": \"http://blueshieldca.com/?Provider_ID\",\n\t\t\t\t\t\"value\": \"org-prpr-id\"\n\t\t\t\t},\n\t\t\t\t{\n\t\t\t\t\t\"system\": \"http://blueshieldca.com/?Facets\",\n\t\t\t\t\t\"value\": \"tax-id\"\n\t\t\t\t}\n\t\t\t],\n"
						+ "\t\t\t\"extension\": [\n\t\t\t\t{\n\t\t\t\t\t\"url\": \"https://www.blueshiledca.com/Facets\",\n\t\t\t\t\t\"valueString\": \"FUTURE USE\"\n\t\t\t\t}\n\t\t\t],\n\t\t\t\"address\": [\n\t\t\t\t{\n\t\t\t\t\t\"use\": \"billing\",\n\t\t\t\t\t\"line\": [\n\t\t\t\t\t\t\"Galapagosweg 91\"\n\t\t\t\t\t],\n\t\t\t\t\t\"city\": \"Den Burg\",\n\t\t\t\t\t\"postalCode\": \"9105 PZ\",\n\t\t\t\t\t\"country\": \"NLD\"\n\t\t\t\t},\n\t\t\t\t{\n\t\t\t\t\t\"use\": \"work\",\n\t\t\t\t\t\"line\": [\n\t\t\t\t\t\t\"PO Box 2311\"\n\t\t\t\t\t],\n\t\t\t\t\t\"city\": \"Den Burg\",\n\t\t\t\t\t\"postalCode\": \"9100 AA\",\n\t\t\t\t\t\"country\": \"NLD\"\n\t\t\t\t}\n\t\t\t]\n\t\t}\n\t],";
				System.out.println(defaultOrganizationBlock);
				Date date = new Date();
				SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");
				String currentDate = formatter.format(date);
				Set<String> procCode = new HashSet<String>();
				Set<String> diaCode = new HashSet<String>();
				Set<String> fromDate = new HashSet<String>();
				Set<String> toDate = new HashSet<String>();
				//storing unique codes for all line items
				for (String key : tempinputDataMap.keySet()) {
					procCode.add(tempinputDataMap.get(key).get("Procedure_Code"));
					diaCode.add(tempinputDataMap.get(key).get("Diagnosis_Code"));
					fromDate.add(tempinputDataMap.get(key).get("FROM Service Date(YYYY-MM-DD)"));
					toDate.add(tempinputDataMap.get(key).get("TO Service Date(YYYY-MM-DD)"));
				}
				List<String> fromDateList = new ArrayList<>(fromDate);
				Collections.sort(fromDateList);
				List<String> toDateList = new ArrayList<>(toDate);
				Collections.sort(toDateList);
				String multipleSmallBlocks = "\t\"identifier\": [\n\t\t{\n\t\t\t\"system\": \"http://www.blueshieldca.com/?transaction_id\",\n\t\t\t\"value\": \"1\"\n\t\t}\n\t],\n\t\"status\": \"active\",\n\t\"type\": {\n\t\t\"coding\": [\n\t\t\t{\n\t\t\t\t\"system\": \"claim_type\",\n\t\t\t\t\"code\": \"medical\"\n\t\t\t}\n\t\t]\n\t},\n\t\"subType\": {\n\t\t\"coding\": [\n\t\t\t{\n\t\t\t\t\"system\": \"claim_subtype\",\n\t\t\t\t\"code\": \"hospital\"\n\t\t\t}\n\t\t]\n\t},\n"
						+ "\t\"use\": \"claim\",\n\t\"billablePeriod\": {\n\t\t\"start\": \"" + fromDateList.get(0)
						+ "T12:00:00-07:00" + "\",\n\t\t\"end\": \"" + toDateList.get(toDateList.size() - 1)
						+ "T23:00:00-07:00" + "\"\n\t},\n\t\"patient\": {\n\t\t\"reference\": \"#"
						+ dbMap.get("MEME_CK")
						+ "\",\n\t\t\"type\": \"Patient\",\n\t\t\"display\": \"Patient reference\"\n\t},\n\t\"created\": \""
						+ currentDate
						+ "\",\n\t\"enterer\": {\n\t\t\"identifier\": {\n\t\t\t\"system\": \"http://blueshieldca.com/?facets_rtc_claim_identifier\",\n\t\t\t\"value\": \"OODA\"\n\t\t}\n\t},\n"
						+ "\t\"insurer\": {\n\t\t\"reference\": \"#BSC1\",\n\t\t\"display\": \"Insurance company identifier\",\n\t\t\"type\": \"Organization\"\n\t},\n\t\"provider\": {\n\t\t\"reference\": \"#"
						+ dbMap.get("PRPR_ID")
						+ "\",\n\t\t\"type\": \"Practitioner\",\n\t\t\"display\": \"BILL\"\n\t},\n\t\"priority\": {\n\t\t\"coding\": [\n\t\t\t{\n\t\t\t\t\"code\": \"normal\"\n\t\t\t}\n\t\t]\n\t},\n\t\"payee\": {\n\t\t\"type\": {\n\t\t\t\"coding\": [\n\t\t\t\t{\n\t\t\t\t\t\"code\": \"provider\"\n\t\t\t\t}\n\t\t\t]\n\t\t},\n\t\t\"party\": {\n\t\t\t\"reference\": \"#org-prpr-id\",\n\t\t\t\"display\": \"Pay-To Name and Address\",\n\t\t\t\"type\": \"Organization\"\n\t\t}\n\t},\n"
						+ "\t\"facility\": {\n\t\t\"identifier\": {\n\t\t\t\"system\": \"http://jurisdiction.org/facilities\",\n\t\t\t\"value\": \"FA0001415001\"\n\t\t}\n\t},";
				System.out.println(multipleSmallBlocks);
				// defaulting discharge codes to specific values
				if("".equals(tempinputDataMap.get(firstRowCnt).get("Discharge_Code")) || " ".equals(tempinputDataMap.get(firstRowCnt).get("Discharge_Code")) || tempinputDataMap.get(firstRowCnt).get("Discharge_Code")==null) {
					tempinputDataMap.get(firstRowCnt).replace("Discharge_Code", "0001");
				}
				String billCode=tempinputDataMap.get(firstRowCnt).get("Type_of_Bill").replace(".0", "").length()<4?"0"+tempinputDataMap.get(firstRowCnt).get("Type_of_Bill").replace(".0", ""):tempinputDataMap.get(firstRowCnt).get("Type_of_Bill").replace(".0", "");
				String disCode=tempinputDataMap.get(firstRowCnt).get("Discharge_Code").replace(".0", "").length()<4?"0"+tempinputDataMap.get(firstRowCnt).get("Discharge_Code").replace(".0", ""):tempinputDataMap.get(firstRowCnt).get("Discharge_Code").replace(".0", "");
				String fromSupportInfomultipleBlocks = "\t\"supportingInfo\": [\n\t\t{\n\t\t\t\"sequence\": 1,\n\t\t\t\"category\": {\n\t\t\t\t\"coding\": [\n\t\t\t\t\t{\n\t\t\t\t\t\t\"system\": \"http://www.blueshieldca.com/?type_of_admission_codes\",\n\t\t\t\t\t\t\"code\": \""
						+ tempinputDataMap.get(firstRowCnt).get("Type_of_Admission_Code").replace(".0", "")
						+ "\"\n\t\t\t\t\t}\n\t\t\t\t]\n\t\t\t}\n\t\t},\n"
						+ "\t\t{\n\t\t\t\"sequence\": 2,\n\t\t\t\"category\": {\n\t\t\t\t\"coding\": [\n\t\t\t\t\t{\n\t\t\t\t\t\t\"system\": \"http://www.blueshieldca.com/?source_of_admission_codes\",\n\t\t\t\t\t\t\"code\": \""
						+ tempinputDataMap.get(firstRowCnt).get("Source_of_Admission_Code").replace(".0", "")
						+ "\"\n\t\t\t\t\t}\n\t\t\t\t]\n\t\t\t}\n\t\t},\n"
						+ "\t\t{\n\t\t\t\"sequence\": 3,\n\t\t\t\"category\": {\n\t\t\t\t\"coding\": [\n\t\t\t\t\t{\n\t\t\t\t\t\t\"system\": \"http://www.blueshieldca.com/?discharge_codes\",\n\t\t\t\t\t\t\"code\": \""
						+ disCode
						+ "\"\n\t\t\t\t\t}\n\t\t\t\t]\n\t\t\t}\n\t\t},\n"
						+ "\t\t{\n\t\t\t\"sequence\": 9,\n\t\t\t\"category\": {\n\t\t\t\t\"coding\": [\n\t\t\t\t\t{\n\t\t\t\t\t\t\"system\": \"hospitalization_start_end_date\",\n\t\t\t\t\t\t\"code\": \"hospitalized\"\n\t\t\t\t\t}\n\t\t\t\t]\n\t\t\t},\n\t\t\t\"timingPeriod\": {\n\t\t\t\t\"start\": \""+fromDateList.get(0)+"T12:00:00-07:00\",\n\t\t\t\t\"end\": \""+toDateList.get(toDateList.size() - 1)+"T23:00:00-07:00\"\n\t\t\t}\n\t\t},\n"
						+ "\t\t{\n\t\t\t\"sequence\": 21,\n\t\t\t\"category\": {\n\t\t\t\t\"coding\": [\n\t\t\t\t\t{\n\t\t\t\t\t\t\"system\": \"http://www.blueshieldca.com/?type_of_bill\",\n\t\t\t\t\t\t\"code\": \""
						+ billCode
						+ "\"\n\t\t\t\t\t}\n\t\t\t\t]\n\t\t\t}\n\t\t}\n\t],";
				System.out.println(fromSupportInfomultipleBlocks);
				String careTeamBlockCode = "\t\"careTeam\": [\n\t\t{\n\t\t\t\"sequence\": 1,\n\t\t\t\"provider\": {\n\t\t\t\t\"reference\": \"#"
						+ dbMap.get("PRPR_ID")
						+ "\",\n\t\t\t\t\"display\": \"REND\",\n\t\t\t\t\"type\": \"Practitioner\"\n\t\t\t}\n\t\t},\n"
						+ "\t\t{\n\t\t\t\"sequence\": 2,\n\t\t\t\"provider\": {\n\t\t\t\t\"reference\": \"#"
						+ dbMap.get("PRPR_ID")
						+ "\",\n\t\t\t\t\"display\": \"OPR\",\n\t\t\t\t\"type\": \"Practitioner\"\n\t\t\t}\n\t\t}\n\t],";
				System.out.println(careTeamBlockCode);
				String diagnosisBlockStart = "\t\"diagnosis\": [";
				System.out.println(diagnosisBlockStart);
				String diagnosisBlockEnd = "\t],";
				System.out.println(diagnosisBlockEnd);
				jsonList.add(introBlock);
				jsonList.add(practitionerBlock);
				jsonList.add(providerBlock);
				jsonList.add(coverageBlock);
				jsonList.add(defaultOrganizationBlock);
				jsonList.add(multipleSmallBlocks);
				jsonList.add(fromSupportInfomultipleBlocks);
				jsonList.add(careTeamBlockCode);
				jsonList.add(diagnosisBlockStart);
				int cnt = 1;
				int diagCodeSetLength = diaCode.size();
				//looping over line items for diagnosis code
				for (String diCode : diaCode) {
					String diagnosisSequenceBlock = "\t\t{\n\t\t\t\"sequence\": " + cnt
							+ ",\n\t\t\t\"diagnosisCodeableConcept\": {\n\t\t\t\t\"coding\": [\n\t\t\t\t\t{\n"
							+ "\t\t\t\t\t\t\"system\": \"principal_diagnosis_code\",\n\t\t\t\t\t\t\"code\": \"" + diCode
							+ "\"\n\t\t\t\t\t}\n\t\t\t\t]\n\t\t\t}\n\t\t},";
					diagProcSequencesMap.put(diCode, String.valueOf(cnt));
					//checking diagnosis code length and storing it to list
					if (cnt == diagCodeSetLength) {
						diagnosisSequenceBlock = diagnosisSequenceBlock.substring(0,
								diagnosisSequenceBlock.length() - 1);
					}
					cnt++;
					jsonList.add(diagnosisSequenceBlock);
				}
				jsonList.add(diagnosisBlockEnd);
				cnt = 1;
				int procCodeSetLength = procCode.size();
				String procedureStartBlock = "\t\"procedure\": [";
				System.out.println(procedureStartBlock);
				jsonList.add(procedureStartBlock);
				for (String proCode : procCode) {
					Map<String, String> procMap = new HashMap<>();
					procMap.putAll(getDataFromQuery("select IPCD_DESC from FC_CMC_IPCD_PROC_CD where IPCD_ID = ?",
							proCode.replace(".0", "")));
					String prCode=proCode;
					//defaulting procedure code to specific value
					if(proCode==null || " ".equals(proCode) || "".equals(proCode)) {
						prCode="99219";
					}
					String procedureSequenceBlock = "\t\t{\n\t\t\t\"sequence\": " + cnt
							+ ",\n\t\t\t\"type\": [\n\t\t\t\t{\n\t\t\t\t\t\"coding\": [\n\t\t\t\t\t\t{\n\t\t\t\t\t\t\t\"code\": \"Procedure\"\n\t\t\t\t\t\t}\n\t\t\t\t\t]\n\t\t\t\t}\n\t\t\t],\n"
							+ "\t\t\t\"date\": \"" + currentDate
							+ "\",\n\t\t\t\"procedureCodeableConcept\": {\n\t\t\t\t\"coding\": [\n\t\t\t\t\t{\n\t\t\t\t\t\t\"code\": \""
							+ prCode.replace(".0", "") + "\"\n\t\t\t\t\t}\n\t\t\t\t],\n\t\t\t\t\"text\": \""
							+ procMap.get("IPCD_DESC") + "\"\n\t\t\t}\n\t\t},";
					diagProcSequencesMap.put(prCode.replace(".0", ""), String.valueOf(cnt));
					//checking procedure code length and storing it to list
					if (cnt == procCodeSetLength) {
						procedureSequenceBlock = procedureSequenceBlock.substring(0,
								procedureSequenceBlock.length() - 1);
					}
					cnt++;
					jsonList.add(procedureSequenceBlock);
				}
				String procedureEndBlock = "\t],";
				System.out.println(procedureEndBlock);
				jsonList.add(procedureEndBlock);
				String insuranceBlock = "\t\"insurance\": [\n\t\t{\n\t\t\t\"sequence\": 1,\n\t\t\t\"focal\": true,\n\t\t\t\"coverage\": {\n\t\t\t\t\"reference\": \"#"
						+ tempinputDataMap.get(firstRowCnt).get("subscriber_id")
						+ "\",\n\t\t\t\t\"type\": \"Coverage\",\n\t\t\t\t\"display\": \"Subscriber's reference\"\n\t\t\t},\n\t\t\t\"preAuthRef\": [\n\t\t\t\t\"codes\"\n\t\t\t]\n\t\t}\n\t],";
				System.out.println(insuranceBlock);
				jsonList.add(insuranceBlock);
				Double totalAmountValue = 0.0;
				String lineItemStartBlock = "\t\"item\": [";
				System.out.println(lineItemStartBlock);
				jsonList.add(lineItemStartBlock);
				String lineitemBlock = "";
				int icnt = 1;
				//looping over all line items of a claim
				for (String tc1 : tempinputDataMap.keySet()) {
					Double calculatedNetVal = Double.parseDouble(tempinputDataMap.get(tc1).get("Amount(Unit Price)"))
							* Double.parseDouble(tempinputDataMap.get(tc1).get("Quantity (units)"));
					String calculatedNetValue = String.valueOf(calculatedNetVal);
					Map<String, String> revenueMap = new HashMap<String, String>();
					revenueMap.putAll(getDataFromQuery("select RCRC_DESC from FC_CMC_RCRC_RC_DESC where RCRC_ID = ?",
							tempinputDataMap.get(tc1).get("Revenue_Code").replace(".0", "")));
					String revCode=tempinputDataMap.get(tc1).get("Revenue_Code").replace(".0", "").length()<4?"0"+tempinputDataMap.get(tc1).get("Revenue_Code").replace(".0", ""):tempinputDataMap.get(tc1).get("Revenue_Code").replace(".0", "");
					lineitemBlock = "\t\t{\n\t\t\t\"sequence\": " + icnt
							+ ",\n\t\t\t\"careTeamSequence\": [\n\t\t\t\t1\n\t\t\t],\n\t\t\t\"procedureSequence\": [\n\t\t\t\t"
							+ diagProcSequencesMap
									.get(tempinputDataMap.get(tc1).get("Procedure_Code").replace(".0", ""))
							+ "\n\t\t\t],\n\t\t\t\"productOrService\": {\n\t\t\t\t\"coding\": [\n\t\t\t\t\t{\n\t\t\t\t\t\t\"system\": \"http://blueshieldca.com/?revenue_code\",\n\t\t\t\t\t\t\"code\": \""
							+ revCode
							+ "\"\n\t\t\t\t\t}\n\t\t\t\t]\n\t\t\t},\n"
							+ "\t\t\t\"servicedPeriod\": {\n\t\t\t\t\"start\": \""
							+ tempinputDataMap.get(tc1).get("FROM Service Date(YYYY-MM-DD)") + "T12:00:00-07:00"
							+ "\",\n\t\t\t\t\"end\": \"" + tempinputDataMap.get(tc1).get("TO Service Date(YYYY-MM-DD)")
							+ "T23:00:00-07:00" + "\"\n\t\t\t},\n\t\t\t\"quantity\": {\n\t\t\t\t\"value\": "
							+ tempinputDataMap.get(tc1).get("Quantity (units)").replace(".0", "")
							+ "\n\t\t\t},\n\t\t\t\"revenue\": {\n\t\t\t\t\"coding\": [\n\t\t\t\t\t{\n\t\t\t\t\t\t\"system\": \"http://blueshieldca.com/?revenue_code\",\n\t\t\t\t\t\t\"code\": \""
							+ revCode
							+ "\",\n\t\t\t\t\t\t\"display\": \"" + revenueMap.get("RCRC_DESC")
							+ "\"\n\t\t\t\t\t}\n\t\t\t\t]\n\t\t\t},\n\t\t\t\"locationCodeableConcept\": {\n\t\t\t\t\"coding\": [\n\t\t\t\t\t{\n\t\t\t\t\t\t\"system\": \"http://blueshieldca.com/?place_of_service\",\n\t\t\t\t\t\t\"code\": \""
							+ "00" + "\"\n"
							+ "\t\t\t\t\t}\n\t\t\t\t]\n\t\t\t},\n\t\t\t\"unitPrice\": {\n\t\t\t\t\"value\": "
							+ tempinputDataMap.get(tc1).get("Amount(Unit Price)")
							+ ",\n\t\t\t\t\"currency\": \"USD\"\n\t\t\t},\n\t\t\t\"net\": {\n\t\t\t\t\"value\": "
							+ calculatedNetValue
							+ ",\n\t\t\t\t\"currency\": \"USD\"\n\t\t\t},\n\t\t\t\"diagnosisSequence\": [\n\t\t\t\t"
							+ diagProcSequencesMap.get(tempinputDataMap.get(tc1).get("Diagnosis_Code"))
							+ "\n\t\t\t]\n\t\t},";
					//verifying line items with map keyset
					if (icnt == tempinputDataMap.size()) {
						lineitemBlock = lineitemBlock.substring(0, lineitemBlock.length() - 1);
					}

					jsonList.add(lineitemBlock);
					System.out.println(lineitemBlock);
					totalAmountValue = totalAmountValue + calculatedNetVal;
					icnt++;
				}
				String lineItemEndBlock = "\t],";
				System.out.println(lineItemEndBlock);
				jsonList.add(lineItemEndBlock);
				Double totalAmt = totalAmountValue;
				String totalAmountEndBlock = "\t\"total\": {\n\t\t\"value\": " + totalAmt
						+ ",\n\t\t\"currency\": \"USD\"\n\t}\n}";
				System.out.println(totalAmountEndBlock);
				jsonList.add(totalAmountEndBlock);
				break;
			}
			writeToJSON(jsonList, tempCnt,patientAccountNumber);
			tempCnt++;
		}
	}

	/**
	 * @param query
	 * @param xmlFileMap
	 * @param claimId
	 */

	private static Map<String, String> getDataFromQuery(String query, Object... claimId) {
		Map<String, String> finalDbMap = new HashMap<String, String>();
		try {

			finalDbMap = new DBUtils().getDataFromPreparedQuery("facets", query, claimId);
		} catch (ArrayIndexOutOfBoundsException e) {

			System.out.println("!!DB Exception in getDataFromQuery method!!");
		}

		return finalDbMap;
	}

}
