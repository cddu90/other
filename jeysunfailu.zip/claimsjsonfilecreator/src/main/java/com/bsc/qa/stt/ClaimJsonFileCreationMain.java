package com.bsc.qa.stt;

import java.io.File;

/**
 * 
 * @author ngami01
 *
 */
public class ClaimJsonFileCreationMain {

	//@param args
	public static void main(String[] args) {

		File folder = new File(System.getenv("JSON_FILE_INPUT"));
		File[] listOfFiles = folder.listFiles();
		//	Looping on the medical and hospital input sheet
		for (File listOfFile:listOfFiles ) {

			// calls medical file generator based on input file name
			if (listOfFile.getName().contains("Medical")) {
				MedicalFileParser medicalfileParser = new MedicalFileParser();
				medicalfileParser.medicalFileParsing();

				// calls hospital file generator based on input file name
			} else if (listOfFile.getName().contains("Hospital")) {
				HospitalFileParser hospitalFileParser = new HospitalFileParser();
				hospitalFileParser.hospitalFileParsing();
			}
		}
	}
}