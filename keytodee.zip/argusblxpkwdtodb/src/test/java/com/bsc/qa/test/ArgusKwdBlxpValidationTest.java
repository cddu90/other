package com.bsc.qa.test;

import java.io.File;
import java.lang.reflect.Method;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.assertj.core.api.SoftAssertions;
import org.testng.IHookCallBack;
import org.testng.IHookable;
import org.testng.ITestResult;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.bsc.qa.framework.base.BaseTest;
import com.bsc.qa.framework.utility.DBUtils;
import com.bsc.qa.framework.utility.ExcelUtils;
import com.bsc.qa.test.parser.KeywordRecord;
import com.bsc.qa.test.parser.KwdFileParser;
import com.relevantcodes.extentreports.LogStatus;

/**
 * 
 * @author skumar33
 *
 */
public class ArgusKwdBlxpValidationTest extends BaseTest implements IHookable {

	
	
	/**
	 * Test method validates all the fields of BOR keyword File
	 * 
	 * @param record
	 */
	@Test(dataProvider = "masterDataProvider",enabled = true) 
	public void testKewordRecord(KeywordRecord record){
		
		DBUtils dbUtils = new DBUtils(); 
		String xlsPath = new File("").getAbsolutePath()+ "/src/test/resources/"+ this.getClass().getSimpleName() + ".xlsx";
		Map<String, String> dataMap;
		boolean dataPresent = true; 
		String claimId = record.getClaimNumber();
		System.out.println("Claim ID :"+claimId);
		String batchId = record.getRunDate().trim() 
						+record.getBatchName().trim()
						+record.getSequenceNumber().trim();
		Object[] values1 = {batchId,claimId};
		dataMap = ExcelUtils.getTestMethodData(xlsPath, "blxpQuery");
		reportInit("Keyword V/S Blxp ", "claim id :"+claimId,"");
		Map<String, String> blxpResult = dbUtils.getDataFromPreparedQuery("facets", dataMap.get("PREPARED_STATEMENT_QUERY"),values1);
		if(blxpResult.size()>0) {
			
			// Record Type Validation
			softAssertions.assertThat(record.getRecordType().trim())
			.as("Record Type for claim id - "+claimId 
			+"  || Actual Value(Keyword File) ==> " + record.getRecordType().trim()
			+"  || Expected Value(Default) ==> " + "EXCL")
			.isEqualTo("EXCL");
			
			//Batch ID Validation
			softAssertions.assertThat(batchId)
			.as("Batch ID for claim id - "+claimId 
			+"  || Actual Value(Keyword File) ==> " + batchId
			+"  || Expected Value(DB blxpQuery) ==> " + blxpResult.get("BLXP_BATCH_ID").trim())
			.isEqualTo(blxpResult.get("BLXP_BATCH_ID").trim());
			
			//Claim ID Validation
			softAssertions.assertThat(claimId)
			.as("Claim ID for claim id - "+claimId 
			+"  || Actual Value(Keyword File) ==> " + claimId
			+"  || Expected Value(DB blxpQuery) ==> " + blxpResult.get("BLXP_CLCL_ID").trim())
			.isEqualTo(blxpResult.get("BLXP_CLCL_ID").trim());
			
			//Line Number Validation
			softAssertions.assertThat(Integer.valueOf(record.getLineNumber().trim()))
			.as("Line Number for claim id - "+claimId 
			+"  || Actual Value(Keyword File) ==> " + Integer.valueOf(record.getLineNumber().trim())
			+"  || Expected Value(DB blxpQuery) ==> " + Integer.valueOf(blxpResult.get("BLXP_CL_LINE_NO").trim()))
			.isEqualTo(Integer.valueOf(blxpResult.get("BLXP_CL_LINE_NO").trim()));
			
			//Plan Category Validation
			softAssertions.assertThat(record.getPlanCategory().trim())
			.as("Plan Category for claim id - "+claimId 
			+"  || Actual Value(Keyword File) ==> " + record.getPlanCategory().trim()
			+"  || Expected Value(DB blxpQuery) ==> " + blxpResult.get("CSPD_CAT").trim())
			.isEqualTo(blxpResult.get("CSPD_CAT").trim());
			
			//Class ID Validation
			softAssertions.assertThat(record.getClassId().trim())
			.as("Class ID for claim id - "+claimId 
			+"  || Actual Value(Keyword File) ==> " + record.getClassId().trim()
			+"  || Expected Value(DB blxpQuery) ==> " + blxpResult.get("CSCS_ID_NVL").trim())
			.isEqualTo(blxpResult.get("CSCS_ID_NVL").trim());
				
			
			SimpleDateFormat format= new SimpleDateFormat("MMddyyyy");
			DateFormat inputFormat = new SimpleDateFormat("yyyy-MM-dd");
			
			String dbEarliestServiceDate = "";
			String dbLatestServiceDate = "";
			try {
				 dbEarliestServiceDate = format.format(inputFormat.parse(blxpResult.get("BLXP_FROM_DT").substring(0,10).trim()));
				 dbLatestServiceDate = format.format(inputFormat.parse(blxpResult.get("BLXP_TO_DT").substring(0,10).trim()));
			} catch (ParseException e) {
				System.out.println("Unable to parse date :"+blxpResult.get("BLXP_FROM_DT").trim() + " || "+blxpResult.get("BLXP_TO_DT").trim());
				e.printStackTrace();
			}
			//Earliest Service Date Validation
			softAssertions.assertThat(record.getEarliestServiceDate().trim())
			.as("Earliest Service Date for claim id - "+claimId 
			+"  || Actual Value(Keyword File) ==> " + record.getEarliestServiceDate().trim()
			+"  || Expected Value(DB blxpQuery) ==> " + dbEarliestServiceDate.trim())
			.isEqualTo(dbEarliestServiceDate.trim());
			
			//Latest Service Date Validation
			softAssertions.assertThat(record.getLatestServiceDate().trim())
			.as("Latest Service Date for claim id - "+claimId 
			+"  || Actual Value(Keyword File) ==> " + record.getLatestServiceDate().trim()
			+"  || Expected Value(DB blxpQuery) ==> " + dbLatestServiceDate.trim())
			.isEqualTo(dbLatestServiceDate.trim());
			
			//Paid Amount Validation
			Double filePaidAmount = getNormalAmount(record.getPaidAmount().trim());
			Double dbPaidAmount = Double.valueOf(blxpResult.get("BLXP_PAID_AMT").trim());
			softAssertions.assertThat(filePaidAmount)
			.as("Paid Amount for claim id - "+claimId 
			+"  || Actual Value(Keyword File) ==> " + filePaidAmount
			+"  || Expected Value(DB blxpQuery) ==> " + dbPaidAmount)
			.isEqualTo(dbPaidAmount);
			
			//Account Category Validation
			softAssertions.assertThat(record.getAccountingCategory().trim())
			.as("Account Category for claim id - "+claimId 
			+"  || Actual Value(Keyword File) ==> " + record.getAccountingCategory().trim()
			+"  || Expected Value(DB blxpQuery) ==> " + blxpResult.get("BLXP_ACCT_CAT").trim())
			.isEqualTo(blxpResult.get("BLXP_ACCT_CAT").trim());
			
			//Diagnosis Code Validation
			softAssertions.assertThat(record.getDiagnosisCode().trim())
			.as("Diagnosis Code for claim id - "+claimId 
			+"  || Actual Value(Keyword File) ==> " + record.getDiagnosisCode().trim()
			+"  || Expected Value(DB blxpQuery) ==> " + blxpResult.get("IDCD_ID").trim())
			.isEqualTo(blxpResult.get("IDCD_ID").trim());
			
			String sbsbId = record.getSubscriberId();
			String cspiId = record.getPlanId();
			String grgrId = record.getGroupId();
			String memberSuffix = record.getMemberSuffix();
			Object[] values2 = {sbsbId,cspiId,grgrId,claimId,memberSuffix};
			System.out.println("SBSB ID :"+sbsbId +" CSPI ID :"+cspiId +" GRGR ID :"+grgrId +" CLM ID :"+claimId+" mem sfx :"+memberSuffix);
			dataMap = ExcelUtils.getTestMethodData(xlsPath, "databaseKeywordQuery");
			Map<String, String> databaseKeywordResult = dbUtils.getDataFromPreparedQuery("facets", dataMap.get("PREPARED_STATEMENT_QUERY"),values2);
			
			//Relationship Code Validation
			softAssertions.assertThat(record.getRelationshipCode().trim())
			.as("Relationship Code for claim id - "+claimId 
			+"  || Actual Value(Keyword File) ==> " + record.getRelationshipCode().trim()
			+"  || Expected Value(DB databaseKeywordQuery) ==> " + databaseKeywordResult.get("MEME_REL").trim())
			.isEqualTo(databaseKeywordResult.get("MEME_REL").trim());
			
			//Member Suffix Validation
			Integer fileMemSfx = Integer.parseInt(record.getMemberSuffix().trim());
			Integer dbMemSfx = Integer.parseInt(databaseKeywordResult.get("MEME_SFX").trim());
			softAssertions.assertThat(fileMemSfx)
			.as("Member Suffix for claim id - "+claimId 
			+"  || Actual Value(Keyword File) ==> " + fileMemSfx
			+"  || Expected Value(DB databaseKeywordQuery) ==> " + dbMemSfx)
			.isEqualTo(dbMemSfx);
			
			//GRGR CK Validation
			softAssertions.assertThat(blxpResult.get("GRGR_CK").trim())
			.as("GRGR_CK for claim id - "+claimId 
			+"  || Actual Value(DB blxpQuery) ==> " + blxpResult.get("GRGR_CK").trim()
			+"  || Expected Value(DB databaseKeywordQuery) ==> " + databaseKeywordResult.get("GRGR_CK").trim())
			.isEqualTo(databaseKeywordResult.get("GRGR_CK").trim());

			//SBSB CK Validation
			softAssertions.assertThat(blxpResult.get("SBSB_CK").trim())
			.as("SBSB_CK for claim id - "+claimId 
			+"  || Actual Value(DB blxpQuery) ==> " + blxpResult.get("SBSB_CK").trim()
			+"  || Expected Value(DB databaseKeywordQuery) ==> " + databaseKeywordResult.get("SBSB_CK").trim())
			.isEqualTo(databaseKeywordResult.get("SBSB_CK").trim());

			//MEME CK Validation
			softAssertions.assertThat(blxpResult.get("MEME_CK").trim())
			.as("MEME_CK for claim id - "+claimId 
			+"  || Actual Value(DB blxpQuery) ==> " + blxpResult.get("MEME_CK").trim()
			+"  || Expected Value(DB databaseKeywordQuery) ==> " + databaseKeywordResult.get("MEME_CK").trim())
			.isEqualTo(databaseKeywordResult.get("MEME_CK").trim());
			
			//PDPD ID Validation
			softAssertions.assertThat(blxpResult.get("PDPD_ID").trim())
			.as("PDPD_ID for claim id - "+claimId 
			+"  || Actual Value(DB blxpQuery) ==> " + blxpResult.get("PDPD_ID").trim()
			+"  || Expected Value(DB databaseKeywordQuery) ==> " + databaseKeywordResult.get("PRDCT_ID").trim())
			.isEqualTo(databaseKeywordResult.get("PRDCT_ID").trim());
			
			//LOBD ID Validation
			softAssertions.assertThat(blxpResult.get("LOBD_ID").trim())
			.as("LOBD_ID for claim id - "+claimId 
			+"  || Actual Value(DB blxpQuery) ==> " + blxpResult.get("LOBD_ID").trim()
			+"  || Expected Value(DB databaseKeywordQuery) ==> " + databaseKeywordResult.get("LOBD_ID").trim())
			.isEqualTo(databaseKeywordResult.get("LOBD_ID").trim());

		}else {
			dataPresent = false;
			softAssertions.assertThat(false).as("Data not found in DB!").isEqualTo(dataPresent);
			logger.log(LogStatus.FAIL, "No Data found for claim id :"+claimId + " and batch id : "+batchId);
		}
		
		
	}
	
	/**
	 * Master DataProvider for Test cases
	 * 
	 * @param method
	 * @return
	 */
	@DataProvider(name = "masterDataProvider")
	private Object[] getData(Method method) {
		List<KeywordRecord> keywordRecords = new ArrayList<KeywordRecord>();
		
		KwdFileParser parser = new KwdFileParser();
		try {
			keywordRecords = parser.parseFile();
		} catch (Exception e) {
			System.out.println("Something went wrong while parsing the file!");
			e.printStackTrace();
		}
		
		Object[] object = new Object[keywordRecords.size()];
		
		for (int j = 0; j < keywordRecords.size(); j++) {
			object[j] = keywordRecords.get(j);
		}
		return object;
	}
	
	/**
	 * Hook method for Test class
	 * 
	 * @param callBack
	 * @param testResult
	 */
	@Override
	public void run(IHookCallBack callBack, ITestResult testResult) {
		softAssertions = new SoftAssertions();
		callBack.runTestMethod(testResult);
		softAssertions.assertAll();
	}
	
	/**
	 * Helper method to convert file number format to normal number format
	 * 
	 * @param str
	 * @return
	 */
	private Double getNormalAmount(String str){
		
		Long integer = Long.parseLong(str);
		long number = integer/100;
		String num = "";
		long decimal = integer%100;
		decimal = Math.abs(decimal);
		String dec = "";
		if(number==0){
			num = number +"0";
		}else{
			num = String.valueOf(number);
		}
		if(decimal==0){
			dec = decimal+"0"; 
		}else if(decimal<10) {
			dec = "0" + decimal;
		}else{
			dec = String.valueOf(decimal);
		}
		return Double.valueOf(num+"."+dec);
	}
	
}
