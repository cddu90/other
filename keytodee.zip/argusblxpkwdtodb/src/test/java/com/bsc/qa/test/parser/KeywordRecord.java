package com.bsc.qa.test.parser;

import com.github.ffpojo.metadata.positional.annotation.PositionalField;
import com.github.ffpojo.metadata.positional.annotation.PositionalRecord;


/**
 * FFpojo for parsing keyword flat file
 * 
 * @author skumar33
 *
 */
@PositionalRecord
public class KeywordRecord{
	private String recordType;
	private String runDate;
	private String batchName;
	private String sequenceNumber;
	private String claimNumber;
	private String lineNumber;
	private String groupId;
	private String subscriberId;
	private String relationshipCode;
	private String memberSuffix;
	private String planCategory;
	private String planId;
	private String classId;
	private String diagnosisCodeType;
	private String procedureCode;
	private String earliestServiceDate;
	private String latestServiceDate;
	private String paidAmount;
	private String recordNumber;
	private String accountingCategory;
	private String experienceCategory;
	private String hsaPaidAmount;
	private String diagnosisCode;

	@PositionalField(initialPosition = 1,finalPosition=4)
	public String getRecordType() {
		return recordType;
	}
	
	@PositionalField(initialPosition = 5, finalPosition = 10)
	public String getRunDate() {
		return runDate;
	}
	
	@PositionalField(initialPosition = 11, finalPosition = 17)
	public String getBatchName() {
		return batchName;
	}
	
	@PositionalField(initialPosition = 18, finalPosition = 19)
	public String getSequenceNumber() {
		return sequenceNumber;
	}
	
	@PositionalField(initialPosition = 20, finalPosition = 31)
	public String getClaimNumber() {
		return claimNumber;
	}
	
	@PositionalField(initialPosition = 32, finalPosition = 33)
	public String getLineNumber() {
		return lineNumber;
	}
	
	@PositionalField(initialPosition = 34, finalPosition = 41)
	public String getGroupId() {
		return groupId;
	}
	
	@PositionalField(initialPosition = 42, finalPosition = 50)
	public String getSubscriberId() {
		return subscriberId;
	}
	
	@PositionalField(initialPosition = 51, finalPosition = 51)
	public String getRelationshipCode() {
		return relationshipCode;
	}
	
	@PositionalField(initialPosition = 52, finalPosition = 53)
	public String getMemberSuffix() {
		return memberSuffix;
	}
	
	@PositionalField(initialPosition = 54, finalPosition = 54)
	public String getPlanCategory() {
		return planCategory;
	}
	
	@PositionalField(initialPosition = 55, finalPosition = 62)
	public String getPlanId() {
		return planId;
	}
	
	@PositionalField(initialPosition = 63, finalPosition = 66)
	public String getClassId() {
		return classId;
	}
	
	@PositionalField(initialPosition = 67, finalPosition = 67)
	public String getDiagnosisCodeType() {
		return diagnosisCodeType;
	}
	
	@PositionalField(initialPosition = 69, finalPosition = 75)
	public String getProcedureCode() {
		return procedureCode;
	}
	
	@PositionalField(initialPosition = 76, finalPosition = 83)
	public String getEarliestServiceDate() {
		return earliestServiceDate;
	}
	
	@PositionalField(initialPosition = 84, finalPosition =91)
	public String getLatestServiceDate() {
		return latestServiceDate;
	}
	
	@PositionalField(initialPosition = 92, finalPosition = 111)
	public String getPaidAmount() {
		return paidAmount;
	}
	
	@PositionalField(initialPosition = 112, finalPosition = 119)
	public String getRecordNumber() {
		return recordNumber;
	}
	
	@PositionalField(initialPosition = 120, finalPosition = 123)
	public String getAccountingCategory() {
		return accountingCategory;
	}
	
	@PositionalField(initialPosition = 124, finalPosition = 127)
	public String getExperienceCategory() {
		return experienceCategory;
	}
	
	@PositionalField(initialPosition = 130, finalPosition = 149)
	public String getHsaPaidAmount() {
		return hsaPaidAmount;
	}
	
	@PositionalField(initialPosition = 150, finalPosition = 159)
	public String getDiagnosisCode() {
		return diagnosisCode;
	}
	
	public void setRecordType(String recordType) {
		this.recordType = recordType;
	}
	public void setRunDate(String runDate) {
		this.runDate = runDate;
	}
	public void setBatchName(String batchName) {
		this.batchName = batchName;
	}
	public void setSequenceNumber(String sequenceNumber) {
		this.sequenceNumber = sequenceNumber;
	}
	public void setClaimNumber(String claimNumber) {
		this.claimNumber = claimNumber;
	}
	public void setLineNumber(String lineNumber) {
		this.lineNumber = lineNumber;
	}
	public void setGroupId(String groupId) {
		this.groupId = groupId;
	}
	public void setSubscriberId(String subscriberId) {
		this.subscriberId = subscriberId;
	}
	public void setRelationshipCode(String relationshipCode) {
		this.relationshipCode = relationshipCode;
	}
	public void setMemberSuffix(String memberSuffix) {
		this.memberSuffix = memberSuffix;
	}
	public void setPlanCategory(String planCategory) {
		this.planCategory = planCategory;
	}
	public void setPlanId(String planId) {
		this.planId = planId;
	}
	public void setClassId(String classId) {
		this.classId = classId;
	}
	public void setDiagnosisCodeType(String diagnosisCodeType) {
		this.diagnosisCodeType = diagnosisCodeType;
	}
	public void setProcedureCode(String procedureCode) {
		this.procedureCode = procedureCode;
	}
	public void setEarliestServiceDate(String earliestServiceDate) {
		this.earliestServiceDate = earliestServiceDate;
	}
	public void setLatestServiceDate(String latestServiceDate) {
		this.latestServiceDate = latestServiceDate;
	}
	public void setPaidAmount(String paidAmount) {
		this.paidAmount = paidAmount;
	}
	public void setRecordNumber(String recordNumber) {
		this.recordNumber = recordNumber;
	}
	public void setAccountingCategory(String accountingCategory) {
		this.accountingCategory = accountingCategory;
	}
	public void setExperienceCategory(String experienceCategory) {
		this.experienceCategory = experienceCategory;
	}
	public void setHsaPaidAmount(String hsaPaidAmount) {
		this.hsaPaidAmount = hsaPaidAmount;
	}
	public void setDiagnosisCode(String diagnosisCode) {
		this.diagnosisCode = diagnosisCode;
	}
	

	@Override
	public String toString() {
		return "KeywordRecord [recordType=" + recordType + ", runDate=" + runDate + ", batchName=" + batchName
				+ ", sequenceNumber=" + sequenceNumber + ", claimNumber=" + claimNumber + ", lineNumber=" + lineNumber
				+ ", groupId=" + groupId + ", subscriberId=" + subscriberId + ", relationshipCode=" + relationshipCode
				+ ", memberSuffix=" + memberSuffix + ", planCategory=" + planCategory + ", planId=" + planId
				+ ", classId=" + classId + ", diagnosisCodeType=" + diagnosisCodeType + ", procedureCode="
				+ procedureCode + ", earliestServiceDate=" + earliestServiceDate + ", latestServiceDate="
				+ latestServiceDate + ", paidAmount=" + paidAmount + ", recordNumber=" + recordNumber
				+ ", accountingCategory=" + accountingCategory + ", experienceCategory=" + experienceCategory
				+ ", hsaPaidAmount=" + hsaPaidAmount + ", diagnosisCode=" + diagnosisCode + "]";
	}
	

	
}
