package com.bsc.qa.test.parser;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

import org.apache.commons.io.FileUtils;
import org.apache.commons.io.filefilter.WildcardFileFilter;

import com.github.ffpojo.file.reader.FileSystemFlatFileReader;
import com.github.ffpojo.file.reader.FlatFileReader;
import com.github.ffpojo.file.reader.FlatFileReaderDefinition;

/**
 * 
 * @author skumar33
 *
 */
public class KwdFileParser {

	/**
	 * Parse the keyword file
	 * 
	 * @return
	 */
	public List<KeywordRecord> parseFile() {

		List<KeywordRecord> keywordlist = new ArrayList<KeywordRecord>();
		FlatFileReaderDefinition ffDefinition = new FlatFileReaderDefinition(KeywordRecord.class);
		FlatFileReader ffReader = null;
		File inputFile = getMatchingAndLatestFile(System.getenv("ARGUS_KWD_INTRM_PATH")+"/", "*.txt");	
		System.out.println(inputFile.getName());
		try {
			ffReader = new FileSystemFlatFileReader(inputFile, ffDefinition);
		} catch (IOException e) {
			e.printStackTrace();
		}

		for (Object record : ffReader) {
			KeywordRecord body = (KeywordRecord) record;
			System.out.println(body);
			keywordlist.add(body);

		}
		if (keywordlist.size() == 0) {
			System.out.println("No Records in File!");
		}
		return keywordlist;
	}

	/**
	 * Method to get the File matching the pattern of wildcard present in directory name folder
	 * 
	 * @param directoryName
	 * @param wildcard
	 * @return
	 */
	public File getMatchingAndLatestFile(String directoryName, String wildcard) {
		{
			File directory = new File(directoryName);
			Collection<File> files = FileUtils.listFiles(directory, new WildcardFileFilter(wildcard), null);
			File latestFile = null;
			Long lastModified = new Long(0);
			for (File file : files) {
				if (lastModified < file.lastModified()) {
					lastModified = file.lastModified();
					latestFile = file;
				}
			}
			return latestFile;
		}
	}

}
